'use strict';
/* =============================================================
   TIDEBOUND ～蒼海の漂流島～
   made by hiro/ヒロ   https://github.com/h1ro223
   ドット絵・効果音・BGMはすべてコードで生成しています
   ============================================================= */

const TILE = 16, MAP = 320, MM = MAP * MAP;
const SAVE_VER = 1;
const SAVE_KEY = 'tidebound_save_v1', SAVE_BAK = 'tidebound_save_v1_bak', SET_KEY = 'tidebound_settings_v1';

/* ---------- 汎用 ---------- */
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const d2 = (ax, ay, bx, by) => { const dx = ax - bx, dy = ay - by; return dx * dx + dy * dy; };
const rnd = (a, b) => a + Math.random() * (b - a);
const irnd = (a, b) => Math.floor(a + Math.random() * (b - a + 1));
const pick = a => a[Math.floor(Math.random() * a.length)];
const chance = p => Math.random() < p;
const $ = s => document.querySelector(s);
const now = () => performance.now();

function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function hash2(x, y, s) {
  let h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(s | 0, 982451653)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}
function vnoise(x, y, s) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi, s), b = hash2(xi + 1, yi, s), c = hash2(xi, yi + 1, s), d = hash2(xi + 1, yi + 1, s);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
function fbm(x, y, s, oct) {
  let t = 0, amp = 1, f = 1, n = 0;
  for (let i = 0; i < oct; i++) { t += vnoise(x * f, y * f, s + i * 101) * amp; n += amp; amp *= 0.5; f *= 2; }
  return t / n;
}
function hexRGB(h) {
  h = h.replace('#', '');
  if (h.length === 3) h = h.split('').map(c => c + c).join('');
  const n = parseInt(h, 16);
  return [n >> 16 & 255, n >> 8 & 255, n & 255];
}
const shade = (c, f) => [clamp(Math.round(c[0] * f), 0, 255), clamp(Math.round(c[1] * f), 0, 255), clamp(Math.round(c[2] * f), 0, 255)];
const mixc = (a, b, t) => [Math.round(lerp(a[0], b[0], t)), Math.round(lerp(a[1], b[1], t)), Math.round(lerp(a[2], b[2], t))];
const rgbStr = (c, a) => a === undefined ? `rgb(${c[0]},${c[1]},${c[2]})` : `rgba(${c[0]},${c[1]},${c[2]},${a})`;
function toHex(c) { return '#' + c.map(v => v.toString(16).padStart(2, '0')).join(''); }

/* ---------- キャンバス ---------- */
function mkCanvas(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const x = c.getContext('2d');
  x.imageSmoothingEnabled = false;
  return [c, x];
}
function flipCanvas(src) {
  const [c, x] = mkCanvas(src.width, src.height);
  x.translate(src.width, 0); x.scale(-1, 1); x.drawImage(src, 0, 0);
  return c;
}
function rotCanvas(src, times) { // 90度単位の回転（ドット崩れなし）
  times = ((times % 4) + 4) % 4;
  if (!times) return src;
  const w = src.width, h = src.height;
  const sw = times % 2 ? h : w, sh = times % 2 ? w : h;
  const [c, x] = mkCanvas(sw, sh);
  x.translate(sw / 2, sh / 2); x.rotate(times * Math.PI / 2); x.drawImage(src, -w / 2, -h / 2);
  return c;
}
function silhouette(src, col, alpha) {
  const [c, x] = mkCanvas(src.width, src.height);
  x.drawImage(src, 0, 0);
  x.globalCompositeOperation = 'source-in';
  x.fillStyle = rgbStr(col, alpha);
  x.fillRect(0, 0, c.width, c.height);
  return c;
}

/* ---------- ピクセルバッファ（ドット絵描画用） ---------- */
class PB {
  constructor(w, h) { this.w = w; this.h = h; this.d = new Uint8ClampedArray(w * h * 4); }
  set(x, y, c, a = 255) {
    x = Math.floor(x); y = Math.floor(y);
    if (x < 0 || y < 0 || x >= this.w || y >= this.h || !c) return;
    const p = (y * this.w + x) * 4;
    this.d[p] = c[0]; this.d[p + 1] = c[1]; this.d[p + 2] = c[2]; this.d[p + 3] = a;
  }
  a(x, y) { if (x < 0 || y < 0 || x >= this.w || y >= this.h) return 0; return this.d[(y * this.w + x) * 4 + 3]; }
  get(x, y) { const p = (y * this.w + x) * 4; return [this.d[p], this.d[p + 1], this.d[p + 2]]; }
  rect(x, y, w, h, c) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.set(x + i, y + j, c); return this; }
  ell(cx, cy, rx, ry, c) {
    for (let y = Math.floor(cy - ry - 1); y <= cy + ry + 1; y++)
      for (let x = Math.floor(cx - rx - 1); x <= cx + rx + 1; x++) {
        const dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry;
        if (dx * dx + dy * dy <= 1) this.set(x, y, c);
      }
    return this;
  }
  circ(cx, cy, r, c) { return this.ell(cx, cy, r, r, c); }
  line(x0, y0, x1, y1, c, th = 1) {
    const dx = x1 - x0, dy = y1 - y0, n = Math.max(Math.abs(dx), Math.abs(dy), 1);
    for (let i = 0; i <= n; i++) {
      const x = x0 + dx * i / n, y = y0 + dy * i / n;
      if (th <= 1) this.set(Math.round(x), Math.round(y), c);
      else this.rect(Math.round(x - th / 2), Math.round(y - th / 2), th, th, c);
    }
    return this;
  }
  poly(pts, c) {
    let minY = 1e9, maxY = -1e9;
    for (const p of pts) { minY = Math.min(minY, p[1]); maxY = Math.max(maxY, p[1]); }
    for (let y = Math.floor(minY); y <= Math.ceil(maxY); y++) {
      const xs = [];
      for (let i = 0; i < pts.length; i++) {
        const a = pts[i], b = pts[(i + 1) % pts.length];
        if ((a[1] <= y + 0.5 && b[1] > y + 0.5) || (b[1] <= y + 0.5 && a[1] > y + 0.5)) {
          xs.push(a[0] + (y + 0.5 - a[1]) / (b[1] - a[1]) * (b[0] - a[0]));
        }
      }
      xs.sort((p, q) => p - q);
      for (let i = 0; i + 1 < xs.length; i += 2)
        for (let x = Math.round(xs[i]); x < Math.round(xs[i + 1]); x++) this.set(x, y, c);
    }
    return this;
  }
  // 明るい左上・暗い右下の自動陰影
  bevel(lf = 1.25, df = 0.72) {
    const cp = new Uint8ClampedArray(this.d);
    const A = (x, y) => (x < 0 || y < 0 || x >= this.w || y >= this.h) ? 0 : cp[(y * this.w + x) * 4 + 3];
    for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) {
      const p = (y * this.w + x) * 4;
      if (!cp[p + 3]) continue;
      let f = 1;
      if (!A(x, y - 1) || !A(x - 1, y)) f = lf;
      else if (!A(x, y + 1) || !A(x + 1, y)) f = df;
      if (f !== 1) { this.d[p] = clamp(cp[p] * f, 0, 255); this.d[p + 1] = clamp(cp[p + 1] * f, 0, 255); this.d[p + 2] = clamp(cp[p + 2] * f, 0, 255); }
    }
    return this;
  }
  outline(c, diag = false) {
    const cp = new Uint8ClampedArray(this.d);
    const A = (x, y) => (x < 0 || y < 0 || x >= this.w || y >= this.h) ? 0 : cp[(y * this.w + x) * 4 + 3];
    for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) {
      if (A(x, y)) continue;
      if (A(x - 1, y) || A(x + 1, y) || A(x, y - 1) || A(x, y + 1) || (diag && (A(x - 1, y - 1) || A(x + 1, y - 1) || A(x - 1, y + 1) || A(x + 1, y + 1)))) this.set(x, y, c);
    }
    return this;
  }
  speck(c, p, seed, onlyOpaque = true) {
    const r = mulberry32(seed);
    for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) {
      if (onlyOpaque && !this.a(x, y)) continue;
      if (r() < p) this.set(x, y, c);
    }
    return this;
  }
  recolor(map) { // map: [[from,to],...]
    for (let i = 0; i < this.d.length; i += 4) {
      if (!this.d[i + 3]) continue;
      for (const [f, t] of map) if (this.d[i] === f[0] && this.d[i + 1] === f[1] && this.d[i + 2] === f[2]) { this.d[i] = t[0]; this.d[i + 1] = t[1]; this.d[i + 2] = t[2]; break; }
    }
    return this;
  }
  clone() { const p = new PB(this.w, this.h); p.d.set(this.d); return p; }
  blit(src, ox, oy) {
    for (let y = 0; y < src.h; y++) for (let x = 0; x < src.w; x++) {
      const p = (y * src.w + x) * 4;
      if (src.d[p + 3]) this.set(ox + x, oy + y, [src.d[p], src.d[p + 1], src.d[p + 2]], src.d[p + 3]);
    }
    return this;
  }
  cv() {
    const [c, x] = mkCanvas(this.w, this.h);
    const id = x.createImageData(this.w, this.h);
    id.data.set(this.d);
    x.putImageData(id, 0, 0);
    return c;
  }
}
// 文字列ドット絵 → PB
function strPB(str, pal) {
  const rows = str.trim().split('\n').map(r => r.trim());
  const h = rows.length, w = Math.max(...rows.map(r => r.length));
  const pb = new PB(w, h);
  for (let y = 0; y < h; y++) for (let x = 0; x < rows[y].length; x++) {
    const ch = rows[y][x];
    if (ch === '.') continue;
    if (pal[ch]) pb.set(x, y, pal[ch]);
  }
  return pb;
}
function pal(o) { const r = {}; for (const k in o) r[k] = hexRGB(o[k]); return r; }

/* ---------- 3x5 ビットマップ数字フォント ---------- */
const FONT3 = {
  '0': '111101101101111', '1': '010110010010111', '2': '111001111100111', '3': '111001111001111', '4': '101101111001001',
  '5': '111100111001111', '6': '111100111101111', '7': '111001010010010', '8': '111101111101111', '9': '111101111001111',
  ':': '000010000010000', '/': '001001010100100', '+': '000010111010000', '-': '000000111000000', 'D': '110101101101110',
  'A': '010101111101101', 'Y': '101101010010010', 'x': '000101010101000', '%': '101001010100101', '!': '010010010000010',
  ' ': '000000000000000', 'L': '100100100100111', 'V': '101101101101010', 'O': '111101101101111', 'K': '101101110101101',
  'M': '101111111101101', 'S': '111100111001111', 'E': '111100110100111', 'P': '110101110100100', 'N': '110101101101101',
  'C': '111100100100111', 'I': '111010010010111', 'R': '110101110101101', 'T': '111010010010010', 'G': '111100101101111',
  'H': '101101111101101', 'B': '110101110101110', 'F': '111100110100100', 'U': '101101101101111', 'W': '101101111111101', '.': '000000000000010'
};
const glyphCache = new Map();
function glyphs(col) {
  const key = col.join(',');
  if (glyphCache.has(key)) return glyphCache.get(key);
  const m = {};
  for (const ch in FONT3) {
    const pb = new PB(3, 5), s = FONT3[ch];
    for (let i = 0; i < 15; i++) if (s[i] === '1') pb.set(i % 3, Math.floor(i / 3), col);
    m[ch] = pb.cv();
  }
  glyphCache.set(key, m);
  return m;
}
function text3(ctx, str, x, y, col = [255, 255, 255], shadow = true, sc = 1) {
  str = String(str).toUpperCase();
  const g = glyphs(col), gs = shadow ? glyphs([12, 14, 24]) : null;
  let cx = Math.round(x);
  for (const ch of str) {
    const gl = g[ch] || g[' '];
    if (gs) ctx.drawImage(gs[ch] || gs[' '], cx + sc, Math.round(y) + sc, 3 * sc, 5 * sc);
    ctx.drawImage(gl, cx, Math.round(y), 3 * sc, 5 * sc);
    cx += 4 * sc;
  }
  return cx - x;
}
const text3W = (str, sc = 1) => String(str).length * 4 * sc - sc;
/* =============================================================
   データ定義：地形・アイテム・オブジェクト・レシピ・生き物
   ============================================================= */

/* ---------- 地形 ---------- */
const T = { DEEP: 0, OCEAN: 1, SHALLOW: 2, SAND: 3, GRASS: 4, FOREST: 5, JUNGLE: 6, DIRT: 7, ROCK: 8, CLIFF: 9, FRESH: 10, RUINS: 11, FARM: 12, VOLC: 13, LAVA: 14 };
const TN = 15;
const T_PRIO = [0, 1, 2, 4, 6, 7, 8, 5, 9, 12, 3, 10, 5, 9, 3];
const T_NAME = ['深い海', '海', '浅瀬', '砂浜', '草原', '森', 'ジャングル', '土', '岩場', '崖', '真水', '遺跡', '畑', '火山岩', '溶岩'];
const U = { WALL: 0, SAND: 1, GRASS: 2, REEF: 3, ROCK: 4, KELP: 5, TRENCH: 6, WRECK: 7, RUIN: 8 };
const UN = 9;
const U_PRIO = [99, 2, 3, 4, 1, 3, 0, 5, 5];
const isSea = t => t <= T.SHALLOW;
const isSwim = t => t === T.DEEP || t === T.OCEAN;
const isWaterAny = t => t <= T.SHALLOW || t === T.FRESH;

/* ---------- アイテム ----------
   cat: mat 素材 / food 食べ物 / tool 道具 / weapon 武器 / place 設置 / equip 装備 / key 大切なもの / misc */
const ITEMS = {
  // 素材
  wood: { n: '木材', d: '木から取れる。建築やクラフトの基本素材。', cat: 'mat', st: 99 },
  stone: { n: '石', d: '岩から取れる。道具や設備の材料。', cat: 'mat', st: 99 },
  fiber: { n: '繊維', d: '草から取れる丈夫な繊維。ロープや布になる。', cat: 'mat', st: 99 },
  palm_leaf: { n: 'ヤシの葉', d: '大きくて丈夫な葉。屋根やベッドの材料。', cat: 'mat', st: 99 },
  flint: { n: '火打石', d: '鋭く割れる石。矢じりに使える。', cat: 'mat', st: 99 },
  clay: { n: '粘土', d: '水辺で取れる。かまど作りに必要。', cat: 'mat', st: 99 },
  sand: { n: '砂', d: 'シャベルで砂浜を掘ると取れる。ガラスの材料。', cat: 'mat', st: 99 },
  iron_ore: { n: '鉄鉱石', d: '山の鉄鉱脈から取れる。かまどで鉄にする。', cat: 'mat', st: 99 },
  coal: { n: '炭', d: '燃料。かまどで精錬に使う。', cat: 'mat', st: 99 },
  iron: { n: '鉄インゴット', d: '丈夫な金属。上等な道具や装備の材料。', cat: 'mat', st: 99 },
  glass: { n: 'ガラス', d: '砂を溶かして作る。マスクやランタンの材料。', cat: 'mat', st: 99 },
  obsidian: { n: '黒曜石', d: '火山島で取れる黒く鋭い石。最強の刃になる。', cat: 'mat', st: 99 },
  shell: { n: '貝殻', d: '浜辺や海底で拾える。', cat: 'mat', st: 99 },
  pearl: { n: '真珠', d: 'シャコ貝からまれに取れる宝石。', cat: 'mat', st: 99 },
  coral: { n: 'サンゴ片', d: '色鮮やかなサンゴのかけら。', cat: 'mat', st: 99 },
  rope: { n: 'ロープ', d: '繊維をより合わせたもの。いろいろな道具に。', cat: 'mat', st: 99 },
  cloth: { n: '布', d: '繊維を織ったもの。帆の材料になる。', cat: 'mat', st: 99 },
  plank: { n: '板', d: '木材を削った板。船体の材料。', cat: 'mat', st: 99 },
  hide: { n: '皮', d: 'イノシシなどから取れる。服や装備の材料。', cat: 'mat', st: 99 },
  resin: { n: '樹脂', d: 'ジャングルの木から取れる。船の防水に必要。', cat: 'mat', st: 99 },
  bamboo: { n: '竹', d: 'ジャングルに生える。水筒やいかだの材料。', cat: 'mat', st: 99 },
  herb: { n: '薬草', d: '傷や毒に効く草。', cat: 'mat', st: 99 },
  shark_tooth: { n: 'サメの歯', d: 'サメから取れる鋭い歯。', cat: 'mat', st: 99 },
  shark_skin: { n: 'サメ皮', d: '水をはじく丈夫な皮。ウェットスーツの材料。', cat: 'mat', st: 99 },
  glow_jelly: { n: '発光ゼリー', d: 'クラゲや発光植物から取れる。ほのかに光る。', cat: 'mat', st: 99 },
  crab_shell: { n: '大甲羅', d: '巨大ヤシガニの甲羅。とても硬い。', cat: 'mat', st: 99 },
  deep_orb: { n: '深海の宝珠', d: '深海の主が守っていた不思議な宝珠。', cat: 'mat', st: 99 },
  arrow: { n: '矢', d: '弓で撃つ矢。', cat: 'mat', st: 99 },
  // 大切なもの
  compass: { n: '羅針盤', d: '沈没船に残されていた羅針盤。これがあれば航海できる！', cat: 'key', st: 1 },
  chart_a: { n: '海図の切れ端・壱', d: '古い海図の一部。ジャングルの遺跡に眠っていた。', cat: 'key', st: 1 },
  chart_b: { n: '海図の切れ端・弐', d: '古い海図の一部。巨大ヤシガニが持っていた。', cat: 'key', st: 1 },
  chart_c: { n: '海図の切れ端・参', d: '古い海図の一部。深海の主が守っていた。', cat: 'key', st: 1 },
  chart: { n: '完全な海図', d: '島の外の航路が記された海図。', cat: 'key', st: 1 },
  ancient_key: { n: '古代の鍵', d: '海底遺跡で見つけた石の鍵。どこかの扉に合いそうだ。', cat: 'key', st: 1 },
  diver_memo: { n: '潜水士のメモ', d: 'エアタンクの作り方が書いてある。', cat: 'key', st: 1 },
  hull: { n: '船体', d: '脱出船の船体。造船台に納めよう。', cat: 'key', st: 1 },
  sail: { n: '帆', d: '脱出船の帆。造船台に納めよう。', cat: 'key', st: 1 },
  // 食べ物  f:{h:空腹, w:のど, hp:体力}
  berry: { n: 'ベリー', d: '甘酸っぱい木の実。', cat: 'food', st: 30, f: { h: 8, w: 3, hp: 0 } },
  coconut: { n: 'ココナッツ', d: '果汁がのどを潤す。', cat: 'food', st: 20, f: { h: 8, w: 24, hp: 0 } },
  banana: { n: 'バナナ', d: '栄養たっぷり。', cat: 'food', st: 20, f: { h: 18, w: 4, hp: 2 } },
  mushroom: { n: 'キノコ', d: '生だとお腹をこわすかも…', cat: 'food', st: 20, f: { h: 4, w: 0, hp: -6 } },
  mushroom_c: { n: '焼きキノコ', d: '香ばしい。', cat: 'food', st: 20, f: { h: 12, w: 0, hp: 4 } },
  fish_raw: { n: '生魚', d: '焼いて食べよう。', cat: 'food', st: 20, f: { h: 6, w: 0, hp: -4 } },
  fish_c: { n: '焼き魚', d: 'ほくほくの焼き魚。', cat: 'food', st: 20, f: { h: 30, w: 2, hp: 6 } },
  meat_raw: { n: '生肉', d: '焼かないと危険。', cat: 'food', st: 20, f: { h: 8, w: 0, hp: -8 } },
  meat_c: { n: '焼き肉', d: 'ジューシーな肉。力がわく。', cat: 'food', st: 20, f: { h: 42, w: 0, hp: 10 } },
  crab_raw: { n: 'カニ肉', d: '焼いて食べよう。', cat: 'food', st: 20, f: { h: 6, w: 0, hp: -4 } },
  crab_c: { n: '焼きガニ', d: '身がぎっしり。', cat: 'food', st: 20, f: { h: 26, w: 2, hp: 6 } },
  clam: { n: '貝', d: '焼くとおいしい。', cat: 'food', st: 20, f: { h: 4, w: 2, hp: -2 } },
  clam_c: { n: '焼き貝', d: '潮の香り。', cat: 'food', st: 20, f: { h: 16, w: 4, hp: 4 } },
  potato: { n: 'イモ', d: '畑に植えると増やせる。焼くとおいしい。', cat: 'food', st: 30, f: { h: 8, w: 0, hp: 0 }, plant: true },
  potato_c: { n: '焼きイモ', d: 'ほっくほく。', cat: 'food', st: 20, f: { h: 28, w: 0, hp: 4 } },
  seaweed: { n: '海藻', d: '海で取れる。食べられなくはない。', cat: 'food', st: 30, f: { h: 3, w: 1, hp: 0 } },
  seaweed_c: { n: '焼き海藻', d: 'パリパリのおやつ。', cat: 'food', st: 30, f: { h: 9, w: 0, hp: 2 } },
  urchin: { n: 'ウニ', d: '海の宝石。生でもおいしい。', cat: 'food', st: 20, f: { h: 12, w: 4, hp: 6 } },
  feast: { n: '島のごちそう', d: '島の恵みを詰め込んだ一皿。体力も大回復。', cat: 'food', st: 10, f: { h: 80, w: 14, hp: 45 } },
  water: { n: '水筒(水)', d: '真水が入っている。のどを潤す。', cat: 'food', st: 5, f: { h: 0, w: 42, hp: 0 }, ret: 'canteen' },
  canteen: { n: '水筒(空)', d: '真水(川・湖)や雨水タンクで水をくめる。', cat: 'misc', st: 5 },
  bandage: { n: '包帯', d: '使うと体力が回復する。', cat: 'food', st: 20, f: { h: 0, w: 0, hp: 35 }, med: true },
  antidote: { n: '解毒薬', d: '毒を治す。', cat: 'food', st: 20, f: { h: 0, w: 0, hp: 10 }, med: true, cure: true },
  // 道具・武器  tool:{t:種類, pow:採集力, dmg:攻撃力, reach:間合い, dur:耐久, cd:間隔, tier}
  axe_s: { n: '石のオノ', d: '木を切る。', cat: 'tool', st: 1, tool: { t: 'axe', pow: 3, dmg: 7, reach: 14, dur: 100, cd: 0.42 } },
  pick_s: { n: '石のツルハシ', d: '岩や鉱石を掘る。', cat: 'tool', st: 1, tool: { t: 'pick', pow: 3, dmg: 6, reach: 14, dur: 100, cd: 0.45, tier: 1 } },
  shovel: { n: 'シャベル', d: '砂や粘土を掘る。草原を耕して畑にできる。', cat: 'tool', st: 1, tool: { t: 'shovel', pow: 2, dmg: 4, reach: 14, dur: 140, cd: 0.4 } },
  spear_s: { n: '石のヤリ', d: '間合いの長い武器。水中でも使える。', cat: 'weapon', st: 1, tool: { t: 'spear', pow: 1, dmg: 13, reach: 22, dur: 110, cd: 0.45 } },
  rod: { n: '釣り竿', d: '水に向かって使うと釣りができる。', cat: 'tool', st: 1, tool: { t: 'rod', pow: 0, dmg: 2, reach: 12, dur: 90, cd: 0.4 } },
  bow: { n: '弓', d: '矢を飛ばす。水中では使えない。', cat: 'weapon', st: 1, tool: { t: 'bow', pow: 0, dmg: 15, reach: 12, dur: 160, cd: 0.55 } },
  harpoon: { n: '銛', d: '水中で素早く突ける武器。', cat: 'weapon', st: 1, tool: { t: 'harpoon', pow: 1, dmg: 19, reach: 26, dur: 220, cd: 0.32 } },
  axe_i: { n: '鉄のオノ', d: 'よく切れるオノ。', cat: 'tool', st: 1, tool: { t: 'axe', pow: 6, dmg: 11, reach: 15, dur: 280, cd: 0.38 } },
  pick_i: { n: '鉄のツルハシ', d: '黒曜石も掘れる。', cat: 'tool', st: 1, tool: { t: 'pick', pow: 6, dmg: 9, reach: 15, dur: 280, cd: 0.4, tier: 2 } },
  spear_i: { n: '鉄のヤリ', d: '鋭い鉄のヤリ。', cat: 'weapon', st: 1, tool: { t: 'spear', pow: 1, dmg: 23, reach: 24, dur: 280, cd: 0.42 } },
  sword_o: { n: '黒曜石の剣', d: '島で最強の刃。広い範囲を斬る。', cat: 'weapon', st: 1, tool: { t: 'sword', pow: 2, dmg: 36, reach: 20, dur: 420, cd: 0.36 } },
  torch: { n: '松明', d: '持つと周りを照らす。Aで地面に置ける。水中では消える。', cat: 'place', st: 30, place: 'TORCH', light: 66 },
  // 設置物
  bench: { n: '作業台', d: '置くと道具や設備が作れる。', cat: 'place', st: 10, place: 'BENCH' },
  campfire: { n: 'たき火', d: '料理ができる。夜の明かりにも。', cat: 'place', st: 10, place: 'CAMPFIRE' },
  furnace: { n: 'かまど', d: '鉱石を精錬できる。料理もできる。', cat: 'place', st: 10, place: 'FURNACE' },
  chest: { n: '収納箱', d: 'アイテムをしまっておける。', cat: 'place', st: 10, place: 'STORAGE' },
  bed: { n: 'ベッド', d: '夜に眠ると朝になる。復活地点になる。', cat: 'place', st: 5, place: 'BED' },
  rain: { n: '雨水タンク', d: '雨が降ると真水がたまる。', cat: 'place', st: 10, place: 'RAIN' },
  wall: { n: '木の壁', d: '敵の侵入を防ぐ。', cat: 'place', st: 99, place: 'WALL' },
  door: { n: '木の扉', d: '自分だけ通れる扉。', cat: 'place', st: 20, place: 'DOOR' },
  floor: { n: '木の床', d: '水の上に置くと橋になる。', cat: 'place', st: 99, place: 'FLOOR' },
  trap: { n: '魚の罠', d: '水に置くと時間で魚がかかる。', cat: 'place', st: 10, place: 'TRAP' },
  shipyard: { n: '造船台', d: '浜辺に置いて脱出船を組み立てる。', cat: 'place', st: 1, place: 'SHIPYARD' },
  raft: { n: 'いかだ', d: '水の上で使うと乗れる。速く進めて疲れない。もう一度Xで降りる。', cat: 'misc', st: 1 },
  // 装備  eq:{s:部位, def, o2, swim, spd, light, hp, atk, drain, uvis}
  mask: { n: 'ダイビングマスク', d: '水中で息が長く続き、よく見える。', cat: 'equip', st: 1, eq: { s: 'head', o2: 15, uvis: 1 } },
  headlamp: { n: 'ヘッドライトマスク', d: 'マスクにランタンを付けた。光る！', cat: 'equip', st: 1, eq: { s: 'head', o2: 18, uvis: 1, light: 92 } },
  helmet: { n: '鉄のかぶと', d: '頭を守る。', cat: 'equip', st: 1, eq: { s: 'head', def: 3 } },
  grass_cloth: { n: '草の服', d: '草で編んだ服。', cat: 'equip', st: 1, eq: { s: 'body', def: 1 } },
  leather: { n: '革の服', d: '丈夫な革の服。', cat: 'equip', st: 1, eq: { s: 'body', def: 3 } },
  iron_armor: { n: '鉄のよろい', d: '重いが頑丈。', cat: 'equip', st: 1, eq: { s: 'body', def: 6, spd: -0.06 } },
  crab_armor: { n: '甲殻の鎧', d: '大甲羅の鎧。軽くて最強の守り。', cat: 'equip', st: 1, eq: { s: 'body', def: 8 } },
  wetsuit: { n: 'ウェットスーツ', d: '水中で速く動け、息も長持ち。', cat: 'equip', st: 1, eq: { s: 'body', def: 2, swim: 0.3, drain: 0.75 } },
  fins: { n: 'フィン', d: '泳ぐ速さが大きく上がる。陸では少し遅い。', cat: 'equip', st: 1, eq: { s: 'feet', swim: 0.6, spd: -0.08 } },
  boots: { n: '革のくつ', d: '陸を速く歩ける。', cat: 'equip', st: 1, eq: { s: 'feet', spd: 0.14 } },
  tank: { n: 'エアタンク', d: '水中で長く潜れる。', cat: 'equip', st: 1, eq: { s: 'back', o2: 45 } },
  tank_l: { n: '大型エアタンク', d: 'さらに長く潜れる。', cat: 'equip', st: 1, eq: { s: 'back', o2: 100 } },
  lantern: { n: '発光ランタン', d: '水中でも消えない光。小物として装備する。', cat: 'equip', st: 1, eq: { s: 'acc', light: 96 } },
  charm_pearl: { n: '真珠のお守り', d: '最大体力が上がる。', cat: 'equip', st: 1, eq: { s: 'acc', hp: 30 } },
  charm_tooth: { n: 'サメの歯のお守り', d: '攻撃力が上がる。', cat: 'equip', st: 1, eq: { s: 'acc', atk: 0.3 } },
  charm_deep: { n: '深海のお守り', d: '水中で息が倍長持ち。ほのかに光る。', cat: 'equip', st: 1, eq: { s: 'acc', drain: 0.5, light: 60, def: 2 } },
};
for (const k in ITEMS) ITEMS[k].id = k;
const EQ_SLOTS = ['head', 'body', 'feet', 'back', 'acc'];
const EQ_NAME = { head: '頭', body: '体', feet: '足', back: '背中', acc: '小物' };

/* ---------- オブジェクト（地形の上に置かれるもの） ----------
   solid:ぶつかる / hp / tool: axe|pick|shovel|any|none / drops:[[id,min,max,確率]]
   harvest: Aで即収穫 / pickup: 拾う / regrow:[日数] / light:光 / ia: 調べた時の動作 / h: 表示高さ */
const OBJ_LIST = [
  ['NONE', {}],
  ['PALM', { n: 'ヤシの木', solid: 1, hp: 10, tool: 'axe', drops: [['wood', 2, 3], ['palm_leaf', 1, 2], ['coconut', 1, 1, 0.45]], regrow: 3, tall: 1 }],
  ['TREE', { n: '木', solid: 1, hp: 12, tool: 'axe', drops: [['wood', 3, 4]], regrow: 4, tall: 1 }],
  ['JTREE', { n: 'ジャングルの木', solid: 1, hp: 16, tool: 'axe', drops: [['wood', 4, 5], ['resin', 1, 1, 0.4]], regrow: 4, tall: 1 }],
  ['PINE', { n: '針葉樹', solid: 1, hp: 12, tool: 'axe', drops: [['wood', 3, 4], ['resin', 1, 1, 0.25]], regrow: 4, tall: 1 }],
  ['STUMP', { n: '切り株', solid: 0, hp: 4, tool: 'axe', drops: [['wood', 1, 1]] }],
  ['BANANA', { n: 'バナナの木', solid: 1, harvest: [['banana', 2, 3]], to: 'BANANA_E', regrow: 2, tall: 1 }],
  ['BANANA_E', { n: 'バナナの木', solid: 1, hp: 6, tool: 'axe', drops: [['palm_leaf', 1, 2]], tall: 1 }],
  ['BUSH', { n: 'ベリーの茂み', solid: 1, harvest: [['berry', 2, 4]], to: 'BUSH_E', regrow: 1 }],
  ['BUSH_E', { n: '茂み', solid: 1, hp: 3, tool: 'any', drops: [['fiber', 1, 2]] }],
  ['GRASS', { n: '草むら', solid: 0, hp: 1, tool: 'any', drops: [['fiber', 1, 2], ['potato', 1, 1, 0.04]], regrow: 1 }],
  ['FLOWER', { n: '花', solid: 0, deco: 1 }],
  ['HERB', { n: '薬草', solid: 0, pickup: [['herb', 1, 2]], regrow: 2 }],
  ['MUSH', { n: 'キノコ', solid: 0, pickup: [['mushroom', 1, 1]], regrow: 2 }],
  ['BAMBOO', { n: '竹', solid: 1, hp: 6, tool: 'any', drops: [['bamboo', 2, 3]], regrow: 3, tall: 1 }],
  ['ROCK', { n: '岩', solid: 1, hp: 14, tool: 'pick', drops: [['stone', 3, 4], ['flint', 1, 1, 0.3]] }],
  ['BIGROCK', { n: '大岩', solid: 1, hp: 28, tool: 'pick', drops: [['stone', 6, 8], ['flint', 1, 2, 0.5]] }],
  ['ORE_IRON', { n: '鉄鉱脈', solid: 1, hp: 22, tool: 'pick', tier: 1, drops: [['iron_ore', 2, 3], ['stone', 1, 1]] }],
  ['ORE_COAL', { n: '石炭の岩', solid: 1, hp: 16, tool: 'pick', drops: [['coal', 2, 3], ['stone', 1, 1]] }],
  ['OBSIDIAN', { n: '黒曜石', solid: 1, hp: 30, tool: 'pick', tier: 2, drops: [['obsidian', 2, 3]] }],
  ['CLAY', { n: '粘土', solid: 0, hp: 5, tool: 'dig', drops: [['clay', 2, 3]], regrow: 3 }],
  ['PEBBLE', { n: '小石', solid: 0, pickup: [['stone', 1, 1], ['flint', 1, 1, 0.25]] }],
  ['STICK', { n: '木の枝', solid: 0, pickup: [['wood', 1, 1]] }],
  ['SHELLP', { n: '貝殻', solid: 0, pickup: [['shell', 1, 1]] }],
  ['DRIFT', { n: '流木', solid: 0, pickup: [['wood', 2, 2]] }],
  ['BOTTLE', { n: '漂流瓶', solid: 0, ia: 'bottle', anim: 2 }],
  ['CRATE', { n: '木箱', solid: 1, hp: 3, tool: 'any', loot: 'crate' }],
  ['BARREL', { n: 'タル', solid: 1, hp: 3, tool: 'any', loot: 'barrel' }],
  ['CHEST', { n: '宝箱', solid: 1, ia: 'chest' }],
  ['BAG', { n: '遺品の袋', solid: 0, ia: 'bag' }],
  ['CAMPFIRE', { n: 'たき火', solid: 1, ia: 'fire', light: 74, anim: 3, built: 'campfire' }],
  ['BENCH', { n: '作業台', solid: 1, ia: 'bench', built: 'bench' }],
  ['FURNACE', { n: 'かまど', solid: 1, ia: 'furnace', light: 36, anim: 2, built: 'furnace', tall: 1 }],
  ['STORAGE', { n: '収納箱', solid: 1, ia: 'chest', built: 'chest' }],
  ['BED', { n: 'ベッド', solid: 1, ia: 'bed', built: 'bed' }],
  ['RAIN', { n: '雨水タンク', solid: 1, ia: 'rain', built: 'rain', tall: 1 }],
  ['TORCH', { n: '松明', solid: 0, light: 64, anim: 2, built: 'torch' }],
  ['WALL', { n: '木の壁', solid: 1, built: 'wall', tall: 1 }],
  ['DOOR', { n: '木の扉', solid: 1, door: 1, built: 'door', tall: 1 }],
  ['FLOOR', { n: '木の床', solid: 0, flat: 1, built: 'floor', bridge: 1 }],
  ['TRAP', { n: '魚の罠', solid: 0, ia: 'trap', built: 'trap' }],
  ['CROP1', { n: 'イモの芽', solid: 0, ia: 'crop', built: 'potato' }],
  ['CROP2', { n: 'イモ(育ち中)', solid: 0, ia: 'crop', built: 'potato' }],
  ['CROP3', { n: 'イモ(収穫どき)', solid: 0, ia: 'crop' }],
  ['SHIPYARD', { n: '造船台', solid: 1, ia: 'shipyard', built: 'shipyard', big: 1 }],
  ['PILLAR', { n: '石柱', solid: 1, tall: 1 }],
  ['STATUE', { n: '石像', solid: 1, tall: 1 }],
  ['RUINDOOR', { n: '封印の扉', solid: 1, ia: 'ruindoor', tall: 1 }],
  ['VENT_S', { n: '噴気孔', solid: 0, deco: 1 }],
  ['WRECKBIT', { n: '難破船の残骸', solid: 1, hp: 18, tool: 'any', drops: [['wood', 5, 6], ['rope', 1, 2], ['cloth', 1, 1], ['plank', 2, 3]], big: 1 }],
  // ---- 海中 ----
  ['CORAL_R', { n: 'サンゴ', solid: 0, hp: 2, tool: 'any', drops: [['coral', 1, 2]], regrow: 3 }],
  ['CORAL_B', { n: 'サンゴ', solid: 0, hp: 2, tool: 'any', drops: [['coral', 1, 2]], regrow: 3 }],
  ['CORAL_Y', { n: 'サンゴ', solid: 0, hp: 2, tool: 'any', drops: [['coral', 1, 2]], regrow: 3 }],
  ['CORAL_F', { n: 'ウミウチワ', solid: 0, hp: 2, tool: 'any', drops: [['coral', 1, 2]], regrow: 3 }],
  ['KELP', { n: 'コンブ', solid: 0, hp: 1, tool: 'any', drops: [['seaweed', 2, 3]], regrow: 2, anim: 2, tall: 1 }],
  ['SEAGRASS', { n: '海草', solid: 0, deco: 1 }],
  ['ROCK_U', { n: '海底の岩', solid: 1, hp: 14, tool: 'pick', drops: [['stone', 2, 3], ['iron_ore', 1, 1, 0.18]] }],
  ['CLAM_O', { n: 'シャコ貝', solid: 0, harvest: [['clam', 1, 1], ['shell', 1, 1, 0.6], ['pearl', 1, 1, 0.2]], to: 'NONE', regrow: 3 }],
  ['URCHIN', { n: 'ウニ', solid: 1, hp: 2, tool: 'tool', drops: [['urchin', 1, 1]], regrow: 2, spiky: 1 }],
  ['STAR', { n: 'ヒトデ', solid: 0, pickup: [['shell', 1, 1]] }],
  ['SHELLU', { n: '貝殻', solid: 0, pickup: [['shell', 1, 2]] }],
  ['CHEST_U', { n: '海底の宝箱', solid: 1, ia: 'chest' }],
  ['HULL', { n: '沈没船', solid: 1, tall: 1 }],
  ['MAST', { n: '折れたマスト', solid: 1 }],
  ['ANCHOR', { n: 'イカリ', solid: 1 }],
  ['PILLAR_U', { n: '海底の石柱', solid: 1, tall: 1 }],
  ['AMPHORA', { n: 'つぼ', solid: 1, hp: 2, tool: 'any', loot: 'amphora' }],
  ['SCRAP', { n: '鉄くず', solid: 1, hp: 10, tool: 'pick', drops: [['iron_ore', 1, 2], ['iron', 1, 1, 0.35]] }],
  ['VENT', { n: '気泡スポット', solid: 0, anim: 3, o2: 1 }],
  ['GLOW', { n: '発光植物', solid: 0, hp: 1, tool: 'any', drops: [['glow_jelly', 1, 1]], regrow: 3, light: 46, anim: 2 }],
  ['BONES', { n: '巨大な骨', solid: 1, big: 1 }],
];
const OBJ = [], O = {};
OBJ_LIST.forEach(([k, d], i) => { d.k = k; d.id = i; OBJ.push(d); O[k] = i; });
// 設置物を壊した時に返すアイテム
const BUILT_ITEM = {};
OBJ.forEach(d => { if (d.built) BUILT_ITEM[d.id] = d.built; });

const LOOT = {
  crate: [['wood', 2, 3, 0.7], ['rope', 1, 2, 0.65], ['berry', 2, 4, 0.5], ['cloth', 1, 1, 0.35], ['torch', 1, 2, 0.35], ['canteen', 1, 1, 0.2], ['fish_c', 1, 1, 0.2]],
  barrel: [['water', 1, 1, 0.45], ['fish_c', 1, 2, 0.35], ['coconut', 1, 2, 0.4], ['rope', 1, 1, 0.3], ['plank', 1, 2, 0.4]],
  amphora: [['pearl', 1, 1, 0.3], ['shell', 1, 2, 0.4], ['coral', 1, 2, 0.3], ['iron', 1, 1, 0.2], ['glass', 1, 1, 0.25], ['arrow', 3, 6, 0.2]],
  treasure: [['pearl', 1, 2, 0.6], ['iron', 1, 3, 0.6], ['glass', 1, 2, 0.4], ['arrow', 4, 10, 0.4], ['glow_jelly', 1, 2, 0.4], ['fish_c', 1, 2, 0.3], ['bandage', 1, 2, 0.4]],
};

/* ---------- レシピ ----------
   st: hand 手作り / bench 作業台 / furnace かまど / fire たき火(かまどでも可)
   cat: tool / build / food / equip / mat */
const RECIPES = [
  // 手作り
  { o: 'rope', st: 'hand', cat: 'mat', i: { fiber: 3 } },
  { o: 'torch', n: 2, st: 'hand', cat: 'build', i: { wood: 1, fiber: 2 } },
  { o: 'bench', st: 'hand', cat: 'build', i: { wood: 8, stone: 3 } },
  { o: 'campfire', st: 'hand', cat: 'build', i: { wood: 5, stone: 5 } },
  { o: 'bandage', st: 'hand', cat: 'food', i: { fiber: 3, herb: 1 } },
  { o: 'antidote', st: 'hand', cat: 'food', i: { herb: 2, shell: 1 } },
  { o: 'headlamp', st: 'hand', cat: 'equip', i: { mask: 1, lantern: 1 } },
  { o: 'chart', st: 'hand', cat: 'mat', i: { chart_a: 1, chart_b: 1, chart_c: 1 }, hideUnless: ['chart_a', 'chart_b', 'chart_c'] },
  // 作業台
  { o: 'axe_s', st: 'bench', cat: 'tool', i: { wood: 3, stone: 3, rope: 1 } },
  { o: 'pick_s', st: 'bench', cat: 'tool', i: { wood: 3, stone: 4, rope: 1 } },
  { o: 'shovel', st: 'bench', cat: 'tool', i: { wood: 3, stone: 2 } },
  { o: 'spear_s', st: 'bench', cat: 'tool', i: { wood: 4, stone: 2, rope: 1 } },
  { o: 'rod', st: 'bench', cat: 'tool', i: { wood: 3, fiber: 4, rope: 1 } },
  { o: 'bow', st: 'bench', cat: 'tool', i: { wood: 6, rope: 2 } },
  { o: 'arrow', n: 6, st: 'bench', cat: 'tool', i: { wood: 1, flint: 1 } },
  { o: 'chest', st: 'bench', cat: 'build', i: { wood: 12 } },
  { o: 'bed', st: 'bench', cat: 'build', i: { wood: 10, palm_leaf: 8, fiber: 6 } },
  { o: 'rain', st: 'bench', cat: 'build', i: { wood: 8, palm_leaf: 5 } },
  { o: 'furnace', st: 'bench', cat: 'build', i: { stone: 15, clay: 6 } },
  { o: 'wall', n: 2, st: 'bench', cat: 'build', i: { wood: 3 } },
  { o: 'door', st: 'bench', cat: 'build', i: { wood: 5 } },
  { o: 'floor', n: 4, st: 'bench', cat: 'build', i: { wood: 2 } },
  { o: 'trap', st: 'bench', cat: 'build', i: { wood: 6, rope: 3 } },
  { o: 'canteen', st: 'bench', cat: 'tool', i: { bamboo: 2, rope: 1 } },
  { o: 'raft', st: 'bench', cat: 'tool', i: { wood: 20, rope: 6, bamboo: 4 } },
  { o: 'plank', n: 2, st: 'bench', cat: 'mat', i: { wood: 2 } },
  { o: 'cloth', st: 'bench', cat: 'mat', i: { fiber: 6 } },
  { o: 'grass_cloth', st: 'bench', cat: 'equip', i: { fiber: 10, palm_leaf: 6 } },
  { o: 'leather', st: 'bench', cat: 'equip', i: { hide: 6, rope: 2 } },
  { o: 'boots', st: 'bench', cat: 'equip', i: { hide: 3, fiber: 2 } },
  { o: 'fins', st: 'bench', cat: 'equip', i: { hide: 3, palm_leaf: 4, rope: 1 } },
  { o: 'mask', st: 'bench', cat: 'equip', i: { glass: 2, hide: 1, rope: 1 } },
  { o: 'harpoon', st: 'bench', cat: 'tool', i: { iron: 2, wood: 3, rope: 2 } },
  { o: 'axe_i', st: 'bench', cat: 'tool', i: { iron: 3, wood: 2 } },
  { o: 'pick_i', st: 'bench', cat: 'tool', i: { iron: 3, wood: 2 } },
  { o: 'spear_i', st: 'bench', cat: 'tool', i: { iron: 3, wood: 3 } },
  { o: 'helmet', st: 'bench', cat: 'equip', i: { iron: 5 } },
  { o: 'iron_armor', st: 'bench', cat: 'equip', i: { iron: 9, hide: 2 } },
  { o: 'sword_o', st: 'bench', cat: 'tool', i: { obsidian: 5, iron: 2, rope: 1 } },
  { o: 'lantern', st: 'bench', cat: 'equip', i: { glass: 2, iron: 1, glow_jelly: 3 } },
  { o: 'tank', st: 'bench', cat: 'equip', i: { iron: 6, hide: 2, rope: 2 }, unlock: 'memo' },
  { o: 'tank_l', st: 'bench', cat: 'equip', i: { tank: 1, iron: 6, pearl: 2 }, unlock: 'memo' },
  { o: 'wetsuit', st: 'bench', cat: 'equip', i: { shark_skin: 4, fiber: 6 } },
  { o: 'crab_armor', st: 'bench', cat: 'equip', i: { crab_shell: 1, hide: 2, rope: 2 } },
  { o: 'charm_pearl', st: 'bench', cat: 'equip', i: { pearl: 3, rope: 1 } },
  { o: 'charm_tooth', st: 'bench', cat: 'equip', i: { shark_tooth: 3, rope: 1 } },
  { o: 'charm_deep', st: 'bench', cat: 'equip', i: { deep_orb: 1, pearl: 2, rope: 1 } },
  { o: 'shipyard', st: 'bench', cat: 'build', i: { wood: 30, rope: 8, iron: 4 }, unlock: 'compass' },
  { o: 'hull', st: 'bench', cat: 'mat', i: { plank: 24, rope: 8, resin: 5 }, unlock: 'compass' },
  { o: 'sail', st: 'bench', cat: 'mat', i: { cloth: 6, rope: 4, bamboo: 2 }, unlock: 'compass' },
  // かまど
  { o: 'iron', st: 'furnace', cat: 'mat', i: { iron_ore: 2, coal: 1 } },
  { o: 'glass', st: 'furnace', cat: 'mat', i: { sand: 3, coal: 1 } },
  { o: 'coal', st: 'furnace', cat: 'mat', i: { wood: 3 } },
  // 料理（たき火・かまど）
  { o: 'fish_c', st: 'fire', cat: 'food', i: { fish_raw: 1 } },
  { o: 'meat_c', st: 'fire', cat: 'food', i: { meat_raw: 1 } },
  { o: 'crab_c', st: 'fire', cat: 'food', i: { crab_raw: 1 } },
  { o: 'clam_c', st: 'fire', cat: 'food', i: { clam: 1 } },
  { o: 'potato_c', st: 'fire', cat: 'food', i: { potato: 1 } },
  { o: 'mushroom_c', st: 'fire', cat: 'food', i: { mushroom: 1 } },
  { o: 'seaweed_c', n: 1, st: 'fire', cat: 'food', i: { seaweed: 2 } },
  { o: 'feast', st: 'fire', cat: 'food', i: { fish_c: 1, meat_c: 1, banana: 1, coconut: 1 } },
];
const ST_NAME = { hand: '手作り', bench: '作業台', furnace: 'かまど', fire: 'たき火' };
const CAT_NAME = { all: 'すべて', tool: '道具', build: '建築', food: '料理', equip: '装備', mat: '素材' };

/* ---------- 生き物 ---------- */
const SPECIES = {
  crab: { n: 'カニ', hp: 14, spd: 26, dmg: 6, env: 'land', ai: 'crab', aggro: 46, drops: [['crab_raw', 1, 1], ['shell', 1, 1, 0.3]], r: 6 },
  boar: { n: 'イノシシ', hp: 36, spd: 30, dmg: 12, env: 'land', ai: 'boar', aggro: 70, drops: [['meat_raw', 1, 2], ['hide', 1, 2]], r: 7 },
  snake: { n: 'ヘビ', hp: 18, spd: 22, dmg: 7, env: 'land', ai: 'snake', aggro: 52, poison: 1, drops: [['meat_raw', 1, 1, 0.5], ['hide', 1, 1, 0.3]], r: 6 },
  monkey: { n: 'サル', hp: 20, spd: 46, dmg: 5, env: 'land', ai: 'monkey', aggro: 96, drops: [['banana', 1, 1, 0.6]], r: 6 },
  turtle: { n: 'ウミガメ', hp: 40, spd: 10, dmg: 0, env: 'land', ai: 'passive', drops: [], r: 7, nohit: 1 },
  gcrab: { n: '巨大ヤシガニ', hp: 320, spd: 30, dmg: 18, env: 'land', ai: 'gcrab', aggro: 150, boss: 1, drops: [['chart_b', 1, 1], ['crab_shell', 1, 1], ['crab_raw', 4, 6]], r: 14 },
  parrot: { n: 'オウム', hp: 1, spd: 70, dmg: 0, env: 'air', ai: 'parrot', drops: [], r: 5, nohit: 1 },
  fish: { n: '魚', hp: 6, spd: 30, dmg: 0, env: 'sea', ai: 'fish', drops: [['fish_raw', 1, 1]], r: 5 },
  tai: { n: 'タイ', hp: 10, spd: 32, dmg: 0, env: 'sea', ai: 'fish', drops: [['fish_raw', 1, 2]], r: 6 },
  ray: { n: 'エイ', hp: 22, spd: 18, dmg: 0, env: 'sea', ai: 'fish', drops: [['fish_raw', 2, 2]], r: 8 },
  jelly: { n: 'クラゲ', hp: 8, spd: 8, dmg: 6, env: 'sea', ai: 'jelly', poison: 1, drops: [['glow_jelly', 1, 2]], r: 5 },
  moray: { n: 'ウツボ', hp: 28, spd: 60, dmg: 12, env: 'sea', ai: 'moray', aggro: 34, drops: [['fish_raw', 1, 2]], r: 6 },
  shark: { n: 'サメ', hp: 75, spd: 50, dmg: 18, env: 'sea', ai: 'shark', aggro: 130, drops: [['shark_tooth', 1, 2], ['shark_skin', 1, 2], ['fish_raw', 1, 2]], r: 10 },
  angler: { n: 'チョウチンアンコウ', hp: 24, spd: 30, dmg: 10, env: 'sea', ai: 'angler', aggro: 90, drops: [['glow_jelly', 1, 2]], r: 6, light: 30 },
  boss: { n: '深海の主', hp: 700, spd: 40, dmg: 22, env: 'sea', ai: 'boss', aggro: 300, boss: 1, drops: [['chart_c', 1, 1], ['deep_orb', 1, 1], ['pearl', 4, 6]], r: 22, light: 60 },
};
/* =============================================================
   ドット絵生成（地形・オブジェクト・キャラ・アイコン・エフェクト）
   ============================================================= */
const SP = { tile: [], tileU: [], over: [], overU: [], foam: [], obj: [], icon: {}, iconURL: {}, pl: {}, cr: {}, fx: {} };
const C = hexRGB;
const OUT = C('#1a1420');
const SHADOW = [0, 0, 0];

/* ---------- 地形テクスチャ ---------- */
const TCOL = [
  ['#1f4f8f', '#183f78', '#2c64a8'], // DEEP
  ['#2f78bd', '#2766a7', '#4c95d6'], // OCEAN
  ['#4ab6cc', '#3aa2bb', '#86dbe3'], // SHALLOW
  ['#ecd59b', '#d9be80', '#f8e9bd'], // SAND
  ['#6fbd4a', '#58a23b', '#8fd466'], // GRASS
  ['#509c3e', '#3f8232', '#64b04d'], // FOREST
  ['#3e8c47', '#2f733a', '#56a65a'], // JUNGLE
  ['#a57a4f', '#8a6340', '#bb9064'], // DIRT
  ['#8f8b85', '#76726d', '#aba79f'], // ROCK
  ['#7a756f', '#5c5853', '#9a958d'], // CLIFF
  ['#58b4e4', '#489fd2', '#93d9f6'], // FRESH
  ['#a29f8c', '#86836f', '#bdbaa5'], // RUINS
  ['#7d5634', '#634227', '#96693f'], // FARM
  ['#4d4241', '#3a3130', '#635655'], // VOLC
  ['#ea5a1e', '#b8360f', '#ffb43c'], // LAVA
];
const T_EDGE = [null, null, null, '#d6bd85', '#4c8f34', '#3a7a2e', '#2d6b35', '#8a6340', '#6a6661', null, '#3f95c8', '#7e7b69', '#5a3a22', '#2f2726', '#ffd04a'];
const UCOL = [
  ['#2d4c58', '#1f3842', '#3f6474'], // WALL
  ['#dcc791', '#c4ad78', '#ecdcac'], // SAND
  ['#bdb47c', '#9c9662', '#d2ca98'], // GRASS(海草原)
  ['#e2b5a4', '#ca978b', '#f2cfbf'], // REEF
  ['#7d8486', '#64696b', '#979ea0'], // ROCK
  ['#9b9a62', '#7f7e4c', '#b4b37b'], // KELP
  ['#353b4e', '#272c3b', '#474e64'], // TRENCH
  ['#7a5636', '#5e4128', '#966b45'], // WRECK
  ['#9aa5a0', '#7e8a85', '#b5bfba'], // RUIN
];
const WATERISH = new Set([T.DEEP, T.OCEAN, T.SHALLOW, T.FRESH, T.LAVA]);

function genTex(cols, kind, seed, frame) {
  const b = C(cols[0]), dk = C(cols[1]), lt = C(cols[2]);
  const pb = new PB(16, 16).rect(0, 0, 16, 16, b);
  const r = mulberry32(seed);
  const sp = (c, p) => { for (let i = 0; i < 256; i++) if (r() < p) pb.set(i % 16, i >> 4, c); };
  switch (kind) {
    case 'water': {
      sp(dk, 0.05);
      for (let i = 0; i < 3; i++) {
        const y = (i * 5 + 1 + Math.floor(r() * 3)) % 16, x0 = Math.floor(r() * 16), len = 2 + Math.floor(r() * 3);
        const off = Math.round(Math.sin((frame / 4 + i / 3) * Math.PI * 2) * 2);
        for (let j = 0; j < len; j++) pb.set((x0 + j + off + 32) % 16, y, lt);
      }
      if (frame === 1 && seed % 7 === 3) pb.set(Math.floor(r() * 16), Math.floor(r() * 16), [235, 245, 255]);
      break;
    }
    case 'shallow': {
      sp(lt, 0.04); sp(dk, 0.05);
      for (let i = 0; i < 2; i++) {
        const y = (i * 8 + 3 + Math.floor(r() * 3)) % 16, x0 = Math.floor(r() * 16);
        const off = Math.round(Math.sin((frame / 4 + i / 2) * Math.PI * 2) * 2);
        for (let j = 0; j < 3; j++) pb.set((x0 + j + off + 32) % 16, y, [190, 240, 245]);
      }
      break;
    }
    case 'sand': sp(dk, 0.07); sp(lt, 0.06); if (r() < 0.3) pb.set(r() * 14 + 1, r() * 14 + 1, C('#f0a8a0')); break;
    case 'grass': {
      for (let i = 0; i < 14; i++) { const x = Math.floor(r() * 16), y = 2 + Math.floor(r() * 14); pb.set(x, y, dk); pb.set(x, y - 1, dk); if (r() < 0.5) pb.set(x, y - 2, lt); }
      sp(lt, 0.03);
      if (seed % 4 === 3) { const fc = pick([C('#ffffff'), C('#ffe060'), C('#ff8aa0')]); pb.set(4 + r() * 8, 4 + r() * 8, fc); pb.set(4 + r() * 8, 4 + r() * 8, fc); }
      break;
    }
    case 'forest': sp(dk, 0.12); sp(lt, 0.05); for (let i = 0; i < 3; i++) { const x = r() * 14, y = r() * 14; pb.rect(x, y, 2, 1, C('#6e7a30')); } break;
    case 'jungle': sp(dk, 0.14); for (let i = 0; i < 5; i++) { const x = r() * 14, y = r() * 14; pb.rect(x, y, 2, 2, lt); pb.set(x + 1, y + 1, b); } break;
    case 'dirt': sp(dk, 0.1); sp(lt, 0.06); break;
    case 'rock': {
      sp(lt, 0.05); sp(dk, 0.06);
      for (let i = 0; i < 2; i++) { let x = r() * 16, y = r() * 16; for (let j = 0; j < 4; j++) { pb.set(x, y, dk); x += r() < 0.5 ? 1 : 0; y += 1; } }
      break;
    }
    case 'cliff': sp(dk, 0.08); sp(lt, 0.05); pb.rect(0, 0, 16, 1, lt); break;
    case 'ruins': {
      for (let y = 0; y < 16; y += 8) {
        pb.rect(0, y, 16, 1, dk);
        const o = (y / 8) % 2 ? 4 : 0;
        for (let x = o; x < 16; x += 8) pb.rect(x, y, 1, 8, dk);
        pb.rect(0, y + 1, 16, 1, lt);
      }
      sp(C('#6f8a4a'), 0.04);
      break;
    }
    case 'farm': for (let y = 1; y < 16; y += 4) { pb.rect(0, y, 16, 1, dk); pb.rect(0, y + 1, 16, 1, lt); } sp(dk, 0.04); break;
    case 'volc': sp(dk, 0.12); sp(lt, 0.05); if (r() < 0.5) pb.set(r() * 16, r() * 16, C('#d04a20')); break;
    case 'lava': {
      sp(dk, 0.1);
      for (let i = 0; i < 4; i++) {
        const cx = (r() * 16 + frame * (i % 2 ? 1 : -1)) % 16, cy = r() * 16;
        pb.ell((cx + 16) % 16, cy, 2 + r() * 2, 1.5, lt);
      }
      sp(C('#fff0a0'), 0.02);
      break;
    }
    // 海底
    case 'usand': sp(dk, 0.05); sp(lt, 0.05); for (let i = 0; i < 2; i++) { const y = Math.floor(r() * 16); for (let x = 0; x < 16; x++) pb.set(x, y + Math.round(Math.sin(x / 2.5 + i) * 0.8), lt); } break;
    case 'ugrass': sp(dk, 0.06); for (let i = 0; i < 12; i++) { const x = r() * 16, y = r() * 16; pb.set(x, y, C('#5a9a5a')); pb.set(x, y - 1, C('#6aaa62')); } break;
    case 'ureef': sp(dk, 0.06); sp(lt, 0.06); for (let i = 0; i < 4; i++) pb.set(r() * 16, r() * 16, pick([C('#ff8a9a'), C('#ffd06a'), C('#9ab0ff')])); break;
    case 'urock': sp(dk, 0.1); sp(lt, 0.05); sp(C('#5a7a62'), 0.04); break;
    case 'ukelp': sp(dk, 0.12); sp(lt, 0.04); break;
    case 'utrench': sp(dk, 0.14); sp(lt, 0.03); if (r() < 0.35) pb.set(r() * 16, r() * 16, C('#4ae0e0')); break;
    case 'uwreck': for (let y = 0; y < 16; y += 4) { pb.rect(0, y, 16, 1, dk); pb.set((y * 3 + 2) % 16, y + 2, C('#3a2a1a')); } sp(C('#4f7a4a'), 0.05); break;
    case 'uruin': for (let y = 0; y < 16; y += 8) { pb.rect(0, y, 16, 1, dk); const o = (y / 8) % 2 ? 4 : 0; for (let x = o; x < 16; x += 8) pb.rect(x, y, 1, 8, dk); } sp(C('#4f8a6a'), 0.08); break;
    case 'uwall': sp(dk, 0.12); sp(lt, 0.05); sp(C('#3a6a5a'), 0.05); break;
  }
  return pb;
}
const T_KIND = ['water', 'water', 'shallow', 'sand', 'grass', 'forest', 'jungle', 'dirt', 'rock', 'cliff', 'water', 'ruins', 'farm', 'volc', 'lava'];
const U_KIND = ['uwall', 'usand', 'ugrass', 'ureef', 'urock', 'ukelp', 'utrench', 'uwreck', 'uruin'];

// 境界マスク（全地形で共通の形にして海岸の泡と揃える）
const EDGE_D = [];
(function () {
  const r = mulberry32(777);
  for (let s = 0; s < 4; s++) {
    const a = []; let v = 3;
    for (let i = 0; i < 16; i++) { if (r() < 0.55) v += r() < 0.5 ? -1 : 1; v = clamp(v, 2, 5); a.push(v); }
    EDGE_D.push(a);
  }
})();
function inMask(dir, x, y) {
  switch (dir) {
    case 0: return y < EDGE_D[0][x];
    case 1: return 15 - x < EDGE_D[1][y];
    case 2: return 15 - y < EDGE_D[2][x];
    case 3: return x < EDGE_D[3][y];
    case 4: { const dx = 15 - x, dy = y; return dx * dx + dy * dy < 18; } // NE
    case 5: { const dx = 15 - x, dy = 15 - y; return dx * dx + dy * dy < 18; } // SE
    case 6: { const dx = x, dy = 15 - y; return dx * dx + dy * dy < 18; } // SW
    case 7: { const dx = x, dy = y; return dx * dx + dy * dy < 18; } // NW
  }
  return false;
}
function maskIn(dir, x, y) { return inMask(dir, clamp(x, 0, 15), clamp(y, 0, 15)) || ((dir === 0 && y < 0) || (dir === 1 && x > 15) || (dir === 2 && y > 15) || (dir === 3 && x < 0)); }
function makeOverlay(texPB, dir, edgeCol) {
  const pb = new PB(16, 16);
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    if (!inMask(dir, x, y)) continue;
    const edge = edgeCol && (!maskIn(dir, x - 1, y) || !maskIn(dir, x + 1, y) || !maskIn(dir, x, y - 1) || !maskIn(dir, x, y + 1));
    pb.set(x, y, edge ? edgeCol : texPB.get(x, y));
  }
  return pb.cv();
}
function makeFoam(dir, frame) {
  const pb = new PB(16, 16), r = mulberry32(900 + dir * 7 + frame * 31);
  const W = [235, 250, 255], W2 = [180, 225, 240];
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
    if (inMask(dir, x, y)) continue;
    const near = maskIn(dir, x - 1, y) || maskIn(dir, x + 1, y) || maskIn(dir, x, y - 1) || maskIn(dir, x, y + 1);
    if (near) { if (r() < 0.85) pb.set(x, y, W); }
    else {
      const near2 = maskIn(dir, x - 2, y) || maskIn(dir, x + 2, y) || maskIn(dir, x, y - 2) || maskIn(dir, x, y + 2);
      if (near2 && r() < (frame ? 0.45 : 0.25)) pb.set(x, y, W2);
    }
  }
  return pb.cv();
}

function buildTerrain() {
  for (let t = 0; t < TN; t++) {
    SP.tile[t] = [];
    for (let v = 0; v < 4; v++) {
      SP.tile[t][v] = [];
      for (let f = 0; f < 4; f++) {
        if (!WATERISH.has(t) && f > 0) { SP.tile[t][v][f] = SP.tile[t][v][0]; continue; }
        SP.tile[t][v][f] = genTex(TCOL[t], T_KIND[t], t * 100 + v * 7 + 3, f).cv();
      }
    }
    SP.over[t] = [];
    if (t === T.DEEP || t === T.CLIFF) continue;
    for (let d = 0; d < 8; d++) {
      SP.over[t][d] = [];
      for (let f = 0; f < 4; f++) {
        if (!WATERISH.has(t) && f > 0) { SP.over[t][d][f] = SP.over[t][d][0]; continue; }
        const tex = genTex(TCOL[t], T_KIND[t], t * 100 + 3, f);
        SP.over[t][d][f] = makeOverlay(tex, d, T_EDGE[t] ? C(T_EDGE[t]) : null);
      }
    }
  }
  for (let t = 0; t < UN; t++) {
    SP.tileU[t] = [];
    for (let v = 0; v < 4; v++) SP.tileU[t][v] = genTex(UCOL[t], U_KIND[t], 500 + t * 100 + v * 7, 0).cv();
    SP.overU[t] = [];
    if (t === U.TRENCH) continue;
    for (let d = 0; d < 8; d++) {
      const tex = genTex(UCOL[t], U_KIND[t], 500 + t * 100, 0);
      SP.overU[t][d] = makeOverlay(tex, d, t === U.WALL ? C('#16303a') : shade(C(UCOL[t][0]), 0.86));
    }
  }
  for (let d = 0; d < 8; d++) SP.foam[d] = [makeFoam(d, 0), makeFoam(d, 1)];
  // 崖の側面
  {
    const pb = new PB(16, 8), r = mulberry32(55);
    pb.rect(0, 0, 16, 8, C('#5a5550'));
    for (let x = 0; x < 16; x++) { if (r() < 0.4) pb.rect(x, 1, 1, 6, C('#4a4642')); if (r() < 0.2) pb.rect(x, 2, 1, 3, C('#6e6964')); }
    pb.rect(0, 0, 16, 1, C('#a49e95'));
    pb.rect(0, 7, 16, 1, C('#2e2b28'));
    SP.cliffFace = pb.cv();
    const pu = new PB(16, 8);
    pu.rect(0, 0, 16, 8, C('#1e3640'));
    for (let x = 0; x < 16; x++) { if (r() < 0.4) pu.rect(x, 1, 1, 6, C('#16282f')); if (r() < 0.25) pu.set(x, 2 + r() * 4, C('#3a6a5a')); }
    pu.rect(0, 0, 16, 1, C('#4f7a86'));
    SP.wallFace = pu.cv();
  }
}

/* ---------- オブジェクト ---------- */
function blob(pb, circles, base, dk, lt) {
  for (const [x, y, r] of circles) pb.circ(x + 1, y + 1.2, r, dk);
  for (const [x, y, r] of circles) pb.circ(x, y, r - 0.4, base);
  for (const [x, y, r] of circles) pb.circ(x - r * 0.3, y - r * 0.35, r * 0.48, lt);
}
function shadowEll(pb, cx, cy, rx, ry) { pb.ell(cx, cy, rx, ry, SHADOW); for (let i = 0; i < pb.d.length; i += 4) if (pb.d[i + 3] === 255 && pb.d[i] === 0 && pb.d[i + 1] === 0 && pb.d[i + 2] === 0) pb.d[i + 3] = 70; }
function finish(pb, ol = OUT) { pb.outline(ol); return pb; }
function shadowFirst(w, h, cx, cy, rx, ry) { const pb = new PB(w, h); shadowEll(pb, cx, cy, rx, ry); return pb; }
// 影は半透明なので、輪郭線の対象から外す
function outlineNoShadow(pb, col) {
  const cp = new Uint8ClampedArray(pb.d);
  const A = (x, y) => (x < 0 || y < 0 || x >= pb.w || y >= pb.h) ? 0 : (cp[(y * pb.w + x) * 4 + 3] === 255 ? 1 : 0);
  for (let y = 0; y < pb.h; y++) for (let x = 0; x < pb.w; x++) {
    if (A(x, y)) continue;
    if (A(x - 1, y) || A(x + 1, y) || A(x, y - 1) || A(x, y + 1)) pb.set(x, y, col);
  }
  return pb;
}

function oPalm(v) {
  const W = 38, H = 44, pb = shadowFirst(W, H, 19, 41, 7, 2.2), r = mulberry32(100 + v);
  const lean = [5, -4, 2][v];
  const trunk = C('#9b6a3e'), ring = C('#74502c'), tl = C('#c48c55');
  for (let i = 0; i <= 28; i++) {
    const t = i / 28, y = 41 - i, x = 19 + lean * t * t, w = 4 - t * 1.4;
    const c = i % 4 === 0 ? ring : trunk;
    pb.rect(Math.round(x - w / 2), y, Math.round(w), 1, c);
    pb.set(Math.round(x - w / 2), y, tl);
  }
  const tx = 19 + lean, ty = 13;
  const G = C('#3f9a3a'), GD = C('#2a722a'), GL = C('#73c652');
  const angs = [-2.9, -2.3, -1.75, -1.25, -0.75, -0.15, 0.45 + v * 0.1, 2.6];
  for (const a of angs) {
    const L = 11 + r() * 4;
    for (let pass = 0; pass < 2; pass++) for (let s = 0; s <= L; s += 0.5) {
      const px = tx + Math.cos(a) * s, py = ty + Math.sin(a) * s * 0.65 + (s / L) * (s / L) * 7;
      const rad = 2.1 * (1 - s / L) + 0.5;
      pb.circ(px, py + (pass ? 0 : 1), rad, pass ? G : GD);
    }
    for (let s = 1; s <= L - 1; s += 0.5) {
      const px = tx + Math.cos(a) * s, py = ty + Math.sin(a) * s * 0.65 + (s / L) * (s / L) * 7;
      pb.set(px, py - 0.5, GL);
    }
  }
  const coc = C('#5e3d22');
  [[-2, 2], [1, 3], [3, 1]].forEach(([dx, dy]) => { pb.circ(tx + dx, ty + dy, 1.7, coc); pb.set(tx + dx - 1, ty + dy - 1, C('#8a6038')); });
  return [outlineNoShadow(pb, OUT).cv()];
}
function oTree(v, cols) {
  const W = 32, H = 40, pb = shadowFirst(W, H, 16, 37, 8, 2.4), r = mulberry32(200 + v);
  const tr = C('#7a5232'), trd = C('#5a3a22');
  pb.rect(14, 24, 5, 14, tr); pb.rect(17, 24, 2, 14, trd); pb.rect(12, 36, 9, 2, tr);
  const [b, d, l] = (cols || ['#4e9a3a', '#2f6b2a', '#7cc451']).map(C);
  const cs = [[16, 15, 9 + r()], [9, 19, 6], [23, 19, 6], [12, 9, 6], [20, 10, 6], [16, 22, 6]];
  blob(pb, cs, b, d, l);
  pb.speck(d, 0.04, 300 + v); pb.speck(l, 0.02, 301 + v);
  for (let y = 0; y < 26; y++) for (let x = 0; x < W; x++) { if (pb.a(x, y) === 255 && hash2(x, y, v) < 0.05) pb.set(x, y, shade(b, 1.15)); }
  return [outlineNoShadow(pb, OUT).cv()];
}
function oJTree(v) {
  const W = 42, H = 50, pb = shadowFirst(W, H, 21, 47, 10, 2.6), r = mulberry32(260 + v);
  const tr = C('#6a4a2e'), trd = C('#4a3220');
  pb.rect(18, 30, 7, 18, tr); pb.rect(22, 30, 3, 18, trd);
  pb.poly([[14, 48], [18, 40], [19, 48]], tr); pb.poly([[29, 48], [24, 40], [24, 48]], trd);
  const [b, d, l] = ['#2f7f3a', '#1b5226', '#4fa651'].map(C);
  blob(pb, [[21, 18, 12], [11, 22, 8], [31, 22, 8], [15, 11, 8], [27, 11, 8], [21, 27, 8], [6, 27, 4], [36, 27, 4]], b, d, l);
  pb.speck(d, 0.05, 333 + v);
  const vine = C('#2a6a2a');
  for (let i = 0; i < 4; i++) { const x = 8 + Math.floor(r() * 26), y0 = 26 + Math.floor(r() * 6), len = 6 + Math.floor(r() * 8); for (let j = 0; j < len; j++) pb.set(x + Math.round(Math.sin(j / 2) * 0.6), y0 + j, vine); pb.set(x + 1, y0 + len - 1, C('#5ab84a')); }
  return [outlineNoShadow(pb, OUT).cv()];
}
function oPine(v) {
  const pb = shadowFirst(26, 42, 13, 39, 7, 2), r = mulberry32(280 + v);
  pb.rect(11, 30, 4, 10, C('#6a4428'));
  const [b, d, l] = ['#2f6e46', '#1d4a30', '#4a8f5e'].map(C);
  for (let i = 0; i < 4; i++) {
    const top = 2 + i * 7, bot = top + 12, hw = 4 + i * 2.6;
    pb.poly([[13, top], [13 + hw, bot], [13 - hw, bot]], d);
    pb.poly([[13, top], [13 + hw - 1, bot - 1], [13 - hw + 1, bot - 1]], b);
    pb.line(12, top + 2, 13 - hw + 2, bot - 2, l);
  }
  pb.speck(d, 0.04, 290 + v);
  return [outlineNoShadow(pb, OUT).cv()];
}
function oBanana(full) {
  const pb = shadowFirst(28, 32, 14, 29, 6, 2);
  const st = C('#8fae4a');
  pb.rect(12, 14, 4, 16, st); pb.rect(15, 14, 1, 16, C('#6a8a34'));
  const L = C('#7cc44a'), LD = C('#4f9a32'), LL = C('#a8e070');
  const leaf = (a, len) => {
    for (let s = 0; s < len; s += 0.5) {
      const x = 14 + Math.cos(a) * s, y = 13 + Math.sin(a) * s * 0.7 + (s / len) ** 2 * 8;
      const rr = 3 * Math.sin(Math.PI * s / len) + 0.6;
      pb.circ(x, y + 1, rr, LD); pb.circ(x, y, rr, L);
    }
    for (let s = 1; s < len; s += 0.5) { const x = 14 + Math.cos(a) * s, y = 13 + Math.sin(a) * s * 0.7 + (s / len) ** 2 * 8; pb.set(x, y, LL); }
  };
  leaf(-2.7, 12); leaf(-0.4, 12); leaf(-1.9, 10); leaf(-1.1, 10);
  if (full) { const Y = C('#ffd84a'), YD = C('#d8a82a'); for (let i = 0; i < 5; i++) { pb.ell(12 + (i % 3) * 2, 16 + Math.floor(i / 3) * 3, 1.3, 2, YD); pb.ell(12 + (i % 3) * 2, 15.5 + Math.floor(i / 3) * 3, 1, 1.6, Y); } }
  return [outlineNoShadow(pb, OUT).cv()];
}
function oBamboo() {
  const pb = shadowFirst(18, 36, 9, 33, 7, 2);
  const g = C('#7fb84a'), n = C('#4f8a2e'), l = C('#aada6c');
  [[3, 6], [8, 2], [13, 8]].forEach(([x, top]) => {
    pb.rect(x, top, 3, 34 - top, g); pb.rect(x, top, 1, 34 - top, l);
    for (let y = top + 5; y < 34; y += 6) pb.rect(x, y, 3, 1, n);
    pb.line(x + 2, top + 3, x + 5, top, C('#5aa040')); pb.line(x, top + 6, x - 3, top + 4, C('#5aa040'));
  });
  return [outlineNoShadow(pb, OUT).cv()];
}
function oStump() {
  const pb = shadowFirst(16, 16, 8, 14, 6, 1.6);
  pb.rect(3, 9, 10, 5, C('#7a5232')); pb.rect(10, 9, 3, 5, C('#5a3a22'));
  pb.ell(8, 9, 5, 2.6, C('#c8a070')); pb.ell(8, 9, 3, 1.5, C('#a07a4a')); pb.set(8, 9, C('#c8a070'));
  return [outlineNoShadow(pb, OUT).cv()];
}
function oBush(berries) {
  const pb = shadowFirst(16, 16, 8, 14, 7, 1.8);
  blob(pb, [[8, 8, 5], [4.5, 10, 3.5], [11.5, 10, 3.5]], C('#3f8f3a'), C('#286628'), C('#62b04c'));
  if (berries) { const R = C('#e8344a'); [[5, 9], [9, 6], [11, 10], [7, 11], [12, 7], [4, 6]].forEach(([x, y]) => { pb.set(x, y, R); pb.set(x + 1, y, C('#b0203a')); pb.set(x, y - 1, C('#ff8a9a')); }); }
  return [outlineNoShadow(pb, OUT).cv()];
}
function oGrass(v) {
  const pb = new PB(16, 16), r = mulberry32(400 + v);
  const cs = [C('#5aa83a'), C('#7fcf55'), C('#3f8a2e')];
  for (let i = 0; i < 7; i++) {
    const bx = 4 + r() * 8, tx = bx + (r() - 0.5) * 8, ty = 4 + r() * 5;
    pb.line(bx, 15, tx, ty, cs[i % 3]);
  }
  return [outlineNoShadow(pb, C('#2a5a22')).cv()];
}
function oFlower(v) {
  const pb = new PB(16, 16), r = mulberry32(450 + v);
  const pc = [C('#ff5a6a'), C('#ffd84a'), C('#f4f4f4'), C('#b07ae8')][v];
  for (let i = 0; i < 3; i++) {
    const x = 3 + i * 4 + Math.floor(r() * 2), y = 6 + Math.floor(r() * 5);
    pb.line(x, 15, x, y + 1, C('#4f9a3a'));
    pb.set(x - 1, y, pc); pb.set(x + 1, y, pc); pb.set(x, y - 1, pc); pb.set(x, y + 1, pc); pb.set(x, y, C('#ffe04a'));
  }
  return [pb.cv()];
}
function oHerb() {
  const pb = new PB(16, 16);
  const L = C('#8fdc6a'), LD = C('#5aa83a');
  [[-1.2, 6], [-1.9, 6], [-0.5, 5], [-2.6, 5]].forEach(([a, l]) => { for (let s = 0; s < l; s += 0.5) pb.circ(8 + Math.cos(a) * s, 13 + Math.sin(a) * s, 1.4 * Math.sin(Math.PI * s / l) + 0.4, s > l * 0.6 ? L : LD); });
  [[5, 6], [8, 4], [11, 6]].forEach(([x, y]) => { pb.set(x, y, [255, 255, 255]); pb.set(x + 1, y, [255, 255, 255]); pb.set(x, y + 1, C('#f0e0f0')); });
  return [outlineNoShadow(pb, C('#2a5a22')).cv()];
}
function oMush() {
  const pb = shadowFirst(16, 16, 8, 14, 5, 1.4);
  const cap = C('#d83a2e'), st = C('#f0e2c8');
  [[6, 9, 3], [11, 11, 2.2]].forEach(([x, y, s]) => { pb.rect(x - 1, y, 2, s + 2, st); pb.ell(x, y, s + 1, s * 0.75, cap); pb.set(x - 1, y - 1, [255, 255, 255]); pb.set(x + 1, y, [255, 255, 255]); });
  return [outlineNoShadow(pb, OUT).cv()];
}
function oRock(big, spec) {
  const W = big ? 26 : 16, H = big ? 22 : 16;
  const pb = shadowFirst(W, H, W / 2, H - 2.5, W / 2 - 1.5, 2);
  const base = spec === 'obs' ? C('#3a3348') : C('#8a8782');
  if (big) { pb.ell(13, 12, 11, 8, base); pb.ell(8, 9, 5, 4, shade(base, 1.08)); }
  else pb.ell(8, 10, 6.5, 5, base);
  pb.bevel(1.22, 0.7);
  pb.speck(shade(base, 0.82), 0.06, 500 + (big ? 1 : 0));
  const r = mulberry32(510 + (spec ? spec.length : 0));
  if (spec === 'iron') for (let i = 0; i < 5; i++) { const x = 3 + r() * 9, y = 6 + r() * 6; pb.rect(x, y, 2, 2, C('#c8783a')); pb.set(x, y, C('#f0a868')); }
  if (spec === 'coal') for (let i = 0; i < 5; i++) { const x = 3 + r() * 9, y = 6 + r() * 6; pb.rect(x, y, 2, 2, C('#26232a')); pb.set(x, y, C('#55505c')); }
  if (spec === 'obs') {
    [[5, 12, 3, 4], [9, 13, 6, 7], [12, 12, 10, 5]].forEach(([x0, y0, x1, y1]) => { pb.poly([[x0 - 2, y0], [x1, y1], [x0 + 2, y0]], C('#251d33')); pb.line(x0 - 1, y0 - 1, x1, y1 + 1, C('#9a8ad0')); });
  }
  return [outlineNoShadow(pb, OUT).cv()];
}
function oClay() {
  const pb = shadowFirst(16, 16, 8, 13, 6, 1.6);
  pb.ell(8, 11, 6, 3.5, C('#b8693e')); pb.ell(7, 10, 3.5, 2, C('#d48a5a')); pb.set(10, 12, C('#8a4a2a')); pb.set(11, 11, C('#8a4a2a'));
  return [outlineNoShadow(pb, C('#4a2414')).cv()];
}
function oPebble() { const pb = new PB(16, 16); [[6, 11, 2], [10, 12, 1.6], [8, 9, 1.3]].forEach(([x, y, s]) => pb.ell(x, y, s, s * 0.8, C('#9a9690'))); pb.bevel(); return [outlineNoShadow(pb, C('#3a3632')).cv()]; }
function oStick() { const pb = new PB(16, 16); pb.line(3, 12, 13, 8, C('#8a5a32')); pb.line(8, 10, 9, 7, C('#8a5a32')); pb.set(9, 6, C('#5aa040')); return [outlineNoShadow(pb, C('#3a2414')).cv()]; }
function shellPB() { const pb = new PB(16, 16); pb.ell(8, 10, 4, 3.2, C('#f2b8a8')); for (let i = -2; i <= 2; i++) pb.line(8, 12, 8 + i * 1.6, 7.6, C('#d8907e')); pb.rect(7, 12, 3, 1, C('#e0a090')); return pb; }
function oShell() { return [outlineNoShadow(shellPB(), C('#6a3a30')).cv()]; }
function oDrift() { const pb = shadowFirst(16, 16, 8, 13, 7, 1.4); pb.ell(8, 11, 6.5, 2.2, C('#a89a86')); pb.line(3, 10, 13, 10, C('#c8baa6')); pb.ell(14, 11, 1.2, 2, C('#7a6a56')); return [outlineNoShadow(pb, OUT).cv()]; }
function oBottle() {
  const fr = [];
  for (let f = 0; f < 2; f++) {
    const pb = new PB(16, 16);
    pb.ell(8, 11, 5, 2.4, C('#4fae88')); pb.rect(12, 10, 3, 2, C('#4fae88')); pb.rect(14, 10, 2, 2, C('#c8a070'));
    pb.rect(5, 10, 5, 2, C('#f4ecd0'));
    outlineNoShadow(pb, C('#1a3a2a'));
    if (f) { pb.set(6, 9, [255, 255, 255]); pb.set(5, 8, [255, 255, 255]); pb.set(7, 8, [255, 255, 255]); pb.set(6, 7, [255, 255, 255]); }
    fr.push(pb.cv());
  }
  return fr;
}
function oCrate() {
  const pb = shadowFirst(16, 16, 8, 15, 7, 1.4);
  const w = C('#b07a44'), d = C('#7a5028');
  pb.rect(2, 3, 12, 12, w); pb.rect(2, 3, 12, 1, C('#d09a60'));
  pb.rect(2, 8, 12, 1, d); pb.line(3, 4, 12, 13, d); pb.rect(2, 3, 1, 12, d); pb.rect(13, 3, 1, 12, d);
  return [outlineNoShadow(pb, OUT).cv()];
}
function oBarrel() {
  const pb = shadowFirst(16, 16, 8, 15, 6, 1.4);
  pb.rect(3, 4, 10, 11, C('#9a6a3c')); pb.rect(4, 3, 8, 13, C('#9a6a3c')); pb.rect(4, 4, 2, 11, C('#b88a54'));
  pb.rect(3, 6, 10, 1, C('#5a5a62')); pb.rect(3, 12, 10, 1, C('#5a5a62')); pb.ell(8, 3.5, 4, 1.2, C('#b88a54'));
  return [outlineNoShadow(pb, OUT).cv()];
}
function chestPB(body, lid, trim) {
  const pb = shadowFirst(16, 16, 8, 15, 7, 1.4);
  pb.rect(2, 7, 12, 8, body); pb.rect(2, 4, 12, 4, lid); pb.rect(2, 4, 12, 1, shade(lid, 1.25));
  pb.rect(2, 7, 12, 1, shade(body, 0.7));
  pb.rect(4, 4, 1, 11, trim); pb.rect(11, 4, 1, 11, trim); pb.rect(7, 7, 2, 3, trim); pb.set(7, 8, OUT);
  return pb;
}
function oChest(u) {
  const pb = chestPB(C('#9a5f2e'), C('#b8743c'), C('#ffcf4a'));
  if (u) pb.speck(C('#4f8a5a'), 0.12, 77);
  return [outlineNoShadow(pb, OUT).cv()];
}
function oStorage() { return [outlineNoShadow(chestPB(C('#b88654'), C('#d0a06a'), C('#6a6a74')), OUT).cv()]; }
function oBag() { const pb = shadowFirst(16, 16, 8, 15, 6, 1.4); pb.ell(8, 11, 5, 4, C('#9a7a4a')); pb.rect(6, 5, 4, 3, C('#9a7a4a')); pb.rect(6, 7, 4, 1, C('#d84a3a')); pb.bevel(); return [outlineNoShadow(pb, OUT).cv()]; }
function flamePB(pb, cx, by, f, sc = 1) {
  const r = mulberry32(600 + f);
  const cols = [C('#e8401e'), C('#ff8a2a'), C('#ffe04a')];
  for (let k = 0; k < 3; k++) {
    const h = (6 - k * 1.8 + r() * 2) * sc, w = (3.2 - k) * sc;
    pb.poly([[cx - w, by], [cx + (r() - 0.5) * 2, by - h], [cx + w, by]], cols[k]);
  }
  if (f === 1) pb.set(cx - 2, by - 7 * sc, cols[1]);
  if (f === 2) pb.set(cx + 2, by - 8 * sc, cols[2]);
}
function oCampfire() {
  const fr = [];
  for (let f = 0; f < 3; f++) {
    const pb = new PB(16, 16);
    pb.line(3, 13, 13, 10, C('#7a5232'), 2); pb.line(3, 10, 13, 13, C('#5a3a22'), 2);
    for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; pb.circ(8 + Math.cos(a) * 6, 12 + Math.sin(a) * 3, 1.3, C('#8a8782')); }
    flamePB(pb, 8, 12, f);
    fr.push(outlineNoShadow(pb, OUT).cv());
  }
  return fr;
}
function oBench() {
  const pb = shadowFirst(16, 16, 8, 15, 7, 1.4);
  pb.rect(2, 10, 2, 5, C('#6a4428')); pb.rect(12, 10, 2, 5, C('#6a4428'));
  pb.rect(1, 6, 14, 5, C('#c8925a')); pb.rect(1, 6, 14, 1, C('#e8b47a')); pb.rect(1, 10, 14, 1, C('#8a5a32'));
  pb.rect(3, 4, 4, 2, C('#8a8a92')); pb.rect(5, 4, 1, 3, C('#7a5232'));
  pb.line(9, 5, 13, 4, C('#c0c0c8')); pb.rect(12, 3, 2, 2, C('#7a5232'));
  return [outlineNoShadow(pb, OUT).cv()];
}
function oFurnace() {
  const fr = [];
  for (let f = 0; f < 2; f++) {
    const pb = shadowFirst(16, 22, 8, 20, 7, 1.6);
    pb.ell(8, 13, 7, 7.5, C('#8a8580'));
    for (let y = 8; y < 20; y += 3) for (let x = 2 + (y % 2) * 2; x < 15; x += 4) pb.set(x, y, C('#6a6560'));
    pb.rect(6, 2, 4, 5, C('#7a7570')); pb.rect(6, 2, 4, 1, C('#5a5550'));
    pb.bevel(1.18, 0.75);
    pb.ell(8, 16, 3.2, 2.6, C('#2a1a14'));
    pb.ell(8, 17, 2, 1.4, f ? C('#ffd04a') : C('#ff8a2a'));
    fr.push(outlineNoShadow(pb, OUT).cv());
  }
  return fr;
}
function oBed() {
  const pb = shadowFirst(16, 16, 8, 15, 7, 1.4);
  pb.rect(2, 1, 12, 14, C('#7a5232')); pb.rect(3, 2, 10, 12, C('#e0c070'));
  pb.rect(4, 2, 8, 3, C('#f4eee0')); pb.rect(3, 7, 10, 7, C('#5aa040')); pb.rect(3, 7, 10, 1, C('#7cc85a'));
  pb.line(4, 10, 12, 10, C('#3f8030'));
  return [outlineNoShadow(pb, OUT).cv()];
}
function oRain() {
  const pb = shadowFirst(16, 22, 8, 20, 6, 1.4);
  pb.rect(3, 9, 10, 11, C('#9a6a3c')); pb.rect(3, 9, 2, 11, C('#b88a54')); pb.rect(3, 12, 10, 1, C('#5a5a62')); pb.rect(3, 17, 10, 1, C('#5a5a62'));
  pb.poly([[0, 3], [16, 3], [11, 9], [5, 9]], C('#4f9a3a')); pb.line(1, 3, 15, 3, C('#7cc85a'));
  pb.rect(5, 7, 6, 2, C('#5ab8e6'));
  return [outlineNoShadow(pb, OUT).cv()];
}
function oTorch() {
  const fr = [];
  for (let f = 0; f < 2; f++) {
    const pb = new PB(16, 16);
    pb.rect(7, 7, 2, 9, C('#7a5232')); pb.rect(6, 6, 4, 2, C('#c8a070'));
    flamePB(pb, 8, 6, f, 0.7);
    fr.push(outlineNoShadow(pb, OUT).cv());
  }
  return fr;
}
function oWall() {
  const pb = shadowFirst(16, 26, 8, 25, 8, 1.2);
  for (let i = 0; i < 3; i++) {
    const x = 1 + i * 5;
    pb.rect(x, 5, 4, 20, C('#9a6a3c')); pb.rect(x, 5, 1, 20, C('#b88a54')); pb.rect(x + 3, 5, 1, 20, C('#6a4428'));
    pb.poly([[x, 5], [x + 2, 1], [x + 4, 5]], C('#9a6a3c'));
  }
  pb.rect(0, 14, 16, 2, C('#c8a878'));
  return [outlineNoShadow(pb, OUT).cv()];
}
function oDoor() {
  const pb = shadowFirst(16, 26, 8, 25, 8, 1.2);
  pb.rect(0, 3, 3, 22, C('#7a5232')); pb.rect(13, 3, 3, 22, C('#7a5232')); pb.rect(0, 2, 16, 3, C('#7a5232'));
  pb.rect(3, 5, 10, 20, C('#c08a50'));
  for (let x = 5; x < 13; x += 3) pb.rect(x, 5, 1, 20, C('#9a6a3c'));
  pb.rect(10, 15, 2, 2, C('#ffcf4a'));
  return [outlineNoShadow(pb, OUT).cv()];
}
function oFloor() {
  const pb = new PB(16, 16);
  pb.rect(0, 0, 16, 16, C('#b8834c'));
  for (let y = 0; y < 16; y += 4) { pb.rect(0, y + 3, 16, 1, C('#7a5232')); pb.rect(0, y, 16, 1, C('#d4a068')); pb.set((y * 5) % 14 + 1, y + 1, C('#5a5a62')); }
  pb.rect(0, 0, 1, 16, C('#8a5a32')); pb.rect(15, 0, 1, 16, C('#8a5a32'));
  return [pb.cv()];
}
function oTrap() {
  const pb = new PB(16, 16);
  pb.ell(8, 10, 6, 4, C('#b08a52'));
  for (let i = 3; i < 14; i += 2) pb.line(i, 7, i, 13, C('#8a6a3a'));
  pb.ell(8, 8, 3, 1.4, C('#3a2a1a'));
  pb.ell(8, 13, 7, 1.5, C('#9ad8f0'));
  return [outlineNoShadow(pb, OUT).cv()];
}
function oCrop(st) {
  const pb = new PB(16, 16), G = C('#5aa83a'), L = C('#8fd466');
  if (st === 1) { [[4, 10], [8, 7], [12, 11]].forEach(([x, y]) => { pb.line(x, y + 3, x, y, G); pb.set(x - 1, y, L); pb.set(x + 1, y, L); }); }
  else {
    const h = st === 2 ? 6 : 8;
    for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + (i - 2) * 0.55; pb.line(8, 14, 8 + Math.cos(a) * h, 14 + Math.sin(a) * h, i % 2 ? G : L, 2); }
    if (st === 3) { pb.ell(5, 14, 2, 1.5, C('#a8743c')); pb.ell(11, 14, 2, 1.5, C('#a8743c')); pb.set(4, 13, C('#d09a60')); }
  }
  return [outlineNoShadow(pb, C('#2a4a1a')).cv()];
}
function oShipyard(stage) {
  const pb = shadowFirst(52, 40, 26, 36, 24, 3);
  const w = C('#9a6a3c'), wd = C('#6a4428');
  pb.rect(2, 30, 48, 4, w); pb.rect(2, 33, 48, 1, wd);
  for (let x = 4; x < 50; x += 9) pb.rect(x, 26, 3, 8, wd);
  if (stage >= 1) {
    pb.poly([[6, 22], [46, 22], [41, 31], [11, 31]], C('#8a5a32'));
    pb.rect(6, 22, 40, 2, C('#b8834c'));
    for (let x = 12; x < 42; x += 6) pb.line(x, 24, x - 1, 30, C('#6a4428'));
  } else {
    for (let x = 10; x < 44; x += 6) { pb.line(x, 30, x - 3, 21, w); pb.line(x, 30, x + 3, 21, w); }
    pb.line(6, 30, 46, 30, wd, 2);
  }
  if (stage >= 2) {
    pb.rect(25, 2, 2, 22, C('#7a5232'));
    pb.poly([[27, 3], [27, 20], [42, 18]], C('#f4eee0')); pb.line(27, 12, 40, 17, C('#d8d0c0'));
    pb.poly([[24, 5], [24, 19], [12, 18]], C('#e8e2d2'));
  }
  return [outlineNoShadow(pb, OUT).cv()];
}
function oPillar(u) {
  const pb = shadowFirst(16, 30, 8, 28, 7, 1.4);
  const s = u ? C('#8a9a96') : C('#a8a596');
  pb.rect(4, 5, 8, 22, s); pb.rect(3, 3, 10, 3, shade(s, 1.1)); pb.rect(3, 26, 10, 3, shade(s, 0.9));
  pb.rect(4, 5, 2, 22, shade(s, 1.15)); pb.rect(10, 5, 2, 22, shade(s, 0.8));
  pb.speck(u ? C('#3f7a5a') : C('#6f8a4a'), 0.12, u ? 61 : 62);
  pb.line(7, 10, 8, 16, shade(s, 0.7));
  return [outlineNoShadow(pb, OUT).cv()];
}
function oStatue() {
  const pb = shadowFirst(16, 32, 8, 30, 7, 1.4);
  const s = C('#9a978a');
  pb.rect(3, 4, 10, 26, s); pb.rect(2, 4, 12, 4, shade(s, 1.08));
  pb.rect(3, 9, 10, 2, shade(s, 0.7)); pb.rect(7, 11, 3, 8, shade(s, 1.12)); pb.rect(9, 11, 1, 8, shade(s, 0.75));
  pb.rect(5, 21, 6, 1, shade(s, 0.6)); pb.rect(4, 12, 2, 2, C('#4ae0d0'));
  pb.rect(10, 12, 2, 2, C('#4ae0d0'));
  pb.speck(C('#6f8a4a'), 0.07, 63);
  return [outlineNoShadow(pb, OUT).cv()];
}
function oRuinDoor() {
  const fr = [];
  for (let f = 0; f < 2; f++) {
    const pb = shadowFirst(16, 28, 8, 27, 8, 1.2);
    pb.rect(1, 2, 14, 25, C('#8f8c7c')); pb.rect(1, 2, 14, 2, C('#aaa794')); pb.rect(1, 2, 2, 25, C('#a29f8c'));
    const g = f ? C('#8affea') : C('#3ac8b0');
    pb.circ(8, 13, 4, g); pb.circ(8, 13, 2.6, C('#8f8c7c')); pb.rect(7, 9, 2, 8, g); pb.rect(4, 12, 8, 2, g);
    fr.push(outlineNoShadow(pb, OUT).cv());
  }
  return fr;
}
function oVentS() { const pb = new PB(16, 16); pb.line(3, 9, 13, 11, C('#2a2020'), 2); pb.set(6, 10, C('#ff8a2a')); pb.set(10, 10, C('#ffd04a')); pb.set(8, 10, C('#d04a20')); return [pb.cv()]; }
function oWreckBit() {
  const pb = shadowFirst(40, 26, 20, 23, 18, 2.6);
  pb.poly([[2, 20], [8, 9], [34, 7], [38, 18], [30, 23], [8, 23]], C('#7a5232'));
  for (let x = 8; x < 36; x += 5) pb.line(x, 9, x - 2, 22, C('#5a3a22'));
  pb.line(4, 16, 36, 14, C('#9a6a3c'), 2);
  pb.poly([[14, 12], [20, 11], [17, 18]], C('#2a1a10'));
  pb.line(24, 8, 33, 0, C('#8a6a44'), 2);
  pb.poly([[30, 1], [37, 5], [31, 7]], C('#d8d0bc'));
  return [outlineNoShadow(pb, OUT).cv()];
}
// ---- 海中 ----
function branchCoral(pb, x, y, a, len, depth, cols, r) {
  const x2 = x + Math.cos(a) * len, y2 = y + Math.sin(a) * len;
  pb.line(x, y, x2, y2, cols[0], depth > 1 ? 2 : 1);
  if (depth <= 0) { pb.set(x2, y2, cols[1]); return; }
  branchCoral(pb, x2, y2, a - 0.5 - r() * 0.3, len * 0.72, depth - 1, cols, r);
  branchCoral(pb, x2, y2, a + 0.5 + r() * 0.3, len * 0.72, depth - 1, cols, r);
}
function oCoral(kind) {
  const pb = new PB(16, 16), r = mulberry32(700 + kind);
  if (kind === 0 || kind === 1) {
    const cols = kind === 0 ? [C('#ff6a7a'), C('#ffc0c8')] : [C('#7a8aff'), C('#c8d0ff')];
    branchCoral(pb, 8, 15, -Math.PI / 2, 5, 2, cols, r);
    branchCoral(pb, 6, 15, -Math.PI / 2 - 0.5, 3, 1, cols, r);
    branchCoral(pb, 10, 15, -Math.PI / 2 + 0.5, 3, 1, cols, r);
    return [outlineNoShadow(pb, kind === 0 ? C('#7a2a3a') : C('#2a2a7a')).cv()];
  }
  if (kind === 2) {
    pb.ell(8, 11, 6, 4.5, C('#ffcf4a'));
    for (let y = 8; y < 15; y += 2) for (let x = 3; x < 14; x++) if (Math.sin(x * 1.3 + y) > 0.2) pb.set(x, y, C('#d8a02a'));
    pb.bevel();
    return [outlineNoShadow(pb, C('#6a4a10')).cv()];
  }
  const F = C('#c060d0');
  for (let a = -2.8; a <= -0.3; a += 0.18) { pb.line(8, 15, 8 + Math.cos(a) * 7, 15 + Math.sin(a) * 9, F); }
  for (let rr = 3; rr < 9; rr += 2.5) for (let a = -2.8; a <= -0.3; a += 0.05) pb.set(8 + Math.cos(a) * rr * 0.8, 15 + Math.sin(a) * rr, C('#e8a0f0'));
  return [outlineNoShadow(pb, C('#5a2060')).cv()];
}
function oKelp() {
  const fr = [];
  for (let f = 0; f < 2; f++) {
    const pb = new PB(16, 36);
    [[5, 30, 0], [10, 34, 1.5], [8, 22, 3]].forEach(([x, len, ph]) => {
      for (let i = 0; i < len; i++) {
        const y = 35 - i, xx = x + Math.sin(i / 5 + ph + f * 1.2) * (i / len) * 3;
        pb.set(xx, y, C('#6a8a2a')); pb.set(xx + 1, y, C('#55741f'));
        if (i % 6 === 3) { pb.ell(xx + 2, y, 2, 1, C('#8aaa3a')); pb.set(xx - 1, y + 1, C('#a0c050')); }
      }
    });
    fr.push(outlineNoShadow(pb, C('#2a3a10')).cv());
  }
  return fr;
}
function oSeagrass() { const pb = new PB(16, 16), r = mulberry32(720); for (let i = 0; i < 6; i++) { const x = 2 + r() * 12; for (let y = 15; y > 7 + r() * 4; y--) pb.set(x + Math.sin(y / 2) * 0.8, y, i % 2 ? C('#4a9a5a') : C('#6ab870')); } return [pb.cv()]; }
function oRockU() { const pb = shadowFirst(16, 16, 8, 14, 7, 1.6); pb.ell(8, 10, 6.5, 5, C('#5a6a72')); pb.bevel(1.2, 0.7); pb.speck(C('#4a7a5a'), 0.12, 731); return [outlineNoShadow(pb, C('#102028')).cv()]; }
function oClam() {
  const pb = shadowFirst(16, 16, 8, 14, 7, 1.4);
  pb.ell(8, 11, 6.5, 3.6, C('#c8b8a0'));
  for (let x = 2; x < 15; x++) pb.set(x, 9 + Math.round(Math.sin(x * 1.4)), C('#e8dcc8'));
  pb.ell(8, 11, 4.6, 1.6, C('#3ab8c8')); pb.set(6, 11, C('#a0f0f8')); pb.set(10, 11, C('#a0f0f8'));
  return [outlineNoShadow(pb, C('#3a3020')).cv()];
}
function oUrchin() {
  const pb = new PB(16, 16);
  for (let i = 0; i < 14; i++) { const a = i / 14 * Math.PI * 2; pb.line(8, 10, 8 + Math.cos(a) * 6.5, 10 + Math.sin(a) * 5.5, C('#4a2a6a')); pb.set(8 + Math.cos(a) * 6.5, 10 + Math.sin(a) * 5.5, C('#9a6ad0')); }
  pb.circ(8, 10, 3.2, C('#2a1a3a')); pb.set(7, 9, C('#6a4a8a'));
  return [pb.cv()];
}
function oStar() {
  const pb = new PB(16, 16), pts = [];
  for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? 2.4 : 6; pts.push([8 + Math.cos(a) * rr, 9 + Math.sin(a) * rr]); }
  pb.poly(pts, C('#ff8a3a')); pb.speck(C('#ffd08a'), 0.2, 741);
  return [outlineNoShadow(pb, C('#6a2a10')).cv()];
}
function oHull() {
  const pb = new PB(16, 22);
  pb.rect(0, 0, 16, 14, C('#76563a'));
  for (let y = 0; y < 14; y += 4) { pb.rect(0, y + 3, 16, 1, C('#4e3622')); pb.rect(0, y, 16, 1, C('#8e6c48')); }
  pb.rect(0, 14, 16, 8, C('#4a3220'));
  for (let x = 0; x < 16; x += 4) pb.rect(x, 14, 1, 8, C('#2a1c10'));
  pb.speck(C('#3f7a4a'), 0.1, 751);
  return [pb.cv()];
}
function oMast() { const pb = new PB(34, 14); pb.rect(1, 5, 32, 5, C('#6a5640')); pb.rect(1, 5, 32, 1, C('#8a7458')); pb.rect(10, 4, 2, 7, C('#c8a878')); pb.rect(24, 4, 2, 7, C('#c8a878')); pb.speck(C('#3f7a4a'), 0.08, 752); return [outlineNoShadow(pb, C('#1a1008')).cv()]; }
function oAnchor() {
  const pb = new PB(16, 16), I = C('#5a5a62');
  pb.rect(7, 2, 2, 11, I); pb.circ(8, 2.5, 1.8, I); pb.rect(5, 4, 6, 1, I);
  for (let a = 0.2; a < Math.PI - 0.2; a += 0.05) pb.set(8 + Math.cos(a) * 5, 9 + Math.sin(a) * 4, I);
  pb.poly([[2, 9], [4, 12], [5, 9]], I); pb.poly([[14, 9], [12, 12], [11, 9]], I);
  pb.speck(C('#8a5a3a'), 0.25, 753);
  return [outlineNoShadow(pb, C('#1a1a20')).cv()];
}
function oAmphora() {
  const pb = shadowFirst(16, 16, 8, 15, 5, 1.2);
  pb.ell(8, 10, 4.5, 5, C('#c0703a')); pb.rect(6, 2, 4, 4, C('#c0703a')); pb.rect(5, 2, 6, 1, C('#a85a2a'));
  pb.line(5, 4, 3, 7, C('#a85a2a')); pb.line(11, 4, 13, 7, C('#a85a2a'));
  pb.rect(4, 9, 8, 1, C('#3a2018')); pb.set(5, 8, C('#e0a070'));
  pb.bevel(1.15, 0.8);
  return [outlineNoShadow(pb, C('#2a1008')).cv()];
}
function oScrap() {
  const pb = shadowFirst(16, 16, 8, 14, 7, 1.4);
  pb.poly([[2, 14], [5, 6], [9, 9], [12, 5], [14, 14]], C('#7a5a42'));
  pb.line(4, 12, 12, 7, C('#9a9aa2'), 2); pb.speck(C('#b86a3a'), 0.25, 754);
  return [outlineNoShadow(pb, C('#1a1008')).cv()];
}
function oVent() {
  const fr = [];
  for (let f = 0; f < 3; f++) {
    const pb = new PB(16, 16);
    pb.ell(8, 12, 6, 3, C('#4a5058')); pb.ell(8, 12, 3, 1.4, C('#1a1e24'));
    for (let i = 0; i < 4; i++) { const y = 10 - ((f * 3 + i * 4) % 10), x = 8 + Math.sin(i * 2 + f) * 2; pb.circ(x, y, i % 2 ? 1 : 1.5, C('#c8f0ff')); pb.set(x, y, C('#5ab0d0')); }
    fr.push(pb.cv());
  }
  return fr;
}
function oGlow() {
  const fr = [];
  for (let f = 0; f < 2; f++) {
    const pb = new PB(16, 20);
    [[5, 8], [9, 4], [12, 9]].forEach(([x, y], i) => {
      pb.line(8, 19, x, y, C('#2a6a7a'));
      pb.circ(x, y, 1.8 + (f + i) % 2 * 0.4, f ? C('#9af8ff') : C('#5ae0f0')); pb.set(x, y, [255, 255, 255]);
    });
    fr.push(pb.cv());
  }
  return fr;
}
function oBones() {
  const pb = new PB(44, 26), B = C('#e8e0c8');
  pb.line(2, 14, 42, 13, B, 2);
  for (let x = 8; x < 38; x += 5) { for (let a = 0; a < Math.PI; a += 0.08) pb.set(x + Math.cos(a) * 2, 13 - Math.sin(a) * (8 - Math.abs(x - 22) / 4), B); for (let a = 0; a < Math.PI; a += 0.08) pb.set(x + Math.cos(a) * 2, 14 + Math.sin(a) * (7 - Math.abs(x - 22) / 4), B); }
  pb.ell(4, 13, 4, 3, B); pb.set(3, 12, OUT);
  return [outlineNoShadow(pb, C('#3a3628')).cv()];
}

function buildObjects() {
  const set = (k, variants) => { SP.obj[O[k]] = variants; };
  set('PALM', [oPalm(0), oPalm(1), oPalm(2)]);
  set('TREE', [oTree(0), oTree(1), oTree(2, ['#5aa63e', '#356f2c', '#88cc58'])]);
  set('JTREE', [oJTree(0), oJTree(1)]);
  set('PINE', [oPine(0), oPine(1)]);
  set('STUMP', [oStump()]);
  set('BANANA', [oBanana(true)]); set('BANANA_E', [oBanana(false)]);
  set('BUSH', [oBush(true)]); set('BUSH_E', [oBush(false)]);
  set('GRASS', [oGrass(0), oGrass(1), oGrass(2)]);
  set('FLOWER', [oFlower(0), oFlower(1), oFlower(2), oFlower(3)]);
  set('HERB', [oHerb()]); set('MUSH', [oMush()]);
  set('BAMBOO', [oBamboo()]);
  set('ROCK', [oRock(false)]); set('BIGROCK', [oRock(true)]);
  set('ORE_IRON', [oRock(false, 'iron')]); set('ORE_COAL', [oRock(false, 'coal')]); set('OBSIDIAN', [oRock(false, 'obs')]);
  set('CLAY', [oClay()]); set('PEBBLE', [oPebble()]); set('STICK', [oStick()]); set('SHELLP', [oShell()]); set('DRIFT', [oDrift()]);
  set('BOTTLE', [oBottle()]); set('CRATE', [oCrate()]); set('BARREL', [oBarrel()]);
  set('CHEST', [oChest(false)]); set('BAG', [oBag()]);
  set('CAMPFIRE', [oCampfire()]); set('BENCH', [oBench()]); set('FURNACE', [oFurnace()]); set('STORAGE', [oStorage()]);
  set('BED', [oBed()]); set('RAIN', [oRain()]); set('TORCH', [oTorch()]); set('WALL', [oWall()]); set('DOOR', [oDoor()]);
  set('FLOOR', [oFloor()]); set('TRAP', [oTrap()]);
  set('CROP1', [oCrop(1)]); set('CROP2', [oCrop(2)]); set('CROP3', [oCrop(3)]);
  set('SHIPYARD', [oShipyard(0), oShipyard(1), oShipyard(2)]);
  set('PILLAR', [oPillar(false)]); set('STATUE', [oStatue()]); set('RUINDOOR', [oRuinDoor()]); set('VENT_S', [oVentS()]);
  set('WRECKBIT', [oWreckBit()]);
  set('CORAL_R', [oCoral(0)]); set('CORAL_B', [oCoral(1)]); set('CORAL_Y', [oCoral(2)]); set('CORAL_F', [oCoral(3)]);
  set('KELP', [oKelp()]); set('SEAGRASS', [oSeagrass()]); set('ROCK_U', [oRockU()]); set('CLAM_O', [oClam()]);
  set('URCHIN', [oUrchin()]); set('STAR', [oStar()]); set('SHELLU', [oShell()]); set('CHEST_U', [oChest(true)]);
  set('HULL', [oHull()]); set('MAST', [oMast()]); set('ANCHOR', [oAnchor()]); set('PILLAR_U', [oPillar(true)]);
  set('AMPHORA', [oAmphora()]); set('SCRAP', [oScrap()]); set('VENT', [oVent()]); set('GLOW', [oGlow()]); set('BONES', [oBones()]);
}

/* ---------- プレイヤー ---------- */
const PL_PAL = pal({ k: '#2a1a1e', h: '#5a3524', H: '#7e4c30', r: '#d8483a', s: '#f4c79c', S: '#d39468', e: '#20202e', b: '#3f86b8', B: '#2c5f86', p: '#c49a5c', P: '#94713f', f: '#5a3a24', g: '#9fe3ff', G: '#33404e', y: '#fff2a0' });
const PL_HEAD_D = `
......kkkk......
....kkhhhhkk....
...khhhHHhhhk...
...khhHhhhhhk...
...krrrrrrrrk...
...khsssssshk...
...kssessessk...
...kSssssssSk...
....kkSSSSkk....`;
const PL_HEAD_U = `
......kkkk......
....kkhhhhkk....
...khhhHHhhhk...
...khhHhhhhhk...
...krrrrrrrrk...
...khhhhhhhhk...
...khhhrrhhhk...
...kShhrrhhSk...
....kkSSSSkk....`;
const PL_HEAD_R = `
......kkkk......
....kkhhhhkk....
...khhhhHHhhk...
...khhhHhhhhk...
.rrkrrrrrrrrk...
..rkhhhsssssk...
...khhssssesk...
...khSssssssk...
....kkSSSSkk....`;
const PL_BODY_D = [`
...kbbbbbbbbk...
..ksbbbbbbbbsk..
..ksbBbbbbBbsk..
..kSkbbbbbbkSk..
...kppppppppk...
...kpppkkpppk...
....kffk.kffk...`, `
...kbbbbbbbbk...
..ksbbbbbbbbsk..
..ksbBbbbbBbsk..
..kSkbbbbbbkSk..
...kppppppppk...
...kpppkkfffk...
....kffk........`, `
...kbbbbbbbbk...
..ksbbbbbbbbsk..
..ksbBbbbbBbsk..
..kSkbbbbbbkSk..
...kppppppppk...
...kfffkkpppk...
.........kffk...`];
const PL_BODY_R = [`
.....kbbbbbk....
.....kbbsbbk....
.....kbBsBbk....
.....kbbSbbk....
.....kpppppk....
.....kppkppk....
.....kffkffk....`, `
.....kbbbbbk....
.....kbbbsbk....
.....kbBbsBk....
.....kbbbSbk....
.....kpppppk....
....kppk.kppk...
....kffk.kffk...`, `
.....kbbbbbk....
.....kbsbbbk....
.....kbsBbbk....
.....kbSbbbk....
.....kpppppk....
......kppk......
......kffk......`];
function mkPlayerFrame(head, body, mask, dir) {
  const rows = (head.trim() + '\n' + body.trim()).split('\n').map(s => s.trim());
  if (mask) {
    if (dir === 'd') rows[6] = '...kGggGGggGk...';
    if (dir === 'r') rows[6] = '...khGGGGggGk...';
    if (dir === 'u') rows[6] = '...kGGGrrGGGk...';
    if (mask === 2 && dir !== 'u') rows[4] = dir === 'd' ? '...krrrryrrrk...' : '.rrkrrrrrrryk...';
  }
  return strPB(rows.join('\n'), PL_PAL).cv();
}
function buildPlayer() {
  for (const m of [0, 1, 2]) {
    const set = { d: [], u: [], r: [], l: [] };
    for (let i = 0; i < 3; i++) {
      set.d.push(mkPlayerFrame(PL_HEAD_D, PL_BODY_D[i], m, 'd'));
      set.u.push(mkPlayerFrame(PL_HEAD_U, PL_BODY_D[i], m, 'u'));
      set.r.push(mkPlayerFrame(PL_HEAD_R, PL_BODY_R[i], m, 'r'));
    }
    set.l = set.r.map(flipCanvas);
    SP.pl[m] = set;
    // ダイバー（右向きを基準に回転）
    const dv = [];
    for (let f = 0; f < 2; f++) {
      const pb = new PB(18, 18);
      const skin = C('#f4c79c'), shirt = C('#3f86b8'), shorts = C('#c49a5c'), hair = C('#5a3524'), fin = C('#2a8a9a');
      const k = f ? 1 : -1;
      pb.line(2, 7 + k, 6, 7, skin, 2); pb.line(2, 10 - k, 6, 10, skin, 2);
      pb.rect(0, 6 + k, 3, 3, fin); pb.rect(0, 9 - k, 3, 3, fin);
      pb.rect(6, 6, 3, 6, shorts);
      pb.ell(10.5, 9, 3, 3.2, shirt);
      pb.line(12, 6, 16, 4 - k, skin, 2); pb.line(12, 12, 16, 14 + k, skin, 2);
      pb.circ(14, 9, 2.6, hair); pb.rect(12, 7, 1, 4, C('#d8483a'));
      if (m) { pb.rect(15, 7, 2, 4, C('#9fe3ff')); pb.set(16, 8, [255, 255, 255]); }
      if (m === 2) pb.set(16, 9, C('#fff2a0'));
      pb.outline(OUT);
      dv.push(pb.cv());
    }
    SP.pl[m].dive = { r: dv, d: dv.map(c => rotCanvas(c, 1)), l: dv.map(c => flipCanvas(c)), u: dv.map(c => rotCanvas(c, 3)) };
  }
}

/* ---------- 生き物 ---------- */
function crFrames(fn, n = 2) { const r = []; for (let f = 0; f < n; f++) r.push(fn(f)); return { r, l: r.map(flipCanvas), sil: r.map(c => silhouette(c, [10, 30, 50], 0.55)) }; }
function buildCreatures() {
  SP.cr.crab = crFrames(f => {
    const pb = new PB(18, 14), R = C('#d9452f');
    for (let i = 0; i < 3; i++) { pb.line(6 - i * 2, 8, 3 - i * 2, 11 + (f + i) % 2, R); pb.line(12 + i * 2, 8, 15 + i * 2, 11 + (f + i + 1) % 2, R); }
    pb.ell(9, 8, 5, 3.4, R); pb.ell(8, 7, 3, 1.6, C('#f07a5a'));
    pb.circ(2.5, 5, 2.2, R); pb.circ(15.5, 5, 2.2, R); pb.set(1, 4, C('#f07a5a')); pb.set(16, 4, C('#f07a5a'));
    pb.rect(7, 3, 1, 2, R); pb.rect(10, 3, 1, 2, R); pb.set(7, 2, [255, 255, 255]); pb.set(10, 2, [255, 255, 255]);
    pb.outline(OUT); pb.set(7, 2, OUT); pb.set(10, 2, OUT);
    return pb.cv();
  });
  SP.cr.gcrab = crFrames(f => {
    const pb = new PB(42, 30), R = C('#5b4a9f'), RL = C('#8a7ad0'), O2 = C('#e88a3a');
    for (let i = 0; i < 4; i++) { pb.line(14 - i * 3, 17, 7 - i * 3, 24 + (f + i) % 2 * 2, R, 2); pb.line(28 + i * 3, 17, 35 + i * 3, 24 + (f + i + 1) % 2 * 2, R, 2); }
    pb.ell(21, 16, 11, 7, R); pb.ell(19, 13, 7, 3, RL);
    pb.line(13, 12, 7, 7, R, 3); pb.line(29, 12, 35, 7, R, 3);
    pb.ell(5, 6 - f, 5, 4, O2); pb.ell(37, 6 - f, 5, 4, O2); pb.line(2, 6 - f, 7, 6 - f, OUT);
    pb.line(35, 6 - f, 40, 6 - f, OUT);
    pb.rect(17, 7, 2, 3, R); pb.rect(23, 7, 2, 3, R); pb.circ(18, 6, 1.4, C('#ff3a3a')); pb.circ(24, 6, 1.4, C('#ff3a3a'));
    pb.speck(RL, 0.04, 9);
    pb.outline(OUT);
    return pb.cv();
  });
  SP.cr.boar = crFrames(f => {
    const pb = new PB(22, 16), B = C('#7a5236'), BD = C('#5a3a24');
    const lg = f ? [[5, 1], [8, -1], [13, 1], [16, -1]] : [[5, -1], [8, 1], [13, -1], [16, 1]];
    for (const [x, o] of lg) pb.rect(x + o, 11, 2, 4, BD);
    pb.ell(10, 8, 7.5, 4.5, B); pb.rect(4, 4, 11, 1, BD);
    pb.circ(17, 8, 3.6, B); pb.rect(19, 8, 3, 3, C('#d8908a')); pb.set(21, 9, OUT);
    pb.set(18, 11, [255, 255, 255]); pb.set(19, 12, [255, 255, 255]);
    pb.set(17, 6, OUT); pb.rect(15, 3, 2, 2, BD);
    pb.line(2, 6, 1, 4, BD);
    pb.ell(9, 6, 4, 1.4, C('#9a6e4a'));
    pb.outline(OUT); pb.set(17, 6, OUT);
    return pb.cv();
  });
  SP.cr.snake = crFrames(f => {
    const pb = new PB(20, 12), G = C('#5aa83a'), Y = C('#e8d84a');
    for (let x = 1; x < 16; x++) { const y = 7 + Math.sin(x / 2.2 + f * 1.6) * 2; pb.rect(x, y - 1, 1, 3, G); pb.set(x, y + 1, Y); if (x % 4 === 0) pb.set(x, y - 1, C('#2f7a2a')); }
    const hy = 7 + Math.sin(16 / 2.2 + f * 1.6) * 2;
    pb.ell(17, hy, 2.6, 2, G); pb.set(18, hy - 1, OUT); pb.line(19, hy + 1, 20, hy + 2, C('#ff3a3a'));
    pb.outline(OUT);
    return pb.cv();
  });
  SP.cr.monkey = crFrames(f => {
    const pb = new PB(16, 16), B = C('#8a5a32'), F = C('#e8c090');
    for (let a = 0; a < 4; a += 0.2) pb.set(3 - Math.cos(a) * 2, 11 - a * 1.5, B);
    pb.ell(8, 11, 4, 3.6, B); pb.rect(5, 13, 2, 3 - f, B); pb.rect(10, 13, 2, 2 + f, B);
    pb.circ(9, 5.5, 3.6, B); pb.ell(10, 6.5, 2.4, 2, F); pb.set(9, 5, OUT); pb.set(11, 5, OUT);
    pb.circ(5.5, 4.5, 1.2, F);
    pb.outline(OUT); pb.set(9, 5, OUT); pb.set(11, 5, OUT);
    return pb.cv();
  });
  SP.cr.turtle = crFrames(f => {
    const pb = new PB(20, 16), G = C('#4f9a5a');
    pb.ell(4 + f, 4, 2.4, 1.6, C('#9ac88a')); pb.ell(4 - f, 12, 2.4, 1.6, C('#9ac88a')); pb.ell(14 - f, 4, 2.4, 1.6, C('#9ac88a')); pb.ell(14 + f, 12, 2.4, 1.6, C('#9ac88a'));
    pb.circ(17, 8, 2.2, C('#9ac88a')); pb.set(18, 7, OUT);
    pb.ell(9, 8, 6.5, 5, G);
    for (let i = 0; i < 4; i++) pb.circ(6 + (i % 2) * 5, 6 + Math.floor(i / 2) * 4, 1.4, C('#3a7a4a'));
    pb.ell(8, 6, 3, 1.4, C('#7ac88a'));
    pb.outline(OUT); pb.set(18, 7, OUT);
    return pb.cv();
  });
  SP.cr.parrot = crFrames(f => {
    const pb = new PB(14, 14), R = C('#e83a3a');
    pb.ell(7, 8, 3.2, 4, R); pb.circ(8, 4, 2.6, R);
    pb.poly(f ? [[4, 6], [0, 2], [6, 9]] : [[4, 7], [0, 11], [6, 10]], C('#3a7ae8')); pb.set(2, f ? 4 : 9, C('#ffd84a'));
    pb.rect(10, 4, 2, 2, C('#ffd84a')); pb.set(11, 5, OUT); pb.set(8, 3, OUT);
    pb.rect(6, 12, 1, 2, C('#7a6a3a')); pb.rect(8, 12, 1, 2, C('#7a6a3a'));
    pb.line(5, 11, 3, 13, C('#3a7ae8'));
    pb.outline(OUT); pb.set(8, 3, OUT);
    return pb.cv();
  });
  const fishPB = (f, body, accent, len) => {
    const pb = new PB(len + 4, 10);
    const cx = len / 2 + 2;
    pb.poly(f ? [[2, 2], [2, 8], [5, 5]] : [[1, 3], [1, 7], [5, 5]], accent);
    pb.ell(cx + 1, 5, len / 2 - 0.5, 2.8, body);
    pb.line(cx - 1, 2.5, cx + 2, 1.5, accent);
    pb.ell(cx + 1, 6, len / 2 - 2, 1.2, shade(body, 1.25));
    pb.set(len, 4, OUT);
    pb.outline(OUT);
    return pb.cv();
  };
  SP.cr.fish = [
    crFrames(f => fishPB(f, C('#4a8ae8'), C('#ffd84a'), 10)),
    crFrames(f => { const c = fishPB(f, C('#ff8a2a'), C('#f4f4f4'), 10); return c; }),
    crFrames(f => fishPB(f, C('#ffd84a'), C('#3a6ad8'), 10)),
    crFrames(f => fishPB(f, C('#9ab8d0'), C('#5a7a9a'), 11)),
  ];
  SP.cr.tai = crFrames(f => fishPB(f, C('#f08a9a'), C('#d85a6a'), 14));
  SP.cr.ray = crFrames(f => {
    const pb = new PB(24, 18), B = C('#8a6a4a');
    pb.poly([[4, 9], [12, 2 + f], [20, 9], [12, 15 - f]], B); pb.ell(12, 9, 3, 4, C('#a88a6a'));
    pb.line(4, 9, 0, 9 + f, B); pb.set(14, 7, OUT); pb.set(14, 11, OUT);
    pb.speck(C('#c8b090'), 0.06, 4);
    pb.outline(OUT);
    return pb.cv();
  });
  SP.cr.jelly = crFrames(f => {
    const pb = new PB(14, 18), J = C('#f0a0d8'), JL = C('#ffd8f4');
    for (let i = 0; i < 4; i++) for (let y = 8; y < 17; y++) pb.set(3 + i * 2.6 + Math.sin(y / 2 + f * 2 + i) * 1.2, y, C('#d080c0'), 200);
    pb.ell(7, 6, 5.5, 4.5 - f * 0.5, J); pb.ell(6, 4.5, 2.5, 1.5, JL); pb.rect(2, 8, 10, 1, C('#c070b0'));
    for (let i = 0; i < pb.d.length; i += 4) if (pb.d[i + 3]) pb.d[i + 3] = Math.min(pb.d[i + 3], 215);
    return pb.cv();
  });
  SP.cr.moray = crFrames(f => {
    const pb = new PB(24, 10), G = C('#7a9a3a');
    for (let x = 1; x < 20; x++) { const y = 5 + Math.sin(x / 3 + f * 1.4) * 1.6; pb.rect(x, y - 1.5, 1, 3, G); if ((x * 7) % 5 === 0) pb.set(x, y, C('#d8d86a')); }
    const hy = 5 + Math.sin(20 / 3 + f * 1.4) * 1.6;
    pb.ell(21, hy, 2.6, 2, G); pb.set(22, hy - 1, C('#ffff8a')); pb.line(21, hy + 1, 23, hy + 1, OUT);
    pb.outline(OUT); pb.set(22, hy - 1, C('#ffff8a'));
    return pb.cv();
  });
  SP.cr.shark = crFrames(f => {
    const pb = new PB(38, 18), S = C('#7a8a9a'), W = C('#e8eef2');
    pb.poly(f ? [[2, 3], [7, 9], [2, 15]] : [[1, 5], [7, 9], [3, 16]], S);
    pb.ell(19, 9, 13, 4.5, S); pb.ell(20, 11, 11, 2, W);
    pb.poly([[17, 5], [21, 0], [23, 5]], S); pb.poly([[18, 12], [22, 17], [24, 12]], S);
    pb.set(29, 8, OUT); pb.line(27, 11, 31, 11, OUT); pb.line(10, 8, 26, 7, C('#9aaaba'));
    pb.outline(OUT); pb.set(29, 8, OUT);
    return pb.cv();
  });
  {
    const fr = [];
    for (let f = 0; f < 2; f++) { const pb = new PB(14, 10); pb.poly([[3, 8], [8, 0], [10, 8]], C('#6a7a8a')); pb.line(8, 1, 9, 7, C('#8a9aaa')); pb.outline(OUT); pb.line(0, 9, 13, 9, C('#d8f4ff')); pb.set(f ? 1 : 12, 8, C('#d8f4ff')); fr.push(pb.cv()); }
    SP.cr.fin = { r: fr, l: fr.map(flipCanvas) };
  }
  SP.cr.angler = crFrames(f => {
    const pb = new PB(18, 16), B = C('#3a3248');
    pb.poly([[1, 5], [5, 8], [1, 11]], B);
    pb.ell(9, 9, 6, 5, B); pb.ell(13, 11, 3, 1.6, C('#1a1420'));
    for (let x = 11; x < 16; x += 2) pb.set(x, 10, [255, 255, 255]);
    pb.line(10, 4, 13, 1, C('#5a5068')); pb.line(13, 1, 15, 2, C('#5a5068'));
    pb.circ(16, 3, 1.5, f ? C('#c8ffff') : C('#6af0ff'));
    pb.set(11, 7, C('#ffe04a'));
    pb.outline(OUT); pb.circ(16, 3, 1.2, f ? C('#ffffff') : C('#9af8ff'));
    return pb.cv();
  });
  SP.cr.boss = crFrames(f => {
    const W = 84, H = 64, pb = new PB(W, H), B = C('#2e2840'), BL = C('#4a4064'), r = mulberry32(31);
    pb.poly([[2, 18 + f * 2], [18, 32], [2, 46 - f * 2]], B);
    pb.ell(42, 34, 28, 22, B); pb.ell(38, 26, 16, 8, BL);
    pb.ell(60, 42, 14, 8, C('#120c18'));
    for (let x = 48; x < 74; x += 3) { pb.poly([[x, 35], [x + 1.5, 40], [x + 3, 35]], C('#f0ece0')); pb.poly([[x, 49], [x + 1.5, 44], [x + 3, 49]], C('#f0ece0')); }
    pb.circ(58, 26, 4, C('#ffe04a')); pb.circ(59, 26, 2, OUT);
    pb.line(46, 12, 58, 2, C('#4a4064'), 2); pb.line(58, 2, 70, 6, C('#4a4064'), 2);
    pb.circ(72, 8, 4.5, f ? C('#d8ffff') : C('#6af0ff'));
    pb.poly([[30, 12], [36, 2], [42, 12]], BL); pb.poly([[34, 54], [40, 62], [46, 54]], BL);
    for (let i = 0; i < 20; i++) pb.circ(22 + r() * 40, 22 + r() * 24, 1, C('#5a4e78'));
    pb.outline(OUT);
    pb.circ(72, 8, 3, [255, 255, 255]);
    return pb.cv();
  });
}

/* ---------- アイコン ---------- */
function icon(id, f, o = {}) {
  const pb = new PB(16, 16);
  f(pb);
  if (o.bev !== false) pb.bevel(1.2, 0.75);
  if (o.ol !== false) pb.outline(o.olc ? C(o.olc) : OUT);
  if (o.post) o.post(pb);
  SP.icon[id] = pb.cv();
}
const HANDLE = C('#8a5a32');
function icAxe(head) { return pb => { pb.line(4, 13, 11, 4, HANDLE, 2); pb.poly([[8, 2], [13, 2], [14, 7], [10, 6]], C(head)); pb.line(9, 3, 13, 3, shade(C(head), 1.3)); }; }
function icPick(head) { return pb => { pb.line(4, 13, 10, 5, HANDLE, 2); pb.line(4, 4, 7, 2, C(head), 2); pb.line(7, 2, 10, 3, C(head), 2); pb.line(10, 3, 13, 6, C(head), 2); pb.line(13, 6, 14, 9, C(head), 2); }; }
function icSpear(tip) { return pb => { pb.line(2, 14, 11, 5, HANDLE, 1); pb.line(3, 14, 12, 5, shade(HANDLE, 0.8), 1); pb.poly([[10, 4], [14, 1], [12, 6]], C(tip)); pb.line(9, 7, 11, 5, C('#c8a878')); }; }
function icSword(bl) { return pb => { pb.line(6, 10, 13, 3, C(bl), 2); pb.line(7, 9, 13, 3, shade(C(bl), 1.4)); pb.line(3, 9, 7, 13, C('#c8a040'), 2); pb.line(2, 14, 5, 11, HANDLE, 2); }; }
function buildIcons() {
  const ic = icon;
  ic('wood', pb => { pb.line(3, 12, 12, 4, C('#9a6a3c'), 4); pb.ell(12.5, 4.5, 2.4, 2.4, C('#d8b078')); pb.set(12, 4, C('#9a6a3c')); });
  ic('stone', pb => { pb.ell(8, 9, 6, 4.5, C('#9a9690')); pb.speck(C('#7a7670'), 0.1, 3); });
  ic('fiber', pb => { for (let i = 0; i < 4; i++) pb.line(3 + i * 3, 14, 6 + i * 2, 2, i % 2 ? C('#7fcf55') : C('#5aa83a')); pb.rect(3, 9, 11, 2, C('#c8a878')); }, { bev: false });
  ic('palm_leaf', pb => { pb.line(2, 14, 13, 3, C('#4f9a32')); for (let s = 2; s < 12; s++) { pb.line(2 + s, 14 - s, s - 1, 9 - s * 0.6, C('#5aa83a')); pb.line(2 + s, 14 - s, s + 5, 15 - s * 0.6, C('#7cc44a')); } });
  ic('flint', pb => { pb.poly([[3, 12], [7, 3], [13, 6], [11, 13]], C('#5a5a68')); pb.line(7, 4, 10, 11, C('#9a9ab0')); });
  ic('clay', pb => { pb.ell(8, 10, 6, 4, C('#b8693e')); pb.ell(7, 8, 3, 1.5, C('#d48a5a')); });
  ic('sand', pb => { pb.poly([[2, 13], [8, 4], [14, 13]], C('#ecd59b')); pb.speck(C('#c8b07a'), 0.15, 5); });
  ic('iron_ore', pb => { pb.ell(8, 9, 6, 5, C('#7a7670')); [[5, 7], [9, 10], [10, 6], [6, 11]].forEach(([x, y]) => { pb.rect(x, y, 2, 2, C('#c8783a')); pb.set(x, y, C('#f0a868')); }); });
  ic('coal', pb => { pb.ell(6, 10, 4, 3.5, C('#2e2a32')); pb.ell(11, 9, 3.5, 3, C('#3a3640')); pb.ell(8, 6, 3, 2.5, C('#34303a')); });
  const ingot = c => pb => { pb.poly([[2, 11], [5, 6], [14, 6], [12, 11]], C(c)); pb.poly([[2, 11], [12, 11], [12, 13], [2, 13]], shade(C(c), 0.7)); pb.line(6, 7, 12, 7, shade(C(c), 1.35)); };
  ic('iron', ingot('#b0b4c0'));
  ic('glass', pb => { pb.rect(3, 3, 10, 11, C('#9ad8f0')); pb.line(5, 11, 10, 5, [255, 255, 255]); pb.line(5, 8, 7, 6, [255, 255, 255]); }, { bev: false });
  ic('obsidian', pb => { pb.poly([[4, 13], [6, 3], [11, 2], [13, 12]], C('#2a2238')); pb.line(7, 4, 9, 12, C('#9a8ad0')); pb.line(10, 3, 12, 10, C('#5a4a80')); });
  ic('shell', pb => pb.blit(shellPB(), 0, -2), { bev: false });
  ic('pearl', pb => { pb.circ(8, 8, 4.5, C('#f4f0f8')); pb.circ(6.5, 6.5, 1.5, [255, 255, 255]); pb.set(10, 10, C('#c8c0e0')); });
  ic('coral', pb => branchCoral(pb, 8, 14, -Math.PI / 2, 5, 2, [C('#ff6a7a'), C('#ffc0c8')], mulberry32(9)), { bev: false });
  ic('seaweed', pb => { for (let i = 0; i < 3; i++) for (let y = 2; y < 15; y++) pb.set(4 + i * 4 + Math.sin(y / 2 + i) * 1.5, y, i % 2 ? C('#4a8a3a') : C('#6aaa4a')); pb.rect(4, 12, 9, 2, C('#3a6a2a')); }, { bev: false });
  ic('rope', pb => { pb.circ(8, 8, 5.5, C('#c8a060')); for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const dd = d2(x + 0.5, y + 0.5, 8, 8); if (dd < 7) pb.set(x, y, [0, 0, 0], 0); } pb.line(11, 11, 14, 14, C('#c8a060')); for (let a = 0; a < 6.3; a += 0.8) pb.set(8 + Math.cos(a) * 4.2, 8 + Math.sin(a) * 4.2, C('#8a6a3a')); });
  ic('cloth', pb => { pb.poly([[2, 5], [12, 3], [14, 11], [4, 13]], C('#e8e0cc')); pb.line(4, 7, 12, 5, C('#c8bea8')); pb.line(5, 10, 13, 8, C('#c8bea8')); });
  ic('plank', pb => { pb.poly([[2, 10], [12, 2], [14, 5], [4, 13]], C('#c8925a')); pb.line(4, 10, 12, 4, C('#9a6a3c')); });
  ic('hide', pb => { pb.poly([[3, 4], [8, 2], [13, 4], [14, 9], [11, 14], [5, 14], [2, 9]], C('#a87048')); pb.speck(C('#8a5a3a'), 0.1, 6); });
  ic('resin', pb => { pb.circ(8, 10, 4, C('#e8a030')); pb.poly([[6, 8], [8, 2], [10, 8]], C('#e8a030')); pb.set(7, 9, C('#fff0a0')); });
  ic('bamboo', pb => { pb.line(4, 14, 12, 2, C('#7fb84a'), 3); for (let i = 1; i < 4; i++) pb.line(3 + i * 2.6, 13 - i * 3.6, 6 + i * 2.6, 13 - i * 3.6, C('#4f8a2e')); });
  ic('herb', pb => { [[-1.2, 6], [-1.9, 6], [-0.5, 5], [-2.6, 5]].forEach(([a, l]) => { for (let s = 0; s < l; s += 0.5) pb.circ(8 + Math.cos(a) * s, 13 + Math.sin(a) * s, 1.3 * Math.sin(Math.PI * s / l) + 0.4, C('#7fd05a')); }); pb.set(6, 5, [255, 255, 255]); pb.set(10, 5, [255, 255, 255]); });
  ic('shark_tooth', pb => { pb.poly([[4, 3], [12, 3], [8, 14]], C('#f4f0e4')); pb.line(5, 4, 8, 12, [255, 255, 255]); });
  ic('shark_skin', pb => { pb.poly([[3, 4], [13, 3], [14, 12], [2, 13]], C('#7a8a9a')); pb.poly([[3, 10], [14, 9], [14, 12], [2, 13]], C('#d8e0e8')); });
  ic('glow_jelly', pb => { pb.ell(8, 9, 5, 4.5, C('#5ae0f0')); pb.circ(6.5, 7.5, 1.6, C('#d8ffff')); }, { olc: '#1a4a5a' });
  ic('crab_shell', pb => { pb.ell(8, 9, 6.5, 5, C('#5b4a9f')); pb.ell(7, 7, 3.5, 2, C('#8a7ad0')); pb.set(5, 10, C('#e88a3a')); pb.set(11, 10, C('#e88a3a')); });
  ic('deep_orb', pb => { pb.circ(8, 8, 5.5, C('#2a4ad0')); pb.circ(8, 8, 3.5, C('#5a8af8')); pb.circ(6.5, 6.5, 1.5, C('#e0f0ff')); }, { olc: '#0a1440' });
  ic('arrow', pb => { pb.line(3, 13, 12, 4, HANDLE); pb.poly([[11, 3], [14, 2], [13, 5]], C('#7a7a88')); pb.line(2, 12, 4, 14, [240, 240, 240]); pb.line(3, 11, 5, 13, [240, 240, 240]); }, { bev: false });
  ic('compass', pb => { pb.circ(8, 8, 6, C('#d8a040')); pb.circ(8, 8, 4.5, C('#f4ecd0')); pb.line(8, 8, 10, 4, C('#e83a3a')); pb.line(8, 8, 6, 12, C('#3a4a6a')); pb.set(8, 8, OUT); }, { bev: false });
  const chartPiece = (pts, mark) => pb => { pb.poly(pts, C('#e8d8a8')); pb.line(4, 6, 11, 7, C('#a88a5a')); pb.line(5, 10, 10, 9, C('#a88a5a')); pb.set(mark[0], mark[1], C('#e83a3a')); pb.set(mark[0] + 1, mark[1] + 1, C('#e83a3a')); pb.set(mark[0] + 1, mark[1], C('#e83a3a')); pb.set(mark[0], mark[1] + 1, C('#e83a3a')); };
  ic('chart_a', chartPiece([[2, 3], [12, 2], [10, 8], [13, 14], [3, 13]], [6, 8]), { bev: false });
  ic('chart_b', chartPiece([[4, 2], [14, 3], [13, 13], [5, 14], [7, 8]], [9, 5]), { bev: false });
  ic('chart_c', chartPiece([[2, 4], [9, 2], [14, 5], [12, 13], [2, 12]], [8, 10]), { bev: false });
  ic('chart', pb => { pb.rect(2, 3, 12, 10, C('#e8d8a8')); pb.rect(1, 2, 2, 12, C('#a87040')); pb.rect(13, 2, 2, 12, C('#a87040')); pb.line(4, 9, 7, 5, C('#4a8ae8')); pb.line(7, 5, 11, 8, C('#4a8ae8')); pb.set(11, 8, C('#e83a3a')); pb.set(10, 7, C('#e83a3a')); }, { bev: false });
  ic('ancient_key', pb => { pb.circ(5, 6, 3.6, C('#5ac8b0')); for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) if (d2(x + 0.5, y + 0.5, 5, 6) < 2.4) pb.set(x, y, [0, 0, 0], 0); pb.line(7, 8, 13, 13, C('#5ac8b0'), 2); pb.rect(11, 12, 2, 3, C('#5ac8b0')); pb.rect(9, 11, 2, 2, C('#5ac8b0')); });
  ic('diver_memo', pb => { pb.rect(3, 2, 10, 12, C('#f4ecd0')); for (let y = 4; y < 13; y += 2) pb.line(5, y, 11, y, C('#8a8a9a')); pb.circ(10, 11, 2, C('#4a8ae8')); }, { bev: false });
  ic('hull', pb => { pb.poly([[1, 6], [15, 6], [12, 13], [4, 13]], C('#8a5a32')); pb.line(1, 6, 15, 6, C('#c8925a')); pb.line(5, 8, 5, 12, C('#5a3a22')); pb.line(11, 8, 11, 12, C('#5a3a22')); });
  ic('sail', pb => { pb.rect(7, 1, 1, 14, C('#7a5232')); pb.poly([[8, 2], [8, 12], [14, 11]], C('#f4eee0')); pb.poly([[6, 3], [6, 12], [2, 11]], C('#e0d8c8')); });
  // 食べ物
  ic('berry', pb => { [[6, 9], [10, 9], [8, 6], [8, 11], [5, 12], [11, 12]].forEach(([x, y]) => { pb.circ(x, y, 2, C('#c8304a')); pb.set(x - 1, y - 1, C('#ff8a9a')); }); pb.line(8, 4, 9, 2, C('#5aa040')); });
  ic('coconut', pb => { pb.circ(8, 9, 5.5, C('#7a5232')); pb.set(6, 7, OUT); pb.set(9, 7, OUT); pb.set(7.5, 10, OUT); pb.speck(C('#9a6e42'), 0.1, 7); });
  ic('banana', pb => { for (let a = 0.3; a < 2.6; a += 0.05) { pb.circ(8 + Math.cos(a) * 6, 4 + Math.sin(a) * 7, 1.5, C('#ffd84a')); } pb.rect(12, 3, 2, 2, C('#7a5a2a')); });
  ic('mushroom', pb => { pb.rect(7, 8, 3, 6, C('#f0e2c8')); pb.ell(8, 7, 6, 4, C('#d83a2e')); pb.set(6, 5, [255, 255, 255]); pb.set(10, 6, [255, 255, 255]); pb.set(8, 4, [255, 255, 255]); });
  ic('mushroom_c', pb => { pb.rect(7, 8, 3, 6, C('#c8a070')); pb.ell(8, 7, 6, 4, C('#8a4a2a')); pb.set(6, 5, C('#c8a070')); });
  const fishIc = (b, a) => pb => { pb.poly([[1, 5], [1, 11], [4, 8]], C(a)); pb.ell(9, 8, 5.5, 3.5, C(b)); pb.set(12, 7, OUT); pb.line(7, 6, 9, 5, C(a)); };
  ic('fish_raw', fishIc('#6aa0e0', '#3a6ab0'));
  ic('fish_c', fishIc('#c88a4a', '#8a5a2a'), { post: pb => { pb.line(6, 9, 11, 9, C('#6a3a1a')); } });
  const meatIc = (m, b) => pb => { pb.ell(9, 7, 5, 4.5, C(m)); pb.line(4, 12, 7, 9, C('#f0ece0'), 2); pb.circ(3.5, 12.5, 1.4, C('#f0ece0')); pb.ell(10, 6, 2, 1.4, C(b)); };
  ic('meat_raw', meatIc('#e86a7a', '#ffb0b8'));
  ic('meat_c', meatIc('#9a5a32', '#c88a5a'));
  ic('crab_raw', pb => { pb.ell(8, 9, 5, 3.5, C('#f4e8e0')); pb.ell(8, 8, 4, 2, C('#e86a5a')); pb.circ(3, 6, 2, C('#e86a5a')); pb.circ(13, 6, 2, C('#e86a5a')); });
  ic('crab_c', pb => { pb.ell(8, 9, 5, 3.5, C('#ff8a3a')); pb.ell(8, 8, 3, 1.5, C('#ffc080')); pb.circ(3, 6, 2, C('#ff7a2a')); pb.circ(13, 6, 2, C('#ff7a2a')); });
  ic('clam', pb => { pb.ell(8, 9, 6, 4, C('#c8b8a0')); for (let x = 3; x < 14; x += 2) pb.line(8, 12, x, 6, C('#a89880')); });
  ic('clam_c', pb => { pb.ell(8, 10, 6, 3, C('#c8b8a0')); pb.ell(8, 8, 4, 2, C('#f0c080')); pb.set(7, 7, C('#fff0c0')); });
  ic('potato', pb => { pb.ell(8, 9, 5.5, 4, C('#b88a4a')); pb.set(6, 8, C('#7a5a2a')); pb.set(10, 10, C('#7a5a2a')); pb.set(9, 7, C('#7a5a2a')); });
  ic('potato_c', pb => { pb.ell(8, 9, 5.5, 4, C('#9a5a2a')); pb.line(5, 8, 11, 9, C('#ffd06a'), 2); });
  ic('seaweed_c', pb => { pb.rect(3, 4, 10, 9, C('#2a4a2a')); pb.speck(C('#4a6a3a'), 0.2, 8); pb.line(3, 6, 12, 6, C('#1a3a1a')); });
  ic('urchin', pb => { for (let i = 0; i < 12; i++) { const a = i / 12 * 6.28; pb.line(8, 8, 8 + Math.cos(a) * 6, 8 + Math.sin(a) * 6, C('#5a3a7a')); } pb.circ(8, 8, 3, C('#ff9a3a')); pb.set(7, 7, C('#ffd08a')); }, { bev: false });
  ic('feast', pb => { pb.ell(8, 11, 7, 3, C('#e8e0d0')); pb.ell(6, 9, 3, 2, C('#9a5a32')); pb.ell(10, 9, 3, 1.6, C('#c88a4a')); pb.circ(8, 7, 1.6, C('#ffd84a')); pb.set(11, 7, C('#5aa040')); });
  ic('water', pb => { pb.rect(5, 3, 6, 11, C('#7fb84a')); pb.rect(5, 6, 6, 6, C('#4ab0f0')); pb.rect(6, 1, 4, 2, C('#c8a070')); pb.line(5, 5, 10, 5, C('#4f8a2e')); });
  ic('canteen', pb => { pb.rect(5, 3, 6, 11, C('#7fb84a')); pb.rect(6, 1, 4, 2, C('#c8a070')); pb.line(5, 5, 10, 5, C('#4f8a2e')); pb.line(5, 10, 10, 10, C('#4f8a2e')); });
  ic('bandage', pb => { pb.circ(8, 8, 5, C('#f4f0e8')); pb.circ(8, 8, 2, C('#d8d0c0')); pb.line(10, 12, 14, 13, C('#f4f0e8'), 2); pb.rect(7, 4, 2, 8, C('#e84a4a')); pb.rect(4, 7, 8, 2, C('#e84a4a')); });
  ic('antidote', pb => { pb.ell(8, 10, 4.5, 4, C('#5ad870')); pb.rect(7, 2, 2, 5, C('#c8e8f0')); pb.rect(6, 1, 4, 2, C('#a87040')); pb.set(6, 9, C('#c8ffd0')); });
  // 道具
  ic('axe_s', icAxe('#8a8a92')); ic('axe_i', icAxe('#c8ccd8'));
  ic('pick_s', icPick('#8a8a92')); ic('pick_i', icPick('#c8ccd8'));
  ic('spear_s', icSpear('#8a8a92')); ic('spear_i', icSpear('#d8dce8'));
  ic('sword_o', icSword('#5a4a8a'));
  ic('shovel', pb => { pb.line(3, 13, 10, 6, HANDLE, 2); pb.poly([[9, 4], [12, 1], [15, 4], [12, 7]], C('#9a9aa2')); pb.line(2, 14, 4, 12, C('#c8a878'), 2); });
  ic('rod', pb => { pb.line(2, 14, 12, 2, HANDLE); pb.line(12, 2, 13, 10, C('#e8e8e8')); pb.circ(13, 11, 1.4, C('#e83a3a')); pb.rect(2, 12, 2, 2, C('#4a4a52')); }, { bev: false });
  ic('bow', pb => { for (let a = -1.2; a <= 1.2; a += 0.05) pb.set(5 + Math.cos(a) * 7, 8 + Math.sin(a) * 7, HANDLE); for (let a = -1.2; a <= 1.2; a += 0.05) pb.set(6 + Math.cos(a) * 7, 8 + Math.sin(a) * 7, HANDLE); pb.line(7, 1, 7, 15, C('#f4f0e0')); });
  ic('harpoon', pb => { pb.line(2, 14, 12, 4, C('#7a7a88')); pb.poly([[11, 3], [15, 1], [13, 5]], C('#d8dce8')); pb.line(10, 6, 12, 7, C('#d8dce8')); pb.line(9, 4, 10, 6, C('#d8dce8')); pb.rect(3, 11, 3, 3, C('#c8a060')); });
  ic('torch', pb => { pb.line(5, 14, 9, 7, HANDLE, 2); pb.rect(8, 5, 3, 3, C('#c8a070')); flamePB(pb, 10, 6, 0, 0.7); });
  ic('lantern', pb => { pb.rect(4, 5, 8, 9, C('#5ae0f0')); pb.rect(4, 4, 8, 1, C('#7a7a88')); pb.rect(4, 13, 8, 1, C('#7a7a88')); pb.rect(6, 1, 4, 3, C('#7a7a88')); pb.circ(8, 9, 2, C('#e0ffff')); });
  // 設置物
  const fromObj = (id, k, sx, sy, sw, sh) => { const src = SP.obj[O[k]][0][0]; const [c, x] = mkCanvas(16, 16); const w = sw || src.width, h = sh || src.height; const scl = Math.min(1, 16 / w, 16 / h); const dw = Math.round(w * scl), dh = Math.round(h * scl); x.drawImage(src, sx || 0, sy || 0, w, h, Math.floor((16 - dw) / 2), Math.floor((16 - dh) / 2), dw, dh); SP.icon[id] = c; };
  fromObj('bench', 'BENCH'); fromObj('campfire', 'CAMPFIRE'); fromObj('chest', 'STORAGE'); fromObj('bed', 'BED'); fromObj('floor', 'FLOOR'); fromObj('trap', 'TRAP');
  ic('furnace', pb => { pb.ell(8, 9, 6, 6, C('#8a8580')); pb.ell(8, 12, 2.6, 2, C('#ff8a2a')); pb.rect(6, 1, 4, 3, C('#7a7570')); });
  ic('rain', pb => { pb.rect(4, 7, 8, 8, C('#9a6a3c')); pb.poly([[1, 3], [15, 3], [11, 7], [5, 7]], C('#4f9a3a')); pb.rect(4, 10, 8, 1, C('#5a5a62')); });
  ic('wall', pb => { for (let i = 0; i < 3; i++) { pb.rect(2 + i * 4, 4, 3, 11, C('#9a6a3c')); pb.poly([[2 + i * 4, 4], [3.5 + i * 4, 1], [5 + i * 4, 4]], C('#9a6a3c')); } pb.rect(1, 9, 14, 1, C('#c8a878')); });
  ic('door', pb => { pb.rect(3, 2, 10, 13, C('#c08a50')); pb.rect(3, 2, 10, 1, C('#7a5232')); pb.line(6, 3, 6, 14, C('#9a6a3c')); pb.line(9, 3, 9, 14, C('#9a6a3c')); pb.rect(10, 8, 1, 2, C('#ffcf4a')); });
  ic('shipyard', pb => { pb.rect(1, 11, 14, 2, C('#9a6a3c')); for (let x = 3; x < 14; x += 3) pb.line(x, 11, x - 1, 5, C('#9a6a3c')); pb.line(2, 5, 14, 5, C('#6a4428')); });
  ic('raft', pb => { for (let i = 0; i < 5; i++) pb.rect(2 + i * 2.5, 3, 2, 10, i % 2 ? C('#9a6a3c') : C('#b88a54')); pb.rect(1, 5, 14, 1, C('#c8a878')); pb.rect(1, 10, 14, 1, C('#c8a878')); });
  // 装備
  ic('mask', pb => { pb.rect(2, 6, 12, 5, C('#33404e')); pb.rect(3, 7, 4, 3, C('#9fe3ff')); pb.rect(9, 7, 4, 3, C('#9fe3ff')); pb.set(4, 7, [255, 255, 255]); pb.set(10, 7, [255, 255, 255]); pb.rect(0, 8, 2, 1, C('#33404e')); pb.rect(14, 8, 2, 1, C('#33404e')); });
  ic('headlamp', pb => { pb.rect(2, 7, 12, 5, C('#33404e')); pb.rect(3, 8, 4, 3, C('#9fe3ff')); pb.rect(9, 8, 4, 3, C('#9fe3ff')); pb.rect(6, 3, 4, 4, C('#7a7a88')); pb.rect(7, 4, 2, 2, C('#fff2a0')); });
  ic('helmet', pb => { pb.ell(8, 9, 6, 6, C('#b0b4c0')); for (let y = 10; y < 16; y++) for (let x = 0; x < 16; x++) pb.set(x, y, [0, 0, 0], 0); pb.rect(1, 9, 14, 2, C('#8a8e9a')); });
  const shirt = (c, c2) => pb => { pb.poly([[2, 4], [6, 2], [10, 2], [14, 4], [13, 8], [11, 7], [11, 14], [5, 14], [5, 7], [3, 8]], C(c)); pb.line(6, 2, 8, 5, C(c2)); pb.line(10, 2, 8, 5, C(c2)); };
  ic('grass_cloth', shirt('#7cc44a', '#4f9a32')); ic('leather', shirt('#a87048', '#7a4a2a')); ic('iron_armor', shirt('#b0b4c0', '#7a7e8a'));
  ic('crab_armor', shirt('#6b5aaf', '#e88a3a')); ic('wetsuit', shirt('#2a3a4a', '#4ab0d0'));
  ic('fins', pb => { pb.poly([[2, 3], [7, 3], [8, 14], [1, 13]], C('#2a8a9a')); pb.poly([[9, 3], [14, 3], [15, 13], [8, 14]], C('#2a8a9a')); pb.rect(2, 3, 5, 3, C('#33404e')); pb.rect(9, 3, 5, 3, C('#33404e')); });
  ic('boots', pb => { pb.rect(3, 3, 4, 9, C('#a87048')); pb.rect(3, 11, 6, 3, C('#a87048')); pb.rect(9, 4, 4, 8, C('#8a5a3a')); pb.rect(9, 11, 6, 3, C('#8a5a3a')); });
  ic('tank', pb => { pb.rect(5, 3, 6, 11, C('#e8c040')); pb.ell(8, 3, 3, 1.5, C('#e8c040')); pb.rect(7, 0, 2, 2, C('#7a7a88')); pb.rect(5, 6, 6, 1, C('#7a5a1a')); });
  ic('tank_l', pb => { pb.rect(2, 3, 5, 11, C('#e86a40')); pb.rect(9, 3, 5, 11, C('#e86a40')); pb.rect(3, 1, 2, 2, C('#7a7a88')); pb.rect(11, 1, 2, 2, C('#7a7a88')); pb.rect(2, 7, 12, 1, C('#7a3a1a')); });
  ic('charm_pearl', pb => { for (let a = 0; a < 6.3; a += 0.3) pb.set(8 + Math.cos(a) * 5, 7 + Math.sin(a) * 5, C('#c8a060')); pb.circ(8, 12, 2.5, C('#f4f0f8')); pb.set(7, 11, [255, 255, 255]); }, { bev: false });
  ic('charm_tooth', pb => { for (let a = 0; a < 6.3; a += 0.3) pb.set(8 + Math.cos(a) * 5, 6 + Math.sin(a) * 5, C('#c8a060')); pb.poly([[6, 10], [10, 10], [8, 15]], C('#f4f0e4')); }, { bev: false });
  ic('charm_deep', pb => { for (let a = 0; a < 6.3; a += 0.3) pb.set(8 + Math.cos(a) * 5, 6 + Math.sin(a) * 5, C('#c8a060')); pb.circ(8, 12, 2.8, C('#3a6af0')); pb.set(7, 11, C('#d0e8ff')); }, { bev: false });
  for (const k in ITEMS) if (!SP.icon[k]) { const [c, x] = mkCanvas(16, 16); x.fillStyle = '#f0f'; x.fillRect(4, 4, 8, 8); SP.icon[k] = c; }
}
function iconURL(id) {
  if (!SP.iconURL[id]) {
    const [c, x] = mkCanvas(32, 32);
    x.drawImage(SP.icon[id] || SP.icon.stone, 0, 0, 32, 32);
    SP.iconURL[id] = c.toDataURL();
  }
  return SP.iconURL[id];
}

/* ---------- エフェクト ---------- */
function buildFX() {
  // 斬撃（右向き基準・3コマ）
  SP.fx.slash = [];
  for (let f = 0; f < 3; f++) {
    const pb = new PB(28, 28);
    const a0 = -1.3 + f * 0.55, a1 = a0 + 1.4;
    for (let a = a0; a < a1; a += 0.03) {
      for (let rr = 9; rr < 13; rr++) { const t = (a - a0) / (a1 - a0); const col = rr >= 12 ? [255, 255, 255] : [170, 220, 255]; pb.set(14 + Math.cos(a) * rr, 14 + Math.sin(a) * rr, col, Math.round(255 * Math.min(1, t * 1.6))); }
    }
    SP.fx.slash.push(pb.cv());
  }
  SP.fx.slashD = SP.fx.slash.map(c => rotCanvas(c, 1));
  SP.fx.slashL = SP.fx.slash.map(c => rotCanvas(c, 2));
  SP.fx.slashU = SP.fx.slash.map(c => rotCanvas(c, 3));
  // いかだ
  {
    const pb = new PB(22, 18);
    for (let i = 0; i < 6; i++) { pb.rect(1 + i * 3.4, 2, 3, 14, i % 2 ? C('#9a6a3c') : C('#b88a54')); pb.set(1 + i * 3.4, 2, C('#d8a870')); }
    pb.rect(0, 4, 22, 2, C('#c8a878')); pb.rect(0, 12, 22, 2, C('#c8a878'));
    pb.outline(OUT);
    SP.fx.raft = pb.cv();
  }
  // 選択カーソル
  {
    const pb = new PB(18, 18), W = [255, 255, 255];
    [[0, 0, 1, 1], [17, 0, -1, 1], [0, 17, 1, -1], [17, 17, -1, -1]].forEach(([x, y, dx, dy]) => { for (let i = 0; i < 4; i++) { pb.set(x + dx * i, y, W); pb.set(x, y + dy * i, W); } });
    SP.fx.cursor = pb.cv();
  }
  // HUDアイコン
  const hud = (f) => { const pb = new PB(9, 9); f(pb); pb.outline(OUT); return pb.cv(); };
  SP.fx.hHeart = hud(pb => { pb.circ(2.5, 3, 2.2, C('#ff4a5a')); pb.circ(6.5, 3, 2.2, C('#ff4a5a')); pb.poly([[0.5, 3.5], [8.5, 3.5], [4.5, 8]], C('#ff4a5a')); pb.set(2, 2, [255, 200, 200]); });
  SP.fx.hFood = hud(pb => { pb.ell(5, 4, 3, 2.6, C('#d8803a')); pb.line(2, 7, 3, 6, C('#f0ece0')); pb.set(1, 8, C('#f0ece0')); pb.set(4, 3, C('#ffc080')); });
  SP.fx.hWater = hud(pb => { pb.poly([[4.5, 0.5], [8, 5.5], [1, 5.5]], C('#4ab0f0')); pb.circ(4.5, 5.5, 3.2, C('#4ab0f0')); pb.set(3, 5, C('#c0f0ff')); });
  SP.fx.hStam = hud(pb => { pb.poly([[5, 0], [1, 5], [4, 5], [3, 9], [8, 3], [5, 3]], C('#ffd84a')); });
  SP.fx.hO2 = hud(pb => { pb.circ(4.5, 4.5, 3.5, C('#9fe3ff')); pb.circ(4.5, 4.5, 2, C('#4ab0f0')); pb.set(3, 3, [255, 255, 255]); });
  SP.fx.hPoison = hud(pb => { pb.circ(4.5, 4, 3.4, C('#8ae04a')); pb.set(3, 3, OUT); pb.set(6, 3, OUT); pb.rect(3, 6, 3, 2, C('#8ae04a')); });
  SP.fx.sun = hud(pb => { pb.circ(4.5, 4.5, 2.6, C('#ffd84a')); [[4, 0], [4, 8], [0, 4], [8, 4]].forEach(([x, y]) => pb.set(x, y, C('#ffd84a'))); });
  SP.fx.moon = hud(pb => { pb.circ(4.5, 4.5, 3.4, C('#f0f0c8')); for (let y = 0; y < 9; y++) for (let x = 0; x < 9; x++) if (d2(x + 0.5, y + 0.5, 6.2, 3.4) < 6) pb.set(x, y, [0, 0, 0], 0); });
  SP.fx.rain = hud(pb => { pb.ell(4.5, 3, 4, 2.2, C('#b0c0d0')); pb.line(2, 6, 1, 8, C('#4ab0f0')); pb.line(5, 6, 4, 8, C('#4ab0f0')); pb.line(8, 6, 7, 8, C('#4ab0f0')); });
  SP.fx.bubble = (() => { const pb = new PB(5, 5); pb.circ(2.5, 2.5, 2, C('#c8f0ff')); pb.set(2, 2, C('#4ab0f0')); pb.set(1, 1, [255, 255, 255]); return pb.cv(); })();
  SP.fx.bubbleE = (() => { const pb = new PB(5, 5); pb.circ(2.5, 2.5, 2, C('#3a5a7a')); return pb.cv(); })();
  // 投射物
  SP.fx.arrow = (() => { const pb = new PB(10, 3); pb.line(0, 1, 8, 1, HANDLE); pb.set(9, 1, C('#d8d8e0')); pb.set(0, 0, [255, 255, 255]); pb.set(0, 2, [255, 255, 255]); return pb.cv(); })();
  SP.fx.coco = (() => { const pb = new PB(6, 6); pb.circ(3, 3, 2.5, C('#7a5232')); pb.set(2, 2, C('#9a6e42')); return pb.cv(); })();
  SP.fx.orb = (() => { const pb = new PB(8, 8); pb.circ(4, 4, 3.5, C('#5ae0f0')); pb.circ(4, 4, 2, C('#e0ffff')); return pb.cv(); })();
  SP.fx.rockp = (() => { const pb = new PB(8, 8); pb.circ(4, 4, 3.2, C('#6a5a58')); pb.bevel(); pb.outline(OUT); return pb.cv(); })();
  SP.fx.ship = (() => {
    const pb = new PB(48, 40);
    pb.poly([[2, 26], [46, 26], [40, 36], [8, 36]], C('#8a5a32')); pb.rect(2, 26, 44, 2, C('#c8925a'));
    pb.rect(23, 2, 2, 25, C('#7a5232'));
    pb.poly([[25, 3], [25, 23], [42, 21]], C('#f4eee0')); pb.poly([[22, 5], [22, 22], [8, 21]], C('#e8e2d2'));
    pb.rect(24, 0, 6, 3, C('#e84a3a'));
    pb.outline(OUT);
    return pb.cv();
  })();
}

/* ---------- タイトルロゴ ---------- */
const LOGO_FONT = {
  T: ['11111', '00100', '00100', '00100', '00100', '00100', '00100'],
  I: ['111', '010', '010', '010', '010', '010', '111'],
  D: ['11110', '10011', '10001', '10001', '10001', '10011', '11110'],
  E: ['11111', '10000', '10000', '11110', '10000', '10000', '11111'],
  B: ['11110', '10001', '10001', '11110', '10001', '10001', '11110'],
  O: ['01110', '10001', '10001', '10001', '10001', '10001', '01110'],
  U: ['10001', '10001', '10001', '10001', '10001', '10001', '01110'],
  N: ['10001', '11001', '10101', '10101', '10011', '10001', '10001'],
};
function drawLogo(cv) {
  const x = cv.getContext('2d'); x.imageSmoothingEnabled = false;
  const W = 120, H = 36, pb = new PB(W, H);
  const word = 'TIDEBOUND';
  let tw = 0; for (const ch of word) tw += LOGO_FONT[ch][0].length + 1; tw -= 1;
  const sc = 2, ox = Math.floor((W - tw * sc) / 2), oy = 3;
  let cx = ox;
  for (const ch of word) {
    const g = LOGO_FONT[ch];
    for (let r = 0; r < 7; r++) for (let c = 0; c < g[r].length; c++) if (g[r][c] === '1') {
      for (let yy = 0; yy < sc; yy++) for (let xx = 0; xx < sc; xx++) {
        const py = oy + r * sc + yy, t = py / (oy + 14);
        pb.set(cx + c * sc + xx, py, mixc(C('#fff8d8'), C('#3ab0f0'), clamp(t, 0, 1)));
      }
    }
    cx += (g[0].length + 1) * sc;
  }
  pb.outline(C('#0a2448'));
  pb.outline(C('#f8e8a8'));
  for (let i = 0; i < W; i++) { const y = 26 + Math.round(Math.sin(i / 5) * 1.5); pb.set(i, y, C('#4ab0f0')); pb.set(i, y + 1, C('#2a78c0')); if (i % 7 === 0) pb.set(i, y - 1, [255, 255, 255]); }
  for (let i = 0; i < W; i++) { const y = 31 + Math.round(Math.sin(i / 6 + 2) * 1.2); pb.set(i, y, C('#2a78c0')); }
  x.clearRect(0, 0, cv.width, cv.height);
  x.drawImage(pb.cv(), 0, 0, cv.width, cv.height);
}

function buildArt() { buildTerrain(); buildObjects(); buildPlayer(); buildCreatures(); buildIcons(); buildFX(); }
/* =============================================================
   ワールド生成（本島・小島・川・湖・海底・ランドマーク）
   ============================================================= */
let G = null;
const idx = (x, y) => y * MAP + x;
const inb = (x, y) => x >= 0 && y >= 0 && x < MAP && y < MAP;
const okey = (l, i) => l * MM + i;

function genWorld(seed) {
  const N = MAP, s = seed % 1000003;
  const R = mulberry32(seed);
  const elev = new Float32Array(MM), trench = new Float32Array(MM);
  const ground = new Uint8Array(MM), seabed = new Uint8Array(MM), objS = new Uint8Array(MM), objU = new Uint8Array(MM);
  const reserved = new Uint8Array(MM);
  const objData = new Map();
  const cx = N / 2 + (R() - 0.5) * 8, cy = N / 2 + (R() - 0.5) * 8;
  const ang = -Math.PI * (0.25 + R() * 0.5);
  const polar = (a, dd) => ({ x: Math.round(N / 2 + Math.cos(a) * dd * N), y: Math.round(N / 2 + Math.sin(a) * dd * N) });
  const isl = [
    Object.assign({ k: 'volcano', r: 18, h: 0.64 }, polar(ang, 0.38)),
    Object.assign({ k: 'sandisle', r: 12, h: 0.48 }, polar(ang + 2.0, 0.38)),
    Object.assign({ k: 'rockisle', r: 12, h: 0.56 }, polar(ang - 2.0, 0.37)),
  ];
  const trC = polar(ang + Math.PI + 0.5, 0.39);
  const mtn = { x: cx + (R() - 0.5) * 24, y: cy + (R() - 0.5) * 24 };

  // ---- 標高 ----
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const i = y * N + x;
    const nx = (x - cx) / (N / 2), ny = (y - cy) / (N / 2);
    const wx = nx + (fbm(x / 48, y / 48, s + 7, 3) - 0.5) * 0.32, wy = ny + (fbm(x / 48, y / 48, s + 13, 3) - 0.5) * 0.32;
    const d = Math.sqrt(wx * wx + wy * wy);
    const n = fbm(x / 38, y / 38, s, 5);
    let e = 0.5 - d + (n - 0.5) * 0.5;
    e += 0.42 * Math.exp(-d2(x, y, mtn.x, mtn.y) / (2 * 22 * 22)) * (0.6 + 0.8 * fbm(x / 20, y / 20, s + 31, 3));
    for (const I of isl) e += I.h * Math.exp(-d2(x, y, I.x, I.y) / (2 * I.r * I.r)) * (0.8 + 0.4 * fbm(x / 14, y / 14, s + 41, 2));
    const tb = Math.exp(-d2(x, y, trC.x, trC.y) / (2 * 24 * 24));
    trench[i] = tb; e -= 0.36 * tb;
    elev[i] = e;
  }
  // ---- 地表 ----
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const i = y * N + x, e = elev[i];
    let g;
    if (e < -0.16) g = T.DEEP;
    else if (e < -0.035) g = T.OCEAN;
    else if (e < 0) g = T.SHALLOW;
    else if (e < 0.05) g = T.SAND;
    else {
      const m = fbm(x / 44, y / 44, s + 50, 4) + (x - cx) / N * 0.3;
      const cn = fbm(x / 12, y / 12, s + 60, 3);
      if (e > 0.6 && cn > 0.5) g = T.CLIFF;
      else if (e > 0.44) g = T.ROCK;
      else if (m > 0.58) g = T.JUNGLE;
      else if (m > 0.47) g = T.FOREST;
      else g = fbm(x / 9, y / 9, s + 70, 2) > 0.76 ? T.DIRT : T.GRASS;
    }
    for (const I of isl) {
      const di = Math.sqrt(d2(x, y, I.x, I.y));
      if (di > I.r * 1.6 || e < 0.05) continue;
      if (I.k === 'volcano') { if (di < 3.3) g = T.LAVA; else if (di < I.r * 0.78) g = T.VOLC; }
      else if (I.k === 'rockisle') g = fbm(x / 6, y / 6, s + 80, 2) > 0.62 ? T.GRASS : T.ROCK;
      else g = e > 0.2 ? T.GRASS : T.SAND;
    }
    ground[i] = g;
  }
  // ---- 川 ----
  const visited = new Uint8Array(MM);
  const carveLake = (lx, ly, rr) => {
    for (let y = -rr - 2; y <= rr + 2; y++) for (let x = -rr - 2; x <= rr + 2; x++) {
      const tx = lx + x, ty = ly + y; if (!inb(tx, ty)) continue;
      const ii = idx(tx, ty);
      if (isSea(ground[ii]) || ground[ii] === T.CLIFF) continue;
      const rn = rr + (vnoise(tx / 3, ty / 3, s + 90) - 0.5) * 2.4;
      if (x * x + y * y < rn * rn) ground[ii] = T.FRESH;
    }
  };
  for (let k = 0; k < 3; k++) {
    let sx = -1, sy = -1;
    for (let t = 0; t < 400; t++) {
      const x = Math.round(mtn.x + (R() - 0.5) * 36), y = Math.round(mtn.y + (R() - 0.5) * 36);
      if (inb(x, y) && elev[idx(x, y)] > 0.5 && ground[idx(x, y)] !== T.CLIFF) { sx = x; sy = y; break; }
    }
    if (sx < 0) continue;
    let x = sx, y = sy, stuck = 0;
    for (let st = 0; st < 600; st++) {
      const i = idx(x, y);
      if (isSea(ground[i])) break;
      visited[i] = 1;
      if (ground[i] !== T.CLIFF) ground[i] = T.FRESH;
      if (elev[i] < 0.3) { const j = idx(x + 1, y); if (inb(x + 1, y) && !isSea(ground[j])) ground[j] = T.FRESH; }
      let best = -1, be = 1e9;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        const nx = x + dx, ny = y + dy; if (!inb(nx, ny)) continue;
        const j = idx(nx, ny); if (visited[j]) continue;
        const ev = elev[j] + (dx && dy ? 0.004 : 0);
        if (ev < be) { be = ev; best = j; }
      }
      if (best < 0) break;
      if (be > elev[i] + 0.015) { stuck++; if (stuck > 25) { carveLake(x, y, 3); break; } }
      x = best % N; y = Math.floor(best / N);
    }
  }
  // ---- スタート地点（本島の南の浜）----
  let start = null;
  for (let k = 0; k < 41 && !start; k++) {
    const dx = (k % 2 ? 1 : -1) * Math.ceil(k / 2);
    const x = Math.round(cx) + dx;
    let lastLand = -1;
    for (let y = Math.round(cy); y < N - 2; y++) {
      const g = ground[idx(x, y)];
      if (isSea(g)) { lastLand = y - 1; break; }
    }
    if (lastLand > 0 && ground[idx(x, lastLand)] === T.SAND && ground[idx(x, lastLand - 1)] === T.SAND) start = { x, y: lastLand - 1 };
  }
  if (!start) start = { x: Math.round(cx), y: Math.round(cy) };
  // ---- 湖 ----
  for (let k = 0, made = 0; k < 400 && made < 2; k++) {
    const x = Math.round(cx + (R() - 0.5) * 120), y = Math.round(cy + (R() - 0.5) * 120);
    if (!inb(x, y)) continue;
    const i = idx(x, y);
    if ((ground[i] === T.GRASS || ground[i] === T.FOREST) && elev[i] > 0.12 && elev[i] < 0.34 && d2(x, y, start.x, start.y) > 400) { carveLake(x, y, 3 + Math.floor(R() * 3)); made++; }
  }
  // ---- 海底 ----
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const i = y * N + x, g = ground[i];
    if (!isSwim(g)) { seabed[i] = U.WALL; continue; }
    const depth = -elev[i];
    const n2 = fbm(x / 18, y / 18, s + 95, 3), n3 = fbm(x / 30, y / 30, s + 120, 3);
    let u;
    if (trench[i] > 0.2 && depth > 0.3) u = U.TRENCH;
    else if (depth < 0.09) u = n2 > 0.6 ? U.GRASS : U.SAND;
    else if (depth < 0.3) u = n3 > 0.56 ? U.REEF : n2 < 0.36 ? U.KELP : n2 > 0.66 ? U.ROCK : U.SAND;
    else u = n2 > 0.52 ? U.ROCK : n3 > 0.6 ? U.KELP : U.SAND;
    seabed[i] = u;
  }

  const lm = { start };
  const putChest = (layer, x, y, items, kind) => {
    const i = idx(x, y);
    (layer ? objU : objS)[i] = kind != null ? kind : (layer ? O.CHEST_U : O.CHEST);
    const slots = new Array(16).fill(null);
    items.forEach((it, j) => { slots[j] = { id: it[0], n: it[1] }; });
    objData.set(okey(layer, i), { items: slots });
  };
  const rollLoot = table => {
    const out = [];
    for (const [id, a, b, p] of LOOT[table]) if (R() < p) out.push([id, a + Math.floor(R() * (b - a + 1))]);
    if (!out.length) out.push(['pearl', 1]);
    return out;
  };
  const allSwim = (x0, y0, w, h) => { for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) { if (!inb(x, y) || !isSwim(ground[idx(x, y)])) return false; } return true; };
  const allLand = (x0, y0, w, h) => { for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) { if (!inb(x, y)) return false; const g = ground[idx(x, y)]; if (isWaterAny(g) || g === T.CLIFF || g === T.LAVA) return false; } return true; };
  const searchLine = (ax, ay, a, minD, maxD, w, h, test) => {
    for (let dd = minD; dd < maxD; dd++) {
      for (const da of [0, 0.05, -0.05, 0.1, -0.1]) {
        const x = Math.round(ax + Math.cos(a + da) * dd - w / 2), y = Math.round(ay + Math.sin(a + da) * dd - h / 2);
        if (test(x, y, w, h)) return { x, y };
      }
    }
    return null;
  };
  const deepEnough = (x, y, w, h, dmin) => { if (!allSwim(x, y, w, h)) return false; for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) if (-elev[idx(xx, yy)] < dmin) return false; return true; };

  // ---- 沈没船 ----
  const stampWreck = (x0, y0, w, h, chestItems, extra) => {
    const cxw = x0 + w / 2 - 0.5, cyw = y0 + h / 2 - 0.5, rx = w / 2, ry = h / 2;
    for (let y = y0 - 1; y <= y0 + h; y++) for (let x = x0 - 1; x <= x0 + w; x++) {
      if (!inb(x, y)) continue;
      const i = idx(x, y); reserved[i] = 1; objU[i] = 0;
      const v = ((x - cxw) / rx) ** 2 + ((y - cyw) / ry) ** 2;
      if (v <= 1) {
        seabed[i] = U.WRECK;
        const gap = (y > cyw && Math.abs(x - cxw) < 1.1) || (Math.abs(y - cyw) < 0.6 && x < cxw - rx + 1.5);
        if (v > 0.55 && !gap) objU[i] = O.HULL;
      }
    }
    putChest(1, Math.round(cxw + rx * 0.4), Math.round(cyw), chestItems);
    objU[idx(Math.round(cxw - 1), Math.round(cyw))] = O.BARREL;
    objU[idx(Math.round(cxw - 2), Math.round(cyw) - 1 >= y0 ? Math.round(cyw) - 1 : Math.round(cyw))] = O.AMPHORA;
    const mx = x0 + w + 2, my = y0 + 1;
    if (inb(mx, my) && isSwim(ground[idx(mx, my)])) { objU[idx(mx, my)] = O.MAST; reserved[idx(mx, my)] = 1; }
    const ax = x0 - 3, ay = y0 + h;
    if (inb(ax, ay) && isSwim(ground[idx(ax, ay)])) { objU[idx(ax, ay)] = O.ANCHOR; reserved[idx(ax, ay)] = 1; }
    if (extra) extra(cxw, cyw);
    return { x: Math.round(cxw), y: Math.round(cyw) };
  };
  {
    let p = null;
    for (const da of [0, 0.4, -0.4, 0.8, -0.8, 1.2, -1.2]) { p = searchLine(start.x, start.y, Math.PI / 2 + da, 12, 70, 16, 7, (x, y, w, h) => deepEnough(x, y, w, h, 0.05)); if (p) break; }
    if (p) lm.wreck1 = stampWreck(p.x, p.y, 16, 7, [['mask', 1], ['diver_memo', 1], ['rope', 3], ['iron', 2], ['fish_c', 2]]);
  }
  {
    const rk = isl[2];
    const a = Math.atan2(rk.y - cy, rk.x - cx);
    let p = null;
    for (const dm of [0.16, 0.11, 0.07, 0.04]) { for (const da of [0, 0.35, -0.35, 0.7, -0.7, 1.1, -1.1]) { p = searchLine(cx, cy, a + da, 60, 140, 20, 8, (x, y, w, h) => deepEnough(x, y, w, h, dm) && (!lm.wreck1 || d2(x, y, lm.wreck1.x, lm.wreck1.y) > 40 * 40)); if (p) break; } if (p) break; }
    if (p) lm.wreck2 = stampWreck(p.x, p.y, 20, 8, [['compass', 1], ['iron', 4], ['pearl', 2], ['glass', 2]], (wx, wy) => {
      putChest(1, Math.round(wx - 4), Math.round(wy), [['harpoon', 1], ['arrow', 10], ['bandage', 2]]);
    });
  }
  // ---- 海底遺跡 ----
  {
    const a = ang + 0.9;
    let p = null;
    for (const dm of [0.12, 0.08, 0.04]) { for (const da of [0, 0.3, -0.3, 0.6, -0.6, 1.0, -1.0]) { p = searchLine(cx, cy, a + da, 66, 140, 13, 13, (x, y, w, h) => deepEnough(x, y, w, h, dm) && (!lm.wreck2 || d2(x, y, lm.wreck2.x, lm.wreck2.y) > 30 * 30)); if (p) break; } if (p) break; }
    if (p) {
      for (let y = p.y; y < p.y + 13; y++) for (let x = p.x; x < p.x + 13; x++) {
        const i = idx(x, y); reserved[i] = 1; objU[i] = 0; seabed[i] = U.RUIN;
        const ex = x === p.x || x === p.x + 12, ey = y === p.y || y === p.y + 12;
        if ((ex || ey) && ((x - p.x) % 3 === 0 || (y - p.y) % 3 === 0) && !((x - p.x) === 6 || (y - p.y) === 6)) objU[i] = O.PILLAR_U;
      }
      [[3, 3], [9, 3], [3, 9], [9, 9]].forEach(([dx, dy]) => { objU[idx(p.x + dx, p.y + dy)] = O.PILLAR_U; });
      [[5, 9], [7, 3], [2, 6], [10, 7]].forEach(([dx, dy]) => { objU[idx(p.x + dx, p.y + dy)] = O.AMPHORA; });
      putChest(1, p.x + 6, p.y + 6, [['ancient_key', 1], ['pearl', 3], ['glow_jelly', 3]]);
      lm.sruins = { x: p.x + 6, y: p.y + 6 };
    }
  }
  // ---- 海溝と深海の主の住処 ----
  {
    let tx = trC.x, ty = trC.y;
    for (let rr = 0; rr < 30; rr++) { if (inb(tx, ty) && isSwim(ground[idx(tx, ty)])) break; tx += Math.sign(N / 2 - tx); ty += Math.sign(N / 2 - ty); }
    for (let y = -13; y <= 13; y++) for (let x = -13; x <= 13; x++) {
      const X = tx + x, Y = ty + y; if (!inb(X, Y)) continue;
      const i = idx(X, Y);
      if (!isSwim(ground[i])) continue;
      const dd = x * x + y * y;
      if (dd <= 144) { seabed[i] = U.TRENCH; objU[i] = 0; reserved[i] = 1; }
      else if (dd <= 170 && hash2(X, Y, s) < 0.35) { objU[i] = O.GLOW; reserved[i] = 1; }
    }
    [[5, 3], [-5, -3], [-4, 5], [4, -5]].forEach(([dx, dy]) => { const X = tx + dx, Y = ty + dy; if (inb(X, Y) && isSwim(ground[idx(X, Y)])) objU[idx(X, Y)] = O.VENT; });
    lm.trench = { x: tx, y: ty };
  }
  // ---- ジャングルの遺跡 ----
  {
    const cands = [];
    for (let y = 8; y < N - 8; y += 2) for (let x = 8; x < N - 8; x += 2) {
      const i = idx(x, y);
      if (ground[i] !== T.JUNGLE && ground[i] !== T.FOREST) continue;
      if (d2(x, y, cx, cy) > 75 * 75) continue;
      const sc = (ground[i] === T.JUNGLE ? 1 : 0) + Math.sqrt(d2(x, y, start.x, start.y)) * 0.01 + R() * 0.3;
      cands.push([sc, x, y]);
    }
    cands.sort((a, b) => b[0] - a[0]);
    for (const [, x, y] of cands) {
      const rx = x - 5, ry = y - 4;
      if (!allLand(rx - 1, ry - 1, 13, 12)) continue;
      for (let yy = ry - 1; yy <= ry + 9; yy++) for (let xx = rx - 1; xx <= rx + 11; xx++) { const i = idx(xx, yy); objS[i] = 0; reserved[i] = 1; }
      for (let yy = ry; yy < ry + 9; yy++) for (let xx = rx; xx < rx + 11; xx++) {
        const i = idx(xx, yy); ground[i] = T.RUINS;
        if (xx === rx || xx === rx + 10 || yy === ry || yy === ry + 8) objS[i] = O.PILLAR;
      }
      objS[idx(rx + 5, ry + 8)] = O.RUINDOOR;
      objS[idx(rx + 2, ry + 2)] = O.STATUE; objS[idx(rx + 8, ry + 2)] = O.STATUE;
      objS[idx(rx + 2, ry + 6)] = O.PILLAR; objS[idx(rx + 8, ry + 6)] = O.PILLAR;
      putChest(0, rx + 5, ry + 3, [['chart_a', 1], ['antidote', 2], ['bandage', 3], ['obsidian', 2]]);
      for (let k = 1; k <= 3; k++) { const i = idx(rx + 5, ry + 8 + k); if (inb(rx + 5, ry + 8 + k) && !isWaterAny(ground[i])) { ground[i] = T.DIRT; objS[i] = 0; reserved[i] = 1; } }
      lm.jruins = { x: rx + 5, y: ry + 8 };
      lm.parrot = { x: rx + 5, y: ry + 12 };
      break;
    }
  }
  // ---- 小島 ----
  {
    const V = isl[0];
    lm.volcano = { x: V.x, y: V.y };
    let gx = V.x, gy = V.y + 7;
    for (let t = 0; t < 40; t++) { const i = idx(gx, gy); if (inb(gx, gy) && ground[i] === T.VOLC) break; gx = V.x + Math.round((R() - 0.5) * 14); gy = V.y + Math.round((R() - 0.5) * 14); }
    lm.gcrab = { x: gx, y: gy };
    for (let y = -3; y <= 3; y++) for (let x = -3; x <= 3; x++) if (inb(gx + x, gy + y)) reserved[idx(gx + x, gy + y)] = 1;
    let chx = V.x - 6, chy = V.y;
    for (let t = 0; t < 60; t++) { if (inb(chx, chy) && ground[idx(chx, chy)] === T.VOLC) break; chx = V.x + Math.round((R() - 0.5) * 16); chy = V.y + Math.round((R() - 0.5) * 16); }
    putChest(0, chx, chy, [['obsidian', 4], ['iron', 3], ['coal', 4]]); reserved[idx(chx, chy)] = 1;
    const S2 = isl[1]; lm.sandisle = { x: S2.x, y: S2.y };
    if (!isWaterAny(ground[idx(S2.x, S2.y)])) { putChest(0, S2.x, S2.y, [['fins', 1], ['water', 2], ['coconut', 3], ['arrow', 6]]); reserved[idx(S2.x, S2.y)] = 1; }
    const R2 = isl[2]; lm.rockisle = { x: R2.x, y: R2.y };
    if (!isWaterAny(ground[idx(R2.x, R2.y)])) { putChest(0, R2.x, R2.y, [['boots', 1], ['iron', 3], ['coal', 4], ['charm_tooth', 1]]); reserved[idx(R2.x, R2.y)] = 1; }
  }

  // ---- オブジェクト配置 ----
  const nearIsl = (x, y, k) => { const I = isl.find(q => q.k === k); return d2(x, y, I.x, I.y) < (I.r * 1.5) ** 2; };
  for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) {
    const i = y * N + x;
    if (reserved[i]) continue;
    const h = hash2(x, y, s + 77), g = ground[i];
    let o = 0;
    switch (g) {
      case T.SAND: o = h < 0.035 ? O.PALM : h < 0.05 ? O.SHELLP : h < 0.058 ? O.PEBBLE : h < 0.064 ? O.DRIFT : h < 0.068 ? O.STICK : 0; break;
      case T.GRASS: o = h < 0.06 ? O.TREE : h < 0.16 ? O.GRASS : h < 0.185 ? O.BUSH : h < 0.215 ? O.FLOWER : h < 0.23 ? O.ROCK : h < 0.24 ? O.PEBBLE : h < 0.255 ? O.STICK : h < 0.262 ? O.HERB : h < 0.2635 ? O.CROP3 : 0; break;
      case T.FOREST: o = h < 0.19 ? O.TREE : h < 0.21 ? O.PINE : h < 0.24 ? O.BUSH : h < 0.3 ? O.GRASS : h < 0.315 ? O.MUSH : h < 0.33 ? O.ROCK : h < 0.35 ? O.STICK : h < 0.356 ? O.HERB : 0; break;
      case T.JUNGLE: o = h < 0.17 ? O.JTREE : h < 0.2 ? O.BANANA : h < 0.23 ? O.BAMBOO : h < 0.245 ? O.HERB : h < 0.32 ? O.GRASS : h < 0.33 ? O.MUSH : h < 0.34 ? O.BUSH : h < 0.35 ? O.STICK : 0; break;
      case T.ROCK: {
        const rich = nearIsl(x, y, 'rockisle');
        o = h < 0.07 ? O.ROCK : h < 0.095 ? O.BIGROCK : h < (rich ? 0.15 : 0.12) ? O.ORE_IRON : h < (rich ? 0.18 : 0.145) ? O.ORE_COAL : h < 0.2 ? O.PINE : h < 0.22 ? O.PEBBLE : h < 0.23 ? O.GRASS : 0; break;
      }
      case T.DIRT: o = h < 0.03 ? O.PEBBLE : h < 0.05 ? O.GRASS : 0; break;
      case T.VOLC: o = h < 0.06 ? O.OBSIDIAN : h < 0.1 ? O.ROCK : h < 0.115 ? O.VENT_S : h < 0.13 ? O.ORE_IRON : 0; break;
    }
    objS[i] = o;
    if (isSwim(g)) {
      const u = seabed[i], h2 = hash2(x, y, s + 177);
      let q = 0;
      switch (u) {
        case U.SAND: q = h2 < 0.02 ? O.SEAGRASS : h2 < 0.03 ? O.SHELLU : h2 < 0.038 ? O.STAR : h2 < 0.046 ? O.CLAM_O : h2 < 0.06 ? O.ROCK_U : 0; break;
        case U.GRASS: q = h2 < 0.3 ? O.SEAGRASS : h2 < 0.32 ? O.CLAM_O : h2 < 0.33 ? O.SHELLU : 0; break;
        case U.REEF: q = h2 < 0.06 ? O.CORAL_R : h2 < 0.11 ? O.CORAL_B : h2 < 0.15 ? O.CORAL_Y : h2 < 0.185 ? O.CORAL_F : h2 < 0.195 ? O.URCHIN : h2 < 0.21 ? O.CLAM_O : h2 < 0.22 ? O.STAR : h2 < 0.25 ? O.SEAGRASS : 0; break;
        case U.KELP: q = h2 < 0.32 ? O.KELP : h2 < 0.35 ? O.ROCK_U : h2 < 0.36 ? O.SEAGRASS : 0; break;
        case U.ROCK: q = h2 < 0.12 ? O.ROCK_U : h2 < 0.145 ? O.URCHIN : h2 < 0.155 ? O.SCRAP : h2 < 0.17 ? O.SEAGRASS : 0; break;
        case U.TRENCH: q = h2 < 0.03 ? O.GLOW : h2 < 0.08 ? O.ROCK_U : h2 < 0.086 ? O.VENT : 0; break;
      }
      if (!q && u !== U.WALL && hash2(x, y, s + 277) < 0.0013) q = O.VENT;
      objU[i] = q;
    }
  }
  // 粘土（川や湖のほとり）
  let clayN = 0;
  for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) {
    const i = idx(x, y), g = ground[i];
    if (reserved[i] || objS[i] || !(g === T.SAND || g === T.GRASS || g === T.FOREST || g === T.DIRT)) continue;
    let near = false;
    for (let dy = -1; dy <= 1 && !near; dy++) for (let dx = -1; dx <= 1; dx++) if (ground[idx(x + dx, y + dy)] === T.FRESH) { near = true; break; }
    if (near && hash2(x, y, s + 333) < 0.2) { objS[i] = O.CLAY; clayN++; }
  }
  for (let t = 0; t < 5000 && clayN < 24; t++) {
    const x = 2 + Math.floor(R() * (N - 4)), y = 2 + Math.floor(R() * (N - 4)), i = idx(x, y);
    if (ground[i] === T.SAND && !objS[i] && !reserved[i] && d2(x, y, cx, cy) < 90 * 90) { objS[i] = O.CLAY; clayN++; }
  }
  // 鉄鉱脈の保証
  let ironN = 0; for (let i = 0; i < MM; i++) if (objS[i] === O.ORE_IRON) ironN++;
  for (let t = 0; t < 8000 && ironN < 30; t++) {
    const x = Math.round(mtn.x + (R() - 0.5) * 50), y = Math.round(mtn.y + (R() - 0.5) * 50);
    if (!inb(x, y)) continue; const i = idx(x, y);
    if ((ground[i] === T.ROCK || ground[i] === T.FOREST || ground[i] === T.GRASS) && !objS[i] && !reserved[i]) { objS[i] = O.ORE_IRON; ironN++; }
  }

  // ---- スタート地点の周り ----
  for (let y = -3; y <= 3; y++) for (let x = -3; x <= 3; x++) { const X = start.x + x, Y = start.y + y; if (inb(X, Y) && objS[idx(X, Y)] && OBJ[objS[idx(X, Y)]].solid) objS[idx(X, Y)] = 0; }
  const placeNear = (o, minR, maxR, tries = 60) => {
    for (let t = 0; t < tries; t++) {
      const a = R() * Math.PI * 2, rr = minR + R() * (maxR - minR);
      const x = Math.round(start.x + Math.cos(a) * rr), y = Math.round(start.y + Math.sin(a) * rr);
      if (!inb(x, y)) continue; const i = idx(x, y);
      const g = ground[i];
      if (isWaterAny(g) || g === T.CLIFF || objS[i] || reserved[i]) continue;
      if (Math.abs(x - start.x) <= 1 && Math.abs(y - start.y) <= 1) continue;
      objS[i] = o; return { x, y };
    }
    return null;
  };
  placeNear(O.WRECKBIT, 3, 5);
  for (let k = 0; k < 3; k++) placeNear(O.CRATE, 2, 7);
  for (let k = 0; k < 2; k++) placeNear(O.BARREL, 2, 7);
  for (let k = 0; k < 5; k++) placeNear(O.DRIFT, 2, 9);
  for (let k = 0; k < 5; k++) placeNear(O.PEBBLE, 2, 9);
  for (let k = 0; k < 4; k++) placeNear(O.STICK, 3, 10);
  for (let k = 0; k < 4; k++) placeNear(O.GRASS, 4, 10);

  // ---- 漂流瓶 ----
  const bottles = [];
  {
    const b0 = placeNear(O.BOTTLE, 2, 4);
    if (b0) { objData.set(okey(0, idx(b0.x, b0.y)), { msg: 0 }); bottles.push(b0); }
    let mi = 1;
    for (let t = 0; t < 20000 && mi < 8; t++) {
      const x = 2 + Math.floor(R() * (N - 4)), y = 2 + Math.floor(R() * (N - 4)), i = idx(x, y);
      if (ground[i] !== T.SAND || objS[i] || reserved[i]) continue;
      let shore = false;
      for (let dy = -1; dy <= 1 && !shore; dy++) for (let dx = -1; dx <= 1; dx++) if (isSea(ground[idx(x + dx, y + dy)])) { shore = true; break; }
      if (!shore) continue;
      if (bottles.some(b => d2(b.x, b.y, x, y) < 34 * 34)) continue;
      objS[i] = O.BOTTLE; objData.set(okey(0, i), { msg: mi++ }); bottles.push({ x, y });
    }
    const uSpots = [lm.sruins, lm.wreck2, lm.trench].filter(Boolean);
    uSpots.forEach((p, k) => {
      for (let t = 0; t < 200; t++) {
        const x = p.x + Math.round((R() - 0.5) * 24), y = p.y + Math.round((R() - 0.5) * 24);
        if (!inb(x, y)) continue; const i = idx(x, y);
        if (!isSwim(ground[i]) || objU[i] || reserved[i] || seabed[i] === U.WALL) continue;
        objU[i] = O.BOTTLE; objData.set(okey(1, i), { msg: 8 + k }); break;
      }
    });
  }
  // ---- 海底のお宝 ----
  for (let t = 0, made = 0; t < 6000 && made < 7; t++) {
    const x = 4 + Math.floor(R() * (N - 8)), y = 4 + Math.floor(R() * (N - 8)), i = idx(x, y);
    if (!isSwim(ground[i]) || elev[i] > -0.12 || objU[i] || reserved[i] || seabed[i] === U.WALL) continue;
    putChest(1, x, y, rollLoot('treasure')); reserved[i] = 1; made++;
  }

  return { seed, ground, seabed, objS, objU, objData, lm, elev };
}

/* ---------- ワールドの参照ヘルパー ---------- */
const terAt = (layer, x, y) => inb(x, y) ? (layer ? G.seabed : G.ground)[idx(x, y)] : (layer ? U.WALL : T.DEEP);
const objAt = (layer, x, y) => inb(x, y) ? (layer ? G.objU : G.objS)[idx(x, y)] : 0;
function setObj(layer, x, y, o) {
  if (!inb(x, y)) return;
  (layer ? G.objU : G.objS)[idx(x, y)] = o;
  const k = okey(layer, idx(x, y));
  if (!o) G.objData.delete(k);
  mapDirty(x, y);
}
const odata = (layer, x, y) => G.objData.get(okey(layer, idx(x, y)));
// 泳げる・歩ける判定  who: 'player' | 'land' | 'sea'
function solidAt(layer, x, y, who) {
  if (!inb(x, y)) return true;
  const i = idx(x, y);
  if (layer === 0) {
    const g = G.ground[i], o = G.objS[i];
    if (o) {
      const d = OBJ[o];
      if (d.bridge) return who === 'sea';
      if (d.solid) { if (d.door && who === 'player') return false; return true; }
    }
    if (g === T.CLIFF) return true;
    if (who === 'land') return g === T.DEEP || g === T.OCEAN || g === T.LAVA;
    if (who === 'sea') return !isSwim(g);
    return false;
  } else {
    if (G.seabed[i] === U.WALL) return true;
    const o = G.objU[i];
    if (o && OBJ[o].solid) return true;
    return false;
  }
}
/* =============================================================
   ストーリー・漂流瓶・クエスト・ヒント
   ============================================================= */
const BOTTLE_MSG = [
  '――この瓶を拾った誰かへ。\nこの島は昔「蒼の島」と呼ばれていたらしい。俺は嵐で船を失い、ここに流れ着いた。\nまずは浜の流木や小石を拾え。草むらからは繊維が取れる。生きろ。　――ミナト',
  '真水は山から流れる川と、森の湖にある。\n海の水は飲むな。のどが渇くだけじゃない、体をこわす。\n竹で水筒を作れば、遠出もできる。',
  '夜の島は危ない。イノシシは気が荒くなり、浜にはカニがうじゃうじゃ出てくる。\nたき火のそばを離れるな。ベッドで眠れば朝が来る。',
  '南の沖に船が沈んでいる。俺が乗ってきた船だ。潜って調べてみるといい。\n息が続かなくなったら、すぐ浮上しろ。海底の「気泡スポット」でも息が吸える。',
  'この島には昔、海を敬う人々が住んでいたらしい。ジャングルの奥に石の遺跡がある。\nだが扉は固く閉ざされていた。鍵は…海の底にあると石版に刻まれていた。',
  '山の岩場で赤茶けた鉱脈を見つけた。鉄だ。かまどで炭と一緒に焼けば丈夫な道具が作れる。\nかまどには粘土が要る。川辺を探せ。砂はシャベルで掘れる。',
  '北の火山島には、巨大なヤシガニがいる。あいつは光るものを集めるクセがある。\n俺の大事な海図の切れ端も持っていかれた…。いかだがあれば渡れるはずだ。',
  '海図は三つに破れてしまった。一つは遺跡に、一つは火山島に、そしてもう一つは――深い深い海の底に。\n羅針盤は二隻目の沈没船に残してきた。',
  'この遺跡は、昔の島の民が「深海の主」を鎮めるために建てたもの。\n主は暗闇を好み、光る餌で獲物を誘う。光を忘れるな。クラゲの発光ゼリーでランタンが作れる。',
  'エアタンクがあれば、もっと深く潜れる。\n一隻目の船に潜水士のメモを残しておいた。読んだか？\nサメの皮で作るウェットスーツも、深海では頼りになる。',
  '…俺はもう戻れないかもしれない。海溝の底で、巨大な影を見た。\n最後の切れ端は、あいつが守っている。\nもしこれを読んだなら、三つを揃えて造船台で船を組め。羅針盤と海図があれば、きっと帰れる。　――ミナト',
];
const BOTTLE_TITLE = ['最初の手紙', '水のこと', '夜のこと', '沈没船', '遺跡の扉', '鉄のこと', '火山島', '三つの海図', '深海の主', 'エアタンク', '最後の手紙'];

const INTRO = [
  '……波の音で、目が覚めた。',
  '乗っていた船は嵐で沈み、どうやら見知らぬ島に流れ着いたらしい。',
  '持ち物は…何もない。とにかく、生き延びなければ。',
  '（近くに何か光る瓶が落ちている…？）',
];

const cnt = id => countItem(id);
const hasI = id => countItem(id) > 0;
const QUESTS = [
  { t: '漂着', d: '浜辺の流木や小石を拾って、木材5・石3を集めよう（近づいてA）', check: () => cnt('wood') >= 5 && cnt('stone') >= 3 },
  { t: '草を刈ろう', d: '草むらを刈って繊維を6つ集めよう', check: () => cnt('fiber') >= 6 || G.stats.placed_bench },
  { t: '作業台', d: 'メニュー（Y）のクラフトで「作業台」を作り、ホットバーで選んでAで置こう', check: () => G.stats.placed_bench },
  { t: '道具づくり', d: '作業台の近くで「石のオノ」と「石のツルハシ」を作ろう（ロープは繊維から）', check: () => G.stats.crafted_axe_s && G.stats.crafted_pick_s },
  { t: '火をおこす', d: '「たき火」を作って置こう。夜の明かりと料理に使える', check: () => G.stats.placed_campfire },
  { t: '真水を探せ', d: '川や湖の真水を飲もう（水に向かってA）。海水は体に悪い', check: () => G.stats.drank_fresh },
  { t: '腹ごしらえ', d: '魚や肉をたき火で焼いて食べよう（たき火を調べると料理）', check: () => G.stats.ate_cooked },
  { t: '寝床', d: '「ベッド」を作って置き、夜（18時以降）に眠ろう', check: () => G.stats.slept },
  { t: '海へ', d: '深い海まで泳いで、Xボタンで潜ってみよう', check: () => G.stats.dived },
  { t: '沈んだ船', d: '南の沖に沈む船を調べよう。宝箱があるかも', target: 'wreck1', check: () => G.flags.memo },
  { t: 'かまど', d: '川辺の粘土と石で「かまど」を作ろう', check: () => G.stats.placed_furnace },
  { t: '鉄の時代', d: '山の鉄鉱脈を掘り、かまどで「鉄インゴット」を作ろう', check: () => G.stats.crafted_iron },
  { t: '深く潜る準備', d: '「エアタンク」を作ろう（潜水士のメモで作れるようになった）', check: () => G.stats.crafted_tank || hasI('tank') || hasI('tank_l') || P.equip.back },
  { t: '羅針盤', d: 'もう一隻の、深い場所の沈没船で羅針盤を見つけよう', target: 'wreck2', check: () => G.flags.compass },
  { t: '三つの海図', d: '', target: 'chart', check: () => (hasI('chart_a') && hasI('chart_b') && hasI('chart_c')) || hasI('chart') || G.flags.ship_chart },
  { t: '海図をつなぐ', d: '三つの切れ端から「完全な海図」を作ろう（手作り）', check: () => hasI('chart') || G.flags.ship_chart },
  { t: '造船', d: '浜辺（砂の上）に「造船台」を作って置こう', check: () => G.stats.placed_shipyard },
  { t: '出航準備', d: '「船体」「帆」「完全な海図」を作って、造船台に納めよう', check: () => G.flags.ship_hull && G.flags.ship_sail && G.flags.ship_chart },
  { t: '脱出', d: '造船台を調べて、島から脱出しよう！', check: () => G.flags.escaped },
  { t: '自由な日々', d: 'クリアおめでとう！ 島での暮らしを自由に楽しもう', check: () => false },
];
function questDesc(q) {
  if (q.t === '三つの海図') {
    const a = hasI('chart_a') || hasI('chart') ? '●' : '○', b = hasI('chart_b') || hasI('chart') ? '●' : '○', c = hasI('chart_c') || hasI('chart') ? '●' : '○';
    let tip = '';
    if (a === '○') tip = hasI('ancient_key') ? '鍵を持ってジャングルの遺跡へ' : '遺跡の鍵は海底遺跡にあるらしい';
    else if (b === '○') tip = '火山島の巨大ヤシガニを倒そう';
    else tip = '海溝の深海の主を倒そう（光と酸素を忘れずに）';
    return `${a}壱:遺跡 ${b}弐:火山島 ${c}参:深海\n${tip}`;
  }
  return q.d;
}
function questTarget(q) {
  if (!q || !q.target) return null;
  if (q.target === 'chart') {
    if (!hasI('chart_a') && !hasI('chart')) return hasI('ancient_key') ? G.lm.jruins : G.lm.sruins;
    if (!hasI('chart_b') && !hasI('chart')) return G.lm.gcrab || G.lm.volcano;
    return G.lm.trench;
  }
  return G.lm[q.target];
}
const PARROT_HINT = [
  'ポコ「キラキラ ノ ビン、ヒロウ！ ナガレギ、イシ、ヒロウ！」',
  'ポコ「クサ カル！ センイ！ センイ！」',
  'ポコ「サギョウダイ、ツクル！ メニュー ノ クラフト！」',
  'ポコ「オノ！ ツルハシ！ ロープ ハ センイ カラ！」',
  'ポコ「ヨル コワイ！ タキビ！ タキビ！」',
  'ポコ「カワ ノ ミズ、ノム！ ウミ ノ ミズ、ダメ！」',
  'ポコ「サカナ ヤク！ タキビ デ ヤク！」',
  'ポコ「ベッド！ ネル！ アサ クル！」',
  'ポコ「フカイ ウミ デ、Xボタン！ モグル！」',
  'ポコ「ミナミ ノ オキ、フネ シズンデル！」',
  'ポコ「ネンド ハ カワ ノ ソバ！ カマド！」',
  'ポコ「ヤマ ノ アカイ イワ、テツ！」',
  'ポコ「エアタンク！ テツ ト カワ！」',
  'ポコ「モウイッセキ ノ フネ、フカイ トコロ！ ラシンバン！」',
  'ポコ「カイズ、ミッツ！ イセキ、カザン、シンカイ！」',
  'ポコ「カイズ、ツナグ！ テヅクリ！」',
  'ポコ「ゾウセンダイ、スナハマ ニ オク！」',
  'ポコ「センタイ、ホ、カイズ！ ゾウセンダイ ニ イレル！」',
  'ポコ「シュッコウ！ シュッコウ！」',
  'ポコ「ポコ、シアワセ！」',
];

const HELP_HTML = `
<div class="helpbox">
<b>■ 目的</b><br>無人島で生き延び、三つの海図と羅針盤を集めて脱出船を作ろう。画面左上の「目標」が道しるべ。<br><br>
<b>■ 操作（スマホ）</b><br>左側をドラッグ：移動 ／ A：使う・調べる・攻撃 ／ B（長押し）：ダッシュ ／ X：潜る・浮上・いかだを降りる ／ Y：メニュー ／ 下のホットバーをタップで持ち替え<br><br>
<b>■ 操作（キーボード）</b><br>WASD・矢印：移動 ／ J・Space：A ／ K・Shift：ダッシュ ／ L・F：潜る/浮上 ／ E・I・Tab：メニュー ／ M：地図 ／ 1〜8・Q/R・ホイール：持ち替え ／ Esc：ポーズ<br><br>
<b>■ 操作（コントローラー）</b><br>左スティック：移動 ／ A：使う ／ B：ダッシュ・戻る ／ X：潜る ／ Y：メニュー ／ LB/RB：持ち替え ／ START：ポーズ ／ BACK：地図（設定でA/B・X/Yを入れ替え可）<br><br>
<b>■ サバイバル</b><br>❤体力　🍖空腹　💧のど　⚡スタミナ。空腹やのどが0になると体力が減る。深い海を泳ぐとスタミナを使い、0になると溺れる。<br>水中では酸素が減る。気泡スポットで息が吸える。マスク・エアタンクで長く潜れる。<br><br>
<b>■ クラフト</b><br>メニューのクラフトで作る。作業台・かまど・たき火の近くだと作れるものが増える。設置物はホットバーで選んでAで置く。オノ・ツルハシで叩くと回収できる。<br><br>
<b>■ ヒント</b><br>・草原をシャベルで耕すと畑。イモを植えると育つ。<br>・木の床は水の上に置くと橋になる。<br>・ベッドで寝ると朝になり、復活地点になる。セーブは朝・就寝時に自動、メニューからも可能。<br>・夜や深海は暗い。松明やランタンで照らそう。
</div>`;
/* =============================================================
   プレイヤー・インベントリ・行動（採集・クラフト・設置・潜水）
   ============================================================= */
let P = null;
const ENTS = [], DROPS = [], PROJ = [], PARTS = [];
const objHit = new Map(), objShake = new Map();
const INV_N = 32, HOT_N = 8;
const PHW = 4, PHH = 3; // 足元の当たり判定（半分の幅・高さ）

function newPlayer(lm) {
  return {
    x: lm.start.x * TILE + 8, y: lm.start.y * TILE + 12, layer: 0, vx: 0, vy: 0, dir: 'd', fx: 0, fy: 1, anim: 0, moving: false,
    hp: 100, hunger: 100, thirst: 100, stam: 100, o2: 20, poison: 0,
    inv: new Array(INV_N).fill(null), equip: { head: null, body: null, feet: null, back: null, acc: null }, sel: 0,
    swing: null, cd: 0, invul: 0, raft: false, spawn: { x: lm.start.x * TILE + 8, y: lm.start.y * TILE + 12 }, fish: null,
    kx: 0, ky: 0, mode: 'walk', drownMsg: 0, dead: false, o2warn: 0, step: 0,
  };
}
/* ---------- 装備による能力 ---------- */
let PS = { def: 0, o2max: 20, swim: 0, spd: 0, light: 0, hpmax: 100, atk: 1, drain: 1, uvis: 0 };
function calcStats() {
  const s = { def: 0, o2max: 20, swim: 0, spd: 0, light: 0, hpmax: 100, atk: 1, drain: 1, uvis: 0 };
  for (const k of EQ_SLOTS) {
    const it = P.equip[k]; if (!it) continue;
    const e = ITEMS[it.id].eq; if (!e) continue;
    s.def += e.def || 0; s.o2max += e.o2 || 0; s.swim += e.swim || 0; s.spd += e.spd || 0;
    s.light = Math.max(s.light, e.light || 0); s.hpmax += e.hp || 0; s.atk += e.atk || 0;
    if (e.drain) s.drain *= e.drain; if (e.uvis) s.uvis = 1;
  }
  PS = s;
  P.hp = Math.min(P.hp, PS.hpmax); P.o2 = Math.min(P.o2, PS.o2max);
}
const maskLevel = () => { const h = P.equip.head && P.equip.head.id; return h === 'headlamp' ? 2 : h === 'mask' ? 1 : 0; };

/* ---------- インベントリ ---------- */
function invCount(id) { let n = 0; for (const s of P.inv) if (s && s.id === id) n += s.n; return n; }
function countItem(id) { let n = invCount(id); for (const k of EQ_SLOTS) if (P.equip[k] && P.equip[k].id === id) n++; return n; }
function addItem(id, n, silent) {
  const it = ITEMS[id]; if (!it || n <= 0) return 0;
  let left = n;
  if (it.st > 1) for (const s of P.inv) { if (s && s.id === id && s.n < it.st) { const a = Math.min(it.st - s.n, left); s.n += a; left -= a; if (!left) break; } }
  while (left > 0) {
    const i = P.inv.findIndex(s => !s); if (i < 0) break;
    const a = Math.min(it.st, left);
    P.inv[i] = { id, n: a }; if (it.tool) P.inv[i].dur = it.tool.dur;
    left -= a;
  }
  const got = n - left;
  if (got > 0) onGotItem(id, got, silent);
  return left;
}
function addOrDrop(id, n, silent) { const left = addItem(id, n, silent); if (left > 0) { spawnDrop(P.layer, P.x, P.y - 2, id, left); toast('持ち物がいっぱい！', 'red'); } }
function removeItem(id, n) {
  for (let pass = 0; pass < 2; pass++) for (let i = INV_N - 1; i >= 0 && n > 0; i--) {
    const s = P.inv[i];
    if (!s || s.id !== id) continue;
    if (pass === 0 && i === P.sel) continue;
    const a = Math.min(s.n, n); s.n -= a; n -= a;
    if (s.n <= 0) P.inv[i] = null;
  }
  uiDirty();
}
function onGotItem(id, n, silent) {
  if (!silent) pickupNotice(id, n);
  if (id === 'diver_memo' && !G.flags.memo) { G.flags.memo = 1; later(() => dialog(['潜水士のメモだ。\n「エアタンク：鉄6・皮2・ロープ2」…作り方が書いてある！', '（エアタンクと大型エアタンクのレシピを覚えた）'])); }
  if (id === 'compass' && !G.flags.compass) { G.flags.compass = 1; later(() => dialog(['羅針盤だ！ 針はまだしっかり北を指している。', 'これがあれば…島から出られるかもしれない！', '（造船台・船体・帆のレシピを覚えた）'])); }
  if (id.startsWith('chart_')) later(() => toast(ITEMS[id].n + 'を手に入れた！', 'gold big'));
  if (id === 'ancient_key') later(() => dialog(['古代の鍵を手に入れた。', 'ジャングルの遺跡の扉に合いそうだ。']));
  if (id === 'deep_orb') G.stats.orb = 1;
  uiDirty();
  checkQuests();
}
function useDurability(slot) {
  const s = P.inv[slot]; if (!s || s.dur == null) return;
  s.dur--;
  if (s.dur <= 0) { toast(ITEMS[s.id].n + 'が壊れた！', 'red'); P.inv[slot] = null; sfx('break'); }
  uiDirty();
}
function equipFrom(i) {
  const s = P.inv[i]; if (!s) return;
  const it = ITEMS[s.id]; if (!it.eq) return;
  const slot = it.eq.s, old = P.equip[slot];
  P.equip[slot] = { id: s.id };
  P.inv[i] = old ? { id: old.id, n: 1 } : null;
  calcStats(); sfx('equip'); uiDirty();
  toast(it.n + 'を装備した');
}
function unequip(slot) {
  const e = P.equip[slot]; if (!e) return;
  const i = P.inv.findIndex(s => !s);
  if (i < 0) { toast('持ち物がいっぱい！', 'red'); return; }
  P.inv[i] = { id: e.id, n: 1 }; P.equip[slot] = null;
  calcStats(); sfx('equip'); uiDirty();
}
const held = () => P.inv[P.sel];
const heldDef = () => { const h = held(); return h ? ITEMS[h.id] : null; };

/* ---------- ターゲット ---------- */
const ptile = () => ({ x: Math.floor(P.x / TILE), y: Math.floor((P.y - 3) / TILE) });
function facingTile() { return { x: Math.floor((P.x + P.fx * 12) / TILE), y: Math.floor((P.y - 4 + P.fy * 12) / TILE) }; }
function objUsable(d) { return d.ia || d.harvest || d.pickup || d.hp || d.built; }
function findTargetObj(filter) {
  const pt = ptile(), cx = P.x, cy = P.y - 4;
  let best = null, bs = -1e9;
  for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
    const tx = pt.x + dx, ty = pt.y + dy;
    const o = objAt(P.layer, tx, ty); if (!o) continue;
    const d = OBJ[o]; if (!objUsable(d)) continue;
    if (filter && !filter(d)) continue;
    const ox = tx * TILE + 8, oy = ty * TILE + 8;
    const vx = ox - cx, vy = oy - cy, dist = Math.hypot(vx, vy);
    if (dist > 24) continue;
    const dot = dist < 6 ? 1 : (vx * P.fx + vy * P.fy) / dist;
    if (dot < 0.25 && !(dx === 0 && dy === 0)) continue;
    const sc = dot * 1.2 - dist / 30 + (d.ia ? 0.3 : 0);
    if (sc > bs) { bs = sc; best = { layer: P.layer, x: tx, y: ty, o, d }; }
  }
  return best;
}
function nearParrot() { for (const e of ENTS) if (e.sp === 'parrot' && P.layer === 0 && d2(e.x, e.y, P.x, P.y) < 30 * 30) return e; return null; }
function waterAhead() {
  for (let k = 1; k <= 2; k++) {
    const tx = Math.floor((P.x + P.fx * 14 * k) / TILE), ty = Math.floor((P.y - 4 + P.fy * 14 * k) / TILE);
    const t = terAt(0, tx, ty);
    if (isWaterAny(t) && !objAt(0, tx, ty)) return { x: tx, y: ty, t };
  }
  return null;
}

/* ---------- Aボタンの文脈アクション ---------- */
function getCtx() {
  if (!P || P.dead) return null;
  if (P.fish) return { lbl: P.fish.state === 'bite' ? '釣り上げる！' : 'リールを巻く', fn: reelFish };
  const h = held(), def = heldDef();
  const ob = findTargetObj(d => d.ia || d.harvest || d.pickup);
  if (ob) {
    const d = ob.d;
    if (d.ia) return { lbl: iaLabel(ob), fn: () => interact(ob) };
    if (d.harvest) return { lbl: '収穫する', fn: () => harvestObj(ob) };
    if (d.pickup) return { lbl: '拾う', fn: () => pickupObj(ob) };
  }
  const par = nearParrot();
  if (par) {
    if (!G.flags.parrot && h && (h.id === 'berry' || h.id === 'banana')) return { lbl: 'エサをあげる', fn: () => befriendParrot(par) };
    if (G.flags.parrot) return { lbl: 'ポコと話す', fn: () => parrotTalk() };
  }
  const ft = facingTile(), fter = terAt(P.layer, ft.x, ft.y), fobj = objAt(P.layer, ft.x, ft.y);
  if (def) {
    if (def.cat === 'food') {
      if (P.layer === 1) return { lbl: '水中では食べられない', fn: () => toast('水中では食べられない', 'red') };
      return { lbl: def.med ? '使う' : (h.id === 'water' ? '飲む' : '食べる'), fn: () => eatSel() };
    }
    if (h.id === 'canteen') {
      if (P.layer === 0 && (fter === T.FRESH || terAt(0, ptile().x, ptile().y) === T.FRESH)) return { lbl: '水をくむ', fn: fillCanteen };
      return { lbl: '水場で使おう', fn: () => toast('川や湖の水、雨水タンクでくめる') };
    }
    if (h.id === 'raft') {
      if (P.layer === 0 && !P.raft && (P.mode === 'swim' || P.mode === 'wade')) return { lbl: 'いかだに乗る', fn: boardRaft };
      return { lbl: '水の上で使おう', fn: () => toast('いかだは水に入ってから使おう') };
    }
    if (def.plant && P.layer === 0 && fter === T.FARM && !fobj) return { lbl: '植える', fn: () => plantAt(ft) };
    if (def.place) return { lbl: '置く', fn: () => placeAt(ft) };
    if (def.eq) return { lbl: '装備する', fn: () => equipFrom(P.sel) };
    if (def.tool) {
      const t = def.tool.t;
      if (t === 'rod') { if (P.layer === 0 && !P.raft && waterAhead()) return { lbl: '釣る', fn: castFish }; }
      if (t === 'bow') return { lbl: P.layer ? '水中では撃てない' : '撃つ', fn: shootBow };
      const hob = findTargetObj(d => d.hp || d.built);
      if (t === 'shovel' && P.layer === 0 && !hob && !fobj) {
        if (fter === T.SAND) return { lbl: '砂を掘る', fn: swing };
        if (fter === T.GRASS || fter === T.DIRT || fter === T.FOREST || fter === T.JUNGLE) return { lbl: '耕す', fn: swing };
      }
      if (P.layer === 0 && fter === T.FRESH && !hob && t !== 'shovel') return { lbl: '水を飲む', fn: () => drink(true) };
      if (hob) return { lbl: toolVerb(t, hob.d), fn: swing };
      return { lbl: def.cat === 'weapon' ? '攻撃' : '振る', fn: swing };
    }
  }
  if (P.layer === 0 && !P.raft) {
    const pt = ptile();
    if (fter === T.FRESH || terAt(0, pt.x, pt.y) === T.FRESH) return { lbl: '水を飲む', fn: () => drink(true) };
    if (!def && isSea(fter) && P.mode !== 'swim') return { lbl: '海水を飲む', fn: () => drink(false) };
  }
  const hob = findTargetObj(d => d.hp || d.built);
  if (hob) return { lbl: '素手で叩く', fn: swing };
  return { lbl: def ? '' : 'パンチ', fn: swing };
}
function toolVerb(t, d) {
  if (d.built) return '壊して回収';
  if (d.tool === 'axe') return t === 'axe' ? '切る' : '叩く';
  if (d.tool === 'pick') return t === 'pick' ? '掘る' : '叩く';
  if (d.tool === 'dig') return '掘る';
  return '叩く';
}
function iaLabel(ob) {
  const d = ob.d;
  switch (d.ia) {
    case 'chest': return '開ける';
    case 'bag': return '回収する';
    case 'bottle': return '読む';
    case 'fire': return '料理する';
    case 'bench': return 'クラフト';
    case 'furnace': return '精錬・料理';
    case 'bed': return '眠る';
    case 'rain': { const od = odata(0, ob.x, ob.y); return od && od.w >= 1 ? (held() && held().id === 'canteen' ? '水をくむ' : '水を飲む') : 'タンク（空）'; }
    case 'trap': { const od = odata(0, ob.x, ob.y); return od && od.n ? '魚を取る' : '罠（からっぽ）'; }
    case 'crop': return ob.o === O.CROP3 ? '収穫する' : '育ち中…';
    case 'shipyard': return '造船台';
    case 'ruindoor': return '扉を調べる';
  }
  return '調べる';
}
function doAction() {
  const c = getCtx();
  if (c && c.fn) c.fn();
}

/* ---------- 採集・攻撃 ---------- */
function swing() {
  if (P.cd > 0 || P.swing) return;
  const def = heldDef();
  const tool = def && def.tool ? def.tool : null;
  const cd = tool ? tool.cd : 0.38;
  P.swing = { t: 0, dur: cd, hit: false, tool, slot: P.sel };
  P.cd = cd;
  sfx('swing');
}
function updateSwing(dt) {
  const s = P.swing; if (!s) return;
  s.t += dt;
  if (!s.hit && s.t >= s.dur * 0.35) {
    s.hit = true;
    let used = playerAttack(s.tool);
    if (!used) used = hitTarget(s.tool);
    if (used && s.tool) useDurability(s.slot);
  }
  if (s.t >= s.dur) P.swing = null;
}
function playerAttack(tool) {
  const reach = tool ? tool.reach : 12;
  let dmg = (tool ? tool.dmg : 3) * PS.atk;
  const t = tool ? tool.t : 'hand';
  if (t === 'harpoon') dmg *= P.layer ? 1.4 : 0.8;
  if (t === 'spear' && P.layer) dmg *= 1.15;
  if (t === 'bow') dmg = 3;
  const cosT = t === 'sword' ? -0.1 : (t === 'spear' || t === 'harpoon') ? 0.72 : 0.35;
  const cx = P.x, cy = P.y - 5;
  let hit = false;
  for (const e of ENTS) {
    if (e.layer !== P.layer || e.dead) continue;
    const sp = SPECIES[e.sp];
    if (sp.env === 'air') continue;
    const ex = e.x, ey = e.y - Math.min(sp.r, 8);
    const dx = ex - cx, dy = ey - cy, dist = Math.hypot(dx, dy);
    if (dist > reach + sp.r) continue;
    const dot = (dx * P.fx + dy * P.fy) / (dist || 1);
    if (dist > sp.r + 5 && dot < cosT) continue;
    if (sp.nohit) { toast(sp.n + 'はそっとしておこう'); hit = true; break; }
    hurtCreature(e, Math.round(dmg * rnd(0.9, 1.1)), cx, cy);
    hit = true;
    if (t !== 'sword') break;
  }
  if (hit) {
    const sx = cx + P.fx * reach * 0.8, sy = cy + P.fy * reach * 0.8;
    fxBurst(sx, sy, [255, 255, 255], 5);
  }
  return hit;
}
function hitTarget(tool) {
  const ob = findTargetObj(d => d.hp || d.built);
  const t = tool ? tool.t : 'hand';
  if (!ob) {
    // シャベルで地面を掘る・耕す
    if (t === 'shovel' && P.layer === 0) {
      const ft = facingTile(), g = terAt(0, ft.x, ft.y);
      if (objAt(0, ft.x, ft.y)) return false;
      if (g === T.SAND) { addOrDrop('sand', irnd(1, 2)); fxBurst(ft.x * 16 + 8, ft.y * 16 + 10, C('#ecd59b'), 6); sfx('dig'); return true; }
      if (g === T.GRASS || g === T.DIRT || g === T.FOREST || g === T.JUNGLE) { G.ground[idx(ft.x, ft.y)] = T.FARM; mapDirty(ft.x, ft.y); fxBurst(ft.x * 16 + 8, ft.y * 16 + 10, C('#7d5634'), 6); sfx('dig'); G.stats.tilled = 1; return true; }
    }
    return false;
  }
  const d = ob.d, k = okey(ob.layer, idx(ob.x, ob.y));
  let pow = 0;
  if (d.built) {
    if (t === 'axe' || t === 'pick') pow = tool.pow; else { toast('オノかツルハシで回収できる'); return false; }
  } else {
    switch (d.tool) {
      case 'axe': pow = t === 'axe' ? tool.pow : t === 'hand' ? 1 : 1; break;
      case 'pick':
        if (t !== 'pick') { toast('ツルハシが必要だ', 'red'); sfx('clank'); fxBurst(ob.x * 16 + 8, ob.y * 16 + 8, [200, 200, 200], 3); return false; }
        if ((tool.tier || 0) < (d.tier || 0)) { toast('もっと強いツルハシが必要だ', 'red'); sfx('clank'); return false; }
        pow = tool.pow; break;
      case 'dig': pow = t === 'shovel' ? 3 : 1; break;
      case 'tool': if (t === 'hand') { toast('素手では危ない！道具を使おう', 'red'); hurtPlayer(3, ob.x * 16 + 8, ob.y * 16 + 8); return false; } pow = 2; break;
      default: pow = tool ? Math.max(1, tool.pow) : 1;
    }
  }
  const maxhp = d.built ? 6 : d.hp;
  const cur = objHit.has(k) ? objHit.get(k).hp : maxhp;
  const nh = cur - pow;
  objShake.set(k, 0.18);
  const px = ob.x * 16 + 8, py = ob.y * 16 + 8;
  const woody = d.tool === 'axe' || d.built;
  fxBurst(px, py, woody ? C('#c8925a') : d.tool === 'pick' ? C('#b0aca4') : C('#7cc451'), 4);
  sfx(woody ? 'chop' : d.tool === 'pick' ? 'mine' : 'hitsoft');
  if (nh <= 0) { objHit.delete(k); breakObj(ob); }
  else objHit.set(k, { hp: nh, t: 4 });
  return true;
}
function rollDrops(list, scale = 1) {
  const out = [];
  for (const [id, a, b, p] of list) if (p == null || Math.random() < p) out.push([id, Math.max(1, Math.round(irnd(a, b) * scale))]);
  return out;
}
function breakObj(ob) {
  const d = ob.d, cx = ob.x * 16 + 8, cy = ob.y * 16 + 10;
  if (d.built) {
    const od = odata(ob.layer, ob.x, ob.y);
    if (od && od.items) od.items.forEach(s => { if (s) spawnDrop(ob.layer, cx, cy, s.id, s.n); });
    if (ob.o === O.SHIPYARD && od) { if (od.hull) spawnDrop(0, cx, cy, 'hull', 1); if (od.sail) spawnDrop(0, cx, cy, 'sail', 1); if (od.chart) spawnDrop(0, cx, cy, 'chart', 1); G.flags.ship_hull = G.flags.ship_sail = G.flags.ship_chart = 0; }
    spawnDrop(ob.layer, cx, cy, BUILT_ITEM[ob.o], 1);
    G.special.delete(okey(ob.layer, idx(ob.x, ob.y)));
    setObj(ob.layer, ob.x, ob.y, 0);
    if (ob.o === O.BED && P.spawn.bx === ob.x && P.spawn.by === ob.y) P.spawn = { x: G.lm.start.x * 16 + 8, y: G.lm.start.y * 16 + 12 };
    fxBurst(cx, cy, C('#c8925a'), 10); sfx('break');
    return;
  }
  const scale = (ob.o === O.TREE || ob.o === O.JTREE || ob.o === O.PALM || ob.o === O.PINE) && heldDef() && heldDef().tool && heldDef().tool.pow >= 6 ? 1.35 : 1;
  if (d.drops) rollDrops(d.drops, scale).forEach(([id, n]) => spawnDrop(ob.layer, cx, cy, id, n));
  if (d.loot) rollDrops(LOOT[d.loot]).forEach(([id, n]) => spawnDrop(ob.layer, cx, cy, id, n));
  const isTree = d.tall && d.tool === 'axe' && ob.o !== O.BANANA_E;
  if (d.regrow) scheduleRegrow(ob.layer, ob.x, ob.y, ob.o, d.regrow);
  setObj(ob.layer, ob.x, ob.y, isTree ? O.STUMP : 0);
  if (ob.o === O.STUMP) cancelRegrow(ob.layer, ob.x, ob.y);
  fxBurst(cx, cy, isTree ? C('#5aa63e') : d.tool === 'pick' ? C('#9a9690') : C('#c8a070'), 10);
  if (isTree) { sfx('treefall'); shake(2); G.stats.trees = (G.stats.trees || 0) + 1; }
  else sfx('break');
}
function harvestObj(ob) {
  const d = ob.d;
  rollDrops(d.harvest).forEach(([id, n]) => addOrDrop(id, n));
  if (d.regrow) scheduleRegrow(ob.layer, ob.x, ob.y, ob.o, d.regrow);
  setObj(ob.layer, ob.x, ob.y, d.to ? O[d.to] : 0);
  fxBurst(ob.x * 16 + 8, ob.y * 16 + 8, C('#7cc451'), 6); sfx('pick');
  P.cd = 0.2;
}
function pickupObj(ob) {
  const d = ob.d;
  rollDrops(d.pickup).forEach(([id, n]) => addOrDrop(id, n));
  if (d.regrow) scheduleRegrow(ob.layer, ob.x, ob.y, ob.o, d.regrow);
  setObj(ob.layer, ob.x, ob.y, 0);
  sfx('pick'); P.cd = 0.15;
}
function scheduleRegrow(layer, x, y, o, days) {
  G.regrow.push({ k: okey(layer, idx(x, y)), o, at: G.clock + days * 1440 * rnd(0.85, 1.15) });
}
function cancelRegrow(layer, x, y) { const k = okey(layer, idx(x, y)); G.regrow = G.regrow.filter(r => r.k !== k); }

/* ---------- 設置 ---------- */
function canPlaceAt(objKey, x, y) {
  if (P.layer !== 0) return '水中には置けない';
  if (!inb(x, y)) return 'ここには置けない';
  const pt = ptile();
  if (x === pt.x && y === pt.y && OBJ[O[objKey]].solid) return '自分の足元には置けない';
  if (objAt(0, x, y)) return 'ここには置けない';
  const g = terAt(0, x, y);
  if (g === T.CLIFF || g === T.LAVA) return 'ここには置けない';
  if (objKey === 'FLOOR') return g === T.DEEP ? '深すぎて置けない' : null;
  if (objKey === 'TRAP') return (g === T.SHALLOW || g === T.OCEAN || g === T.FRESH) ? null : '水の中に置こう';
  if (isWaterAny(g)) return '水の上には置けない';
  if (objKey === 'SHIPYARD' && g !== T.SAND) return '砂浜に置こう';
  if (OBJ[O[objKey]].solid) for (const e of ENTS) if (e.layer === 0 && Math.floor(e.x / 16) === x && Math.floor((e.y - 3) / 16) === y) return '生き物がいて置けない';
  return null;
}
function placeAt(ft) {
  const h = held(); if (!h) return;
  const def = ITEMS[h.id], key = def.place;
  if (key === 'SHIPYARD' && G.lm.shipyard && objAt(0, G.lm.shipyard.x, G.lm.shipyard.y) === O.SHIPYARD) { toast('造船台はひとつだけ', 'red'); return; }
  const err = canPlaceAt(key, ft.x, ft.y);
  if (err) { toast(err, 'red'); sfx('err'); return; }
  const o = O[key];
  setObj(0, ft.x, ft.y, o);
  const k = okey(0, idx(ft.x, ft.y));
  if (key === 'STORAGE') G.objData.set(k, { items: new Array(16).fill(null) });
  if (key === 'RAIN') { G.objData.set(k, { w: 0 }); G.special.add(k); }
  if (key === 'TRAP') { G.objData.set(k, { t: G.clock, n: 0 }); G.special.add(k); }
  if (key === 'SHIPYARD') { G.objData.set(k, { hull: 0, sail: 0, chart: 0 }); G.lm.shipyard = { x: ft.x, y: ft.y }; }
  removeItem(h.id, 1);
  if (P.inv[P.sel] && P.inv[P.sel].id === h.id && P.inv[P.sel].n <= 0) P.inv[P.sel] = null;
  G.stats['placed_' + h.id] = 1;
  fxBurst(ft.x * 16 + 8, ft.y * 16 + 12, C('#d8c8a0'), 6);
  sfx('place'); P.cd = 0.25;
  checkQuests(); uiDirty();
}
function plantAt(ft) {
  const h = held(); if (!h) return;
  setObj(0, ft.x, ft.y, O.CROP1);
  const k = okey(0, idx(ft.x, ft.y));
  G.objData.set(k, { t: G.clock }); G.special.add(k);
  removeItem(h.id, 1);
  sfx('place'); P.cd = 0.25; G.stats.planted = 1;
}

/* ---------- 食べる・飲む ---------- */
function eatSel() {
  const h = held(); if (!h || P.cd > 0) return;
  const def = ITEMS[h.id], f = def.f;
  if (!def.med && f.h > 0 && P.hunger >= 99 && f.w <= 0) { toast('お腹いっぱいだ'); return; }
  P.hunger = clamp(P.hunger + f.h, 0, 100);
  P.thirst = clamp(P.thirst + f.w, 0, 100);
  if (f.hp > 0) P.hp = Math.min(PS.hpmax, P.hp + f.hp);
  if (f.hp < 0) { P.hp += f.hp; if (Math.random() < 0.5) { P.poison = Math.max(P.poison, 4); toast('お腹をこわした…', 'red'); } }
  if (def.cure) { P.poison = 0; toast('毒が治った！', 'gold'); }
  if (h.id.endsWith('_c') || h.id === 'feast') G.stats.ate_cooked = 1;
  G.stats.eaten = (G.stats.eaten || 0) + 1;
  h.n--; if (h.n <= 0) P.inv[P.sel] = null;
  if (def.ret) addOrDrop(def.ret, 1, true);
  sfx(h.id === 'water' ? 'drink' : 'eat');
  fxText(P.x, P.y - 18, def.med ? '+HP' : 'もぐもぐ', [255, 240, 200]);
  P.cd = 0.35;
  uiDirty(); checkQuests();
}
function drink(fresh) {
  if (P.cd > 0) return;
  P.cd = 0.4;
  if (fresh) {
    P.thirst = clamp(P.thirst + 22, 0, 100);
    G.stats.drank_fresh = 1;
    sfx('drink'); fxText(P.x, P.y - 18, 'ごくごく', [180, 230, 255]);
    checkQuests();
  } else {
    P.thirst = clamp(P.thirst + 4, 0, 100); P.hp -= 4;
    sfx('hurt'); toast('しょっぱい！ 海水は体に悪い…', 'red');
  }
}
function fillCanteen() {
  const h = held(); if (!h || h.id !== 'canteen') return;
  removeItem('canteen', 1); addOrDrop('water', 1, true);
  toast('水筒に水をくんだ'); sfx('drink'); P.cd = 0.3; uiDirty();
}

/* ---------- 釣り ---------- */
function castFish() {
  const w = waterAhead(); if (!w) return;
  P.fish = { state: 'wait', t: rnd(2.5, 7), bx: w.x * 16 + 8 + rnd(-3, 3), by: w.y * 16 + 9 + rnd(-2, 2), fresh: w.t === T.FRESH, slot: P.sel };
  P.cd = 0.3; sfx('cast');
}
function updateFish(dt) {
  const f = P.fish; if (!f) return;
  if (Math.hypot(input.mx, input.my) > 0.5 || P.layer || !held() || held().id !== 'rod') { P.fish = null; return; }
  f.t -= dt;
  if (f.state === 'wait' && f.t <= 0) { f.state = 'bite'; f.t = 0.9; sfx('bite'); fxText(f.bx, f.by - 12, '!', [255, 220, 80]); vib(30); }
  else if (f.state === 'bite' && f.t <= 0) { P.fish = null; toast('逃げられた…'); }
}
function reelFish() {
  const f = P.fish; if (!f) return;
  P.fish = null; P.cd = 0.3;
  if (f.state !== 'bite') { toast('何もかからなかった'); sfx('cast'); return; }
  let got;
  const r = Math.random();
  if (f.fresh) got = ['fish_raw', 1];
  else got = r < 0.7 ? ['fish_raw', 1] : r < 0.82 ? ['seaweed', 2] : r < 0.9 ? ['shell', 1] : r < 0.94 ? ['pearl', 1] : r < 0.97 ? ['clam', 1] : pick(rollDrops(LOOT.treasure).concat([['iron', 1]]));
  addOrDrop(got[0], got[1]);
  G.stats.fish = (G.stats.fish || 0) + 1;
  fxSplash(f.bx, f.by); sfx('catch');
  useDurability(f.slot);
}
function shootBow() {
  if (P.cd > 0) return;
  if (P.layer) { toast('水中では弓は使えない', 'red'); return; }
  if (invCount('arrow') <= 0) { toast('矢がない！', 'red'); return; }
  removeItem('arrow', 1);
  const def = heldDef();
  PROJ.push({ x: P.x + P.fx * 6, y: P.y - 6 + P.fy * 6, vx: P.fx * 230, vy: P.fy * 230, layer: 0, owner: 'p', dmg: Math.round(def.tool.dmg * PS.atk), spr: 'arrow', life: 0.9, ang: Math.atan2(P.fy, P.fx) });
  P.cd = def.tool.cd; sfx('bow'); useDurability(P.sel);
}

/* ---------- いかだ・潜水 ---------- */
function boardRaft() { P.raft = true; P.vx = P.vy = 0; sfx('splash'); toast('いかだに乗った（Xで降りる）'); G.stats.raft = 1; }
function xAction() {
  if (!P || P.dead) return;
  if (P.raft) { P.raft = false; sfx('splash'); toast('いかだを降りた'); return; }
  if (P.layer === 0) {
    if (P.mode === 'swim') {
      const pt = ptile();
      if (terAt(1, pt.x, pt.y) === U.WALL) { toast('ここは浅くて潜れない'); return; }
      P.layer = 1; P.vx *= 0.3; P.vy *= 0.3;
      unstick(P, 1);
      fxSplash(P.x, P.y); sfx('dive');
      G.stats.dived = 1; checkQuests();
      mapAddDiscover();
    } else if (P.mode === 'wade') toast('もっと深い所で潜れる');
  } else {
    P.layer = 0; fxSplash(P.x, P.y); sfx('surface');
    if (P.o2 < PS.o2max * 0.3) fxText(P.x, P.y - 18, 'ぷはっ！', [200, 240, 255]);
  }
}
function unstick(e, layer) {
  const hw = PHW, hh = PHH;
  if (!boxSolid(layer, e.x, e.y, hw, hh, 'player')) return;
  for (let r = 4; r < 48; r += 4) for (let a = 0; a < 8; a++) {
    const nx = e.x + Math.cos(a * Math.PI / 4) * r, ny = e.y + Math.sin(a * Math.PI / 4) * r;
    if (!boxSolid(layer, nx, ny, hw, hh, 'player')) { e.x = nx; e.y = ny; return; }
  }
}

/* ---------- 移動と当たり判定 ---------- */
function boxSolid(layer, x, y, hw, hh, who) {
  const x0 = Math.floor((x - hw) / TILE), x1 = Math.floor((x + hw - 0.01) / TILE), y0 = Math.floor((y - hh) / TILE), y1 = Math.floor((y + hh - 0.01) / TILE);
  for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) if (solidAt(layer, tx, ty, who)) return true;
  return false;
}
function moveBox(e, dx, dy, hw, hh, who) {
  let hit = false;
  const steps = Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / 5) || 1;
  const sx = dx / steps, sy = dy / steps;
  for (let i = 0; i < steps; i++) {
    if (sx) { if (!boxSolid(e.layer, e.x + sx, e.y, hw, hh, who)) e.x += sx; else hit = true; }
    if (sy) { if (!boxSolid(e.layer, e.x, e.y + sy, hw, hh, who)) e.y += sy; else hit = true; }
  }
  return hit;
}
function playerMode() {
  if (P.layer === 1) return 'dive';
  const pt = { x: Math.floor(P.x / TILE), y: Math.floor((P.y - 1) / TILE) };
  const o = objAt(0, pt.x, pt.y);
  if (o && OBJ[o].bridge) return 'walk';
  if (P.raft) return 'raft';
  const g = terAt(0, pt.x, pt.y);
  if (isSwim(g)) return 'swim';
  if (g === T.SHALLOW || g === T.FRESH) return 'wade';
  return 'walk';
}
function updatePlayer(dt) {
  if (P.dead) return;
  const ax = input.mx, ay = input.my;
  const mag = Math.min(1, Math.hypot(ax, ay));
  P.mode = playerMode();
  if (mag > 0.2) {
    P.fx = ax / Math.hypot(ax, ay); P.fy = ay / Math.hypot(ax, ay);
    P.dir = Math.abs(ax) > Math.abs(ay) ? (ax > 0 ? 'r' : 'l') : (ay > 0 ? 'd' : 'u');
  }
  const run = input.b && mag > 0.2 && P.stam > 1 && (P.mode === 'walk' || P.mode === 'wade');
  let spd;
  switch (P.mode) {
    case 'walk': spd = 62 * (1 + PS.spd) * (run ? 1.55 : 1); break;
    case 'wade': spd = 44 * (1 + PS.spd * 0.5) * (run ? 1.35 : 1); break;
    case 'swim': spd = 38 * (1 + PS.swim) * (input.b && P.stam > 1 ? 1.35 : 1); break;
    case 'dive': spd = 46 * (1 + PS.swim) * (input.b ? 1.3 : 1); break;
    case 'raft': spd = 92; break;
  }
  if (P.fish) spd = 0;
  if (P.swing && P.mode === 'walk') spd *= 0.6;
  const tvx = ax * spd * (mag > 0.2 ? 1 : 0), tvy = ay * spd * (mag > 0.2 ? 1 : 0);
  const k = (P.mode === 'dive' || P.mode === 'raft' || P.mode === 'swim') ? 1 - Math.exp(-dt * 4.5) : 1 - Math.exp(-dt * 20);
  P.vx = lerp(P.vx, tvx, k); P.vy = lerp(P.vy, tvy, k);
  let dx = (P.vx + P.kx) * dt, dy = (P.vy + P.ky) * dt;
  P.kx *= Math.exp(-dt * 10); P.ky *= Math.exp(-dt * 10);
  if (P.raft) {
    const nx = P.x + dx, ny = P.y + dy, tx = Math.floor(nx / TILE), ty = Math.floor((ny - 1) / TILE);
    const g = terAt(0, tx, ty);
    if (!isWaterAny(g) && !solidAt(0, tx, ty, 'player')) { P.raft = false; toast('いかだを降りた'); }
  }
  moveBox(P, dx, dy, PHW, PHH, 'player');
  P.x = clamp(P.x, 8, MAP * TILE - 8); P.y = clamp(P.y, 8, MAP * TILE - 8);
  P.moving = Math.hypot(P.vx, P.vy) > 8;
  if (P.moving) {
    P.anim += dt * (run ? 12 : 8);
    P.step -= dt;
    if (P.step <= 0) {
      P.step = run ? 0.24 : 0.34;
      if (P.mode === 'walk') { const g = terAt(0, ptile().x, ptile().y); sfx(g === T.SAND ? 'stepsand' : 'step'); }
      else if (P.mode === 'wade' || P.mode === 'swim') { sfx('swimstroke'); fxRipple(P.x, P.y); }
      else if (P.mode === 'dive' && Math.random() < 0.3) fxBubble(P.x + rnd(-3, 3), P.y - 10);
    }
  } else P.anim = 0;
  // スタミナ
  if (run) P.stam -= 18 * dt;
  else if (P.mode === 'swim') P.stam -= (P.moving ? 4.8 : 2.4) * (input.b ? 1.8 : 1) * dt;
  else if (P.mode === 'walk') P.stam += (P.hunger < 10 ? 9 : 22) * dt;
  else if (P.mode === 'wade') P.stam += 10 * dt;
  else if (P.mode === 'raft') P.stam += 15 * dt;
  P.stam = clamp(P.stam, 0, 100);
  if (P.mode === 'swim' && P.stam <= 0) {
    P.hp -= 6 * dt;
    P.drownMsg -= dt; if (P.drownMsg <= 0) { toast('疲れて溺れそう！ 陸へ急げ！', 'red'); P.drownMsg = 3; sfx('warn'); }
  }
  // 酸素
  if (P.layer === 1) {
    const pt = ptile();
    let drain = PS.drain * (terAt(1, pt.x, pt.y) === U.TRENCH ? 1.5 : 1);
    let nearVent = false;
    for (let dy = -1; dy <= 1 && !nearVent; dy++) for (let dx2 = -1; dx2 <= 1; dx2++) if (objAt(1, pt.x + dx2, pt.y + dy) === O.VENT && d2((pt.x + dx2) * 16 + 8, (pt.y + dy) * 16 + 10, P.x, P.y) < 22 * 22) { nearVent = true; break; }
    if (nearVent) { P.o2 = Math.min(PS.o2max, P.o2 + 30 * dt); if (Math.random() < 0.3) fxBubble(P.x + rnd(-4, 4), P.y - 6); }
    else P.o2 -= drain * dt;
    if (P.o2 <= 0) {
      P.o2 = 0; P.hp -= 10 * dt;
      P.o2warn -= dt; if (P.o2warn <= 0) { toast('息が…！ Xで浮上！', 'red'); sfx('warn'); P.o2warn = 2; vib(80); }
    } else if (P.o2 < PS.o2max * 0.25) { P.o2warn -= dt; if (P.o2warn <= 0) { sfx('warn'); P.o2warn = 1.6; } }
    if (Math.random() < dt * 0.8) fxBubble(P.x + rnd(-2, 2), P.y - 12);
  } else P.o2 = Math.min(PS.o2max, P.o2 + 30 * dt);
  // 空腹・のど
  const act = (run ? 1.6 : 1) * (P.mode === 'swim' || P.mode === 'dive' ? 1.3 : 1);
  const hot = terAt(0, ptile().x, ptile().y) === T.VOLC || terAt(0, ptile().x, ptile().y) === T.LAVA ? 1.6 : 1;
  P.hunger = Math.max(0, P.hunger - dt * (100 / 760) * act);
  P.thirst = Math.max(0, P.thirst - dt * (100 / 560) * act * hot);
  if (P.hunger <= 0) P.hp -= 1.2 * dt;
  if (P.thirst <= 0) P.hp -= 1.2 * dt;
  if (P.poison > 0) { P.poison -= dt; P.hp -= 1.4 * dt; }
  else if (P.hunger > 40 && P.thirst > 40 && P.hp < PS.hpmax) P.hp = Math.min(PS.hpmax, P.hp + 0.55 * dt);
  // ウニ
  if (P.layer === 1 && P.invul <= 0) {
    const pt = ptile();
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      if (objAt(1, pt.x + dx, pt.y + dy) !== O.URCHIN) continue;
      const ux = (pt.x + dx) * 16 + 8, uy = (pt.y + dy) * 16 + 10;
      if (Math.abs(P.x - ux) < 11 && Math.abs(P.y - uy) < 10) { hurtPlayer(4, ux, uy); toast('ウニのトゲが刺さった！', 'red'); }
    }
  }
  // 溶岩
  if (P.layer === 0 && P.mode === 'walk' && terAt(0, Math.floor(P.x / 16), Math.floor((P.y - 1) / 16)) === T.LAVA) {
    hurtPlayer(14, P.x - P.fx * 10, P.y - P.fy * 10, false, true);
    if (Math.random() < 0.4) toast('あつっ！ 溶岩だ！', 'red');
  }
  if (P.invul > 0) P.invul -= dt;
  if (P.cd > 0) P.cd -= dt;
  updateSwing(dt);
  updateFish(dt);
  if (P.hp <= 0) killPlayer();
}
function hurtPlayer(dmg, sx, sy, poison, ignoreInv) {
  if (P.dead || (P.invul > 0 && !ignoreInv)) return;
  const real = Math.max(1, Math.round(dmg * Math.max(0.3, 1 - PS.def * 0.06)));
  P.hp -= real; P.invul = 0.7;
  const a = Math.atan2(P.y - sy, P.x - sx);
  P.kx = Math.cos(a) * 140; P.ky = Math.sin(a) * 140;
  if (poison) { P.poison = Math.max(P.poison, 7); toast('毒を受けた！', 'red'); }
  fxText(P.x, P.y - 20, '-' + real, [255, 90, 90]);
  fxBurst(P.x, P.y - 8, [255, 80, 80], 6);
  shake(3); flashScreen(0.25); sfx('hurt'); vib(60);
  if (P.fish) P.fish = null;
  if (P.hp <= 0) killPlayer();
}
function killPlayer() {
  if (P.dead) return;
  P.dead = true; P.hp = 0; P.swing = null; P.fish = null; P.raft = false;
  const items = P.inv.filter(Boolean).map(s => ({ ...s }));
  if (items.length) {
    let tx = Math.floor(P.x / 16), ty = Math.floor((P.y - 3) / 16);
    let found = false;
    for (let r = 0; r < 6 && !found; r++) for (let dy = -r; dy <= r && !found; dy++) for (let dx = -r; dx <= r; dx++) {
      const x = tx + dx, y = ty + dy;
      if (!inb(x, y) || objAt(P.layer, x, y)) continue;
      if (P.layer === 0 && (terAt(0, x, y) === T.CLIFF || terAt(0, x, y) === T.LAVA)) continue;
      if (P.layer === 1 && terAt(1, x, y) === U.WALL) continue;
      tx = x; ty = y; found = true; break;
    }
    if (found) {
      setObj(P.layer, tx, ty, O.BAG);
      const slots = new Array(32).fill(null); items.forEach((s, i) => slots[i] = s);
      G.objData.set(okey(P.layer, idx(tx, ty)), { items: slots });
      G.lm.bag = { x: tx, y: ty, layer: P.layer };
    }
    P.inv = new Array(INV_N).fill(null);
  }
  G.stats.deaths = (G.stats.deaths || 0) + 1;
  sfx('death'); shake(6);
  uiDirty();
  later(() => showDeath(), 900);
}
function respawn() {
  P.dead = false; P.layer = 0;
  P.x = P.spawn.x; P.y = P.spawn.y;
  P.hp = Math.round(PS.hpmax * 0.6); P.hunger = Math.max(P.hunger, 50); P.thirst = Math.max(P.thirst, 50); P.stam = 100; P.o2 = PS.o2max; P.poison = 0;
  P.vx = P.vy = P.kx = P.ky = 0; P.invul = 2;
  unstick(P, 0);
  for (let i = ENTS.length - 1; i >= 0; i--) if (!SPECIES[ENTS[i].sp].boss && ENTS[i].sp !== 'parrot' && d2(ENTS[i].x, ENTS[i].y, P.x, P.y) < 200 * 200) ENTS.splice(i, 1);
  G.clock += 120;
  snapCamera();
  uiDirty();
}

/* ---------- 調べる ---------- */
function interact(ob) {
  const d = ob.d, k = okey(ob.layer, idx(ob.x, ob.y));
  P.cd = 0.25;
  switch (d.ia) {
    case 'chest': openChest(ob); sfx('chest'); break;
    case 'bag': {
      const od = G.objData.get(k);
      if (od && od.items) {
        for (let i = 0; i < od.items.length; i++) { const s = od.items[i]; if (!s) continue; const left = addItem(s.id, s.n, true); if (left) s.n = left; else od.items[i] = null; }
        if (od.items.every(s => !s)) { setObj(ob.layer, ob.x, ob.y, 0); G.lm.bag = null; toast('遺品をすべて回収した', 'gold'); }
        else toast('持ち物がいっぱいで全部は持てない', 'red');
      }
      sfx('pick'); uiDirty(); break;
    }
    case 'bottle': {
      const od = G.objData.get(k); const mi = od ? od.msg : 0;
      setObj(ob.layer, ob.x, ob.y, 0);
      if (!G.read.includes(mi)) G.read.push(mi);
      sfx('paper');
      dialog([{ name: '漂流瓶の手紙「' + BOTTLE_TITLE[mi] + '」', text: BOTTLE_MSG[mi] }, '（ノートに記録した）']);
      break;
    }
    case 'fire': openMenu('craft', 'fire'); break;
    case 'bench': openMenu('craft', 'bench'); break;
    case 'furnace': openMenu('craft', 'furnace'); break;
    case 'bed': useBed(ob); break;
    case 'rain': {
      const od = G.objData.get(k);
      if (!od || od.w < 1) { toast('まだ水がたまっていない（雨を待とう）'); break; }
      if (held() && held().id === 'canteen') { od.w -= 1; removeItem('canteen', 1); addOrDrop('water', 1, true); toast('水筒に雨水をくんだ'); }
      else { od.w -= 1; P.thirst = clamp(P.thirst + 30, 0, 100); G.stats.drank_fresh = 1; fxText(P.x, P.y - 18, 'ごくごく', [180, 230, 255]); checkQuests(); }
      sfx('drink'); uiDirty(); break;
    }
    case 'trap': {
      const od = G.objData.get(k);
      if (od && od.n) { addOrDrop('fish_raw', od.n); od.n = 0; od.t = G.clock; sfx('catch'); fxSplash(ob.x * 16 + 8, ob.y * 16 + 10); }
      else toast('まだ何もかかっていない');
      break;
    }
    case 'crop': {
      if (ob.o !== O.CROP3) { toast('まだ育っている途中だ'); break; }
      addOrDrop('potato', irnd(2, 4));
      setObj(0, ob.x, ob.y, 0); G.special.delete(k); sfx('pick');
      break;
    }
    case 'shipyard': openShipyard(ob); break;
    case 'ruindoor': {
      if (invCount('ancient_key') > 0) {
        removeItem('ancient_key', 1);
        dialog(['古代の鍵を差し込んだ……', 'ゴゴゴゴ…… 扉が開いた！'], () => { setObj(0, ob.x, ob.y, 0); sfx('door'); shake(4); G.flags.ruin_open = 1; });
      } else dialog(['古い文字が刻まれた石の扉だ。中央にくぼみがある。', '「海の底に眠る鍵のみが、この扉を開く」…と読める。']);
      break;
    }
  }
}
function useBed(ob) {
  const tod = G.clock % 1440;
  P.spawn = { x: ob.x * 16 + 8, y: ob.y * 16 + 26, bx: ob.x, by: ob.y };
  if (!boxSolid(0, P.spawn.x, P.spawn.y, PHW, PHH, 'player')) { } else P.spawn = { x: P.x, y: P.y, bx: ob.x, by: ob.y };
  if (!(tod >= 1080 || tod < 300)) { toast('まだ眠れない（復活地点をここにした）'); return; }
  for (const e of ENTS) if (e.aggro && !e.dead && d2(e.x, e.y, P.x, P.y) < 110 * 110) { toast('近くに敵がいて眠れない！', 'red'); return; }
  dialog([{ text: '眠りますか？', choices: [['眠る', () => doSleep()], ['やめる', null]] }]);
}
function doSleep() {
  fadeOut(() => {
    const tod = G.clock % 1440;
    G.clock += tod >= 1080 ? (1440 - tod + 360) : (360 - tod);
    P.hunger = Math.max(5, P.hunger - 18); P.thirst = Math.max(5, P.thirst - 22);
    P.hp = Math.min(PS.hpmax, P.hp + 45); P.stam = 100; P.poison = 0;
    G.stats.slept = 1;
    for (let i = ENTS.length - 1; i >= 0; i--) if (ENTS[i].aggro && !SPECIES[ENTS[i].sp].boss) ENTS.splice(i, 1);
    tickWorld(0);
    saveGame(true);
    checkQuests();
    fadeIn();
    toast(`${dayNum()}日目の朝が来た`, 'gold big');
  });
}

/* ---------- クラフト ---------- */
function nearStations() {
  const s = { hand: true, bench: false, furnace: false, fire: false };
  if (P.layer !== 0) return s;
  const pt = ptile();
  for (let dy = -3; dy <= 3; dy++) for (let dx = -3; dx <= 3; dx++) {
    const o = objAt(0, pt.x + dx, pt.y + dy);
    if (o === O.BENCH) s.bench = true;
    else if (o === O.FURNACE) { s.furnace = true; s.fire = true; }
    else if (o === O.CAMPFIRE) s.fire = true;
  }
  return s;
}
function recipeVisible(r) {
  if (r.unlock && !G.flags[r.unlock]) return false;
  if (r.hideUnless && !r.hideUnless.some(id => countItem(id) > 0)) return false;
  return true;
}
function hasIngredients(r) { for (const k in r.i) if (invCount(k) < r.i[k]) return false; return true; }
function canCraft(r, st) { return !!st[r.st] && hasIngredients(r); }
function craft(r, times) {
  const st = nearStations();
  let made = 0;
  for (let t = 0; t < times; t++) {
    if (!canCraft(r, st)) break;
    for (const k in r.i) removeItem(k, r.i[k]);
    addOrDrop(r.o, r.n || 1, true);
    made++;
  }
  if (made) {
    G.stats['crafted_' + r.o] = 1;
    G.stats.crafted = (G.stats.crafted || 0) + made;
    toast(`${ITEMS[r.o].n} ×${made * (r.n || 1)} を作った！`, 'gold');
    sfx(r.st === 'fire' ? 'cook' : r.st === 'furnace' ? 'smelt' : 'craft');
    if (r.o === 'chart') dialog(['三つの切れ端をつなぎ合わせた。', '島の外へ続く航路が、はっきりと描かれている！']);
    checkQuests(); uiDirty();
  }
  return made;
}

/* ---------- オウム ---------- */
function befriendParrot(e) {
  removeItem(held().id, 1);
  G.flags.parrot = 1;
  e.tame = true;
  sfx('parrot');
  dialog(['オウムはエサをおいしそうに食べた。', 'オウム「ポコ！ ポコ！」', '…どうやら懐いたようだ。「ポコ」と名付けよう。', '（ポコに話しかけるとヒントをくれる）']);
  uiDirty();
}
function parrotTalk() {
  sfx('parrot');
  const qi = Math.min(G.quest, PARROT_HINT.length - 1);
  dialog([PARROT_HINT[qi]]);
}
/* =============================================================
   生き物・AI・ボス・投射物・ドロップ・パーティクル・世界の時間
   ============================================================= */
function makeCreature(sp, x, y, layer, extra) {
  const S = SPECIES[sp];
  const e = { sp, x, y, layer, hp: S.hp, maxhp: S.hp, vx: 0, vy: 0, kx: 0, ky: 0, face: 1, st: 'idle', t: rnd(0.5, 2), anim: Math.random() * 10, flash: 0, inv: 0, atk: 0, home: { x, y }, aggro: false, dead: false, tx: x, ty: y };
  if (sp === 'fish') e.var = irnd(0, 3);
  if (extra) Object.assign(e, extra);
  ENTS.push(e);
  return e;
}
const crWho = e => SPECIES[e.sp].env === 'land' ? 'land' : e.layer === 0 ? 'sea' : 'player';
function crMove(e, vx, vy, dt) {
  const S = SPECIES[e.sp];
  if (S.env === 'air') { e.x += (vx + e.kx) * dt; e.y += (vy + e.ky) * dt; }
  else {
    const hw = Math.min(6, S.r * 0.6), hh = Math.min(4, S.r * 0.45);
    const hit = moveBox(e, (vx + e.kx) * dt, (vy + e.ky) * dt, hw, hh, crWho(e));
    if (hit) e.blocked = (e.blocked || 0) + dt; else e.blocked = 0;
  }
  e.kx *= Math.exp(-dt * 8); e.ky *= Math.exp(-dt * 8);
  if (Math.abs(vx) > 2) e.face = vx > 0 ? 1 : -1;
}
const toward = (e, tx, ty, spd) => { const dx = tx - e.x, dy = ty - e.y, d = Math.hypot(dx, dy) || 1; return [dx / d * spd, dy / d * spd, d]; };
function canSeePlayer(e) {
  if (P.dead || e.layer !== P.layer) return false;
  const S = SPECIES[e.sp];
  if (S.env === 'land' && (P.mode === 'swim' || P.mode === 'raft')) return false;
  return true;
}
function wander(e, dt, spd, radius) {
  e.t -= dt;
  if (e.t <= 0 || e.blocked > 0.3) {
    e.t = rnd(1, 3.5);
    if (Math.random() < 0.35) { e.tx = e.x; e.ty = e.y; }
    else { const a = Math.random() * Math.PI * 2, r = rnd(10, radius); e.tx = e.home.x + Math.cos(a) * r; e.ty = e.home.y + Math.sin(a) * r; }
    e.blocked = 0;
  }
  const [vx, vy, d] = toward(e, e.tx, e.ty, spd);
  if (d > 3) crMove(e, vx, vy, dt); else crMove(e, 0, 0, dt);
}
function contactDamage(e, range, dmg, poison) {
  if (e.atk > 0 || !canSeePlayer(e)) return false;
  if (d2(e.x, e.y - 4, P.x, P.y - 4) < range * range) { hurtPlayer(dmg, e.x, e.y, poison); e.atk = 1.1; return true; }
  return false;
}
function updateCreature(e, dt) {
  const S = SPECIES[e.sp];
  e.anim += dt * 6;
  if (e.flash > 0) e.flash -= dt;
  if (e.inv > 0) e.inv -= dt;
  if (e.atk > 0) e.atk -= dt;
  const dP = Math.sqrt(d2(e.x, e.y, P.x, P.y));
  const see = canSeePlayer(e);
  const night = isNight();
  switch (S.ai) {
    case 'passive': wander(e, dt, S.spd, 50); break;
    case 'crab': {
      const ag = (S.aggro * (night ? 1.6 : 1));
      if (see && (dP < ag || e.aggro)) { e.aggro = dP < ag * 2; const [vx, vy] = toward(e, P.x, P.y, S.spd * (night ? 1.25 : 1)); crMove(e, vx, vy, dt); contactDamage(e, 11, S.dmg); }
      else wander(e, dt, S.spd * 0.5, 40);
      break;
    }
    case 'boar': {
      const ag = S.aggro * (night ? 1.5 : 1);
      if (e.hp < e.maxhp * 0.3 && see && dP < 120) { const [vx, vy] = toward(e, P.x, P.y, -S.spd * 1.4); crMove(e, vx, vy, dt); break; }
      if (e.st === 'charge') {
        e.t -= dt; crMove(e, e.cvx, e.cvy, dt);
        if (contactDamage(e, 13, S.dmg)) { e.st = 'rest'; e.t = 1.2; }
        if (e.t <= 0 || e.blocked > 0.05) { e.st = 'rest'; e.t = 1; if (e.blocked) { shake(1); fxBurst(e.x, e.y - 4, [200, 180, 150], 4); } }
      } else if (e.st === 'alert') {
        e.t -= dt; crMove(e, 0, 0, dt);
        if (e.t <= 0) { const [vx, vy] = toward(e, P.x, P.y, S.spd * 3.6); e.cvx = vx; e.cvy = vy; e.st = 'charge'; e.t = 1.1; sfx('charge'); }
      } else if (e.st === 'rest') { e.t -= dt; crMove(e, 0, 0, dt); if (e.t <= 0) e.st = 'idle'; }
      else {
        if (see && (dP < ag || (e.aggro && dP < ag * 2))) { e.aggro = true; e.st = 'alert'; e.t = 0.55; fxText(e.x, e.y - 16, '!', [255, 80, 60]); }
        else wander(e, dt, S.spd * 0.45, 60);
      }
      break;
    }
    case 'snake': {
      if (e.st === 'lunge') { e.t -= dt; crMove(e, e.cvx, e.cvy, dt); contactDamage(e, 10, S.dmg, true); if (e.t <= 0) { e.st = 'idle'; e.atk = Math.max(e.atk, 1.2); } break; }
      if (see && (dP < S.aggro || e.aggro)) {
        e.aggro = dP < S.aggro * 2.5;
        if (dP < 26 && e.atk <= 0) { const [vx, vy] = toward(e, P.x, P.y, 150); e.cvx = vx; e.cvy = vy; e.st = 'lunge'; e.t = 0.22; sfx('hiss'); }
        else { const [vx, vy] = toward(e, P.x, P.y, S.spd); crMove(e, vx, vy, dt); }
      } else wander(e, dt, S.spd * 0.5, 40);
      break;
    }
    case 'monkey': {
      if (see && (dP < S.aggro || e.aggro)) {
        e.aggro = dP < S.aggro * 1.8;
        const want = 64;
        const [vx, vy] = toward(e, P.x, P.y, dP > want + 10 ? S.spd * 0.7 : dP < want - 10 ? -S.spd : 0);
        const sx = -vy * 0.4, sy = vx * 0.4;
        crMove(e, vx + sx, vy + sy, dt);
        e.t -= dt;
        if (e.t <= 0) { e.t = rnd(1.8, 2.8); const [px, py] = toward(e, P.x, P.y - 4, 125); PROJ.push({ x: e.x, y: e.y - 8, vx: px, vy: py, layer: 0, owner: 'e', dmg: S.dmg, spr: 'coco', life: 1.6 }); sfx('throw'); }
      } else wander(e, dt, S.spd * 0.4, 50);
      break;
    }
    case 'parrot': updateParrot(e, dt); break;
    case 'fish': {
      if (see && dP < 46) { const [vx, vy] = toward(e, P.x, P.y, -S.spd * 1.6); crMove(e, vx, vy, dt); e.home.x = e.x; e.home.y = e.y; }
      else wander(e, dt, S.spd * 0.45, 60);
      break;
    }
    case 'jelly': {
      e.t -= dt;
      if (e.t <= 0) { e.t = rnd(2, 4); const a = Math.random() * Math.PI * 2; e.cvx = Math.cos(a) * S.spd; e.cvy = Math.sin(a) * S.spd; }
      const pulse = (Math.sin(e.anim * 0.6) + 1) * 0.5;
      crMove(e, (e.cvx || 0) * pulse, (e.cvy || 0) * pulse, dt);
      contactDamage(e, 10, S.dmg, true);
      break;
    }
    case 'moray': {
      if (e.st === 'lunge') { e.t -= dt; crMove(e, e.cvx, e.cvy, dt); contactDamage(e, 11, S.dmg); if (e.t <= 0) { e.st = 'back'; } break; }
      if (e.st === 'back') { const [vx, vy, d] = toward(e, e.home.x, e.home.y, 50); crMove(e, vx, vy, dt); if (d < 4) { e.st = 'idle'; e.atk = 1.6; } break; }
      if (see && d2(P.x, P.y, e.home.x, e.home.y) < (S.aggro + 10) ** 2 && e.atk <= 0) { const [vx, vy] = toward(e, P.x, P.y, 170); e.cvx = vx; e.cvy = vy; e.st = 'lunge'; e.t = 0.3; e.aggro = true; }
      else { e.face = P.x > e.x ? 1 : -1; crMove(e, Math.sin(e.anim * 0.3) * 4, 0, dt); }
      break;
    }
    case 'shark': updateShark(e, dt, dP, see); break;
    case 'angler': {
      if (see && (dP < S.aggro || e.aggro)) { e.aggro = true; const [vx, vy] = toward(e, P.x, P.y, S.spd); crMove(e, vx, vy, dt); contactDamage(e, 11, S.dmg); }
      else wander(e, dt, S.spd * 0.4, 50);
      break;
    }
    case 'gcrab': updateGCrab(e, dt, dP, see); break;
    case 'boss': updateBoss(e, dt, dP, see); break;
  }
}
function updateShark(e, dt, dP, see) {
  const S = SPECIES.shark;
  // 水面を泳ぐプレイヤーを追って浮上（背びれ）
  const pt = ptile();
  if (!P.dead && e.layer !== P.layer && dP < 160) {
    if (P.layer === 0 && P.mode === 'swim' && isSwim(terAt(0, Math.floor(e.x / 16), Math.floor(e.y / 16)))) { e.layer = 0; e.st = 'circle'; e.t = rnd(2, 3); }
    else if (P.layer === 1) e.layer = 1;
  }
  if (e.layer === 0 && (P.layer !== 0 || P.mode !== 'swim')) {
    e.layer = 1; e.st = 'idle';
  }
  const hunting = e.layer === P.layer && !P.dead && (dP < S.aggro || e.aggro) && (P.layer === 1 || P.mode === 'swim');
  if (!hunting) { wander(e, dt, S.spd * 0.5, 120); e.st = 'idle'; return; }
  e.aggro = dP < S.aggro * 2;
  if (e.st === 'charge') {
    e.t -= dt; crMove(e, e.cvx, e.cvy, dt);
    if (contactDamage(e, 14, S.dmg)) { e.st = 'circle'; e.t = rnd(2, 3.5); }
    if (e.t <= 0) { e.st = 'circle'; e.t = rnd(2, 3.5); }
  } else {
    if (e.st !== 'circle') { e.st = 'circle'; e.t = rnd(2, 3.5); }
    e.t -= dt;
    const a = Math.atan2(e.y - P.y, e.x - P.x) + dt * 1.4;
    const tx = P.x + Math.cos(a) * 52, ty = P.y + Math.sin(a) * 52;
    const [vx, vy] = toward(e, tx, ty, S.spd);
    crMove(e, vx, vy, dt);
    if (e.t <= 0) { const [cx, cy] = toward(e, P.x, P.y, S.spd * 2.6); e.cvx = cx; e.cvy = cy; e.st = 'charge'; e.t = 0.9; sfx('charge'); }
  }
}
function updateGCrab(e, dt, dP, see) {
  const S = SPECIES.gcrab;
  const enr = e.hp < e.maxhp * 0.4 ? 1.35 : 1;
  if (!see || dP > 220) { wander(e, dt, S.spd * 0.4, 30); e.aggro = false; return; }
  if (!e.aggro) { e.aggro = true; bossBar(e); sfx('roar'); toast('巨大ヤシガニが襲ってきた！', 'red big'); setMusic('boss'); }
  e.t -= dt;
  switch (e.st) {
    case 'pinch': crMove(e, 0, 0, dt); if (e.t <= 0) { if (dP < 34) hurtPlayer(S.dmg, e.x, e.y); fxBurst(e.x + e.face * 18, e.y - 8, [255, 200, 120], 8); shake(3); sfx('clank'); e.st = 'walk'; e.t = rnd(1.2, 2) / enr; } break;
    case 'charge': crMove(e, e.cvx, e.cvy, dt); contactDamage(e, 22, S.dmg); if (e.t <= 0 || e.blocked > 0.05) { e.st = 'walk'; e.t = 1.4 / enr; if (e.blocked) shake(3); } break;
    case 'windup': crMove(e, 0, 0, dt); if (e.t <= 0) { const [vx, vy] = toward(e, P.x, P.y, S.spd * 4 * enr); e.cvx = vx; e.cvy = vy; e.st = 'charge'; e.t = 0.9; sfx('charge'); } break;
    case 'rocks': crMove(e, 0, 0, dt); if (e.t <= 0) {
      const base = Math.atan2(P.y - e.y, P.x - e.x);
      for (let i = -2; i <= 2; i++) { const a = base + i * 0.28; PROJ.push({ x: e.x, y: e.y - 14, vx: Math.cos(a) * 120 * enr, vy: Math.sin(a) * 120 * enr, layer: 0, owner: 'e', dmg: 9, spr: 'rockp', life: 2 }); }
      sfx('throw'); e.st = 'walk'; e.t = 1.6 / enr;
    } break;
    default: {
      const [vx, vy] = toward(e, P.x, P.y, S.spd * enr); crMove(e, vx, vy, dt);
      contactDamage(e, 18, S.dmg * 0.7);
      if (e.t <= 0) {
        const r = Math.random();
        if (dP < 40) { e.st = 'pinch'; e.t = 0.55 / enr; fxText(e.x, e.y - 30, '!', [255, 80, 60]); }
        else if (r < 0.45) { e.st = 'windup'; e.t = 0.6 / enr; fxText(e.x, e.y - 30, '!!', [255, 80, 60]); }
        else { e.st = 'rocks'; e.t = 0.5; }
      }
    }
  }
}
function updateBoss(e, dt, dP, see) {
  const S = SPECIES.boss;
  if (!see || dP > 340) { wander(e, dt, 20, 40); if (e.aggro && dP > 400) { e.aggro = false; } return; }
  if (!e.aggro) { e.aggro = true; bossBar(e); sfx('roar'); shake(6); toast('深海の主が目を覚ました！', 'red big'); setMusic('boss'); }
  const ph = e.hp < e.maxhp * 0.25 ? 3 : e.hp < e.maxhp * 0.6 ? 2 : 1;
  const sp = 1 + (ph - 1) * 0.25;
  e.t -= dt;
  if (e.dark > 0) e.dark -= dt;
  switch (e.st) {
    case 'tele': crMove(e, 0, 0, dt); if (e.t <= 0) { const [vx, vy] = toward(e, P.x, P.y, 230 * sp); e.cvx = vx; e.cvy = vy; e.st = 'dash'; e.t = 0.8; sfx('charge'); } break;
    case 'dash': crMove(e, e.cvx, e.cvy, dt); contactDamage(e, 30, S.dmg); if (e.t <= 0) { e.st = 'swim'; e.t = rnd(1.5, 2.5) / sp; } break;
    case 'orbs': {
      crMove(e, 0, 0, dt);
      e.sub = (e.sub || 0) - dt;
      if (e.sub <= 0) {
        e.sub = ph === 3 ? 0.12 : 0.22; e.cnt = (e.cnt || 0) + 1;
        const base = ph === 3 ? e.cnt * 0.5 : Math.atan2(P.y - e.y, P.x - e.x);
        const n = ph === 3 ? 4 : 3;
        for (let i = 0; i < n; i++) { const a = ph === 3 ? base + i * Math.PI / 2 : base + (i - 1) * 0.3; PROJ.push({ x: e.x + 20 * e.face, y: e.y - 20, vx: Math.cos(a) * 95, vy: Math.sin(a) * 95, layer: 1, owner: 'e', dmg: 10, spr: 'orb', life: 3.2, light: 14 }); }
        sfx('orb');
      }
      if (e.t <= 0) { e.st = 'swim'; e.t = rnd(1.5, 2.5) / sp; e.cnt = 0; }
      break;
    }
    case 'summon': crMove(e, 0, 0, dt); if (e.t <= 0) {
      const n = ENTS.filter(q => q.sp === 'angler' && !q.dead).length;
      for (let i = 0; i < Math.min(2, 5 - n); i++) makeCreature('angler', e.x + rnd(-30, 30), e.y + rnd(-30, 30), 1, { aggro: true });
      e.st = 'swim'; e.t = 2 / sp;
    } break;
    default: {
      const want = 80, [vx, vy] = toward(e, P.x, P.y, dP > want ? S.spd * sp : -S.spd * 0.5);
      crMove(e, vx + Math.sin(e.anim * 0.4) * 10, vy + Math.cos(e.anim * 0.3) * 10, dt);
      contactDamage(e, 26, S.dmg * 0.6);
      if (e.t <= 0) {
        const r = Math.random();
        if (ph >= 2 && r < 0.2 && !(e.dark > 0)) { e.dark = 5; toast('光が…消えていく！', 'red'); sfx('dark'); e.st = 'swim'; e.t = 1; }
        else if (r < 0.5) { e.st = 'tele'; e.t = 0.75 / sp; fxText(e.x, e.y - 40, '!!', [255, 80, 60]); }
        else if (r < 0.8 || ph === 1) { e.st = 'orbs'; e.t = ph === 3 ? 2.4 : 1.4; e.sub = 0; }
        else { e.st = 'summon'; e.t = 0.6; }
      }
    }
  }
}
function updateParrot(e, dt) {
  if (G.flags.parrot) e.tame = true;
  if (!e.tame) {
    e.t -= dt;
    if (e.t <= 0) { e.t = rnd(1, 3); e.tx = e.home.x + rnd(-24, 24); e.ty = e.home.y + rnd(-16, 16); }
    const [vx, vy, d] = toward(e, e.tx, e.ty, 26);
    if (d > 2) crMove(e, vx, vy, dt);
    if (P.layer === 0 && d2(e.x, e.y, P.x, P.y) < 60 * 60 && !G.flags.parrotHint) { G.flags.parrotHint = 1; toast('オウムがいる。エサ（ベリーかバナナ）をあげてみよう'); }
    return;
  }
  e.layer = 0;
  const tx = P.layer === 0 ? P.x - P.fx * 14 + Math.sin(e.anim * 0.5) * 6 : e.x, ty = P.layer === 0 ? P.y - 18 - P.fy * 8 + Math.cos(e.anim * 0.7) * 3 : e.y;
  const d = Math.hypot(tx - e.x, ty - e.y);
  if (d > 400) { e.x = P.x; e.y = P.y - 20; }
  const [vx, vy] = toward(e, tx, ty, Math.min(140, d * 3));
  if (d > 2) crMove(e, vx, vy, dt);
  e.t -= dt;
  if (e.t <= 0) { e.t = rnd(70, 120); if (P.layer === 0 && G.quest < QUESTS.length - 1 && !UI.mode.match(/menu|dialog/)) toast(PARROT_HINT[Math.min(G.quest, PARROT_HINT.length - 1)]); }
}
function hurtCreature(e, dmg, sx, sy) {
  if (e.dead || e.inv > 0) return;
  const S = SPECIES[e.sp];
  e.hp -= dmg; e.flash = 0.15; e.inv = 0.1; e.aggro = true;
  const a = Math.atan2(e.y - sy, e.x - sx), kb = S.boss ? 25 : 120;
  e.kx = Math.cos(a) * kb; e.ky = Math.sin(a) * kb;
  fxText(e.x, e.y - S.r - 8, String(dmg), [255, 240, 120]);
  sfx('hit'); hitStop(0.04);
  if (S.ai === 'fish' || S.ai === 'passive') { e.home.x = e.x + Math.cos(a) * 60; e.home.y = e.y + Math.sin(a) * 60; e.t = 0; }
  if (e.hp <= 0) killCreature(e);
}
function killCreature(e) {
  const S = SPECIES[e.sp];
  e.dead = true;
  rollDrops(S.drops).forEach(([id, n]) => spawnDrop(e.layer, e.x, e.y - 4, id, n));
  fxBurst(e.x, e.y - 6, S.env === 'sea' ? [180, 220, 255] : [255, 255, 255], S.boss ? 30 : 10);
  G.stats.kills = (G.stats.kills || 0) + 1;
  sfx(S.boss ? 'bossdie' : 'kill');
  if (e.sp === 'gcrab') { G.flags.gcrab_dead = 1; bossBar(null); setMusic(null); shake(8); later(() => dialog(['巨大ヤシガニを倒した！', 'ヤシガニが持っていた海図の切れ端を手に入れられそうだ。']), 600); }
  if (e.sp === 'boss') { G.flags.boss_dead = 1; bossBar(null); setMusic(null); shake(10); later(() => dialog(['深海の主を倒した……！', '暗い海の底に、静かな光が戻ってきた。', '主が守っていた海図の切れ端と、不思議な宝珠が落ちている。']), 800); }
  if (e.sp === 'shark') G.stats.sharks = (G.stats.sharks || 0) + 1;
}

/* ---------- 出現と消滅 ---------- */
let spawnT = 0;
function spawnTick(dt) {
  spawnT -= dt;
  if (spawnT > 0) return;
  spawnT = 1.2;
  const px = P.x / 16, py = P.y / 16;
  // 遠くの生き物を消す
  for (let i = ENTS.length - 1; i >= 0; i--) {
    const e = ENTS[i];
    if (e.dead) { ENTS.splice(i, 1); continue; }
    const S = SPECIES[e.sp];
    if (e.sp === 'parrot' && (e.tame || d2(e.x / 16, e.y / 16, px, py) < 60 * 60)) continue;
    const far = d2(e.x / 16, e.y / 16, px, py);
    if (S.boss ? far > 60 * 60 : far > 46 * 46) { if (S.boss) bossBar(null), setMusic(null); ENTS.splice(i, 1); }
  }
  // ボス
  if (!G.flags.gcrab_dead && G.lm.gcrab && P.layer === 0 && d2(px, py, G.lm.gcrab.x, G.lm.gcrab.y) < 26 * 26 && !ENTS.some(e => e.sp === 'gcrab')) makeCreature('gcrab', G.lm.gcrab.x * 16 + 8, G.lm.gcrab.y * 16 + 12, 0);
  if (!G.flags.boss_dead && G.lm.trench && P.layer === 1 && d2(px, py, G.lm.trench.x, G.lm.trench.y) < 13 * 13 && !ENTS.some(e => e.sp === 'boss')) makeCreature('boss', G.lm.trench.x * 16 + 8, (G.lm.trench.y - 4) * 16, 1);
  // オウム
  if (G.lm.parrot && !ENTS.some(e => e.sp === 'parrot') && (G.flags.parrot || d2(px, py, G.lm.parrot.x, G.lm.parrot.y) < 40 * 40)) {
    const p = G.flags.parrot ? { x: P.x, y: P.y - 20 } : { x: G.lm.parrot.x * 16 + 8, y: G.lm.parrot.y * 16 + 8 };
    makeCreature('parrot', p.x, p.y, 0, { tame: !!G.flags.parrot, t: 30 });
  }
  const night = isNight();
  const landN = ENTS.filter(e => SPECIES[e.sp].env === 'land' && !SPECIES[e.sp].boss).length;
  const seaN = ENTS.filter(e => SPECIES[e.sp].env === 'sea' && !SPECIES[e.sp].boss).length;
  const landCap = night ? 16 : 11;
  if (P.layer === 0 && landN < landCap) {
    for (let tries = 0; tries < 6; tries++) {
      const a = Math.random() * Math.PI * 2, r = rnd(15, 26);
      const tx = Math.floor(px + Math.cos(a) * r), ty = Math.floor(py + Math.sin(a) * r);
      if (!inb(tx, ty) || objAt(0, tx, ty) || solidAt(0, tx, ty, 'land')) continue;
      const g = terAt(0, tx, ty), rr = Math.random(), nm = night ? 1.7 : 1;
      let sp = null;
      if (g === T.SAND) sp = rr < 0.32 * nm ? 'crab' : (!night && rr > 0.95) ? 'turtle' : null;
      else if (g === T.GRASS) sp = rr < 0.14 * nm ? 'boar' : null;
      else if (g === T.FOREST) sp = rr < 0.2 * nm ? 'boar' : rr < 0.27 * nm ? 'snake' : null;
      else if (g === T.JUNGLE) sp = rr < 0.18 * nm ? 'snake' : rr < 0.32 * nm ? 'monkey' : rr < 0.4 * nm ? 'boar' : null;
      else if (g === T.ROCK) sp = rr < 0.07 * nm ? 'boar' : null;
      else if (g === T.VOLC) sp = rr < 0.15 * nm ? 'crab' : null;
      if (sp) { makeCreature(sp, tx * 16 + 8, ty * 16 + 12, 0); break; }
    }
  }
  const inWater = P.layer === 1 || P.mode === 'swim' || P.mode === 'raft' || P.mode === 'wade';
  const seaCap = P.layer === 1 ? 20 : inWater ? 10 : 4;
  if (seaN < seaCap) {
    for (let tries = 0; tries < 6; tries++) {
      const a = Math.random() * Math.PI * 2, r = rnd(10, 22);
      const tx = Math.floor(px + Math.cos(a) * r), ty = Math.floor(py + Math.sin(a) * r);
      if (!inb(tx, ty) || !isSwim(terAt(0, tx, ty)) || solidAt(1, tx, ty, 'player')) continue;
      const u = terAt(1, tx, ty), depth = -G.elev[idx(tx, ty)], rr = Math.random();
      let sp = null, n = 1;
      if (u === U.TRENCH) sp = rr < 0.4 ? 'angler' : rr < 0.75 ? 'jelly' : null;
      else if (depth > 0.2) sp = rr < 0.14 ? 'shark' : rr < 0.38 ? 'jelly' : rr < 0.65 ? 'fish' : rr < 0.75 ? 'tai' : null;
      else if (u === U.REEF) sp = rr < 0.6 ? 'fish' : rr < 0.75 ? 'tai' : rr < 0.85 ? 'moray' : null;
      else if (u === U.KELP) sp = rr < 0.45 ? 'fish' : rr < 0.65 ? 'jelly' : null;
      else if (u === U.ROCK) sp = rr < 0.2 ? 'moray' : rr < 0.5 ? 'fish' : rr < 0.56 && depth > 0.12 ? 'shark' : null;
      else sp = rr < 0.45 ? 'fish' : rr < 0.58 ? 'ray' : rr < 0.68 ? 'tai' : null;
      if (sp === 'shark' && ENTS.filter(e => e.sp === 'shark').length >= 2) sp = 'fish';
      if (!sp) continue;
      if (sp === 'fish') n = irnd(3, 5);
      const v = irnd(0, 3);
      for (let k = 0; k < n; k++) makeCreature(sp, tx * 16 + 8 + rnd(-8, 8), ty * 16 + 8 + rnd(-8, 8), 1, sp === 'fish' ? { var: v } : null);
      break;
    }
  }
}

/* ---------- 投射物 ---------- */
function updateProj(dt) {
  for (let i = PROJ.length - 1; i >= 0; i--) {
    const p = PROJ[i];
    p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt;
    let dead = p.life <= 0;
    const tx = Math.floor(p.x / 16), ty = Math.floor(p.y / 16);
    if (p.layer === 0) { const o = objAt(0, tx, ty); if ((o && OBJ[o].solid && OBJ[o].tall) || terAt(0, tx, ty) === T.CLIFF) dead = true; }
    else if (solidAt(1, tx, ty, 'player')) dead = true;
    if (!dead && p.owner === 'p') {
      for (const e of ENTS) {
        if (e.dead || e.layer !== p.layer) continue;
        const S = SPECIES[e.sp]; if (S.env === 'air' || S.nohit) continue;
        if (d2(e.x, e.y - Math.min(S.r, 8), p.x, p.y) < (S.r + 3) ** 2) { hurtCreature(e, p.dmg, p.x - p.vx, p.y - p.vy); dead = true; break; }
      }
    } else if (!dead && p.owner === 'e' && p.layer === P.layer && !P.dead) {
      if (d2(P.x, P.y - 6, p.x, p.y) < 8 * 8) { hurtPlayer(p.dmg, p.x - p.vx, p.y - p.vy); dead = true; }
    }
    if (dead) { fxBurst(p.x, p.y, p.spr === 'orb' ? [120, 240, 255] : [220, 200, 170], 4); PROJ.splice(i, 1); }
  }
}

/* ---------- 落ちているアイテム ---------- */
function spawnDrop(layer, x, y, id, n) {
  if (!id || !ITEMS[id]) return;
  const a = Math.random() * Math.PI * 2, sp = rnd(20, 50);
  DROPS.push({ layer, x, y, id, n, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, z: 0, vz: layer ? 10 : 60, age: 0 });
}
function updateDrops(dt) {
  for (let i = DROPS.length - 1; i >= 0; i--) {
    const d = DROPS[i];
    d.age += dt;
    d.x += d.vx * dt; d.y += d.vy * dt; d.vx *= Math.exp(-dt * 5); d.vy *= Math.exp(-dt * 5);
    if (d.layer === 0) { d.vz -= 220 * dt; d.z += d.vz * dt; if (d.z < 0) { d.z = 0; d.vz = -d.vz * 0.35; if (Math.abs(d.vz) < 15) d.vz = 0; } }
    else d.z = Math.sin(d.age * 3) * 2 + 3;
    if (d.age > 600) { DROPS.splice(i, 1); continue; }
    if (P.dead || d.layer !== P.layer || d.age < 0.45) continue;
    const dd = d2(d.x, d.y, P.x, P.y - 2);
    if (dd < 30 * 30) {
      const [vx, vy] = toward(d, P.x, P.y - 2, 150);
      d.x += vx * dt; d.y += vy * dt;
      if (dd < 8 * 8) {
        const left = addItem(d.id, d.n);
        if (left <= 0) { DROPS.splice(i, 1); sfx('pickup'); }
        else { d.n = left; d.age = -2; toast('持ち物がいっぱい！', 'red'); }
      }
    }
  }
}

/* ---------- パーティクル ---------- */
function fxBurst(x, y, col, n) {
  for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI * 2, s = rnd(30, 90); PARTS.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 30, g: P && P.layer ? 20 : 200, life: rnd(0.3, 0.6), max: 0.6, col, sz: Math.random() < 0.3 ? 2 : 1, layer: P ? P.layer : 0 }); }
}
function fxText(x, y, str, col) { PARTS.push({ x, y, vx: 0, vy: -26, g: 0, life: 0.9, max: 0.9, col, text: str, layer: P ? P.layer : 0 }); }
function fxBubble(x, y) { PARTS.push({ x, y, vx: rnd(-4, 4), vy: rnd(-26, -16), g: 0, life: rnd(0.8, 1.6), max: 1.6, bubble: 1, layer: 1 }); }
function fxSplash(x, y) {
  for (let i = 0; i < 14; i++) { const a = -Math.PI * rnd(0.1, 0.9), s = rnd(30, 80); PARTS.push({ x, y: y - 2, vx: Math.cos(a) * s, vy: Math.sin(a) * s, g: 240, life: rnd(0.3, 0.7), max: 0.7, col: [220, 245, 255], sz: 1, layer: 0 }); }
  PARTS.push({ x, y, ring: 1, life: 0.6, max: 0.6, layer: 0, vx: 0, vy: 0, g: 0 });
  PARTS.push({ x, y, ring: 1, life: 0.6, max: 0.6, layer: 1, vx: 0, vy: 0, g: 0 });
}
function fxRipple(x, y) { PARTS.push({ x, y, ring: 1, life: 0.5, max: 0.5, layer: 0, vx: 0, vy: 0, g: 0, small: 1 }); }
function updateParts(dt) {
  for (let i = PARTS.length - 1; i >= 0; i--) {
    const p = PARTS[i];
    p.life -= dt;
    if (p.life <= 0) { PARTS.splice(i, 1); continue; }
    p.vy += (p.g || 0) * dt; p.x += p.vx * dt; p.y += p.vy * dt;
    if (p.bubble) { p.x += Math.sin(p.life * 8) * 0.3; }
  }
  if (PARTS.length > 500) PARTS.splice(0, PARTS.length - 500);
}

/* ---------- 時間・天気・再生 ---------- */
const dayNum = () => Math.floor(G.clock / 1440) + 1;
const tod = () => G.clock % 1440;
function isNight() { const t = tod(); return t >= 1170 || t < 300; }
function timeStr() { const t = tod(); return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(Math.floor(t % 60 / 10) * 10).padStart(2, '0'); }
function darknessLevel() {
  const h = tod() / 60;
  let d;
  if (h >= 7 && h < 17.5) d = 0;
  else if (h >= 17.5 && h < 20) d = (h - 17.5) / 2.5 * 0.84;
  else if (h >= 20 || h < 4.5) d = 0.84;
  else d = 0.84 * (1 - (h - 4.5) / 2.5);
  if (G.weather.type !== 'clear') d += (G.weather.type === 'storm' ? 0.28 : 0.16) * (1 - d);
  return d;
}
let worldTickT = 0;
function tickWorld(dt) {
  const prevDay = dayNum(), prevTod = tod();
  G.clock += dt * 3;
  if (dayNum() !== prevDay || (prevTod < 360 && tod() >= 360)) {
    if (tod() >= 360 && prevTod < 360) { toast(`${dayNum()}日目の朝`, 'gold big'); saveGame(true); }
  }
  // 天気
  G.weather.t -= dt * 3;
  if (G.weather.t <= 0) {
    const r = Math.random();
    const prev = G.weather.type;
    G.weather.type = prev !== 'clear' ? 'clear' : r < 0.62 ? 'clear' : r < 0.92 || dayNum() < 3 ? 'rain' : 'storm';
    G.weather.t = G.weather.type === 'clear' ? rnd(300, 900) : rnd(90, 260);
    if (G.weather.type === 'rain' && prev === 'clear') toast('雨が降ってきた');
    if (G.weather.type === 'storm') toast('嵐が来た！', 'red');
  }
  worldTickT -= dt;
  if (worldTickT > 0 && dt > 0) return;
  worldTickT = 1;
  // 再生
  for (let i = G.regrow.length - 1; i >= 0; i--) {
    const r = G.regrow[i];
    if (G.clock < r.at) continue;
    const layer = r.k >= MM ? 1 : 0, ii = r.k % MM, x = ii % MAP, y = Math.floor(ii / MAP);
    const cur = layer ? G.objU[ii] : G.objS[ii];
    const ok = !cur || cur === O.STUMP || cur === O.BUSH_E || cur === O.BANANA_E;
    if (ok) {
      if (OBJ[r.o].solid && layer === P.layer && Math.abs(P.x - (x * 16 + 8)) < 14 && Math.abs(P.y - (y * 16 + 8)) < 14) continue;
      setObj(layer, x, y, r.o);
    }
    G.regrow.splice(i, 1);
  }
  // 特殊オブジェクト
  for (const k of G.special) {
    const layer = k >= MM ? 1 : 0, ii = k % MM, x = ii % MAP, y = Math.floor(ii / MAP);
    const o = layer ? G.objU[ii] : G.objS[ii], od = G.objData.get(k);
    if (!o || !od) { G.special.delete(k); continue; }
    if (o === O.RAIN) { if (G.weather.type !== 'clear') od.w = Math.min(10, (od.w || 0) + 0.12 * (G.weather.type === 'storm' ? 2 : 1)); }
    else if (o === O.TRAP) { if (G.clock - od.t > 120 && (od.n || 0) < 3) { od.n = (od.n || 0) + 1; od.t = G.clock; } }
    else if (o === O.CROP1 || o === O.CROP2) {
      const el = G.clock - od.t;
      if (o === O.CROP1 && el > 600) setObj(0, x, y, O.CROP2), G.objData.set(k, od);
      else if (o === O.CROP2 && el > 1200) setObj(0, x, y, O.CROP3), G.objData.set(k, od);
    }
  }
  // 叩いた跡の回復
  for (const [k, v] of objHit) { v.t -= 1; if (v.t <= 0) objHit.delete(k); }
}

/* ---------- クエスト ---------- */
function checkQuests() {
  if (!G || !P) return;
  if (!G.qdone) G.qdone = [];
  let adv = false;
  const last = QUESTS.length - 1;
  for (let i = 0; i < last; i++) {
    if (G.qdone[i]) continue;
    let ok = false; try { ok = QUESTS[i].check(); } catch (e) { ok = false; }
    if (ok) { G.qdone[i] = 1; adv = true; toast('目標達成：' + QUESTS[i].t, 'gold'); }
  }
  if (G.flags.escaped) for (let i = 0; i < last; i++) G.qdone[i] = 1;
  let q = 0; while (q < last && G.qdone[q]) q++;
  G.quest = q;
  if (adv) { sfx('quest'); questUI(true); }
  else questUI(false);
}
/* =============================================================
   入力（キーボード・タッチ・コントローラー）／サウンド／セーブ
   ============================================================= */
const SET = { bgm: 0.55, se: 0.8, swap: false, shake: true, vib: true };
function loadSettings() { try { const s = JSON.parse(localStorage.getItem(SET_KEY) || '{}'); if (s && typeof s === 'object') for (const k in SET) if (typeof s[k] === typeof SET[k]) SET[k] = s[k]; } catch (e) { } }
function saveSettings() { try { localStorage.setItem(SET_KEY, JSON.stringify(SET)); } catch (e) { } applyVolumes(); }

/* ---------- 入力 ---------- */
const input = { mx: 0, my: 0, a: false, b: false, x: false, y: false, lb: false, rb: false, start: false, back: false, pr: {}, mode: 'kb' };
const BTN = ['a', 'b', 'x', 'y', 'lb', 'rb', 'start', 'back', 'up', 'down', 'left', 'right'];
const keys = {};
const keyLatch = new Set(), touchLatch = new Set();
const touchBtn = {};
const stick = { id: null, ox: 0, oy: 0, dx: 0, dy: 0 };
let prevBtn = {};
const KEYMAP = {
  a: ['KeyJ', 'Space', 'Enter', 'KeyZ'], b: ['KeyK', 'ShiftLeft', 'ShiftRight', 'KeyC'], x: ['KeyL', 'KeyF'], y: ['KeyE', 'KeyI', 'Tab'],
  lb: ['KeyQ'], rb: ['KeyR'], start: ['Escape', 'KeyP'], back: ['KeyM'],
  up: ['KeyW', 'ArrowUp'], down: ['KeyS', 'ArrowDown'], left: ['KeyA', 'ArrowLeft'], right: ['KeyD', 'ArrowRight'],
};
function setInputMode(m) {
  if (input.mode === m) return;
  input.mode = m;
  document.body.classList.toggle('pad', m === 'pad');
  document.body.classList.toggle('kb', m === 'kb');
  if (m === 'touch') clearNavFocus();
}
window.addEventListener('keydown', e => {
  if (e.target && e.target.tagName === 'INPUT' && e.target.type !== 'range') return;
  keys[e.code] = true;
  if (!e.repeat) keyLatch.add(e.code);
  if (['Space', 'Tab', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
  setInputMode('kb');
  audioUnlock();
  if (UI.mode === 'play' && /^Digit[1-8]$/.test(e.code)) selectHot(+e.code.slice(5) - 1);
});
window.addEventListener('keyup', e => { keys[e.code] = false; });
window.addEventListener('blur', () => { for (const k in keys) keys[k] = false; for (const k in touchBtn) touchBtn[k] = false; stick.id = null; stick.dx = stick.dy = 0; });
window.addEventListener('wheel', e => { if (UI.mode === 'play') { selectHot((P.sel + (e.deltaY > 0 ? 1 : -1) + HOT_N) % HOT_N); } }, { passive: true });

function initTouch() {
  const zone = $('#stickZone'), base = $('#stickBase'), knob = $('#stickKnob');
  const R = 44;
  const placeBase = (x, y) => { base.style.left = x + 'px'; base.style.top = y + 'px'; };
  zone.addEventListener('touchstart', e => {
    e.preventDefault(); setInputMode('touch'); audioUnlock();
    if (stick.id !== null) return;
    const t = e.changedTouches[0];
    stick.id = t.identifier; stick.ox = t.clientX; stick.oy = t.clientY; stick.dx = stick.dy = 0;
    placeBase(t.clientX, t.clientY); knob.style.transform = 'translate(0,0)';
  }, { passive: false });
  const mv = e => {
    for (const t of e.changedTouches) if (t.identifier === stick.id) {
      e.preventDefault();
      let dx = t.clientX - stick.ox, dy = t.clientY - stick.oy;
      const d = Math.hypot(dx, dy);
      if (d > R) { dx = dx / d * R; dy = dy / d * R; }
      stick.dx = dx / R; stick.dy = dy / R;
      knob.style.transform = `translate(${dx}px,${dy}px)`;
    }
  };
  const end = e => {
    for (const t of e.changedTouches) if (t.identifier === stick.id) { stick.id = null; stick.dx = stick.dy = 0; knob.style.transform = 'translate(0,0)'; base.style.left = ''; base.style.top = ''; }
  };
  zone.addEventListener('touchmove', mv, { passive: false });
  window.addEventListener('touchmove', mv, { passive: false });
  window.addEventListener('touchend', end); window.addEventListener('touchcancel', end);
  document.querySelectorAll('.tb').forEach(el => {
    const b = el.dataset.b;
    const on = e => { e.preventDefault(); setInputMode('touch'); audioUnlock(); touchBtn[b] = true; touchLatch.add(b); el.classList.add('on'); vib(8); };
    const off = e => { e.preventDefault(); touchBtn[b] = false; el.classList.remove('on'); };
    el.addEventListener('touchstart', on, { passive: false });
    el.addEventListener('touchend', off, { passive: false });
    el.addEventListener('touchcancel', off, { passive: false });
    el.addEventListener('mousedown', e => { touchBtn[b] = true; touchLatch.add(b); el.classList.add('on'); });
    el.addEventListener('mouseup', e => { touchBtn[b] = false; el.classList.remove('on'); });
    el.addEventListener('mouseleave', e => { touchBtn[b] = false; el.classList.remove('on'); });
  });
  // 長押し・ダブルタップでの拡大やメニューを防止
  document.addEventListener('gesturestart', e => e.preventDefault());
  document.addEventListener('dblclick', e => e.preventDefault(), { passive: false });
  document.addEventListener('contextmenu', e => e.preventDefault());
  let lastTouch = 0;
  document.addEventListener('touchend', e => {
    const n = Date.now(), t = e.target;
    const ui = t && t.closest && t.closest('.btn,.slot,.tab,.chip,.rc,.tbtn,#dialog,input,a,#menuBody,#modalInner,#title,#hotbar');
    if (!ui && n - lastTouch < 320) e.preventDefault();
    lastTouch = n;
  }, { passive: false });
  document.addEventListener('touchstart', e => { if (e.touches.length > 1) e.preventDefault(); setInputMode('touch'); }, { passive: false });
}
function padButtons(gp) {
  const pressed = i => gp.buttons[i] && (gp.buttons[i].pressed || gp.buttons[i].value > 0.5);
  const sw = SET.swap;
  return {
    a: pressed(sw ? 1 : 0), b: pressed(sw ? 0 : 1), x: pressed(sw ? 3 : 2), y: pressed(sw ? 2 : 3),
    lb: pressed(4) || pressed(6), rb: pressed(5) || pressed(7), back: pressed(8), start: pressed(9),
    up: pressed(12), down: pressed(13), left: pressed(14), right: pressed(15),
  };
}
let padPrevAny = false;
function pollInput() {
  const cur = {};
  for (const b of BTN) cur[b] = KEYMAP[b] ? KEYMAP[b].some(k => keys[k] || keyLatch.has(k)) : false;
  keyLatch.clear();
  let kx = (cur.right ? 1 : 0) - (cur.left ? 1 : 0), ky = (cur.down ? 1 : 0) - (cur.up ? 1 : 0);
  if (kx && ky) { kx *= 0.7071; ky *= 0.7071; }
  let mx = kx, my = ky;
  if (Math.hypot(stick.dx, stick.dy) > Math.hypot(mx, my)) { mx = stick.dx; my = stick.dy; }
  for (const b in touchBtn) if (touchBtn[b] || touchLatch.has(b)) cur[b] = true;
  touchLatch.clear();
  const pads = navigator.getGamepads ? navigator.getGamepads() : [];
  for (const gp of pads) {
    if (!gp || !gp.connected) continue;
    const pb = padButtons(gp);
    let gx = gp.axes[0] || 0, gy = gp.axes[1] || 0;
    if (Math.hypot(gx, gy) < 0.25) gx = gy = 0;
    if (pb.left) gx = -1; if (pb.right) gx = 1; if (pb.up) gy = -1; if (pb.down) gy = 1;
    const any = Object.values(pb).some(v => v) || gx || gy;
    if (any && !padPrevAny) setInputMode('pad');
    padPrevAny = any;
    if (Math.hypot(gx, gy) > Math.hypot(mx, my)) { mx = gx; my = gy; }
    for (const b in pb) if (pb[b]) cur[b] = true;
  }
  const m = Math.hypot(mx, my); if (m > 1) { mx /= m; my /= m; }
  input.mx = mx; input.my = my;
  for (const b of BTN) { input.pr[b] = cur[b] && !prevBtn[b]; input[b] = cur[b]; }
  // メニュー移動用：スティックの方向をボタン化
  const dir = m > 0.5 ? (Math.abs(mx) > Math.abs(my) ? (mx > 0 ? 'right' : 'left') : (my > 0 ? 'down' : 'up')) : null;
  input.pr.nav = dir && dir !== prevBtn.nav ? dir : null;
  cur.nav = dir;
  prevBtn = cur;
}
function vib(ms) { if (SET.vib && navigator.vibrate && input.mode === 'touch') try { navigator.vibrate(ms); } catch (e) { } }

/* ---------- サウンド（WebAudioで全部生成） ---------- */
const AU = { ctx: null, master: null, sfxG: null, bgmG: null, noise: null, amb: {}, mus: { cur: null, step: 0, next: 0, fade: 0 }, last: {} };
function audioUnlock() {
  if (AU.ctx) { if (AU.ctx.state === 'suspended') AU.ctx.resume(); return; }
  try {
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    const c = new AC(); AU.ctx = c;
    AU.master = c.createGain(); AU.master.gain.value = 0.9; AU.master.connect(c.destination);
    AU.sfxG = c.createGain(); AU.sfxG.connect(AU.master);
    AU.bgmG = c.createGain(); AU.bgmMix = c.createGain(); AU.bgmMix.connect(AU.bgmG);
    AU.bgmLP = c.createBiquadFilter(); AU.bgmLP.type = 'lowpass'; AU.bgmLP.frequency.value = 20000;
    AU.bgmG.connect(AU.bgmLP); AU.bgmLP.connect(AU.master);
    const len = c.sampleRate * 2, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    AU.noise = buf;
    const mkAmb = (type, freq, q) => { const s = c.createBufferSource(); s.buffer = buf; s.loop = true; const f = c.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q || 0.7; const g = c.createGain(); g.gain.value = 0; s.connect(f); f.connect(g); g.connect(AU.sfxG); s.start(); return { g, f }; };
    AU.amb.wave = mkAmb('lowpass', 520);
    AU.amb.under = mkAmb('lowpass', 180);
    AU.amb.rain = mkAmb('highpass', 2400);
    AU.amb.wind = mkAmb('bandpass', 400, 0.5);
    applyVolumes();
    if (c.state === 'suspended') c.resume();
  } catch (e) { AU.ctx = null; }
}
function applyVolumes() { if (!AU.ctx) return; AU.sfxG.gain.value = SET.se; AU.bgmG.gain.value = SET.bgm * 0.5; }
function tone(f, d, type = 'square', vol = 0.2, slide = 0, delay = 0, dest) {
  const c = AU.ctx, t = c.currentTime + delay;
  const o = c.createOscillator(), g = c.createGain();
  o.type = type; o.frequency.setValueAtTime(f, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, slide), t + d);
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
  o.connect(g); g.connect(dest || AU.sfxG); o.start(t); o.stop(t + d + 0.02);
}
function nz(d, freq, vol = 0.2, type = 'bandpass', q = 1, delay = 0, slide = 0, dest) {
  const c = AU.ctx, t = c.currentTime + delay;
  const s = c.createBufferSource(); s.buffer = AU.noise;
  const f = c.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(freq, t); f.Q.value = q;
  if (slide) f.frequency.exponentialRampToValueAtTime(slide, t + d);
  const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
  s.connect(f); f.connect(g); g.connect(dest || AU.sfxG); s.start(t, Math.random() * 1.5); s.stop(t + d + 0.02);
}
function sfx(n) {
  if (!AU.ctx) return;
  const tnow = AU.ctx.currentTime;
  if (AU.last[n] && tnow - AU.last[n] < 0.03) return;
  AU.last[n] = tnow;
  const U2 = P && P.layer === 1;
  switch (n) {
    case 'swing': nz(0.09, U2 ? 500 : 1800, 0.12, 'bandpass', 1.5, 0, U2 ? 300 : 900); break;
    case 'chop': nz(0.08, 900, 0.3, 'bandpass', 2); tone(180, 0.08, 'triangle', 0.18, 120); break;
    case 'mine': tone(1200, 0.06, 'square', 0.08, 900); nz(0.07, 3000, 0.2, 'highpass'); break;
    case 'hitsoft': nz(0.07, 1400, 0.18, 'bandpass', 1); break;
    case 'clank': tone(900, 0.1, 'square', 0.1, 700); tone(1400, 0.08, 'square', 0.06, 1200, 0.02); break;
    case 'break': nz(0.2, 700, 0.3, 'lowpass'); tone(220, 0.12, 'triangle', 0.15, 90); break;
    case 'treefall': nz(0.5, 400, 0.35, 'lowpass', 1, 0, 120); tone(110, 0.35, 'triangle', 0.2, 50, 0.1); break;
    case 'pick': tone(660, 0.06, 'square', 0.1); tone(990, 0.08, 'square', 0.08, 0, 0.05); break;
    case 'pickup': tone(880, 0.05, 'square', 0.07); tone(1320, 0.06, 'square', 0.06, 0, 0.04); break;
    case 'place': nz(0.08, 300, 0.3, 'lowpass'); tone(160, 0.08, 'triangle', 0.2, 100); break;
    case 'eat': for (let i = 0; i < 3; i++) nz(0.05, 1200, 0.18, 'bandpass', 3, i * 0.09); break;
    case 'drink': for (let i = 0; i < 3; i++) tone(400 + i * 80, 0.07, 'sine', 0.15, 700 + i * 80, i * 0.1); break;
    case 'hurt': tone(300, 0.15, 'square', 0.18, 120); nz(0.1, 800, 0.2); break;
    case 'hit': nz(0.06, 1600, 0.25, 'bandpass', 1); tone(240, 0.06, 'square', 0.12, 140); break;
    case 'kill': tone(520, 0.08, 'square', 0.12, 260); nz(0.15, 900, 0.2); break;
    case 'bossdie': for (let i = 0; i < 6; i++) { nz(0.3, 300 + i * 100, 0.3, 'lowpass', 1, i * 0.12); tone(200 - i * 20, 0.3, 'sawtooth', 0.1, 60, i * 0.12); } break;
    case 'death': tone(440, 0.3, 'triangle', 0.2, 220); tone(330, 0.4, 'triangle', 0.2, 110, 0.25); tone(220, 0.7, 'triangle', 0.2, 55, 0.55); break;
    case 'dive': nz(0.4, 900, 0.3, 'lowpass', 1, 0, 200); tone(300, 0.3, 'sine', 0.12, 120); break;
    case 'surface': nz(0.3, 400, 0.25, 'lowpass', 1, 0, 1600); tone(200, 0.2, 'sine', 0.12, 500); break;
    case 'splash': nz(0.3, 1200, 0.25, 'bandpass', 0.7, 0, 300); break;
    case 'swimstroke': nz(0.15, 700, 0.06, 'bandpass', 0.8); break;
    case 'step': nz(0.04, 500, 0.05, 'lowpass'); break;
    case 'stepsand': nz(0.06, 2400, 0.035, 'highpass'); break;
    case 'craft': tone(523, 0.07, 'square', 0.1); tone(659, 0.07, 'square', 0.1, 0, 0.07); tone(784, 0.12, 'square', 0.1, 0, 0.14); break;
    case 'cook': nz(0.4, 3000, 0.12, 'highpass'); tone(600, 0.1, 'triangle', 0.08, 0, 0.3); break;
    case 'smelt': nz(0.3, 500, 0.2, 'lowpass'); tone(880, 0.15, 'square', 0.06, 0, 0.25); break;
    case 'equip': tone(330, 0.05, 'square', 0.1); tone(495, 0.08, 'square', 0.08, 0, 0.05); break;
    case 'err': tone(150, 0.12, 'square', 0.12); break;
    case 'warn': tone(880, 0.08, 'square', 0.12); tone(660, 0.1, 'square', 0.12, 0, 0.1); break;
    case 'quest': [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.12, 'square', 0.1, 0, i * 0.09)); break;
    case 'chest': tone(392, 0.08, 'square', 0.1); tone(587, 0.12, 'square', 0.1, 0, 0.08); tone(784, 0.18, 'triangle', 0.12, 0, 0.16); break;
    case 'paper': nz(0.15, 4000, 0.1, 'highpass'); break;
    case 'door': nz(1.0, 200, 0.4, 'lowpass', 1, 0, 80); break;
    case 'cast': nz(0.2, 2400, 0.1, 'bandpass', 2, 0, 600); break;
    case 'bite': tone(1000, 0.05, 'square', 0.12); tone(1000, 0.05, 'square', 0.12, 0, 0.1); break;
    case 'catch': nz(0.25, 1000, 0.25, 'bandpass'); [660, 880, 1100].forEach((f, i) => tone(f, 0.08, 'square', 0.08, 0, 0.1 + i * 0.07)); break;
    case 'bow': tone(500, 0.12, 'triangle', 0.15, 200); break;
    case 'throw': nz(0.12, 1200, 0.1, 'bandpass', 1, 0, 400); break;
    case 'charge': nz(0.3, 300, 0.25, 'lowpass', 1, 0, 900); break;
    case 'hiss': nz(0.3, 5000, 0.1, 'highpass'); break;
    case 'roar': tone(90, 0.8, 'sawtooth', 0.25, 50); nz(0.8, 300, 0.3, 'lowpass'); break;
    case 'orb': tone(1200, 0.12, 'sine', 0.08, 600); break;
    case 'dark': tone(200, 1, 'sine', 0.2, 60); break;
    case 'parrot': tone(1500, 0.06, 'square', 0.1, 1800); tone(1800, 0.08, 'square', 0.1, 1300, 0.08); break;
    case 'ui': tone(880, 0.03, 'square', 0.06); break;
    case 'uiopen': tone(523, 0.05, 'square', 0.07); tone(784, 0.06, 'square', 0.07, 0, 0.04); break;
    case 'uiclose': tone(784, 0.05, 'square', 0.07); tone(523, 0.06, 'square', 0.07, 0, 0.04); break;
    case 'thunder': nz(1.6, 200, 0.5, 'lowpass', 1, 0, 60); nz(0.3, 2000, 0.3, 'highpass'); break;
    case 'crackle': nz(0.03, 3000 + Math.random() * 2000, 0.05, 'bandpass', 4); break;
  }
}
// ---- BGM ----
const NOTE_I = { C: 0, 'C#': 1, Db: 1, D: 2, 'D#': 3, Eb: 3, E: 4, F: 5, 'F#': 6, Gb: 6, G: 7, 'G#': 8, Ab: 8, A: 9, 'A#': 10, Bb: 10, B: 11 };
function nfreq(s) { const m = s.match(/^([A-G][#b]?)(-?\d)$/); if (!m) return 0; const n = NOTE_I[m[1]] + (+m[2] + 1) * 12; return 440 * Math.pow(2, (n - 69) / 12); }
const TRACKS = {
  day: {
    bpm: 112, ch: [
      { w: 'square', v: 0.07, n: 'F5 . A5 . C6 . A5 . G5 . F5 . D5 . F5 . E5 . - . D5 . E5 F5 A5 - - - . . . . D5 . F5 . Bb5 . A5 . G5 . F5 . D5 - . . C5 . E5 . G5 . Bb5 . A5 . G5 . E5 . C5 .', len: 0.9 },
      { w: 'triangle', v: 0.16, n: 'F2 . . . F3 . . . C3 . . . F3 . . . D2 . . . D3 . . . A2 . . . D3 . . . Bb1 . . . Bb2 . . . F2 . . . Bb2 . . . C2 . . . C3 . . . G2 . . . C3 . . .', len: 0.8 },
      { w: 'sine', v: 0.06, n: '. . F4 . . . A4 . . . C5 . . . A4 . . . D4 . . . F4 . . . A4 . . . F4 . . . Bb3 . . . D4 . . . F4 . . . D4 . . . C4 . . . E4 . . . G4 . . . E4 .', len: 0.6 },
    ], dr: 'k . h . s . h . k . h k s . h . k . h . s . h . k . h k s . h h k . h . s . h . k . h k s . h . k . h . s . h . k k h . s h s h'
  },
  night: {
    bpm: 76, ch: [
      { w: 'triangle', v: 0.1, n: 'A4 . . . C5 . . . E5 . . . D5 . C5 . B4 - - - - - - - G4 - - - - - - - A4 . . . C5 . . . E5 . . . G5 . E5 . D5 - - - - - - - - - - - - - - -', len: 0.95 },
      { w: 'sine', v: 0.14, n: 'A2 - - - - - - - E2 - - - - - - - G2 - - - - - - - D2 - - - - - - - F2 - - - - - - - C2 - - - - - - - E2 - - - - - - - E2 - - - - - - -', len: 0.95 },
    ], dr: 'h . . . . . . . h . . . . . . . h . . . . . . . h . . . . . h .'
  },
  under: {
    bpm: 84, lp: 1400, ch: [
      { w: 'sine', v: 0.08, n: 'D4 F4 A4 D5 A4 F4 D4 F4 A4 D5 A4 F4 D4 F4 A4 F4 Bb3 D4 F4 Bb4 F4 D4 Bb3 D4 F4 Bb4 F4 D4 Bb3 D4 F4 D4 F3 A3 C4 F4 C4 A3 F3 A3 C4 F4 C4 A3 F3 A3 C4 A3 A3 C#4 E4 A4 E4 C#4 A3 C#4 E4 A4 E4 C#4 A3 C#4 E4 C#4', len: 0.5 },
      { w: 'triangle', v: 0.09, n: 'A5 - - - - - - - G5 - - - F5 - - - F5 - - - - - - - D5 - - - E5 - - - C5 - - - - - - - D5 - - - E5 - - - E5 - - - - - - - - - - - - - - -', len: 0.95 },
      { w: 'sine', v: 0.14, n: 'D2 - - - - - - - - - - - - - - - Bb1 - - - - - - - - - - - - - - - F2 - - - - - - - - - - - - - - - A1 - - - - - - - - - - - - - - -', len: 0.95 },
    ], dr: ''
  },
  boss: {
    bpm: 150, ch: [
      { w: 'square', v: 0.07, n: 'E5 . G5 . B5 . A5 G5 F#5 . D5 . E5 . . . E5 . G5 . B5 . D6 . C6 . B5 . A5 . . . C6 . B5 . A5 . G5 . F#5 . G5 . A5 . B5 . E5 . . . . . . . E6 . D6 . B5 . . .', len: 0.85 },
      { w: 'sawtooth', v: 0.06, n: 'E2 E2 E3 E2 E2 E3 E2 E3 E2 E2 E3 E2 E2 E3 E2 E3 G2 G2 G3 G2 G2 G3 G2 G3 A2 A2 A3 A2 B2 B2 B3 B2 C3 C3 C4 C3 C3 C4 C3 C4 D3 D3 D4 D3 D3 D4 D3 D4 E2 E2 E3 E2 E2 E3 E2 E3 B1 B1 B2 B1 B1 B2 B1 B2', len: 0.6 },
    ], dr: 'k . h . s . h . k k h . s . h h k . h . s . h . k k h . s s s s'
  },
  title: {
    bpm: 92, ch: [
      { w: 'triangle', v: 0.1, n: 'E5 - - . G5 - . . A5 - - . G5 . E5 . D5 - - . E5 - . . C5 - - - - . . . E5 - - . G5 - . . A5 - - . C6 . B5 . A5 - - - - . G5 . A5 - - - - - - -', len: 0.9 },
      { w: 'sine', v: 0.06, n: 'C4 E4 G4 C5 G4 E4 C4 E4 G3 B3 D4 G4 D4 B3 G3 B3 A3 C4 E4 A4 E4 C4 A3 C4 F3 A3 C4 F4 C4 A3 F3 A3 C4 E4 G4 C5 G4 E4 C4 E4 G3 B3 D4 G4 D4 B3 G3 B3 F3 A3 C4 F4 C4 A3 F3 A3 G3 B3 D4 G4 D4 B3 G3 B3', len: 0.5 },
      { w: 'triangle', v: 0.13, n: 'C2 - - - - - - - G1 - - - - - - - A1 - - - - - - - F1 - - - - - - - C2 - - - - - - - G1 - - - - - - - F1 - - - - - - - G1 - - - - - - -', len: 0.95 },
    ], dr: ''
  },
  ending: {
    bpm: 118, ch: [
      { w: 'square', v: 0.07, n: 'C5 . E5 . G5 . C6 - - . B5 . A5 . G5 . A5 . F5 . A5 . C6 - - . D6 . C6 . A5 . G5 . E5 . G5 . C6 - - . E6 . D6 . C6 . D6 - - - - . . . C6 - - - - - - -', len: 0.9 },
      { w: 'triangle', v: 0.15, n: 'C3 . . . G2 . . . C3 . . . G2 . . . F2 . . . C3 . . . F2 . . . C3 . . . C3 . . . G2 . . . A2 . . . E2 . . . G2 . . . D3 . . . C3 . . . . . . .', len: 0.8 },
    ], dr: 'k . h . s . h . k . h . s . h h'
  },
};
for (const k in TRACKS) { const tr = TRACKS[k]; tr.ch.forEach(c => c.arr = c.n.split(/\s+/)); tr.drA = tr.dr ? tr.dr.split(/\s+/) : []; }
let musicWant = null, musicForce = null;
function setMusic(n) { musicForce = n; }
function musicContext() {
  if (UI.mode === 'title' || UI.mode === 'loading') return 'title';
  if (UI.mode === 'ending') return 'ending';
  if (musicForce) return musicForce;
  if (!P) return 'title';
  if (P.layer === 1) return 'under';
  return isNight() ? 'night' : 'day';
}
function updateMusic() {
  if (!AU.ctx) return;
  const c = AU.ctx, want = musicContext(), M = AU.mus;
  const now = c.currentTime;
  if (want !== M.cur) {
    if (!M.fading) { M.fading = true; AU.bgmMix.gain.cancelScheduledValues(now); AU.bgmMix.gain.setValueAtTime(AU.bgmMix.gain.value, now); AU.bgmMix.gain.linearRampToValueAtTime(0, now + 0.6); M.fadeEnd = now + 0.62; }
    else if (now >= M.fadeEnd) {
      M.cur = want; M.step = 0; M.next = now + 0.05; M.fading = false;
      AU.bgmMix.gain.cancelScheduledValues(now); AU.bgmMix.gain.setValueAtTime(0, now); AU.bgmMix.gain.linearRampToValueAtTime(1, now + 0.8);
      const tr = TRACKS[want]; AU.bgmLP.frequency.setTargetAtTime(tr && tr.lp ? tr.lp : 20000, now, 0.3);
    }
    if (M.fading) return;
  }
  const tr = TRACKS[M.cur]; if (!tr) return;
  const sd = 60 / tr.bpm / 4;
  while (M.next < now + 0.15) {
    playStep(tr, M.step, M.next, sd);
    M.next += sd; M.step++;
  }
}
function playStep(tr, step, t, sd) {
  const c = AU.ctx;
  for (const ch of tr.ch) {
    const a = ch.arr, i = step % a.length, tok = a[i];
    if (tok === '.' || tok === '-') continue;
    const f = nfreq(tok); if (!f) continue;
    let hold = 1; while (a[(i + hold) % a.length] === '-' && hold < 32) hold++;
    const dur = hold * sd * (ch.len || 0.8);
    const o = c.createOscillator(), g = c.createGain();
    o.type = ch.w; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(ch.v, t + 0.012);
    g.gain.setValueAtTime(ch.v, t + Math.max(0.02, dur * 0.6)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(AU.bgmMix); o.start(t); o.stop(t + dur + 0.05);
  }
  if (tr.drA.length) {
    const tok = tr.drA[step % tr.drA.length];
    if (tok === 'k') { const o = c.createOscillator(), g = c.createGain(); o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(40, t + 0.12); g.gain.setValueAtTime(0.28, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.14); o.connect(g); g.connect(AU.bgmMix); o.start(t); o.stop(t + 0.16); }
    else if (tok === 's' || tok === 'h') {
      const s = c.createBufferSource(); s.buffer = AU.noise;
      const f = c.createBiquadFilter(); f.type = tok === 's' ? 'bandpass' : 'highpass'; f.frequency.value = tok === 's' ? 1800 : 7000;
      const g = c.createGain(); const v = tok === 's' ? 0.16 : 0.05, d = tok === 's' ? 0.12 : 0.04;
      g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      s.connect(f); f.connect(g); g.connect(AU.bgmMix); s.start(t, Math.random()); s.stop(t + d + 0.02);
    }
  }
}
let ambT = 0;
function updateAmbient(dt) {
  if (!AU.ctx || !AU.amb.wave) return;
  ambT += dt;
  let sea = 0;
  if (P && UI.mode !== 'title') {
    const pt = ptile();
    for (let dy = -6; dy <= 6; dy += 3) for (let dx = -6; dx <= 6; dx += 3) if (isSea(terAt(0, pt.x + dx, pt.y + dy))) sea++;
    sea /= 25;
  } else sea = 0.6;
  const under = P && P.layer === 1 && UI.mode !== 'title';
  const raining = G && G.weather && G.weather.type !== 'clear' && UI.mode !== 'title';
  const swell = 0.6 + 0.4 * Math.sin(ambT * 0.9) * Math.sin(ambT * 0.37);
  const s = 0.4;
  AU.amb.wave.g.gain.setTargetAtTime(under ? 0 : sea * 0.22 * swell * s * 2, AU.ctx.currentTime, 0.2);
  AU.amb.under.g.gain.setTargetAtTime(under ? 0.35 * s : 0, AU.ctx.currentTime, 0.3);
  AU.amb.rain.g.gain.setTargetAtTime(raining && !under ? (G.weather.type === 'storm' ? 0.22 : 0.12) * s * 2 : 0, AU.ctx.currentTime, 0.5);
  AU.amb.wind.g.gain.setTargetAtTime(raining && G.weather.type === 'storm' && !under ? 0.2 * s * (0.6 + 0.4 * Math.sin(ambT * 0.7)) : 0, AU.ctx.currentTime, 0.5);
}

/* ---------- セーブ・ロード ---------- */
function rleEncode(a) { const out = []; let v = 0, n = 0; for (let i = 0; i < a.length; i++) { const b = a[i] ? 1 : 0; if (b === v) n++; else { out.push(n); v = b; n = 1; } } out.push(n); return out.join(','); }
function rleDecode(s, len) { const a = new Uint8Array(len); if (!s) return a; let i = 0, v = 0; for (const p of s.split(',')) { const n = +p; if (v) a.fill(1, i, Math.min(len, i + n)); i += n; v ^= 1; } return a; }
function diffArr(cur, base) { const out = []; for (let i = 0; i < cur.length; i++) if (cur[i] !== base[i]) out.push(i, cur[i]); return out; }
function serialize() {
  const od = []; for (const [k, v] of G.objData) od.push([k, v]);
  return JSON.stringify({
    v: SAVE_VER, seed: G.seed, clock: G.clock, weather: G.weather, flags: G.flags, stats: G.stats, quest: G.quest, qdone: G.qdone, read: G.read,
    regrow: G.regrow, special: [...G.special], lm: G.lm,
    ground: diffArr(G.ground, G.base.ground), objS: diffArr(G.objS, G.base.objS), objU: diffArr(G.objU, G.base.objU), od,
    explored: rleEncode(G.explored),
    player: { x: P.x, y: P.y, layer: P.layer, hp: P.hp, hunger: P.hunger, thirst: P.thirst, stam: P.stam, o2: P.o2, poison: P.poison, inv: P.inv, equip: P.equip, sel: P.sel, spawn: P.spawn, raft: P.raft },
    savedAt: Date.now(),
  });
}
function saveGame(silent) {
  if (!G || !P || P.dead || G.ended === 'pending') return false;
  try {
    const data = serialize();
    const old = localStorage.getItem(SAVE_KEY);
    if (old) { try { localStorage.setItem(SAVE_BAK, old); } catch (e) { localStorage.removeItem(SAVE_BAK); } }
    localStorage.setItem(SAVE_KEY, data);
    if (!silent) toast('セーブしました', 'gold');
    else saveIcon();
    return true;
  } catch (e) {
    toast('セーブに失敗しました（容量不足かも）', 'red');
    return false;
  }
}
function readSave(key) {
  try {
    const s = localStorage.getItem(key); if (!s) return null;
    const d = JSON.parse(s);
    if (!d || d.v !== SAVE_VER || typeof d.seed !== 'number' || !d.player || !Array.isArray(d.player.inv)) return null;
    return d;
  } catch (e) { return null; }
}
function getSave() { const a = readSave(SAVE_KEY); if (a) return a; return readSave(SAVE_BAK); }
function saveInfo() {
  const d = getSave(); if (!d) return null;
  const day = Math.floor(d.clock / 1440) + 1;
  return { day, quest: QUESTS[Math.min(d.quest || 0, QUESTS.length - 1)].t, at: d.savedAt };
}
function sanitizeSlot(s) {
  if (!s || typeof s !== 'object' || !ITEMS[s.id]) return null;
  const n = Math.max(1, Math.min(ITEMS[s.id].st, Math.floor(+s.n || 1)));
  const o = { id: s.id, n };
  if (ITEMS[s.id].tool) o.dur = Math.max(1, Math.min(ITEMS[s.id].tool.dur, Math.floor(+s.dur || ITEMS[s.id].tool.dur)));
  return o;
}
function buildGame(w, save) {
  G = {
    seed: w.seed, ground: w.ground, seabed: w.seabed, objS: w.objS, objU: w.objU, objData: w.objData, lm: w.lm, elev: w.elev,
    base: { ground: w.ground.slice(), objS: w.objS.slice(), objU: w.objU.slice() },
    clock: 7 * 60, weather: { type: 'clear', t: 600 }, flags: {}, stats: {}, quest: 0, qdone: [], read: [], regrow: [], special: new Set(),
    explored: new Uint8Array(MM),
  };
  P = newPlayer(w.lm);
  if (save) {
    const ap = (arr, d) => { if (!Array.isArray(d)) return; for (let i = 0; i + 1 < d.length; i += 2) { const k = d[i] | 0; if (k >= 0 && k < MM) arr[k] = d[i + 1] | 0; } };
    try {
      ap(G.ground, save.ground); ap(G.objS, save.objS); ap(G.objU, save.objU);
      for (let i = 0; i < MM; i++) { if (G.objS[i] >= OBJ.length) G.objS[i] = 0; if (G.objU[i] >= OBJ.length) G.objU[i] = 0; if (G.ground[i] >= TN) G.ground[i] = T.SAND; }
      if (Array.isArray(save.od)) { G.objData = new Map(); for (const [k, v] of save.od) if (typeof k === 'number' && v && typeof v === 'object') { if (v.items) v.items = v.items.map(sanitizeSlot); G.objData.set(k, v); } }
      G.clock = +save.clock || G.clock;
      if (save.weather && save.weather.type) G.weather = save.weather;
      G.flags = save.flags || {}; G.stats = save.stats || {}; G.quest = clamp(save.quest | 0, 0, QUESTS.length - 1);
      G.qdone = Array.isArray(save.qdone) ? save.qdone.map(v => v ? 1 : 0) : new Array(G.quest).fill(1);
      G.read = Array.isArray(save.read) ? save.read : [];
      G.regrow = Array.isArray(save.regrow) ? save.regrow.filter(r => r && typeof r.k === 'number') : [];
      G.special = new Set(Array.isArray(save.special) ? save.special : []);
      if (save.lm) G.lm = Object.assign({}, w.lm, { shipyard: save.lm.shipyard || null, bag: save.lm.bag || null });
      G.explored = rleDecode(save.explored, MM);
      const sp = save.player;
      P.x = clamp(+sp.x || P.x, 8, MAP * 16 - 8); P.y = clamp(+sp.y || P.y, 8, MAP * 16 - 8); P.layer = sp.layer === 1 ? 1 : 0;
      P.hp = clamp(+sp.hp || 50, 1, 999); P.hunger = clamp(+sp.hunger || 50, 0, 100); P.thirst = clamp(+sp.thirst || 50, 0, 100);
      P.stam = clamp(+sp.stam || 100, 0, 100); P.o2 = +sp.o2 || 20; P.poison = +sp.poison || 0;
      P.inv = new Array(INV_N).fill(null).map((_, i) => sanitizeSlot(sp.inv[i]));
      for (const k of EQ_SLOTS) { const e = sp.equip && sp.equip[k]; P.equip[k] = e && ITEMS[e.id] && ITEMS[e.id].eq && ITEMS[e.id].eq.s === k ? { id: e.id } : null; }
      P.sel = clamp(sp.sel | 0, 0, HOT_N - 1);
      if (sp.spawn && typeof sp.spawn.x === 'number') P.spawn = sp.spawn;
      P.raft = !!sp.raft && invCount('raft') > 0;
    } catch (e) { console.warn('save partially broken', e); toast('セーブデータの一部が壊れていたので修復しました', 'red'); }
  }
  calcStats();
  if (save) { P.hp = Math.min(P.hp, PS.hpmax); }
  else P.o2 = PS.o2max;
  ENTS.length = 0; DROPS.length = 0; PROJ.length = 0; PARTS.length = 0; objHit.clear(); objShake.clear();
  unstick(P, P.layer);
  mapInit();
}
/* =============================================================
   UI（HUD・ホットバー・メニュー・宝箱・会話・地図・タイトル・エンディング）
   ============================================================= */
const UI = { mode: 'title', tab: 'inv', station: null, sel: null, rsel: null, cat: 'all', chest: null, dirty: true, boss: null, flash: 0, hitstop: 0, dlgQ: [], dlg: null, focus: null, focusKey: null, saveT: 0, ctxT: 0, endT: 0 };
const later = (fn, ms = 0) => setTimeout(fn, ms);
function shake(n) { if (SET.shake) CAM.shake = Math.max(CAM.shake, n); }
function flashScreen(a) { UI.flash = Math.max(UI.flash, a); }
function hitStop(t) { UI.hitstop = Math.max(UI.hitstop, t); }
function saveIcon() { UI.saveT = 1.6; }
function bossBar(e) { UI.boss = e; }
function uiDirty() { UI.dirty = true; }

/* ---------- 通知 ---------- */
let lastToast = '', lastToastT = 0;
function toast(msg, cls = '') {
  const n = now();
  if (msg === lastToast && n - lastToastT < 1200) return;
  lastToast = msg; lastToastT = n;
  const box = $('#toasts'), d = document.createElement('div');
  d.className = 'toast ' + cls; d.textContent = msg;
  box.appendChild(d);
  while (box.children.length > 4) box.firstChild.remove();
  setTimeout(() => { d.style.transition = 'opacity .4s'; d.style.opacity = '0'; setTimeout(() => d.remove(), 420); }, cls.includes('big') ? 3000 : 2300);
}
const pkMap = new Map();
function pickupNotice(id, n) {
  const box = $('#pickups');
  let e = pkMap.get(id);
  if (e && e.el.isConnected) { e.n += n; clearTimeout(e.tm); }
  else { const el = document.createElement('div'); el.className = 'pk'; box.appendChild(el); e = { el, n }; pkMap.set(id, e); while (box.children.length > 6) box.firstChild.remove(); }
  e.el.innerHTML = `<img src="${iconURL(id)}">${ITEMS[id].n} +${e.n}`;
  e.tm = setTimeout(() => { e.el.remove(); pkMap.delete(id); }, 2200);
}

/* ---------- ホットバー ---------- */
function slotHTML(s, attrs, cls, k) {
  let h = `<div class="slot nav ${cls || ''}" ${attrs}>`;
  if (s && ITEMS[s.id]) {
    h += `<img src="${iconURL(s.id)}" alt="">`;
    if (s.n > 1) h += `<span class="n">${s.n}</span>`;
    if (s.dur != null && ITEMS[s.id].tool) { const r = s.dur / ITEMS[s.id].tool.dur; h += `<span class="dur"><i style="width:${Math.round(r * 100)}%;background:${r < 0.25 ? '#ff6b5a' : r < 0.5 ? '#ffd25a' : '#7fe07a'}"></i></span>`; }
  }
  if (k) h += `<span class="k">${k}</span>`;
  return h + '</div>';
}
function renderHotbar() {
  if (!P) return;
  let h = '';
  for (let i = 0; i < HOT_N; i++) h += slotHTML(P.inv[i], `data-hot="${i}"`, i === P.sel ? 'active' : '', input.mode === 'kb' ? String(i + 1) : '');
  $('#hotbar').innerHTML = h;
}
function selectHot(i) {
  if (!P || i < 0 || i >= HOT_N) return;
  if (P.sel !== i) { P.sel = i; P.fish = null; sfx('ui'); }
  const s = P.inv[i];
  if (s) toastItem(s.id);
  uiDirty();
}
let toastItemT = 0;
function toastItem(id) { const n = now(); if (n - toastItemT < 250) return; toastItemT = n; toast(ITEMS[id].n); }

/* ---------- クエスト表示 ---------- */
function questUI(done) {
  const q = QUESTS[G.quest];
  $('#questTitle').textContent = q.t;
  $('#questDesc').textContent = questDesc(q);
  if (done) { const el = $('#quest'); el.classList.remove('done'); void el.offsetWidth; el.classList.add('done'); }
}

/* ---------- 会話 ---------- */
function dialog(lines, onEnd) {
  UI.dlgQ.push({ lines: lines.map(l => typeof l === 'string' ? { text: l } : l), onEnd });
  if (!UI.dlg) nextDialog();
}
function nextDialog() {
  const g = UI.dlgQ.shift();
  if (!g) { UI.dlg = null; $('#dialog').classList.add('hidden'); if (UI.mode === 'dialog') UI.mode = UI.dlgPrev || 'play'; if (UI.mode !== 'play' && UI.mode !== 'ending' && UI.mode !== 'menu' && UI.mode !== 'chest') UI.mode = 'play'; return; }
  if (UI.mode === 'menu' || UI.mode === 'chest') closeMenu(true);
  if (UI.mode !== 'dialog') UI.dlgPrev = UI.mode === 'ending' ? 'ending' : 'play';
  UI.mode = 'dialog';
  UI.dlg = { g, i: 0, shown: 0, t: 0 };
  $('#dialog').classList.remove('hidden');
  showDlgLine();
}
function showDlgLine() {
  const d = UI.dlg, l = d.g.lines[d.i];
  $('#dlgName').textContent = l.name || '';
  $('#dlgText').textContent = '';
  d.shown = 0; d.t = 0;
  $('#dlgChoices').innerHTML = '';
  $('#dlgNext').style.visibility = 'hidden';
}
function updateDialog(dt) {
  const d = UI.dlg; if (!d) return;
  const l = d.g.lines[d.i];
  if (d.shown < l.text.length) {
    d.t += dt * 55;
    const n = Math.min(l.text.length, Math.floor(d.t));
    if (n !== d.shown) { d.shown = n; $('#dlgText').textContent = l.text.slice(0, n); if (n % 3 === 0) sfx('ui'); }
    if (d.shown >= l.text.length) dlgLineDone();
  }
}
function dlgLineDone() {
  const d = UI.dlg, l = d.g.lines[d.i];
  $('#dlgText').textContent = l.text;
  d.shown = l.text.length;
  if (l.choices) {
    $('#dlgChoices').innerHTML = l.choices.map((c, i) => `<div class="btn nav" data-k="ch${i}" data-ch="${i}">${c[0]}</div>`).join('');
    if (input.mode !== 'touch') setNavFocus($('#dlgChoices .btn'));
  } else $('#dlgNext').style.visibility = 'visible';
}
function advanceDialog() {
  const d = UI.dlg; if (!d) return;
  const l = d.g.lines[d.i];
  if (d.shown < l.text.length) { dlgLineDone(); return; }
  if (l.choices) return;
  d.i++;
  if (d.i >= d.g.lines.length) { const cb = d.g.onEnd; UI.dlg = null; nextDialog(); if (cb) cb(); }
  else showDlgLine();
}
function chooseDialog(i) {
  const d = UI.dlg; if (!d) return;
  const l = d.g.lines[d.i], c = l.choices[i];
  clearNavFocus();
  UI.dlg = null; UI.dlgQ.length = 0; nextDialog();
  if (c && c[1]) c[1]();
}

/* ---------- メニュー ---------- */
const TABS = [['inv', 'もちもの'], ['craft', 'クラフト'], ['map', '地図'], ['note', 'ノート'], ['sys', 'システム']];
function openMenu(tab, station) {
  if (!P || P.dead) return;
  UI.mode = 'menu'; UI.tab = tab || 'inv'; UI.station = station || null; UI.sel = null; UI.rsel = null;
  if (station === 'fire') UI.cat = 'food'; else if (station === 'furnace') UI.cat = 'mat'; else if (station === 'bench') UI.cat = 'all';
  P.fish = null;
  $('#menu').classList.remove('hidden');
  renderMenu(); sfx('uiopen');
}
function closeMenu(silent) {
  $('#menu').classList.add('hidden');
  UI.chest = null; UI.sel = null;
  if (UI.mode === 'menu' || UI.mode === 'chest') UI.mode = 'play';
  clearNavFocus();
  if (!silent) sfx('uiclose');
  uiDirty();
}
function renderMenu() {
  const keep = UI.focusKey;
  const tabs = $('#menuTabs'), body = $('#menuBody');
  if (UI.mode === 'chest') {
    tabs.innerHTML = `<div class="tab on">${OBJ[UI.chest.o].n}</div>`;
    body.innerHTML = chestHTML();
  } else {
    tabs.innerHTML = TABS.map(([k, n]) => `<div class="tab nav ${UI.tab === k ? 'on' : ''}" data-k="tab${k}" data-tab="${k}">${n}</div>`).join('');
    body.innerHTML = UI.tab === 'inv' ? invHTML() : UI.tab === 'craft' ? craftHTML() : UI.tab === 'map' ? mapHTML() : UI.tab === 'note' ? noteHTML() : sysHTML();
    if (UI.tab === 'map') drawMapCanvas();
    if (UI.tab === 'sys') bindSettings(body);
  }
  if (keep && input.mode !== 'touch') { const el = document.querySelector(`#menu [data-k="${keep}"]`); if (el) setNavFocus(el, true); }
}
function itemStats(id) {
  const it = ITEMS[id], out = [];
  if (it.f) { if (it.f.h) out.push(`空腹+${it.f.h}`); if (it.f.w) out.push(`のど+${it.f.w}`); if (it.f.hp) out.push(`体力${it.f.hp > 0 ? '+' : ''}${it.f.hp}`); if (it.cure) out.push('毒を治す'); }
  if (it.tool) { const t = it.tool; if (t.dmg) out.push(`攻撃${t.dmg}`); if (t.pow > 1) out.push(`採集力${t.pow}`); out.push(`耐久${t.dur}`); }
  if (it.eq) { const e = it.eq; out.push(`部位:${EQ_NAME[e.s]}`); if (e.def) out.push(`防御+${e.def}`); if (e.o2) out.push(`酸素+${e.o2}秒`); if (e.swim) out.push(`泳ぎ+${Math.round(e.swim * 100)}%`); if (e.spd) out.push(`歩き${e.spd > 0 ? '+' : ''}${Math.round(e.spd * 100)}%`); if (e.light) out.push('光る'); if (e.hp) out.push(`最大体力+${e.hp}`); if (e.atk) out.push(`攻撃+${Math.round(e.atk * 100)}%`); if (e.drain) out.push(`酸素消費${Math.round(e.drain * 100)}%`); }
  return out.join('　');
}
function invHTML() {
  let eq = '';
  for (const k of EQ_SLOTS) eq += `<div class="eqcell">${slotHTML(P.equip[k], `data-k="eq${k}" data-eq="${k}"`, 'eq')}<span>${EQ_NAME[k]}</span></div>`;
  let grid = '';
  for (let i = 0; i < INV_N; i++) grid += slotHTML(P.inv[i], `data-k="s${i}" data-slot="${i}"`, (i < HOT_N ? 'hot ' : '') + (UI.sel === i ? 'sel' : ''), i < HOT_N ? String(i + 1) : '');
  let info = '<div class="ds">アイテムをタップで選択。もう一度別のマスをタップすると入れ替え。</div>';
  const s = UI.sel != null ? P.inv[UI.sel] : null;
  if (s) {
    const it = ITEMS[s.id];
    let acts = '';
    if (it.cat === 'food') acts += `<div class="btn small nav" data-k="aeat" data-act="eat">${it.med ? '使う' : '食べる'}</div>`;
    if (it.eq) acts += `<div class="btn small nav green" data-k="aeq" data-act="equip">装備する</div>`;
    if (UI.sel >= HOT_N) acts += `<div class="btn small nav" data-k="ahot" data-act="tohot">ホットバーへ</div>`;
    else acts += `<div class="btn small nav" data-k="ahold" data-act="hold">手に持つ</div>`;
    if (it.cat !== 'key') { acts += `<div class="btn small nav" data-k="adrop1" data-act="drop1">1つ捨てる</div>`; if (s.n > 1) acts += `<div class="btn small nav red" data-k="adropa" data-act="dropall">全部捨てる</div>`; }
    info = `<div class="nm">${it.n}${s.n > 1 ? ' ×' + s.n : ''}</div><div class="ds">${it.d}<br>${itemStats(s.id)}</div><div class="acts">${acts}</div>`;
  }
  const st = `体力 <b>${Math.ceil(P.hp)}/${PS.hpmax}</b>　防御 <b>${PS.def}</b>　攻撃 <b>×${PS.atk.toFixed(2)}</b><br>酸素 <b>${PS.o2max}秒</b>${PS.drain < 1 ? `（消費${Math.round(PS.drain * 100)}%）` : ''}　泳ぎ <b>+${Math.round(PS.swim * 100)}%</b>　歩き <b>${PS.spd >= 0 ? '+' : ''}${Math.round(PS.spd * 100)}%</b>${PS.light ? '　<b>光</b>' : ''}${P.poison > 0 ? '　<b style="color:#8ae04a">毒</b>' : ''}`;
  return `<div class="cols"><div class="col" style="flex:0 1 300px"><div class="h">装備（タップで外す）</div><div class="eqgrid">${eq}</div><div class="h">ステータス</div><div class="stats">${st}</div></div>
  <div class="col"><div class="h">もちもの（上の段がホットバー）</div><div class="grid">${grid}</div><div class="h">くわしく</div><div class="info">${info}</div></div></div>`;
}
function craftHTML() {
  const st = nearStations();
  let h = '<div class="chips">';
  for (const k of ['hand', 'bench', 'furnace', 'fire']) h += `<span class="chip ${st[k] ? 'ok' : 'ng'}">${ST_NAME[k]}${st[k] ? ' ✓' : ''}</span>`;
  h += '</div><div class="chips">';
  for (const k in CAT_NAME) h += `<span class="chip nav ${UI.cat === k ? 'on' : ''}" data-k="cat${k}" data-cat="${k}">${CAT_NAME[k]}</span>`;
  h += '</div>';
  const list = RECIPES.map((r, i) => ({ r, i })).filter(({ r }) => recipeVisible(r) && (UI.cat === 'all' || r.cat === UI.cat));
  const rank = r => canCraft(r, st) ? 0 : hasIngredients(r) ? 1 : st[r.st] ? 2 : 3;
  list.sort((a, b) => rank(a.r) - rank(b.r) || a.i - b.i);
  const sel = UI.rsel != null ? RECIPES[UI.rsel] : null;
  if (sel) {
    const can = canCraft(sel, st), it = ITEMS[sel.o];
    h += `<div class="info" style="margin-bottom:6px"><div class="nm"><img src="${iconURL(sel.o)}" style="width:24px;height:24px;vertical-align:middle;image-rendering:pixelated"> ${it.n}${sel.n > 1 ? ' ×' + sel.n : ''}</div><div class="ds">${it.d}　${itemStats(sel.o)}</div>
    <div class="ds">${ingHTML(sel)}　<span style="color:${st[sel.st] ? '#a8f0a0' : '#ff9a8a'}">［${ST_NAME[sel.st]}${st[sel.st] ? '' : 'の近くで'}］</span></div>
    <div class="acts"><div class="btn nav ${can ? 'gold' : 'dis'}" data-k="mk1" data-act="mk1">作る</div>${it.st > 1 ? `<div class="btn nav ${can ? '' : 'dis'}" data-k="mk5" data-act="mk5">×5</div>` : ''}<div class="btn nav small" data-k="mkx" data-act="unsel">閉じる</div></div></div>`;
  } else h += `<div class="ds" style="font-size:12px;color:var(--ink2);margin-bottom:6px">レシピをタップすると詳細と「作る」ボタンが出ます。${UI.station ? '' : '作業台・かまど・たき火の近くだと作れる物が増えます。'}</div>`;
  h += '<div class="rlist">';
  for (const { r, i } of list) {
    const k = rank(r), it = ITEMS[r.o];
    h += `<div class="rc nav ${k === 0 ? 'can' : 'cant'} ${UI.rsel === i ? 'sel' : ''}" data-k="r${i}" data-r="${i}"><img src="${iconURL(r.o)}" alt=""><div><div class="rn">${it.n}${r.n > 1 ? ' ×' + r.n : ''}</div><div class="ri">${ingHTML(r)}${st[r.st] ? '' : `<br><span class="ng">${ST_NAME[r.st]}が必要</span>`}</div></div></div>`;
  }
  return h + '</div>';
}
function ingHTML(r) { let s = ''; for (const k in r.i) { const have = invCount(k), need = r.i[k]; s += `<span class="ing"><img src="${iconURL(k)}" alt=""><span class="${have >= need ? 'ok' : 'ng'}">${ITEMS[k].n}${have}/${need}</span></span>`; } return s; }
function noteHTML() {
  let h = '<div class="h">目標</div>';
  const q = QUESTS[G.quest];
  h += `<div class="note cur"><b style="color:var(--gold);font-weight:normal">▶ ${q.t}</b>\n${questDesc(q)}</div>`;
  for (let i = QUESTS.length - 2; i >= 0; i--) if (G.qdone && G.qdone[i]) h += `<div class="note done">✓ ${QUESTS[i].t}</div>`;
  h += `<div class="h">漂流瓶の手紙（${G.read.length}/${BOTTLE_MSG.length}）</div><div class="chips">`;
  for (let i = 0; i < BOTTLE_MSG.length; i++) h += G.read.includes(i) ? `<span class="chip nav" data-k="b${i}" data-bottle="${i}">${BOTTLE_TITLE[i]}</span>` : `<span class="chip ng">？？？</span>`;
  h += '</div>';
  let ex = 0; for (let i = 0; i < MM; i += 7) ex += G.explored[i]; ex = Math.round(ex / (MM / 7) * 100);
  const s = G.stats;
  h += `<div class="h">記録</div><div class="stats">生存 <b>${dayNum()}日目</b>　探索率 <b>${ex}%</b><br>倒した生き物 <b>${s.kills || 0}</b>　釣った魚 <b>${s.fish || 0}</b>　作った物 <b>${s.crafted || 0}</b><br>切った木 <b>${s.trees || 0}</b>　力尽きた回数 <b>${s.deaths || 0}</b>${G.flags.parrot ? '<br>相棒 <b>ポコ（オウム）</b>' : ''}</div>`;
  return h;
}
function settingsHTML() {
  return `<div class="row"><label>BGMの音量</label><input type="range" class="nav" data-k="sbgm" min="0" max="1" step="0.05" value="${SET.bgm}" data-set="bgm"></div>
  <div class="row"><label>効果音の音量</label><input type="range" class="nav" data-k="sse" min="0" max="1" step="0.05" value="${SET.se}" data-set="se"></div>
  <div class="row"><label>A/B・X/Yの入れ替え</label><div class="btn tog nav ${SET.swap ? 'on' : ''}" data-k="sswap" data-tog="swap">${SET.swap ? 'ON（任天堂配置）' : 'OFF'}</div></div>
  <div class="row"><label>画面のゆれ</label><div class="btn tog nav ${SET.shake ? 'on' : ''}" data-k="sshake" data-tog="shake">${SET.shake ? 'ON' : 'OFF'}</div></div>
  <div class="row"><label>振動（スマホ）</label><div class="btn tog nav ${SET.vib ? 'on' : ''}" data-k="svib" data-tog="vib">${SET.vib ? 'ON' : 'OFF'}</div></div>`;
}
function bindSettings(root) {
  root.querySelectorAll('input[data-set]').forEach(el => el.addEventListener('input', () => { SET[el.dataset.set] = +el.value; saveSettings(); }));
}
function sysHTML() {
  return `<div class="h">ゲーム</div><div class="row"><div class="btn gold nav" data-k="ysave" data-act="save">セーブする</div><div class="btn nav" data-k="yhelp" data-act="help">あそびかた</div><div class="btn red nav" data-k="ytitle" data-act="title">タイトルへ戻る</div></div>
  <div class="h">設定</div>${settingsHTML()}
  <div class="h">クレジット</div><div class="stats">TIDEBOUND ～蒼海の漂流島～<br>made by <a href="https://github.com/h1ro223" target="_blank" rel="noopener">hiro/ヒロ</a>　<a href="https://github.com/h1ro223" target="_blank" rel="noopener">https://github.com/h1ro223</a><br>ドット絵・音楽・効果音はすべてプログラムで生成しています。</div>`;
}
function chestHTML() {
  const od = UI.chest.od;
  let cg = ''; for (let i = 0; i < od.items.length; i++) cg += slotHTML(od.items[i], `data-k="c${i}" data-cslot="${i}"`, '');
  let ig = ''; for (let i = 0; i < INV_N; i++) ig += slotHTML(P.inv[i], `data-k="s${i}" data-islot="${i}"`, i < HOT_N ? 'hot' : '', i < HOT_N ? String(i + 1) : '');
  return `<div class="ds" style="font-size:12px;color:var(--ink2);margin-bottom:4px">タップしたアイテムを反対側へ移します。</div><div class="h">${OBJ[UI.chest.o].n}の中身</div><div class="grid">${cg}</div>
  <div class="row"><div class="btn nav" data-k="ctake" data-act="takeall">全部取る</div><div class="btn nav" data-k="cput" data-act="putall">ホットバー以外をしまう</div><div class="btn nav gold" data-k="cclose" data-act="close">閉じる</div></div>
  <div class="h">もちもの</div><div class="grid">${ig}</div>`;
}
function openChest(ob) {
  const k = okey(ob.layer, idx(ob.x, ob.y));
  let od = G.objData.get(k);
  if (!od || !od.items) { od = { items: new Array(16).fill(null) }; G.objData.set(k, od); }
  UI.chest = { ...ob, od }; UI.mode = 'chest';
  $('#menu').classList.remove('hidden');
  renderMenu();
}
function moveToChest(i) {
  const s = P.inv[i]; if (!s) return;
  const items = UI.chest.od.items, st = ITEMS[s.id].st;
  for (const c of items) if (c && c.id === s.id && c.n < st && s.n > 0) { const a = Math.min(st - c.n, s.n); c.n += a; s.n -= a; }
  if (s.n > 0) { const j = items.findIndex(c => !c); if (j < 0) { toast('箱がいっぱい', 'red'); } else { items[j] = { ...s }; s.n = 0; } }
  if (s.n <= 0) P.inv[i] = null;
}
function moveFromChest(i) {
  const items = UI.chest.od.items, c = items[i]; if (!c) return;
  const left = addItem(c.id, c.n, true);
  if (left > 0) { c.n = left; toast('持ち物がいっぱい！', 'red'); } else items[i] = null;
  if (c.dur != null && !left) { const sl = P.inv.find(s => s && s.id === c.id && s.dur === ITEMS[c.id].tool.dur); if (sl) sl.dur = c.dur; }
}
function menuClick(e) {
  const t = e.target.closest('[data-tab],[data-slot],[data-eq],[data-act],[data-r],[data-cat],[data-bottle],[data-cslot],[data-islot],[data-tog]');
  if (!t) return;
  if (t.classList.contains('nav')) UI.focusKey = t.dataset.k;
  const D = t.dataset;
  if (D.tab) { UI.tab = D.tab; UI.sel = null; UI.rsel = null; UI.focusKey = 'tab' + D.tab; sfx('ui'); renderMenu(); return; }
  if (D.cslot != null) { moveFromChest(+D.cslot); sfx('ui'); renderMenu(); uiDirty(); return; }
  if (D.islot != null) { moveToChest(+D.islot); sfx('ui'); renderMenu(); uiDirty(); return; }
  if (D.slot != null) {
    const i = +D.slot;
    if (UI.sel == null) { if (P.inv[i]) UI.sel = i; }
    else if (UI.sel === i) UI.sel = null;
    else {
      const a = P.inv[UI.sel], b = P.inv[i];
      if (a && b && a.id === b.id && ITEMS[a.id].st > 1) { const m = Math.min(ITEMS[a.id].st - b.n, a.n); b.n += m; a.n -= m; if (a.n <= 0) P.inv[UI.sel] = null; }
      else { P.inv[UI.sel] = b; P.inv[i] = a; }
      UI.sel = null;
    }
    sfx('ui'); renderMenu(); uiDirty(); return;
  }
  if (D.eq) { unequip(D.eq); renderMenu(); return; }
  if (D.cat) { UI.cat = D.cat; UI.rsel = null; sfx('ui'); renderMenu(); return; }
  if (D.r != null) { UI.rsel = UI.rsel === +D.r ? null : +D.r; sfx('ui'); renderMenu(); if (UI.rsel != null) { UI.focusKey = 'mk1'; const el = $('[data-k="mk1"]'); if (el && input.mode !== 'touch') setNavFocus(el); $('#menuBody').scrollTop = 0; } return; }
  if (D.bottle != null) { const i = +D.bottle; dialog([{ name: '漂流瓶の手紙「' + BOTTLE_TITLE[i] + '」', text: BOTTLE_MSG[i] }]); return; }
  if (D.tog) { SET[D.tog] = !SET[D.tog]; saveSettings(); sfx('ui'); if (UI.mode === 'menu') renderMenu(); else openSettingsModal(); return; }
  const s = UI.sel != null ? P.inv[UI.sel] : null;
  switch (D.act) {
    case 'eat': { const old = P.sel; P.sel = UI.sel; P.cd = 0; eatSel(); P.sel = old; if (!P.inv[UI.sel]) UI.sel = null; renderMenu(); break; }
    case 'equip': equipFrom(UI.sel); UI.sel = null; renderMenu(); break;
    case 'tohot': { let j = P.inv.slice(0, HOT_N).findIndex(x => !x); if (j < 0) j = P.sel; const tmp = P.inv[j]; P.inv[j] = s; P.inv[UI.sel] = tmp; UI.sel = null; sfx('ui'); renderMenu(); uiDirty(); break; }
    case 'hold': P.sel = UI.sel; UI.sel = null; sfx('ui'); renderMenu(); uiDirty(); break;
    case 'drop1': if (s) { spawnDrop(P.layer, P.x + P.fx * 10, P.y + P.fy * 10, s.id, 1); const dd = DROPS[DROPS.length - 1]; if (dd) dd.age = -1.5; s.n--; if (s.n <= 0) { P.inv[UI.sel] = null; UI.sel = null; } sfx('ui'); renderMenu(); uiDirty(); } break;
    case 'dropall': if (s) { spawnDrop(P.layer, P.x + P.fx * 10, P.y + P.fy * 10, s.id, s.n); const dd = DROPS[DROPS.length - 1]; if (dd) dd.age = -1.5; P.inv[UI.sel] = null; UI.sel = null; sfx('ui'); renderMenu(); uiDirty(); } break;
    case 'mk1': case 'mk5': { const r = RECIPES[UI.rsel]; if (r) { if (!canCraft(r, nearStations())) { sfx('err'); toast(nearStations()[r.st] ? '材料が足りない' : ST_NAME[r.st] + 'の近くで作ろう', 'red'); } else craft(r, D.act === 'mk5' ? 5 : 1); if (UI.mode === 'menu') renderMenu(); } break; }
    case 'unsel': UI.rsel = null; renderMenu(); break;
    case 'save': saveGame(false); break;
    case 'help': openHelp(); break;
    case 'title': confirmModal('タイトルに戻りますか？（セーブしてから戻ります）', () => { saveGame(true); toTitle(); }); break;
    case 'takeall': UI.chest.od.items.forEach((c, i) => moveFromChest(i)); sfx('ui'); renderMenu(); uiDirty(); break;
    case 'putall': for (let i = HOT_N; i < INV_N; i++) moveToChest(i); sfx('ui'); renderMenu(); uiDirty(); break;
    case 'close': closeMenu(); break;
  }
}

/* ---------- モーダル ---------- */
function openModal(html, mode = 'modal') {
  UI.modalPrev = UI.mode === 'modal' ? UI.modalPrev : UI.mode;
  UI.mode = mode;
  $('#modalInner').innerHTML = html;
  $('#modal').classList.remove('hidden');
  if (input.mode !== 'touch') { const f = $('#modalInner .nav'); if (f) setNavFocus(f); }
}
function closeModal() {
  $('#modal').classList.add('hidden');
  clearNavFocus();
  if (UI.mode === 'modal' || UI.mode === 'dead') UI.mode = UI.modalPrev && UI.modalPrev !== 'modal' && UI.modalPrev !== 'dead' ? UI.modalPrev : 'play';
}
function confirmModal(msg, yes) {
  openModal(`<h2>確認</h2><div>${msg}</div><div class="btns"><div class="btn nav gold" data-k="my" id="mYes">はい</div><div class="btn nav" data-k="mn" id="mNo">いいえ</div></div>`);
  $('#mYes').onclick = () => { closeModal(); yes(); };
  $('#mNo').onclick = () => closeModal();
}
function openHelp() { openModal(`<h2>あそびかた</h2>${HELP_HTML}<div class="btns"><div class="btn nav gold" data-k="hclose" id="mClose">閉じる</div></div>`); $('#mClose').onclick = closeModal; }
function openSettingsModal() {
  openModal(`<h2>設定</h2>${settingsHTML()}<div class="btns"><div class="btn nav gold" data-k="sclose" id="mClose">閉じる</div></div>`);
  bindSettings($('#modalInner'));
  $('#modalInner').onclick = menuClick;
  $('#mClose').onclick = e => { e.stopPropagation(); closeModal(); };
}
function openShipyard(ob) {
  const k = okey(0, idx(ob.x, ob.y));
  const od = G.objData.get(k) || { hull: 0, sail: 0, chart: 0 };
  G.objData.set(k, od);
  const row = (key, nm) => od[key] ? `<div class="row"><img src="${iconURL(key)}" style="width:28px;image-rendering:pixelated"> ${nm}：<b style="color:var(--green);font-weight:normal">納めた ✓</b></div>`
    : `<div class="row"><img src="${iconURL(key)}" style="width:28px;image-rendering:pixelated"> ${nm}：${invCount(key) ? `<div class="btn nav small gold" data-k="put${key}" data-put="${key}">納める</div>` : '<span style="color:#ff9a8a">まだない</span>'}</div>`;
  const ready = od.hull && od.sail && od.chart;
  const hasC = invCount('compass') > 0;
  openModal(`<h2>造船台</h2><div>脱出船を組み立てよう。三つの部品を納め、羅針盤を持って出航だ。</div>
    ${row('hull', '船体')}${row('sail', '帆')}${row('chart', '完全な海図')}
    <div class="row"><img src="${iconURL('compass')}" style="width:28px;image-rendering:pixelated"> 羅針盤：${hasC ? '<b style="color:var(--green);font-weight:normal">持っている ✓</b>' : '<span style="color:#ff9a8a">持っていない</span>'}</div>
    <div class="btns">${ready && hasC ? '<div class="btn nav gold big" data-k="sail" id="mSail">出航する！</div>' : ''}<div class="btn nav" data-k="sclose" id="mClose">閉じる</div></div>`);
  $('#modalInner').onclick = e => {
    const t = e.target.closest('[data-put]'); if (!t) return;
    const key = t.dataset.put;
    if (invCount(key) <= 0) return;
    removeItem(key, 1); od[key] = 1; G.flags['ship_' + key] = 1;
    sfx('place'); shake(2); checkQuests();
    openShipyard(ob);
  };
  $('#mClose').onclick = e => { e.stopPropagation(); closeModal(); };
  const ms = $('#mSail'); if (ms) ms.onclick = e => { e.stopPropagation(); closeModal(); startEnding(); };
}
function showDeath() {
  openModal(`<h2 style="color:#ff8a7a">力尽きた……</h2><div>持ち物は「遺品の袋」としてその場に残った。<br>復活地点（ベッド）で目を覚まします。</div><div class="btns"><div class="btn nav gold big" data-k="rev" id="mRev">復活する</div></div>`, 'dead');
  $('#mRev').onclick = () => { closeModal(); UI.mode = 'play'; respawn(); toast(G.lm.bag ? '遺品の袋を取り戻そう（地図に印）' : '目を覚ました'); };
}

/* ---------- フォーカス操作（キーボード・コントローラー） ---------- */
function navRoot() {
  switch (UI.mode) {
    case 'menu': case 'chest': return $('#menu');
    case 'modal': case 'dead': return $('#modal');
    case 'title': return $('#title');
    case 'dialog': return $('#dialog');
    case 'ending': return $('#modal');
  }
  return null;
}
function navEls() { const r = navRoot(); if (!r) return []; return [...r.querySelectorAll('.nav')].filter(e => e.offsetParent !== null && !e.closest('.hidden')); }
function setNavFocus(el, noScroll) {
  if (UI.focus) UI.focus.classList.remove('nav-focus');
  UI.focus = el;
  if (el) { el.classList.add('nav-focus'); UI.focusKey = el.dataset.k || null; if (!noScroll) try { el.scrollIntoView({ block: 'nearest' }); } catch (e) { } }
}
function clearNavFocus() { if (UI.focus) UI.focus.classList.remove('nav-focus'); UI.focus = null; }
function navMove(dir) {
  const els = navEls(); if (!els.length) return;
  if (!UI.focus || !els.includes(UI.focus)) { setNavFocus(els[0]); return; }
  if (UI.focus.type === 'range' && (dir === 'left' || dir === 'right')) {
    const el = UI.focus; el.value = clamp(+el.value + (dir === 'right' ? 0.05 : -0.05), 0, 1); el.dispatchEvent(new Event('input')); sfx('ui'); return;
  }
  const r = UI.focus.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  let best = null, bs = 1e9;
  for (const e of els) {
    if (e === UI.focus) continue;
    const q = e.getBoundingClientRect(), x = q.left + q.width / 2, y = q.top + q.height / 2, dx = x - cx, dy = y - cy;
    let ok, pr, se;
    if (dir === 'left') { ok = dx < -4; pr = -dx; se = Math.abs(dy); }
    else if (dir === 'right') { ok = dx > 4; pr = dx; se = Math.abs(dy); }
    else if (dir === 'up') { ok = dy < -4; pr = -dy; se = Math.abs(dx); }
    else { ok = dy > 4; pr = dy; se = Math.abs(dx); }
    if (!ok) continue;
    const sc = pr + se * 2.2;
    if (sc < bs) { bs = sc; best = e; }
  }
  if (best) { setNavFocus(best); sfx('ui'); }
}
function uiInput() {
  const pr = input.pr;
  if (UI.mode === 'dialog') {
    if (UI.dlg && UI.dlg.g.lines[UI.dlg.i].choices && UI.dlg.shown >= UI.dlg.g.lines[UI.dlg.i].text.length) {
      if (pr.nav) navMove(pr.nav);
      if (pr.a && UI.focus) UI.focus.click();
    } else if (pr.a || pr.b) advanceDialog();
    return;
  }
  if (UI.mode === 'title' && !$('#tapStart').classList.contains('hidden')) { if (pr.a || pr.start) titleTap(); return; }
  if (input.mode === 'touch' && !pr.a && !pr.b && !pr.y && !pr.start) return;
  if (pr.nav) navMove(pr.nav);
  if (pr.a && UI.focus) { if (UI.focus.type !== 'range') UI.focus.click(); }
  if (UI.mode === 'menu' || UI.mode === 'chest') {
    if (pr.b || pr.y || pr.start) closeMenu();
    if (UI.mode === 'menu' && (pr.lb || pr.rb)) {
      const i = TABS.findIndex(t => t[0] === UI.tab), n = TABS.length;
      UI.tab = TABS[(i + (pr.rb ? 1 : n - 1)) % n][0]; UI.sel = null; UI.rsel = null; UI.focusKey = 'tab' + UI.tab; sfx('ui'); renderMenu();
    }
  } else if (UI.mode === 'modal') {
    if (pr.b || pr.start) { const c = $('#mClose') || $('#mNo'); if (c) c.click(); else closeModal(); }
  }
}

/* ---------- 地図 ---------- */
const MAPCOL = ['#1d4a85', '#2c6fb2', '#4cb3c9', '#e8d29a', '#6cb848', '#3f8a34', '#2f7a3a', '#a07850', '#8a8680', '#5a5650', '#5ab8e6', '#b0aa90', '#7d5634', '#4d4241', '#ff6a1e'].map(hexRGB);
let mapImg = null, mapCtx = null, mapData = null, mapNeed = false;
function mapInit() {
  const [c, x] = mkCanvas(MAP, MAP); mapImg = c; mapCtx = x;
  mapData = x.createImageData(MAP, MAP);
  for (let i = 0; i < MM; i++) mapPix(i);
  mapNeed = true;
}
function mapPix(i) {
  const p = i * 4, d = mapData.data;
  if (!G.explored[i]) { const x = i % MAP, y = (i / MAP) | 0; const v = ((x >> 3) + (y >> 3)) % 2 ? 14 : 18; d[p] = v; d[p + 1] = v + 6; d[p + 2] = v + 20; d[p + 3] = 255; return; }
  let c = MAPCOL[G.ground[i]];
  const o = G.objS[i];
  if (o && OBJ[o].built) c = [255, 224, 128];
  else if (o && OBJ[o].tall && OBJ[o].tool === 'axe') c = shade(c, 0.78);
  else if (o === O.PILLAR || o === O.STATUE) c = [200, 196, 170];
  d[p] = c[0]; d[p + 1] = c[1]; d[p + 2] = c[2]; d[p + 3] = 255;
}
function mapDirty(x, y) { if (!mapData) return; const i = idx(x, y); if (G.explored[i]) { mapPix(i); mapNeed = true; } }
function mapAddDiscover() {
  if (!G || !P) return;
  const pt = ptile(), r = P.layer ? 7 : 11;
  for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
    if (dx * dx + dy * dy > r * r) continue;
    const x = pt.x + dx, y = pt.y + dy; if (!inb(x, y)) continue;
    const i = idx(x, y);
    if (!G.explored[i]) { G.explored[i] = 1; mapPix(i); mapNeed = true; }
  }
}
function mapHTML() {
  const disc = [];
  const L = G.lm;
  const seen = p => p && G.explored[idx(p.x, p.y)];
  if (seen(L.wreck1)) disc.push('⚓ 沈没船（南）'); if (seen(L.wreck2)) disc.push('⚓ 沈没船（深い）'); if (seen(L.sruins)) disc.push('◆ 海底遺跡');
  if (seen(L.jruins)) disc.push('■ ジャングルの遺跡'); if (seen(L.volcano)) disc.push('▲ 火山島'); if (seen(L.trench)) disc.push('● 海溝');
  if (seen(L.sandisle)) disc.push('・砂の小島'); if (seen(L.rockisle)) disc.push('・岩の小島');
  return `<div id="mapWrap"><canvas id="mapCv" width="640" height="640"></canvas><div class="legend">
  <div><i style="background:#fff"></i>現在地</div><div><i style="background:#ff4a5a"></i>復活地点</div><div><i style="background:#ffd25a"></i>目標（★）</div>${L.bag ? '<div><i style="background:#c08aff"></i>遺品の袋</div>' : ''}<div><i style="background:#ffe080"></i>建てた物</div>
  <div style="margin-top:6px;color:var(--gold)">発見した場所</div>${disc.length ? disc.map(s => `<div>${s}</div>`).join('') : '<div>まだない</div>'}
  <div style="margin-top:6px">${dayNum()}日目 ${timeStr()}</div></div></div>`;
}
function drawMapCanvas() {
  const cv = $('#mapCv'); if (!cv) return;
  if (mapNeed) { mapCtx.putImageData(mapData, 0, 0); mapNeed = false; }
  const x = cv.getContext('2d'); x.imageSmoothingEnabled = false;
  x.drawImage(mapImg, 0, 0, 640, 640);
  const blink = Math.floor(now() / 400) % 2;
  const dot = (tx, ty, col, r) => { x.fillStyle = col; x.fillRect(tx * 2 - r, ty * 2 - r, r * 2, r * 2); x.strokeStyle = '#000'; x.lineWidth = 1; x.strokeRect(tx * 2 - r, ty * 2 - r, r * 2, r * 2); };
  const L = G.lm;
  if (P.spawn) dot(P.spawn.x / 16, P.spawn.y / 16, '#ff4a5a', 4);
  if (L.shipyard) dot(L.shipyard.x, L.shipyard.y, '#ffe080', 4);
  if (L.bag) dot(L.bag.x, L.bag.y, '#c08aff', 5);
  const tq = questTarget(QUESTS[G.quest]);
  if (tq) { x.fillStyle = blink ? '#ffd25a' : '#fff4c0'; x.font = 'bold 22px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.strokeStyle = '#000'; x.lineWidth = 3; x.strokeText('★', tq.x * 2, tq.y * 2); x.fillText('★', tq.x * 2, tq.y * 2); }
  const px = P.x / 16 * 2, py = P.y / 16 * 2;
  x.save(); x.translate(px, py); x.rotate(Math.atan2(P.fy, P.fx));
  x.fillStyle = blink ? '#ffffff' : '#ffe86a'; x.strokeStyle = '#000'; x.lineWidth = 2;
  x.beginPath(); x.moveTo(9, 0); x.lineTo(-6, -6); x.lineTo(-3, 0); x.lineTo(-6, 6); x.closePath(); x.stroke(); x.fill();
  x.restore();
}

/* ---------- タイトル・開始 ---------- */
function titleShow() {
  UI.mode = 'title';
  $('#title').classList.remove('hidden');
  ['#hud', '#hotbar', '#touch'].forEach(s => $(s).classList.add('hidden'));
  const info = saveInfo();
  $('#tContinue').classList.toggle('hidden', !info);
  $('#titleInfo').textContent = info ? `セーブ：${info.day}日目　目標「${info.quest}」` : (localStorage.getItem(SAVE_KEY) ? 'セーブデータが壊れていたため読み込めませんでした' : '');
  if (!$('#titleMenu').classList.contains('hidden') && input.mode !== 'touch') setNavFocus(info ? $('#tContinue') : $('#tNew'));
}
function titleTap() {
  if (UI.mode !== 'title') return;
  audioUnlock();
  if (!$('#tapStart').classList.contains('hidden')) {
    $('#tapStart').classList.add('hidden'); $('#titleMenu').classList.remove('hidden'); sfx('uiopen');
    titleShow();
  }
}
function showLoading(on, txt) { $('#loading').classList.toggle('hidden', !on); if (txt) $('#loadText').textContent = txt; $('#loadBar i').style.width = on ? '30%' : '0'; }
function startNewGame() {
  showLoading(true, '島を生成中…'); UI.mode = 'loading';
  setTimeout(() => {
    $('#loadBar i').style.width = '70%';
    setTimeout(() => {
      const seed = (Math.random() * 1e9) | 0;
      const w = genWorld(seed);
      buildGame(w, null);
      enterPlay(true);
    }, 30);
  }, 60);
}
function loadGame() {
  const d = getSave(); if (!d) { toast('セーブデータが見つかりません', 'red'); return; }
  showLoading(true, '島へ戻っています…'); UI.mode = 'loading';
  setTimeout(() => {
    $('#loadBar i').style.width = '70%';
    setTimeout(() => {
      try { const w = genWorld(d.seed); buildGame(w, d); enterPlay(false); }
      catch (e) { console.error(e); showLoading(false); titleShow(); toast('読み込みに失敗しました', 'red'); }
    }, 30);
  }, 60);
}
function enterPlay(isNew) {
  showLoading(false);
  $('#title').classList.add('hidden');
  ['#hud', '#hotbar'].forEach(s => $(s).classList.remove('hidden'));
  $('#touch').classList.toggle('hidden', !isTouchDevice());
  UI.mode = 'play'; UI.boss = null; musicForce = null;
  clearNavFocus();
  snapCamera(); mapAddDiscover(); uiDirty(); checkQuests(); questUI(false); resize();
  if (isNew) { saveGame(true); later(() => dialog(INTRO), 500); }
  else toast(`${dayNum()}日目　おかえりなさい`, 'gold');
}
function toTitle() {
  closeMenu(true); closeModal();
  G = null; P = null; ENTS.length = 0;
  $('#tapStart').classList.add('hidden'); $('#titleMenu').classList.remove('hidden');
  titleShow();
}
const isTouchDevice = () => ('ontouchstart' in window) || navigator.maxTouchPoints > 0;

/* ---------- エンディング ---------- */
function startEnding() {
  G.flags.escaped = 1; checkQuests();
  saveGame(true);
  dialog(['……準備は整った。', '羅針盤の針が、海図に記された航路を指している。', 'ありがとう、蒼の島。――出航！'], () => {
    fadeOut(() => {
      UI.mode = 'ending'; UI.endT = 0;
      ['#hud', '#hotbar', '#touch'].forEach(s => $(s).classList.add('hidden'));
      fadeIn();
      later(showCredits, 2500);
    });
  });
}
function showCredits() {
  if (UI.mode !== 'ending') return;
  const s = G.stats;
  const lines = ['TIDEBOUND', '～ 蒼海の漂流島 ～', '', `生存日数　${dayNum()}日`, `倒した生き物　${s.kills || 0}`, `釣った魚　${s.fish || 0}`, `読んだ手紙　${G.read.length}/${BOTTLE_MSG.length}`, '', 'ミナトの手紙は、きっと誰かを救った。', '', 'made by hiro/ヒロ', 'https://github.com/h1ro223', '', 'THANK YOU FOR PLAYING!'];
  const el = document.createElement('div');
  el.id = 'credits';
  el.style.cssText = 'position:absolute;inset:0;z-index:44;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;pointer-events:none;text-shadow:0 2px 0 #000;font-size:16px;line-height:1.9';
  el.innerHTML = lines.map((l, i) => `<div style="opacity:0;transition:opacity 1s;${i === 0 ? 'font-size:30px;color:#ffe8a0' : ''}">${l || '&nbsp;'}</div>`).join('');
  $('#game').appendChild(el);
  [...el.children].forEach((c, i) => setTimeout(() => c.style.opacity = '1', 600 * i));
  setTimeout(() => {
    if (UI.mode !== 'ending') return;
    openModal(`<h2>クリアおめでとう！</h2><div>このまま島での暮らしを続けることもできます。</div><div class="btns"><div class="btn nav gold" data-k="econt" id="eCont">島での暮らしを続ける</div><div class="btn nav" data-k="etitle" id="eTitle">タイトルへ</div></div>`, 'ending');
    const done = () => { const c = $('#credits'); if (c) c.remove(); $('#modal').classList.add('hidden'); clearNavFocus(); };
    $('#eCont').onclick = () => { done(); G.ended = 'done'; UI.mode = 'play'; ['#hud', '#hotbar'].forEach(s => $(s).classList.remove('hidden')); $('#touch').classList.toggle('hidden', !isTouchDevice()); saveGame(true); musicForce = null; };
    $('#eTitle').onclick = () => { done(); G.ended = 'done'; saveGame(true); toTitle(); };
  }, 600 * lines.length + 2500);
}
function fadeOut(cb) { $('#fade').classList.add('on'); setTimeout(cb, 480); }
function fadeIn() { setTimeout(() => $('#fade').classList.remove('on'), 60); }

/* ---------- UIの初期化 ---------- */
function initUI() {
  $('#menuBody').addEventListener('click', menuClick);
  $('#menuTabs').addEventListener('click', menuClick);
  $('#menuClose').addEventListener('click', () => closeMenu());
  $('#menu').addEventListener('click', e => { if (e.target.id === 'menu') closeMenu(); });
  $('#hotbar').addEventListener('click', e => { const t = e.target.closest('[data-hot]'); if (t) selectHot(+t.dataset.hot); });
  $('#dialog').addEventListener('click', e => { const c = e.target.closest('[data-ch]'); if (c) { chooseDialog(+c.dataset.ch); return; } advanceDialog(); });
  $('#topBtns').addEventListener('click', e => { const t = e.target.closest('[data-act]'); if (!t || UI.mode !== 'play') return; audioUnlock(); openMenu(t.dataset.act === 'map' ? 'map' : 'sys'); });
  $('#title').addEventListener('click', e => { if (e.target.closest('a')) return; titleTap(); });
  $('#tNew').onclick = e => { e.stopPropagation(); audioUnlock(); if (getSave()) confirmModal('新しく始めると、今のセーブデータは上書きされます。よろしいですか？', startNewGame); else startNewGame(); };
  $('#tContinue').onclick = e => { e.stopPropagation(); audioUnlock(); loadGame(); };
  $('#tSettings').onclick = e => { e.stopPropagation(); openSettingsModal(); };
  $('#tHelp').onclick = e => { e.stopPropagation(); openHelp(); };
  drawLogo($('#logo'));
}
/* =============================================================
   描画（地形・オブジェクト・キャラ・光・天気・HUD）とメインループ
   ============================================================= */
const CAM = { x: 0, y: 0, shake: 0 };
let VW = 320, VH = 180, SCALE = 2, TIME = 0;
const cv = $('#cv'), ctx = cv.getContext('2d');
let lightCv = null, lightCtx = null;
function resize() {
  const W = window.innerWidth, H = window.innerHeight;
  SCALE = Math.max(1, Math.round(Math.min(W, H) / 225));
  VW = Math.ceil(W / SCALE); VH = Math.ceil(H / SCALE);
  cv.width = VW; cv.height = VH;
  cv.style.width = VW * SCALE + 'px'; cv.style.height = VH * SCALE + 'px';
  ctx.imageSmoothingEnabled = false;
  [lightCv, lightCtx] = mkCanvas(Math.ceil(VW / 2) + 2, Math.ceil(VH / 2) + 2);
  readSafe();
  HUDX = 4 + Math.ceil(SAFE.l / SCALE); HUDY = 4 + Math.ceil(SAFE.t / SCALE);
  const rs = document.documentElement.style;
  rs.setProperty('--hudh', ((HUDY + 46) * SCALE) + 'px');
  rs.setProperty('--hudr', ((HUDY + 16) * SCALE) + 'px');
  $('#rotateHint').classList.toggle('hidden', !(H > W && isTouchDevice() && UI.mode === 'play'));
}
const SAFE = { l: 0, r: 0, t: 0, b: 0 };
let HUDX = 4, HUDY = 4, safeProbe = null;
function readSafe() {
  if (!safeProbe) { safeProbe = document.createElement('div'); safeProbe.style.cssText = 'position:fixed;left:0;top:0;width:0;height:0;padding:env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left);visibility:hidden;pointer-events:none'; document.body.appendChild(safeProbe); }
  const cs = getComputedStyle(safeProbe);
  SAFE.t = parseFloat(cs.paddingTop) || 0; SAFE.r = parseFloat(cs.paddingRight) || 0; SAFE.b = parseFloat(cs.paddingBottom) || 0; SAFE.l = parseFloat(cs.paddingLeft) || 0;
}
function clampCam() { CAM.x = clamp(CAM.x, 0, MAP * TILE - VW); CAM.y = clamp(CAM.y, 0, MAP * TILE - VH); }
function snapCamera() { if (!P) return; CAM.x = P.x - VW / 2; CAM.y = P.y - 8 - VH / 2; clampCam(); }
function updateCamera(dt) {
  const tx = P.x - VW / 2 + P.vx * 0.3, ty = P.y - 8 - VH / 2 + P.vy * 0.3, k = 1 - Math.exp(-dt * 7);
  CAM.x = lerp(CAM.x, tx, k); CAM.y = lerp(CAM.y, ty, k); clampCam();
}

/* ---------- 地形タイル ---------- */
const CORNER_ORTH = [[0, 1], [1, 2], [2, 3], [3, 0]];
const NB = [[0, -1], [1, 0], [0, 1], [-1, 0], [1, -1], [1, 1], [-1, 1], [-1, -1]];
const nbT = new Array(8);
const land = q => !isWaterAny(q) && q !== T.CLIFF;
function drawGround(getT, tx, ty, px, py, wf, ff) {
  const g = getT(tx, ty);
  const v = (hash2(tx, ty, 7) * 4) | 0;
  ctx.drawImage(SP.tile[g][v][WATERISH.has(g) ? wf : 0], px, py);
  const pr = T_PRIO[g];
  let types = null;
  for (let d = 0; d < 8; d++) {
    const q = getT(tx + NB[d][0], ty + NB[d][1]); nbT[d] = q;
    if (q !== g && T_PRIO[q] > pr && q !== T.CLIFF) { if (!types) types = []; if (!types.includes(q)) types.push(q); }
  }
  if (types) {
    if (types.length > 1) types.sort((a, b) => T_PRIO[a] - T_PRIO[b]);
    for (const q of types) {
      const ov = SP.over[q]; if (!ov || !ov.length) continue;
      const qf = WATERISH.has(q) ? wf : 0;
      for (let d = 0; d < 4; d++) if (nbT[d] === q) ctx.drawImage(ov[d][qf], px, py);
      for (let d = 4; d < 8; d++) if (nbT[d] === q && nbT[CORNER_ORTH[d - 4][0]] !== q && nbT[CORNER_ORTH[d - 4][1]] !== q) ctx.drawImage(ov[d][qf], px, py);
    }
  }
  if (g <= T.SHALLOW) {
    for (let d = 0; d < 4; d++) if (land(nbT[d])) ctx.drawImage(SP.foam[d][ff], px, py);
    for (let d = 4; d < 8; d++) if (land(nbT[d]) && !land(nbT[CORNER_ORTH[d - 4][0]]) && !land(nbT[CORNER_ORTH[d - 4][1]])) ctx.drawImage(SP.foam[d][ff], px, py);
  }
  if (g === T.CLIFF && nbT[2] !== T.CLIFF) ctx.drawImage(SP.cliffFace, px, py + 8);
}
function drawSeabed(tx, ty, px, py) {
  const u = terAt(1, tx, ty), v = (hash2(tx, ty, 9) * 4) | 0;
  ctx.drawImage(SP.tileU[u][v], px, py);
  const pr = U_PRIO[u];
  let types = null;
  for (let d = 0; d < 8; d++) {
    const q = terAt(1, tx + NB[d][0], ty + NB[d][1]); nbT[d] = q;
    if (q !== u && U_PRIO[q] > pr) { if (!types) types = []; if (!types.includes(q)) types.push(q); }
  }
  if (types) {
    if (types.length > 1) types.sort((a, b) => U_PRIO[a] - U_PRIO[b]);
    for (const q of types) {
      const ov = SP.overU[q]; if (!ov || !ov.length) continue;
      for (let d = 0; d < 4; d++) if (nbT[d] === q) ctx.drawImage(ov[d], px, py);
      for (let d = 4; d < 8; d++) if (nbT[d] === q && nbT[CORNER_ORTH[d - 4][0]] !== q && nbT[CORNER_ORTH[d - 4][1]] !== q) ctx.drawImage(ov[d], px, py);
    }
  }
  if (u === U.WALL && nbT[2] !== U.WALL) ctx.drawImage(SP.wallFace, px, py + 8);
}

/* ---------- スプライト ---------- */
const whiteCache = new WeakMap();
function whiteOf(img) { let w = whiteCache.get(img); if (!w) { w = silhouette(img, [255, 255, 255], 1); whiteCache.set(img, w); } return w; }
function objImg(layer, tx, ty, o) {
  const vars = SP.obj[o]; if (!vars) return null;
  let vi = 0;
  if (o === O.SHIPYARD) { const od = odata(0, tx, ty); vi = od ? (od.hull ? (od.sail ? 2 : 1) : 0) : 0; }
  else if (vars.length > 1) vi = (hash2(tx, ty, 3) * vars.length) | 0;
  const fr = vars[vi];
  const f = fr.length > 1 ? Math.floor(TIME * (o === O.KELP ? 1.6 : o === O.BOTTLE ? 1.2 : 6) + tx * 0.7 + ty * 0.3) % fr.length : 0;
  return fr[f];
}
function drawObj(layer, tx, ty, o, ox, oy) {
  const img = objImg(layer, tx, ty, o); if (!img) return;
  const d = OBJ[o];
  let px = tx * 16 + 8 - img.width / 2 - ox, py = d.flat ? ty * 16 - oy : ty * 16 + 16 - img.height - oy;
  const k = okey(layer, idx(tx, ty));
  if (objShake.has(k)) px += Math.sin(TIME * 90) * 1.5;
  let fade = false;
  if (d.tall && img.height > 22 && layer === P.layer && !P.dead) {
    const sx = tx * 16 + 8 - img.width / 2, sy = ty * 16 + 16 - img.height;
    if (P.x > sx + 2 && P.x < sx + img.width - 2 && P.y - 8 > sy && P.y < ty * 16 + 12) fade = true;
  }
  if (fade) ctx.globalAlpha = 0.45;
  ctx.drawImage(img, Math.round(px), Math.round(py));
  if (fade) ctx.globalAlpha = 1;
}
function shadowAt(x, y, w) { ctx.fillStyle = 'rgba(0,0,0,0.22)'; ctx.fillRect(Math.round(x - w / 2), Math.round(y - 1), w, 2); ctx.fillRect(Math.round(x - w / 2 + 1), Math.round(y - 2), w - 2, 4); }
function drawPlayer(ox, oy) {
  if (P.dead) return;
  if (P.invul > 0 && Math.floor(TIME * 20) % 2) return;
  const set = SP.pl[maskLevel()];
  const px = Math.round(P.x - ox), py = Math.round(P.y - oy);
  if (P.layer === 1) {
    const fr = set.dive[P.dir][Math.floor(TIME * (P.moving ? 7 : 2)) % 2];
    const bob = Math.round(Math.sin(TIME * 2) * 1);
    if (P.equip.back) { ctx.fillStyle = P.equip.back.id === 'tank_l' ? '#e86a40' : '#e8c040'; const tx2 = px - P.fx * 3, ty2 = py - 8 + bob - P.fy * 3; ctx.fillRect(Math.round(tx2 - 2), Math.round(ty2 - 2), 4, 4); }
    ctx.drawImage(fr, px - fr.width / 2, py - fr.height / 2 - 7 + bob);
  } else {
    const cyc = [0, 1, 0, 2][Math.floor(P.anim) % 4];
    const fr = set[P.dir][P.moving ? cyc : 0];
    if (P.mode === 'swim') {
      const bob = Math.round(Math.sin(TIME * 3));
      ctx.drawImage(fr, 0, 0, 16, 10, px - 8, py - 12 + bob, 16, 10);
      ctx.fillStyle = 'rgba(220,245,255,0.8)';
      const w = 14 + Math.round(Math.sin(TIME * 4) * 2);
      ctx.fillRect(px - w / 2, py - 2 + bob, w, 1); ctx.fillRect(px - w / 2 + 2, py - 1 + bob, w - 4, 1);
    } else if (P.mode === 'raft') {
      const bob = Math.round(Math.sin(TIME * 2.5) * 1);
      ctx.drawImage(SP.fx.raft, px - 11, py - 12 + bob);
      ctx.drawImage(fr, px - 8, py - 18 + bob);
    } else if (P.mode === 'wade') {
      ctx.drawImage(fr, 0, 0, 16, 13, px - 8, py - 15, 16, 13);
      ctx.fillStyle = 'rgba(220,245,255,0.7)'; const w = 12 + Math.round(Math.sin(TIME * 5) * 2); ctx.fillRect(px - w / 2, py - 2, w, 1);
    } else {
      shadowAt(px, py, 10);
      ctx.drawImage(fr, px - 8, py - 16);
    }
  }
  // 持っている松明
  const h = held();
  if (h && h.id === 'torch' && P.layer === 0 && !P.swing && P.mode !== 'swim') {
    const side = P.dir === 'l' ? -1 : 1;
    ctx.drawImage(SP.obj[O.TORCH][0][Math.floor(TIME * 6) % 2], px - 8 + side * 6, py - 22);
  }
  // 道具を振る
  if (P.swing) {
    const s = P.swing, t = clamp(s.t / s.dur, 0, 1);
    const base = Math.atan2(P.fy, P.fx);
    const a = base - 1.2 + t * 2.4;
    const hx = px + Math.cos(a) * 8, hy = py - 8 + Math.sin(a) * 8;
    const ic = h ? SP.icon[h.id] : null;
    if (ic && s.tool) {
      ctx.save(); ctx.translate(Math.round(hx), Math.round(hy)); ctx.rotate(a + Math.PI / 4);
      ctx.drawImage(ic, -4, -12, 14, 14); ctx.restore();
    }
    if (t > 0.2 && t < 0.85) {
      const fi = Math.min(2, Math.floor((t - 0.2) / 0.22));
      const set2 = Math.abs(P.fx) > Math.abs(P.fy) ? (P.fx > 0 ? SP.fx.slash : SP.fx.slashL) : (P.fy > 0 ? SP.fx.slashD : SP.fx.slashU);
      const im = set2[fi], rr = s.tool && (s.tool.t === 'spear' || s.tool.t === 'harpoon') ? 12 : 6;
      ctx.drawImage(im, Math.round(px + P.fx * rr - im.width / 2), Math.round(py - 8 + P.fy * rr - im.height / 2));
    }
  }
  // 釣り糸
  if (P.fish) {
    const f = P.fish, bx = Math.round(f.bx - ox), by = Math.round(f.by - oy + (f.state === 'bite' ? 2 : Math.sin(TIME * 3)));
    ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(px + P.fx * 6 + 0.5, py - 12 + 0.5); ctx.quadraticCurveTo((px + bx) / 2, Math.min(py, by) - 10, bx + 0.5, by + 0.5); ctx.stroke();
    ctx.fillStyle = '#ff4a4a'; ctx.fillRect(bx - 1, by - 2, 3, 2); ctx.fillStyle = '#fff'; ctx.fillRect(bx - 1, by, 3, 1);
    if (f.state === 'bite') text3(ctx, '!', bx - 1, by - 12, [255, 220, 80]);
  }
}
function crSet(e) { return e.sp === 'fish' ? SP.cr.fish[e.var || 0] : SP.cr[e.sp]; }
function drawCreature(e, ox, oy) {
  const S = SPECIES[e.sp];
  let set = crSet(e);
  const f = Math.floor(e.anim * (S.ai === 'fish' ? 0.9 : 0.6)) % 2;
  if (e.sp === 'shark' && e.layer === 0) {
    const img = (e.face > 0 ? SP.cr.fin.r : SP.cr.fin.l)[f];
    ctx.drawImage(img, Math.round(e.x - img.width / 2 - ox), Math.round(e.y - img.height - oy));
    return;
  }
  let img = (e.face > 0 ? set.r : set.l)[f];
  const sea = S.env === 'sea', air = S.env === 'air';
  let px = e.x - img.width / 2 - ox, py = sea ? e.y - img.height / 2 - 6 - oy : e.y - img.height - oy;
  if (air) { const h = 10 + Math.sin(e.anim * 0.8) * 2; shadowAt(e.x - ox, e.y - oy + 10, 6); py -= h - 10; }
  else if (!sea) shadowAt(e.x - ox, e.y - oy, Math.min(20, img.width * 0.6));
  const tele = (e.st === 'tele' || e.st === 'windup' || e.st === 'pinch' || e.st === 'alert') && Math.floor(TIME * 14) % 2;
  if (e.flash > 0 || tele) img = whiteOf(img);
  if (e.sp === 'turtle' || S.ai === 'crab') { }
  ctx.drawImage(img, Math.round(px), Math.round(py));
  if (!S.boss && e.hp < e.maxhp && !S.nohit) {
    const w = 14, r = e.hp / e.maxhp;
    ctx.fillStyle = '#000'; ctx.fillRect(Math.round(e.x - ox - w / 2), Math.round(py - 4), w, 3);
    ctx.fillStyle = r > 0.5 ? '#7fe07a' : r > 0.25 ? '#ffd25a' : '#ff6b5a'; ctx.fillRect(Math.round(e.x - ox - w / 2) + 1, Math.round(py - 3), Math.max(1, Math.round((w - 2) * r)), 1);
  }
}
function drawDrop(d, ox, oy) {
  const ic = SP.icon[d.id]; if (!ic) return;
  const x = Math.round(d.x - ox), y = Math.round(d.y - oy);
  if (d.layer === 0) shadowAt(x, y, 8);
  const bob = d.layer === 0 ? (d.z > 0 ? d.z : Math.sin(TIME * 4 + d.x) * 1.5 + 1.5) : d.z;
  ctx.drawImage(ic, x - 6, Math.round(y - 13 - bob), 12, 12);
  if (Math.floor(TIME * 3 + d.x) % 7 === 0) { ctx.fillStyle = '#fff'; ctx.fillRect(x + 3, Math.round(y - 13 - bob), 1, 1); }
}
function drawProj(p, ox, oy) {
  const x = Math.round(p.x - ox), y = Math.round(p.y - oy);
  if (p.spr === 'arrow') { ctx.save(); ctx.translate(x, y); ctx.rotate(p.ang || Math.atan2(p.vy, p.vx)); ctx.drawImage(SP.fx.arrow, -5, -1); ctx.restore(); }
  else { const im = SP.fx[p.spr]; ctx.drawImage(im, x - im.width / 2, y - im.height / 2); }
}

/* ---------- ワールド描画 ---------- */
const DL = [];
function renderWorld() {
  const sh = CAM.shake > 0.05 ? CAM.shake : 0;
  const ox = Math.round(CAM.x + (sh ? rnd(-sh, sh) : 0)), oy = Math.round(CAM.y + (sh ? rnd(-sh, sh) : 0));
  const L = P.layer;
  const t0 = Math.floor(ox / 16) - 1, t1 = Math.floor((ox + VW) / 16) + 1, r0 = Math.floor(oy / 16) - 1, r1 = Math.floor((oy + VH) / 16) + 1;
  const wf = Math.floor(TIME * 3) % 4, ff = Math.floor(TIME * 2) % 2;
  const getT = (x, y) => inb(x, y) ? G.ground[y * MAP + x] : T.DEEP;
  for (let ty = r0; ty <= r1; ty++) for (let tx = t0; tx <= t1; tx++) {
    const px = tx * 16 - ox, py = ty * 16 - oy;
    if (L === 0) drawGround(getT, tx, ty, px, py, wf, ff); else drawSeabed(tx, ty, px, py);
  }
  // 平らなもの・水中の影
  const OB = L ? G.objU : G.objS;
  for (let ty = r0; ty <= r1; ty++) for (let tx = t0; tx <= t1; tx++) {
    if (!inb(tx, ty)) continue;
    const o = OB[ty * MAP + tx];
    if (o && OBJ[o].flat) drawObj(L, tx, ty, o, ox, oy);
  }
  if (L === 0) {
    ctx.globalAlpha = 0.4;
    for (const e of ENTS) {
      if (e.layer !== 1 || e.x < ox - 40 || e.x > ox + VW + 40 || e.y < oy - 40 || e.y > oy + VH + 40) continue;
      if (!isSwim(terAt(0, Math.floor(e.x / 16), Math.floor(e.y / 16)))) continue;
      const set = crSet(e); const img = (e.face > 0 ? set.sil : set.sil.map ? set.sil : set.sil)[Math.floor(e.anim * 0.6) % 2];
      if (img) ctx.drawImage(img, Math.round(e.x - img.width / 2 - ox), Math.round(e.y - img.height / 2 - oy));
    }
    ctx.globalAlpha = 1;
  }
  // 奥行き順に描く
  DL.length = 0;
  for (let ty = r0; ty <= r1 + 3; ty++) for (let tx = t0 - 1; tx <= t1 + 1; tx++) {
    if (!inb(tx, ty)) continue;
    const o = OB[ty * MAP + tx];
    if (o && !OBJ[o].flat) DL.push({ y: ty * 16 + 15, k: 0, tx, ty, o });
  }
  for (const e of ENTS) if (e.layer === L && e.x > ox - 60 && e.x < ox + VW + 60 && e.y > oy - 40 && e.y < oy + VH + 70) DL.push({ y: e.y + (SPECIES[e.sp].env === 'air' ? 30 : 0), k: 1, e });
  for (const d of DROPS) if (d.layer === L && d.x > ox - 20 && d.x < ox + VW + 20 && d.y > oy - 20 && d.y < oy + VH + 20) DL.push({ y: d.y, k: 3, d });
  DL.push({ y: P.y, k: 2 });
  DL.sort((a, b) => a.y - b.y);
  for (const it of DL) {
    if (it.k === 0) drawObj(L, it.tx, it.ty, it.o, ox, oy);
    else if (it.k === 1) drawCreature(it.e, ox, oy);
    else if (it.k === 2) drawPlayer(ox, oy);
    else drawDrop(it.d, ox, oy);
  }
  for (const p of PROJ) if (p.layer === L) drawProj(p, ox, oy);
  // パーティクル
  for (const p of PARTS) {
    if (p.layer !== L) continue;
    const x = Math.round(p.x - ox), y = Math.round(p.y - oy), a = clamp(p.life / p.max, 0, 1);
    if (p.text) {
      if (/^[\x20-\x7e]+$/.test(p.text)) text3(ctx, p.text, x - text3W(p.text) / 2, y, p.col);
      else { ctx.font = '12px "DotGothic16",sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#000'; ctx.fillText(p.text, x + 1, y + 1); ctx.fillStyle = rgbStr(p.col); ctx.fillText(p.text, x, y); }
    } else if (p.bubble) { ctx.globalAlpha = a; ctx.drawImage(SP.fx.bubble, x - 2, y - 2); ctx.globalAlpha = 1; }
    else if (p.ring) {
      const r = (1 - a) * (p.small ? 8 : 14) + 2;
      ctx.strokeStyle = `rgba(230,250,255,${a})`; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(x, y, r, r * 0.45, 0, 0, Math.PI * 2); ctx.stroke();
    } else { ctx.globalAlpha = a; ctx.fillStyle = rgbStr(p.col); ctx.fillRect(x, y, p.sz || 1, p.sz || 1); ctx.globalAlpha = 1; }
  }
  // 対象のカーソル・設置プレビュー
  if (!P.dead && UI.mode === 'play') {
    const h = held(), def = heldDef();
    if (def && def.place && P.layer === 0) {
      const ft = facingTile(), err = canPlaceAt(def.place, ft.x, ft.y);
      const img = objImg(0, ft.x, ft.y, O[def.place]);
      if (img && h.id !== 'torch') { ctx.globalAlpha = 0.45; const d = OBJ[O[def.place]]; ctx.drawImage(img, ft.x * 16 + 8 - img.width / 2 - ox, d.flat ? ft.y * 16 - oy : ft.y * 16 + 16 - img.height - oy); ctx.globalAlpha = 1; }
      ctx.strokeStyle = err ? 'rgba(255,90,90,0.9)' : 'rgba(120,255,120,0.9)'; ctx.lineWidth = 1; ctx.strokeRect(ft.x * 16 - ox + 0.5, ft.y * 16 - oy + 0.5, 15, 15);
    } else {
      const ob = findTargetObj();
      if (ob) { const b = Math.floor(TIME * 3) % 2; ctx.globalAlpha = 0.85; ctx.drawImage(SP.fx.cursor, ob.x * 16 - 1 - ox - b, ob.y * 16 - 1 - oy - b, 18 + b * 2, 18 + b * 2); ctx.globalAlpha = 1; }
    }
  }
  // 水中の効果
  if (L === 1) renderUnderwaterFX(ox, oy);
  else renderWeather(ox, oy);
  renderLighting(ox, oy);
}
function renderUnderwaterFX(ox, oy) {
  ctx.globalCompositeOperation = 'multiply';
  ctx.fillStyle = PS.uvis ? 'rgb(160,214,240)' : 'rgb(128,186,222)';
  ctx.fillRect(0, 0, VW, VH);
  ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = PS.uvis ? 'rgba(20,110,160,0.12)' : 'rgba(30,100,140,0.24)';
  ctx.fillRect(0, 0, VW, VH);
  const pt = ptile(), depth = -G.elev[idx(pt.x, pt.y)];
  const ray = clamp(0.09 - depth * 0.2, 0, 0.08) * (isNight() ? 0.3 : 1);
  if (ray > 0.005) {
    ctx.fillStyle = `rgba(220,250,255,${ray})`;
    for (let i = 0; i < 7; i++) {
      const x = ((i * 97 + TIME * 6 - ox * 0.3) % (VW + 120) + VW + 120) % (VW + 120) - 60;
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x + 18 + (i % 3) * 6, 0); ctx.lineTo(x - 30 + (i % 3) * 6, VH); ctx.lineTo(x - 52, VH); ctx.closePath(); ctx.fill();
    }
  }
  ctx.fillStyle = 'rgba(230,245,255,0.5)';
  for (let i = 0; i < 46; i++) {
    const sx = (hash2(i, 1, 5) * (VW + 40) - (ox * 0.6) % (VW + 40) + VW + 40) % (VW + 40) - 20;
    const sy = (hash2(i, 2, 5) * (VH + 40) + TIME * (3 + hash2(i, 3, 5) * 5) - (oy * 0.6) % (VH + 40) + VH + 40) % (VH + 40) - 20;
    ctx.fillRect(Math.round(sx), Math.round(sy), 1, 1);
  }
}
let lightningT = 8;
function renderWeather(ox, oy) {
  const w = G.weather.type;
  if (w === 'clear') return;
  const n = w === 'storm' ? 160 : 90;
  ctx.strokeStyle = w === 'storm' ? 'rgba(190,210,240,0.55)' : 'rgba(190,215,245,0.45)'; ctx.lineWidth = 1;
  ctx.beginPath();
  for (let i = 0; i < n; i++) {
    const sp = 260 + hash2(i, 9, 1) * 120;
    const x = ((hash2(i, 7, 1) * (VW + 60) - TIME * sp * 0.35 - ox) % (VW + 60) + VW + 60) % (VW + 60) - 30;
    const y = ((hash2(i, 8, 1) * (VH + 60) + TIME * sp - oy) % (VH + 60) + VH + 60) % (VH + 60) - 30;
    ctx.moveTo(Math.round(x) + 0.5, Math.round(y)); ctx.lineTo(Math.round(x - 2) + 0.5, Math.round(y + 6));
  }
  ctx.stroke();
}
function renderLighting(ox, oy) {
  let dark = darknessLevel(), col = [8, 12, 36];
  if (P.layer === 1) {
    const pt = ptile(), depth = -G.elev[idx(pt.x, pt.y)];
    dark = Math.max(dark * 0.85, clamp(0.04 + depth * 1.2, 0.04, 0.88));
    if (terAt(1, pt.x, pt.y) === U.TRENCH) dark = Math.max(dark, 0.94);
    col = [0, 14, 34];
  }
  const boss = UI.boss && !UI.boss.dead && UI.boss.dark > 0;
  if (boss) dark = 0.985;
  const tt = tod() / 60;
  if (P.layer === 0 && ((tt > 16.5 && tt < 19.5) || (tt > 4.5 && tt < 7.5))) {
    const a = tt > 12 ? Math.sin((tt - 16.5) / 3 * Math.PI) : Math.sin((tt - 4.5) / 3 * Math.PI);
    ctx.fillStyle = `rgba(255,120,40,${0.13 * a})`; ctx.fillRect(0, 0, VW, VH);
  }
  if (dark < 0.02) return;
  const lc = lightCtx, lw = lightCv.width, lh = lightCv.height;
  lc.globalCompositeOperation = 'source-over';
  lc.clearRect(0, 0, lw, lh);
  lc.fillStyle = rgbStr(col, dark); lc.fillRect(0, 0, lw, lh);
  lc.globalCompositeOperation = 'destination-out';
  const light = (x, y, r, inten = 1) => {
    const cx = (x - ox) / 2, cy = (y - oy) / 2, rr = r / 2;
    if (cx < -rr || cy < -rr || cx > lw + rr || cy > lh + rr) return;
    for (let i = 0; i < 4; i++) {
      lc.fillStyle = `rgba(0,0,0,${0.25 * inten})`;
      lc.beginPath(); lc.arc(cx, cy, rr * (1 - i * 0.2), 0, Math.PI * 2); lc.fill();
    }
  };
  if (!P.dead) {
    light(P.x, P.y - 8, boss ? 18 : 30, 0.8);
    let pl = PS.light;
    const h = held();
    if (h && h.id === 'torch' && P.layer === 0 && P.mode !== 'swim') pl = Math.max(pl, ITEMS.torch.light);
    if (pl) light(P.x, P.y - 8, pl * (1 + Math.sin(TIME * 9) * 0.02), 1);
  }
  const L = P.layer, OB = L ? G.objU : G.objS;
  const t0 = Math.floor(ox / 16) - 5, t1 = Math.floor((ox + VW) / 16) + 5, r0 = Math.floor(oy / 16) - 5, r1 = Math.floor((oy + VH) / 16) + 5;
  if (!boss) for (let ty = r0; ty <= r1; ty++) for (let tx = t0; tx <= t1; tx++) {
    if (!inb(tx, ty)) continue;
    const o = OB[ty * MAP + tx];
    if (o && OBJ[o].light) { const fl = o === O.CAMPFIRE || o === O.TORCH ? 1 + Math.sin(TIME * 11 + tx) * 0.05 : 1; light(tx * 16 + 8, ty * 16 + 8, OBJ[o].light * fl, 1); }
    if (L === 0 && G.ground[ty * MAP + tx] === T.LAVA) light(tx * 16 + 8, ty * 16 + 8, 26, 0.7);
  }
  for (const e of ENTS) {
    if (e.layer !== L) continue;
    if (e.sp === 'jelly') light(e.x, e.y - 6, 22, 0.7);
    else if (SPECIES[e.sp].light) { const lx = e.x + e.face * (e.sp === 'boss' ? 34 : 8), ly = e.y - (e.sp === 'boss' ? 30 : 10); light(lx, ly, SPECIES[e.sp].light * (1 + Math.sin(TIME * 5) * 0.1), 1); }
  }
  for (const p of PROJ) if (p.layer === L && p.light) light(p.x, p.y, p.light, 0.9);
  ctx.drawImage(lightCv, 0, 0, lw * 2, lh * 2);
}

/* ---------- HUD ---------- */
function bar(x, y, icon, v, max, col, w = 44) {
  ctx.drawImage(icon, x, y);
  ctx.fillStyle = '#0c0a14'; ctx.fillRect(x + 11, y + 2, w + 2, 6);
  ctx.fillStyle = '#2a2a3a'; ctx.fillRect(x + 12, y + 3, w, 4);
  const f = clamp(v / max, 0, 1), fw = Math.round(w * f);
  ctx.fillStyle = col; ctx.fillRect(x + 12, y + 3, fw, 4);
  ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fillRect(x + 12, y + 3, fw, 1);
  if (f < 0.25 && Math.floor(TIME * 4) % 2) { ctx.fillStyle = 'rgba(255,80,80,0.5)'; ctx.fillRect(x + 11, y + 2, w + 2, 6); }
}
function renderHUD() {
  const x0 = HUDX, y0 = HUDY;
  ctx.fillStyle = 'rgba(8,16,30,0.45)'; ctx.fillRect(x0 - 2, y0 - 2, 62, 46);
  bar(x0, y0, SP.fx.hHeart, P.hp, PS.hpmax, P.poison > 0 ? '#8ae04a' : '#ff4a5a');
  bar(x0, y0 + 11, SP.fx.hFood, P.hunger, 100, '#e8903a');
  bar(x0, y0 + 22, SP.fx.hWater, P.thirst, 100, '#4ab0f0');
  bar(x0, y0 + 33, SP.fx.hStam, P.stam, 100, '#ffd84a');
  if (P.poison > 0) ctx.drawImage(SP.fx.hPoison, x0 + 62, y0);
  // 酸素の泡（頭の上）
  if (!P.dead && (P.layer === 1 || P.o2 < PS.o2max - 0.5)) {
    const n = 10, f = P.o2 / PS.o2max;
    const px = Math.round(P.x - CAM.x) - 25, py = Math.round(P.y - CAM.y) - (P.layer ? 34 : 30);
    for (let i = 0; i < n; i++) ctx.drawImage(f * n > i ? SP.fx.bubble : SP.fx.bubbleE, px + i * 5, py);
  }
  // 時刻
  const tstr = timeStr(), dstr = 'DAY ' + dayNum();
  const rw = Math.max(text3W(dstr), text3W(tstr)) + 14;
  const rx = VW - rw - 4 - Math.ceil(SAFE.r / SCALE), ry = HUDY - 2;
  ctx.fillStyle = 'rgba(8,16,30,0.45)'; ctx.fillRect(rx - 2, ry - 2, rw + 4, 16);
  ctx.drawImage(isNight() ? SP.fx.moon : SP.fx.sun, rx, ry);
  text3(ctx, dstr, rx + 12, ry, [255, 236, 170]);
  text3(ctx, tstr, rx + 12, ry + 7, [220, 230, 255]);
  if (G.weather.type !== 'clear') ctx.drawImage(SP.fx.rain, rx - 12, ry);
  // ボス
  const b = UI.boss;
  if (b && !b.dead && b.aggro) {
    const w = Math.min(160, VW - 80), bx = Math.round((VW - w) / 2), by = VH - Math.ceil((70 + SAFE.b) / SCALE) - 6;
    ctx.fillStyle = '#0c0a14'; ctx.fillRect(bx - 1, by - 1, w + 2, 6);
    ctx.fillStyle = '#3a1a2a'; ctx.fillRect(bx, by, w, 4);
    ctx.fillStyle = '#ff4a6a'; ctx.fillRect(bx, by, Math.round(w * b.hp / b.maxhp), 4);
    ctx.font = '12px "DotGothic16",sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#000'; ctx.fillText(SPECIES[b.sp].n, VW / 2 + 1, by - 3); ctx.fillStyle = '#ffd0d8'; ctx.fillText(SPECIES[b.sp].n, VW / 2, by - 4);
  }
  // 目標の方向
  const tq = questTarget(QUESTS[G.quest]);
  if (tq && !P.dead) {
    const tx = tq.x * 16 + 8, ty = tq.y * 16 + 8, dx = tx - P.x, dy = ty - P.y, dist = Math.hypot(dx, dy);
    if (dist > 140) {
      const a = Math.atan2(dy, dx), cx = VW / 2, cy = VH / 2, R = Math.min(VW, VH) / 2 - 22;
      const ax = cx + Math.cos(a) * R, ay = cy + Math.sin(a) * R;
      ctx.save(); ctx.translate(Math.round(ax), Math.round(ay)); ctx.rotate(a);
      ctx.fillStyle = Math.floor(TIME * 3) % 2 ? '#ffd25a' : '#fff0b0'; ctx.strokeStyle = '#3a2a00'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(-4, -4); ctx.lineTo(-2, 0); ctx.lineTo(-4, 4); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.restore();
      text3(ctx, Math.round(dist / 16) + 'M', Math.round(ax) - 6, Math.round(ay) + 6, [255, 236, 170]);
    }
  }
  if (UI.saveT > 0) text3(ctx, 'SAVE', rx + 12, ry + 15, [255, 236, 170]);
  if (UI.flash > 0) { ctx.fillStyle = `rgba(255,40,40,${UI.flash * 0.5})`; ctx.fillRect(0, 0, VW, VH); }
  if (UI.lightning > 0) { ctx.fillStyle = `rgba(255,255,255,${UI.lightning})`; ctx.fillRect(0, 0, VW, VH); }
}

/* ---------- タイトル・エンディングの背景 ---------- */
let titleMap = null;
function makeTitleMap() {
  const W = 72, H = 44, m = new Uint8Array(W * H), objs = [];
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const dx = (x - 36) / 16, dy = (y - 30) / 8, d = Math.sqrt(dx * dx + dy * dy) + (fbm(x / 6, y / 6, 3, 3) - 0.5) * 0.6;
    const dx2 = (x - 12) / 6, dy2 = (y - 14) / 4, d2b = Math.sqrt(dx2 * dx2 + dy2 * dy2) + (fbm(x / 5, y / 5, 9, 2) - 0.5) * 0.5;
    const e = Math.min(d, d2b + 0.2);
    m[y * W + x] = e < 0.55 ? T.GRASS : e < 0.85 ? T.SAND : e < 1.05 ? T.SHALLOW : e < 1.6 ? T.OCEAN : T.DEEP;
    if (m[y * W + x] === T.SAND && hash2(x, y, 4) < 0.12) objs.push([x, y, O.PALM]);
    if (m[y * W + x] === T.GRASS && hash2(x, y, 5) < 0.18) objs.push([x, y, O.TREE]);
  }
  titleMap = { W, H, m, objs };
}
function renderTitleBG() {
  if (!titleMap) makeTitleMap();
  const M = titleMap;
  const ox = Math.round((TIME * 6) % (M.W * 16)), oy = Math.max(0, (M.H * 16 - VH) / 2 + Math.sin(TIME * 0.2) * 10) | 0;
  const getT = (x, y) => { x = ((x % M.W) + M.W) % M.W; if (y < 0 || y >= M.H) return T.DEEP; return M.m[y * M.W + x]; };
  const wf = Math.floor(TIME * 3) % 4, ff = Math.floor(TIME * 2) % 2;
  const t0 = Math.floor(ox / 16) - 1, t1 = Math.floor((ox + VW) / 16) + 1, r0 = Math.floor(oy / 16) - 1, r1 = Math.floor((oy + VH) / 16) + 1;
  for (let ty = r0; ty <= r1; ty++) for (let tx = t0; tx <= t1; tx++) drawGround(getT, tx, ty, tx * 16 - ox, ty * 16 - oy, wf, ff);
  const list = [];
  for (const [x, y, o] of M.objs) for (const k of [-1, 0, 1]) { const wx = x * 16 + k * M.W * 16; if (wx > ox - 40 && wx < ox + VW + 40) list.push([wx, y, o]); }
  list.sort((a, b) => a[1] - b[1]);
  for (const [wx, y, o] of list) { const img = SP.obj[o][(hash2(wx, y, 3) * SP.obj[o].length) | 0][0]; ctx.drawImage(img, Math.round(wx + 8 - img.width / 2 - ox), y * 16 + 16 - img.height - oy); }
  ctx.fillStyle = 'rgba(4,10,24,0.25)'; ctx.fillRect(0, 0, VW, VH);
}
function renderEnding() {
  UI.endT += 1 / 60;
  const t = UI.endT;
  const g = ctx.createLinearGradient(0, 0, 0, VH * 0.5);
  g.addColorStop(0, '#2a1a4a'); g.addColorStop(0.6, '#e8705a'); g.addColorStop(1, '#ffc070');
  ctx.fillStyle = g; ctx.fillRect(0, 0, VW, VH * 0.5);
  ctx.fillStyle = '#fff0a0'; ctx.beginPath(); ctx.arc(VW * 0.7, VH * 0.48, 18, Math.PI, 0); ctx.fill();
  const wf = Math.floor(TIME * 3) % 4;
  for (let y = Math.floor(VH * 0.5 / 16) * 16; y < VH + 16; y += 16) for (let x = -16; x < VW + 16; x += 16) ctx.drawImage(SP.tile[T.OCEAN][((x / 16 + y / 16) & 3)][wf], x - ((t * 20) % 16), y - (VH * 0.5) % 16 + 0);
  ctx.fillStyle = 'rgba(255,160,80,0.18)'; ctx.fillRect(0, VH * 0.5, VW, VH * 0.5);
  ctx.fillStyle = 'rgba(255,240,180,0.5)';
  for (let i = 0; i < 12; i++) ctx.fillRect(VW * 0.7 - 20 + Math.sin(t * 2 + i) * 14, VH * 0.5 + 4 + i * 5, 40 - i * 2, 1);
  const ix = VW * 0.15 - t * 4;
  ctx.fillStyle = '#2a4a3a'; ctx.beginPath(); ctx.ellipse(ix, VH * 0.5, 60, 10, 0, Math.PI, 0); ctx.fill();
  ctx.fillStyle = '#1e3a2e'; ctx.beginPath(); ctx.ellipse(ix + 10, VH * 0.5 - 6, 26, 12, 0, Math.PI, 0); ctx.fill();
  const sx = VW * 0.42 + Math.sin(t * 0.3) * 6, sy = VH * 0.62 + Math.sin(t * 1.6) * 2;
  ctx.drawImage(SP.fx.ship, Math.round(sx - 24), Math.round(sy - 36));
  ctx.fillStyle = 'rgba(255,255,255,0.6)';
  for (let i = 0; i < 6; i++) ctx.fillRect(Math.round(sx - 24 - i * 8 - (t * 30) % 8), Math.round(sy + 1 + (i % 2)), 5, 1);
  if (G && G.flags.parrot) { const pi = SP.cr.parrot.r[Math.floor(t * 6) % 2]; ctx.drawImage(pi, Math.round(sx + 10), Math.round(sy - 46 + Math.sin(t * 3) * 3)); }
}

/* ---------- メインループ ---------- */
let lastTs = 0, discT = 0, ctxT = 0, crackT = 0;
function updateCtxLabel() {
  if (!P) return;
  const c = UI.mode === 'play' ? getCtx() : null;
  const lbl = c ? c.lbl : '';
  const generic = !lbl || lbl === '振る' || lbl === 'パンチ' || lbl === '攻撃';
  $('#lblA').textContent = lbl ? (lbl.length > 6 ? lbl.slice(0, 6) : lbl) : '使う';
  $('#tbA').classList.toggle('ctx', !generic);
  const xl = P.layer ? '浮上' : P.raft ? '降りる' : P.mode === 'swim' ? '潜る' : '';
  $('#lblX').textContent = xl || '—';
  $('#tbX').style.opacity = xl ? '1' : '0.45';
  $('#tbX').classList.toggle('ctx', xl === '潜る' || (xl === '浮上' && P.o2 < PS.o2max * 0.3));
  const kbl = input.mode === 'pad' ? (SET.swap ? 'Ⓑ' : 'Ⓐ') : '[J]';
  const xk = input.mode === 'pad' ? (SET.swap ? 'Ⓨ' : 'Ⓧ') : '[L]';
  let s = '';
  if (input.mode !== 'touch' && UI.mode === 'play') { if (!generic) s = `${kbl} ${lbl}`; if (xl) s += (s ? '　' : '') + `${xk} ${xl}`; }
  $('#ctxLabel').textContent = s;
}
function gameInput() {
  const pr = input.pr;
  if (!P || P.dead) return;
  if (pr.a) doAction();
  else if (input.a && !P.swing && P.cd <= 0 && !P.fish) { const c = getCtx(); if (c && c.fn === swing) swing(); }
  if (pr.x) xAction();
  if (pr.y) { openMenu('inv'); return; }
  if (pr.start) { openMenu('sys'); return; }
  if (pr.back) { openMenu('map'); return; }
  if (pr.lb) selectHot((P.sel + HOT_N - 1) % HOT_N);
  if (pr.rb) selectHot((P.sel + 1) % HOT_N);
}
function update(dt) {
  updateMusic(); updateAmbient(dt);
  if (UI.mode === 'dialog') updateDialog(dt);
  if (UI.mode === 'play') gameInput(); else uiInput();
  if (UI.mode === 'play' && G && P) {
    if (UI.hitstop > 0) { UI.hitstop -= dt; dt *= 0.15; }
    tickWorld(dt);
    updatePlayer(dt);
    for (let i = 0; i < ENTS.length; i++) if (!ENTS[i].dead) updateCreature(ENTS[i], dt);
    spawnTick(dt);
    updateProj(dt); updateDrops(dt); updateParts(dt);
    updateCamera(dt);
    for (const [k, v] of objShake) { const nv = v - dt; if (nv <= 0) objShake.delete(k); else objShake.set(k, nv); }
    discT -= dt; if (discT <= 0) { discT = 0.5; mapAddDiscover(); }
    if (G.weather.type === 'storm' && P.layer === 0) { lightningT -= dt; if (lightningT <= 0) { lightningT = rnd(6, 15); UI.lightning = 0.7; later(() => sfx('thunder'), 300 + Math.random() * 900); } }
    crackT -= dt;
    if (crackT <= 0) { crackT = 0.25; const pt = ptile(); let near = false; for (let dy = -3; dy <= 3 && !near; dy++) for (let dx = -3; dx <= 3; dx++) if (objAt(0, pt.x + dx, pt.y + dy) === O.CAMPFIRE) { near = true; break; } if (near && P.layer === 0 && Math.random() < 0.6) sfx('crackle'); }
  }
  ctxT -= dt; if (ctxT <= 0) { ctxT = 0.12; updateCtxLabel(); }
  if (UI.flash > 0) UI.flash = Math.max(0, UI.flash - dt * 1.5);
  if (UI.lightning > 0) UI.lightning = Math.max(0, UI.lightning - dt * 2);
  if (UI.saveT > 0) UI.saveT -= dt;
  if (CAM.shake > 0) CAM.shake = Math.max(0, CAM.shake - dt * 14);
  if (UI.dirty && P) { UI.dirty = false; renderHotbar(); }
}
function render() {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.imageSmoothingEnabled = false;
  if (UI.mode === 'title' || UI.mode === 'loading' || !G || !P) { renderTitleBG(); return; }
  if (UI.mode === 'ending') { renderEnding(); return; }
  renderWorld();
  renderHUD();
}
function frame(ts) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, Math.max(0, (ts - lastTs) / 1000)) || 0.016;
  lastTs = ts; TIME += dt;
  try {
    pollInput();
    update(dt);
    render();
  } catch (e) { console.error(e); }
}
function boot() {
  loadSettings();
  buildArt();
  resize();
  window.addEventListener('resize', resize);
  window.addEventListener('orientationchange', () => setTimeout(resize, 250));
  initTouch(); initUI();
  if (!isTouchDevice()) document.body.classList.add('kb'); else input.mode = 'touch';
  cv.addEventListener('mousedown', e => {
    if (e.button !== 0 || UI.mode !== 'play' || !P || P.dead || input.mode === 'touch') return;
    audioUnlock();
    const wx = CAM.x + e.clientX / SCALE, wy = CAM.y + e.clientY / SCALE;
    const dx = wx - P.x, dy = wy - (P.y - 6), d = Math.hypot(dx, dy);
    if (d > 2) { P.fx = dx / d; P.fy = dy / d; P.dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'r' : 'l') : (dy > 0 ? 'd' : 'u'); }
    doAction();
  });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { if (G && P && (UI.mode === 'play' || UI.mode === 'menu')) saveGame(true); if (AU.ctx) AU.ctx.suspend(); }
    else if (AU.ctx) AU.ctx.resume();
  });
  window.addEventListener('pagehide', () => { if (G && P && !P.dead && UI.mode !== 'title') saveGame(true); });
  titleShow();
  requestAnimationFrame(frame);
}
boot();
