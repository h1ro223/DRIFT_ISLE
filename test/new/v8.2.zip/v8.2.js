'use strict';
/* =========================================================
   売倍アイランド（旧：無人島サバイバル債務録）
   2Dドット / シングルプレイ / セーブ：localStorage
   ========================================================= */
(function () {

/* ---------- 1. 基本設定 ---------- */
const CONFIG = {
  dayLength: 300,   // 1日の長さ（秒）※v6.2：5分（昼3分30秒＋夜1分30秒）。タイトルのデバッグで変えられる（settings.dayDay・dayNight）
  dayPart: 210,     // 6:00〜20:00 の長さ（秒）。残りが夜（v6.2：90秒）
  dropLife: 1,      // v6.2：地面に出た物が消えるまでの日数（ゲーム内の丸1日。6:00の日付変更ではなく、出た時からの経過）
  rainCatchMax: 2,  // v6.2：雨の日に器へ雨水がたまる最大の回数（1日あたり。時刻はランダム）
  saveKey: 'mujintou-saimu-save-v1',      // v1の旧セーブ（起動時にスロット1へ移行）
  slotKey: 'mujintou-saimu-save-v2-s',    // + スロット番号
  slots: 3,
  settingsKey: 'mujintou-saimu-settings-v1',
  saveVersion: 18,  // v8c：天気は1日2回（wHalf）・地上に洞窟の魔物が出る日（surfD）・弓と矢。v8b：炉の燃料（furnace.fuel）・採掘機の2×2・自動伐採機・家の中の広さ。v8a：マップの種（seed）・チュートリアルの手順を2つ追加。 v7c：木造の家（室内のマップ house）。v7b：自動採掘機・銅鉱脈・石炭鉱脈・借金の記録（debtLog）。v7a：幸福（happy）・1日の出現数（daily）。v6.2：1日の長さの記録（tdef）・落とし物の消える日時・雨水の予定。v4：アイテムバー8枠・持ち物8枠／たいまつの耐久。v6a：覚醒・洞窟の地図。v6b：左手・防具。v6c：広い島（古いセーブは今までの島のまま）。v6.1d：広い洞窟（古いセーブは今までの洞窟のまま）
  dropLock: 0,      // 捨てた物を拾えるようになるまでの秒数（v3で廃止＝すぐ拾える）
  placeRange: 5,    // 設置できる範囲（マス）
  hotSize: 8,       // アイテムバーの枠数（持ち物の枠のうち先頭8つ）
  slotsBase: 16,    // 最初の持ち物の枠数（アイテムバー8＋持ち物8）
  slotsUp: 8,       // 大きなかばん・運搬カートで増える枠数（それぞれ+8）
  stackMax: 5,      // 1枠に入る数（道具・設置物は1。たいまつは5本）
  awakeSec: 120,    // v6a：プロテインの「覚醒」の長さ（秒）。重ねて飲んでもこれを超えない
  happySec: 300,    // v7a：黄金の焼き肉の「幸福」の長さ（秒）。食べ直すと最初に戻る（重ねても延びない）
  goldRabbit: { p: 0.01, perDay: 1 },   // v7a：ウサギが出る時に金のウサギになる確率・1日の上限
  bee: { p: 0.05, perDay: 3 },
  surface: { from: 4, p: 0.34 },   // v8c：4日目から、毎日34%（だいたい3日に1回）で、その夜は洞窟の魔物（サソリ・コウモリ）が地上にも出る
  // v7b：自動採掘機（every秒ごとに1回。石は必ず1個、lootはそれぞれ独立に抽選。燃料は木炭1個でfuelPer回・最大fuelMax個。保管はcap個まで、空きがstopFree個未満で止まる）
  bow: { r: 80, cd: 0.7, dmg: [9, 13], speed: 240 },   // v8c：弓。射程＝自分を中心に半径5マスの円、撃つ間隔0.7秒、ダメージ9〜13、矢の速さ
  furnaceFuel: { max: 10, branch: 2, charcoal: 8, coal: 10 },   // v8b：炉の燃料ゲージ（最大10。1回の加工で1減る）と、燃料1個で増える量
  lumber: { every: 8, cap: 60, wood: 3, branch: 1 },   // v8b：自動伐採機（8秒ごとに範囲の木を1本切る。保管60個まで、いっぱいになると止まる）
  miner: { every: 20, fuelPer: 10, fuelCoal: 15, fuelMax: 10, cap: 50, stopFree: 5, loot: [['ironore', 0.35], ['copperore', 0.18], ['goldore', 0.08], ['crystal', 0.05]] },
  debtLogMax: 400,   // v7b：借金グラフに残す点の数
  house: { buildH: 12, drain: 0.5 },   // v7c：木造の家（建設はゲーム内の時計で12時間。家の中は空腹・渇きの減りが半分）          // v7a：木を切り始めた時に蜂が出る確率・1日の上限（チュートリアル中とデモプレイは出ない）
  // v6.1a：プレイヤーの攻撃。ダメージ＝round((基礎攻撃力 + 武器補正 + 乱数) × 会心倍率)
  atk: { base: 6, handRng: 1, crit: 0.05, critMul: 1.5 },
  // v6.1c：毒（every秒ごとにdmg減る・sec秒で治る。重ねて受けてもsec秒まで。毒では体力1より下がらない）
  poison: { sec: 10, every: 2, dmg: 3 },
  // 空腹・渇きの減り（1秒あたり）。ノーマルは遊びやすく、ハードは以前の速さ
  survival: { normal: { h: 0.25, t: 0.32, cave: 1.1, hot: 1.2 }, hard: { h: 0.385, t: 0.5, cave: 1.2, hot: 1.35 } },
  islandSeed: 20261027,
  baseCap: 30,
  queueMax: 30,
  autosaveSec: 60,
  bgm: 'Game.mp3',  // BGM（ずっとループ）。versions.json と同じフォルダに置く
};
const TILE = 16;
const PRESETS = [
  { id: 'easy',   label: 'かんたん',   debt: 3000, days: 12, rate: 1 },
  { id: 'normal', label: 'ふつう',     debt: 5000, days: 10, rate: 2 },
  { id: 'hard',   label: 'むずかしい', debt: 8000, days: 9,  rate: 3 },
];
const LIMITS = { debt: [1000, 20000, 500], days: [5, 30, 1], rate: [0, 5, 0.5] };
// デモプレイの契約（free：返済期限・締め日なし）。数値はここで変更できます
const DEMO = { debt: 1000, days: 99, rate: 0, free: true };

/* ---------- 2. ユーティリティ ---------- */
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const lerp = (a, b, t) => a + (b - a) * t;
const rnd = (a, b) => a + Math.random() * (b - a);
const rndi = (a, b) => Math.floor(a + Math.random() * (b - a + 1));
const chance = p => Math.random() < p;
const fmt$ = n => '$' + Math.round(n).toLocaleString('en-US');
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function hash2(x, y, s) { let h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(s | 0, 1442695041); h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16; return (h >>> 0) / 4294967296; }
function vnoise(x, y, s) { const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi; const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf); const a = hash2(xi, yi, s), b = hash2(xi + 1, yi, s), c = hash2(xi, yi + 1, s), d = hash2(xi + 1, yi + 1, s); return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v; }
const hexCache = {};
function hexRgb(h) { if (hexCache[h]) return hexCache[h]; const n = parseInt(h.slice(1), 16); return (hexCache[h] = [(n >> 16) & 255, (n >> 8) & 255, n & 255]); }

/* ---------- 3. タイル ---------- */
const T = { DEEP: 0, SHALLOW: 1, SAND: 2, GRASS: 3, FOREST: 4, ROCK: 5, SPRING: 6, PIER: 7, PATH: 8, CFLOOR: 9, CWALL: 10, CLIFF: 11, LEDGE: 12, WFLOOR: 13, WWALL: 14 };   // v7c：WFLOOR・WWALL＝木造の家の床と壁   // v6c：CLIFF＝崖の壁（縄梯子を掛けられる）、LEDGE＝台地のふち
const WALK = [false, false, true, true, true, true, false, true, true, true, false, false, false, true, false];
const isWater = v => v === T.DEEP || v === T.SHALLOW;
const isLandT = v => v === T.SAND || v === T.GRASS || v === T.FOREST || v === T.ROCK || v === T.PATH;
const DIRV = [[0, 1], [0, -1], [-1, 0], [1, 0]]; // 下・上・左・右
// v8d：8方向（0下 1上 2左 3右 4左下 5右下 6左上 7右上）。player.dir（4方向）は拾う・切る・掘るの向き、dir8() は絵と攻撃の向き
const D8 = [[0, 1], [0, -1], [-1, 0], [1, 0], [-0.7071, 0.7071], [0.7071, 0.7071], [-0.7071, -0.7071], [0.7071, -0.7071]];
const D8_OF = [3, 5, 0, 4, 2, 6, 1, 7];   // 角度（右から時計回りに45度ずつ）→ 向き
function setFace8(mx, my) {
  const a = Math.atan2(my, mx);
  if (player.d8 != null && player.d8dir === player.dir) { if (Math.abs(angDiff(a, Math.atan2(D8[player.d8][1], D8[player.d8][0]))) < 0.5) return; }   // スティックが境目でも絵がちらつかないように
  player.d8 = D8_OF[((Math.round(a / (Math.PI / 4)) % 8) + 8) % 8]; player.d8dir = player.dir;
}
function dir8() { return player.d8 != null && player.d8dir === player.dir ? player.d8 : player.dir; }

/* ---------- 4. データ ---------- */
// c: 価格帯（1=日用品 2=中級 3=希少 4=財宝）
const ITEMS = {
  stone:     { n: '石', p: 5, c: 1, d: 'どこにでもある石。道具や設備の材料。' },
  branch:    { n: '木の枝', p: 5, c: 1, d: '燃料や簡単な道具に使える。' },
  fiber:     { n: '繊維', p: 4, c: 1, d: '草から取れる。ロープや帆布の材料。' },
  wood:      { n: '木材', p: 10, c: 1, d: '道具や建築に使う。作業台で板材に加工できる。' },
  driftwood: { n: '流木', p: 12, c: 1, d: '浜辺に流れ着いた木。作業台で木材に加工できる。' },
  plank:     { n: '板材', p: 14, c: 1, d: '木材を加工した板。木材より高く売れる。' },
  rope:      { n: 'ロープ', p: 14, c: 1, d: '繊維をより合わせた丈夫なひも。' },
  arrow:     { n: '矢', p: 3, c: 1, d: '弓で撃つ矢。1本ずつ使い切り。作業台で作れる。', stack: 20 },   // v8c：1枠に20本
  coconut:   { n: 'ココナッツ', p: 30, c: 2, d: '売れば現金。飲むと渇きが少し回復する。', food: { h: 0, t: 15 } },   // v6a：空腹の回復をなくし、渇きだけに
  berry:     { n: 'ベリー', p: 8, c: 1, d: '甘酸っぱい木の実。少しお腹が満たされる。', food: { h: 6, t: 4 } },
  bowl:      { n: '木の器', p: 6, c: 1, d: '泉で水を汲める。雨の日に外にいると雨水がたまる。' },
  rawwater:  { n: '泉の水（生水）', p: 2, c: 1, d: '汲んだままの水。焚き火で15秒ろ過すると、きれいな水になる。そのまま飲むとお腹を壊すかも。', food: { h: 0, t: 8, raw: 1, sickP: 0.45 }, ret: 'bowl', noQuick: 1 },   // v6.2：渇き+12→+8・お腹を壊す確率25%→45%・飲むのに0.8秒
  cleanwater:{ n: 'きれいな水', p: 10, c: 1, d: 'ろ過した安全な水。飲むと渇きが30回復する（器は手元に残る）。', food: { h: 0, t: 30 }, ret: 'bowl' },
  fish:      { n: 'アジ', p: 22, c: 2, d: 'よく釣れる魚。焚き火で焼くと焼きアジになる。生だとお腹を壊すかも。', food: { h: 12, t: 0, raw: 1 } },
  bigfish:   { n: 'タイ', p: 65, c: 3, d: '立派なタイ。高く売れる。焼くと焼きタイになり、さらに高く売れる。', food: { h: 18, t: 0, raw: 1 } },
  grilled:   { n: '焼き魚', p: 38, c: 2, d: '以前のバージョンで焼いた魚。空腹が大きく回復する。', food: { h: 35, t: 0 } },
  sardine:   { n: 'イワシ', p: 10, c: 1, d: '小さな魚。焚き火で焼くと焼きイワシになる。生だとお腹を壊すかも。', food: { h: 6, t: 0, raw: 1 } },
  katsuo:    { n: 'カツオ', p: 95, c: 3, d: '朝によく釣れる大物。焼くと焼きカツオになり、とても高く売れる。', food: { h: 20, t: 0, raw: 1 } },
  octopus:   { n: 'タコ', p: 42, c: 2, d: '夜によく釣れる。焼くと焼きタコになる。', food: { h: 12, t: 0, raw: 1 } },
  fugu:      { n: 'フグ', p: 48, c: 3, d: '高く売れるが、生は猛毒。焚き火で焼けば食べられる。', food: { h: 0, t: 0, poison: 1 }, noQuick: 1 },
  grilledSardine: { n: '焼きイワシ', p: 18, c: 1, d: '香ばしく焼いたイワシ。', food: { h: 14, t: 0 } },
  grilledAji:     { n: '焼きアジ', p: 38, c: 2, d: '脂ののった焼きアジ。', food: { h: 24, t: 0 } },
  grilledTako:    { n: '焼きタコ', p: 62, c: 2, d: '弾力のある焼きタコ。', food: { h: 26, t: 0 } },
  grilledTai:     { n: '焼きタイ', p: 100, c: 3, d: '縁起のいい焼きタイ。高く売れる。', food: { h: 32, t: 0 } },
  grilledKatsuo:  { n: '焼きカツオ', p: 140, c: 3, d: '香りのいいカツオのたたき。とても高く売れる。', food: { h: 38, t: 0 } },
  grilledFugu:    { n: '焼きフグ', p: 80, c: 3, d: '毒を抜いて焼いたフグ。空腹が大きく回復する。', food: { h: 50, t: 0 } },
  meat:      { n: '生肉', p: 15, c: 1, d: '動物から取れる肉。焚き火で焼くと焼き肉になる。生だとお腹を壊すかも。', food: { h: 8, t: 0, raw: 1 } },
  steak:     { n: '焼き肉', p: 40, c: 2, d: 'こんがり焼けた肉。空腹が大きく回復する。', food: { h: 38, t: 0 } },
  crabmeat:  { n: 'カニの身', p: 15, c: 1, d: 'カニから取れる身。焚き火で焼くと焼きガニになる。生だとお腹を壊すかも。', food: { h: 8, t: 0, raw: 1 } },
  bossGem:   { n: '黒い宝玉', p: 5000, c: 0, d: '地下2階の主が落とした、妖しく光る宝玉。とても高く売れる。', noEv: 1 },   // v6b：1個$5,000。特需・値崩れ・勝負の対象外
  grilledCrab: { n: '焼きガニ', p: 40, c: 2, d: '香ばしく焼いたカニ。空腹が大きく回復する。', food: { h: 38, t: 0 } },
  hide:      { n: '毛皮', p: 35, c: 2, d: '動物の毛皮。ゼニ丸が買い取ってくれる。' },
  claw:      { n: '大きなハサミ', p: 50, c: 3, d: '大ガニのハサミ。珍味として高く売れる。' },
  // v7a：金のウサギ・蜂のドロップ。黄金の3つは値下がりなし（c:4）・特需・値崩れ・勝負の対象外（noEv）
  goldMeat:  { n: '黄金の生肉', p: 1000, c: 4, d: '金のウサギから取れた、金色に輝く肉。とても高く売れる。焚き火で20秒焼くと「黄金の焼き肉」になる。', food: { h: 1, t: 0 }, noEv: 1 },
  goldSteak: { n: '黄金の焼き肉', p: 1500, c: 4, d: '黄金の生肉を焼いた最高級の肉。食べると空腹が全回復し、5分間「幸福」になる（体力の自然回復が2倍）。お腹がいっぱいでも食べられる。', food: { h: 100, t: 0, full: 1, happy: 1 }, noEv: 1 },
  goldHide:  { n: '黄金の毛皮', p: 1500, c: 4, d: '金のウサギの毛皮。まばゆく光り、とても高く売れる。', noEv: 1 },
  honey:     { n: 'ハチミツ', p: 40, c: 1, d: '蜂が落とした甘いハチミツ。体力を20回復する（毒は治らない）。', heal: 20 },
  boot:      { n: '古い長靴', p: 2, c: 2, d: '釣れてしまった。ほとんど価値はない。' },
  shell:     { n: '貝殻', p: 15, c: 2, d: 'きれいな貝殻。お土産として売れる。' },
  rareshell: { n: '珍しい貝殻', p: 60, c: 3, d: '虹色に光る貝殻。加工するともっと高く売れる。' },
  accessory: { n: '貝のアクセサリー', p: 160, c: 3, d: '珍しい貝殻で作った首飾り。高級品。' },
  metal:     { n: '金属片', p: 25, c: 3, d: '難破船の金属。高性能な道具の材料。' },
  ironore:   { n: '鉄鉱石', p: 40, c: 3, d: '炉で精錬すると鉄インゴットになる。' },
  ingot:     { n: '鉄インゴット', p: 110, c: 3, d: '精錬した鉄。鉄の道具の材料。' },
  crystal:   { n: '水晶', p: 65, c: 3, d: '洞窟で光る透明な結晶。' },
  goldore:   { n: '金鉱石', p: 150, c: 3, d: '金を含む鉱石。炉で延べ棒にできる。' },
  // v7b：自動採掘機の開発ツリー。歯車から先の部品は、値下がりなし（c:0）・特需・値崩れ・勝負の対象外（noEv）
  copperore: { n: '銅鉱石', p: 35, c: 3, d: '銅鉱脈から掘れる鉱石。炉で銅インゴットにできる。' },
  coal:      { n: '石炭', p: 18, c: 1, d: '洞窟の入口の近くにある石炭鉱脈から掘れる。炉で鉄インゴットと合わせると鋼鉄になる。' },
  copper:    { n: '銅インゴット', p: 100, c: 3, d: '精錬した銅。歯車やモーターの材料。' },
  charcoal:  { n: '木炭', p: 15, c: 1, d: '木材を炉で焼いた炭。鉄板の材料になり、自動採掘機の燃料にもなる。' },
  ironplate: { n: '鉄板', p: 90, c: 3, d: '鉄インゴットを打ち延ばした板。機械部品や機械フレームの材料。' },
  steel:     { n: '鋼鉄インゴット', p: 180, c: 3, d: '鉄と石炭から作る硬い鋼鉄。機械フレームやドリルヘッドの材料。' },
  gear:      { n: '歯車', p: 100, c: 0, d: '鉄と銅で作った歯車。機械部品・モーター・ドリルヘッドの材料。', noEv: 1 },
  part:      { n: '機械部品', p: 210, c: 0, d: '歯車と鉄板を組み合わせた部品。機械の組み立てに使う。', noEv: 1 },
  motor:     { n: 'モーター', p: 290, c: 0, d: '機械を動かすモーター。自動採掘機の材料。', noEv: 1 },
  frame:     { n: '機械フレーム', p: 680, c: 0, d: '鋼鉄の骨組み。自動採掘機の材料。', noEv: 1 },
  drill:     { n: 'ドリルヘッド', p: 440, c: 0, d: '岩を掘り進む鋼鉄のドリル。自動採掘機の材料。', noEv: 1 },
  nail:      { n: '釘', p: 385, c: 3, d: '鉄と水晶と金属片で作った丈夫な釘。木造の家の材料。' },   // v7c
  goldbar:   { n: '金の延べ棒', p: 420, c: 3, d: 'まばゆい金の延べ棒。超高級品。' },
  coin:      { n: '古代のコイン', p: 100, c: 3, d: '岩の中から出てきた古いコイン。' },
  canned:    { n: '缶詰', p: 20, c: 2, d: 'ゼニ丸から買える保存食。', food: { h: 40, t: 10 } },
  medkit:    { n: '救急キット', p: 30, c: 2, d: '体力を50回復する。毒も治る。', heal: 50, cure: 1 },   // v6.1c：毒も治る（v7a：cure＝毒を治す）
  saliva:    { n: '澄んだ唾液', p: 12, c: 1, d: '野犬が落とす、透きとおった唾液。作業台の加工で「プロテイン」の材料になる。' },
  protein:   { n: 'プロテイン', p: 60, c: 2, d: '作業台で作る特製ドリンク。飲むと2分間「覚醒」して、体がよく動く。', buff: 1, stack: 1 },   // v6a：1枠に1個まで
  cloth:     { n: '帆布', p: 80, c: 3, d: '繊維を編んだ丈夫な布。いかだの帆になる。' },
  turtle:    { n: '黄金の亀像', p: 1200, c: 4, d: '島の守り神とされる黄金の像。手放してはいけない気がする……', key: 1 },
  ledger:    { n: '裏帳簿', p: 0, c: 0, d: '鮫島海運の裏帳簿。沈めた船と保険金の記録。', key: 1 },
  // 設置物（クラフトすると持ち物に入り、アイテムバーで持って右クリックで置く。売値は素材の約4割）。v7a：石・木材・金属片の値下げに合わせて、焚き火・作業台・寝床・炉・チェストも下げた
  campfire:  { n: '焚き火', p: 16, c: 0, d: '置くと魚や肉を焼ける。近くにいると夜も寒くない。', place: 1 },
  workbench: { n: '作業台', p: 20, c: 0, d: '置くと高度なクラフトと素材の加工ができる。', place: 1 },
  bed:       { n: '寝床', p: 26, c: 0, d: '置くと夕方以降に朝まで眠れる。', place: 1 },
  furnace:   { n: '炉', p: 55, c: 0, d: '置くと鉱石を精錬できる。', place: 1 },
  chest:     { n: 'チェスト', p: 43, c: 0, d: '置くと8枠（40個）までしまえる。道具も入る。', place: 1 },
  houseKit:  { n: '木造の家（設計キット）', p: 900, c: 0, d: '使うと、木造の家を建てる場所を選べる（島の上・5×5の空いた地面。まわり1マスは通り道）。建て始めると、ゲーム内の時計で12時間で完成する。1軒まで。', place: 1 },   // v7c：売値は素材の約4割
  miner:     { n: '自動採掘機', p: 760, c: 0, d: '木炭か石炭を燃料に、20秒ごとに自動で岩を掘る機械。島の岩場の2×2マスに置ける（1台まで）。', place: 1 },
  lumber:    { n: '自動伐採機', p: 228, c: 0, d: 'まわり3×3マスの木を自動で切って、木材と木の枝をためる機械。燃料はいらない。木が生え直すと、また切ってくれる。', place: 1 },   // v8b   // v7b：売値は素材の約4割
  ladder:    { n: '縄梯子', p: 30, c: 0, d: '崖の壁に掛けると、崖を上り下りできる。1個で崖の1列ぶん。掛けたら外せない。', place: 1 },   // v6c
};
const DROP = [0, 0.02, 0.035, 0.05, 0]; // 1個売るごとの値下がり幅
const VOYAGE_FOOD = ['coconut', 'grilled', 'canned', 'grilledSardine', 'grilledAji', 'grilledTako', 'grilledTai', 'grilledKatsuo', 'grilledFugu', 'steak', 'grilledCrab'];

const TOOLS = {
  stoneAxe:  { n: '石斧', cat: 'axe', lv: 1, dur: 40, atk: 4, rng: 1 },   // v6.1a：atk＝攻撃力補正、rng＝ダメージ乱数（±）
  ironAxe:   { n: '鉄の斧', cat: 'axe', lv: 2, dur: 150, atk: 6, rng: 2 },
  stonePick: { n: '石のつるはし', cat: 'pick', lv: 1, dur: 40, atk: 3, rng: 1 },
  ironPick:  { n: '鉄のつるはし', cat: 'pick', lv: 2, dur: 120, atk: 5, rng: 2 },
  rod:       { n: '釣り竿', cat: 'rod', lv: 1, dur: 25 },
  torch:     { n: 'たいまつ', cat: 'torch', lv: 1, dur: 60, stack: 5 },   // 手に持っている間だけ1秒に1減る（1本1分）。1枠に5本まで
  stoneSword:{ n: '石の剣', cat: 'sword', lv: 1, dur: 50, atk: 7, rng: 2 },
  ironSword: { n: '鉄の剣', cat: 'sword', lv: 2, dur: 180, atk: 18, rng: 3 },
  ironArmor: { n: '鉄の防具', cat: 'armor', lv: 2, dur: 50, def: 0.3 },
  bow:       { n: '弓', cat: 'bow', lv: 1, dur: 80 },   // v8c：まわりの円の中の生き物を自動で狙って矢を撃つ（矢は使い切り）   // v6b：装備すると受けるダメージ-30%。攻撃を受けた回数で耐久が減る（必殺技は防げない）
};
const BUILD_NAMES = { campfire: '焚き火', workbench: '作業台', bed: '寝床', furnace: '炉', chest: 'チェスト', ladder: '縄梯子', lumber: '自動伐採機' };   // v6.2：縄梯子の名前がクラフトに出ていなかった
const UP_NAMES = { bag: '大きなかばん', cart: '運搬カート', benchUp: '作業台強化', magnet: 'アイテム回収機' };

// st: hand=どこでも / bench=作業台の近く
const RECIPES = [
  { id: 'rope', st: 'hand', out: 'rope', n: 1, cost: { fiber: 3 }, d: '繊維3つから作る。売値も少し上がる。' },
  { id: 'bowl', st: 'bench', out: 'bowl', n: 1, cost: { wood: 1 }, d: '泉で水を汲むための器。焚き火でろ過すると安全な水になる。' },
  { id: 'stoneAxe', st: 'hand', tool: 'stoneAxe', cost: { stone: 2, wood: 2 }, d: '木材の採集量が1回1個→3個に。耐久40回。' },
  { id: 'stonePick', st: 'hand', tool: 'stonePick', cost: { stone: 3, wood: 1 }, d: '岩・鉄鉱脈・水晶が掘れる。耐久40回。' },
  { id: 'bow', st: 'bench', tool: 'bow', cost: { wood: 3, rope: 2, fiber: 2 }, d: '自分のまわり半径5マスの円の中の生き物を自動で狙い、矢を撃つ（矢を使う）。ダメージ9〜13。耐久80回。ボスには効かない。' },   // v8c
  { id: 'arrow', st: 'bench', out: 'arrow', n: 5, cost: { branch: 1, stone: 1, fiber: 1 }, d: '弓で撃つ矢（5本）。' },   // v8c
  { id: 'stoneSword', st: 'hand', tool: 'stoneSword', cost: { stone: 3, wood: 1, fiber: 2 }, d: '動物や敵を攻撃する武器。ダメージ11〜15（素手は5〜7）。耐久50回。' },
  { id: 'torch', st: 'hand', tool: 'torch', cost: { branch: 2, fiber: 2 }, d: '夜や洞窟を広く照らす。手に持っている間だけ燃える（1本1分）。1枠に5本まで。' },
  { id: 'campfire', st: 'hand', build: 'campfire', cost: { branch: 4, stone: 4 }, d: '魚を焼ける。近くにいると夜も寒くない。' },
  { id: 'workbench', st: 'hand', build: 'workbench', cost: { wood: 4, stone: 2 }, d: '高度なクラフトと素材の加工ができる。' },
  { id: 'rod', st: 'bench', tool: 'rod', cost: { branch: 3, rope: 2 }, d: '水辺で釣りができる。耐久25回。' },
  { id: 'bed', st: 'bench', build: 'bed', cost: { wood: 4, fiber: 6 }, d: '夕方以降に眠ると朝まで休める。' },
  { id: 'bag', st: 'bench', up: 'bag', bp: 'bag', cost: { fiber: 6, rope: 3, hide: 2 }, d: '持ち物の枠が8つ増える（40個ぶん）。' },   // v6a：繊維6・ロープ3・毛皮2
  { id: 'cart', st: 'bench', up: 'cart', bp: 'cart', cost: { plank: 4, rope: 2, ingot: 2 }, d: '持ち物の枠がさらに8つ増える（40個ぶん）。' },   // v6a：板材4・ロープ2・鉄インゴット2
  { id: 'chest', st: 'bench', build: 'chest', cost: { wood: 8, rope: 2 }, d: '8枠（40個）までしまえる箱。道具も入れられる。' },
  { id: 'ladder', build: 'ladder', cost: { rope: 4, plank: 2 }, d: '崖の壁に掛けて、崖の上へ登れる（1個で崖の1列ぶん。掛けたら外せない）。' },   // v6c
  { id: 'furnace', st: 'bench', build: 'furnace', bp: 'furnace', cost: { stone: 10, metal: 2 }, d: '鉱石を精錬して高く売れる。' },
  { id: 'benchUp', st: 'bench', up: 'benchUp', bp: 'benchUp', cost: { plank: 4, metal: 2 }, d: '作業台の加工時間が半分になる。' },
  { id: 'ironAxe', st: 'bench', tool: 'ironAxe', bp: 'iron', cost: { ingot: 2, wood: 2 }, d: '木材4個。速くて丈夫（耐久150回）。' },
  { id: 'ironSword', st: 'bench', tool: 'ironSword', bp: 'iron', cost: { ingot: 2, wood: 1 }, d: 'ダメージ21〜27の頼れる剣。耐久180回。' },
  { id: 'ironPick', st: 'bench', tool: 'ironPick', bp: 'iron', cost: { ingot: 3, wood: 2 }, d: '金鉱脈と硬い岩も砕ける（耐久120回）。' },
  { id: 'ironArmor', st: 'bench', tool: 'ironArmor', bp: 'iron', cost: { ingot: 6, hide: 3, rope: 2 }, d: '鉄の防具一式。持ち物画面で装備すると、受けるダメージが30%減る。攻撃を受けるたびに耐久が減る（50回）。' },   // v6b
  { id: 'cloth', st: 'bench', out: 'cloth', n: 1, bp: 'raft', cost: { fiber: 8, rope: 2, hide: 2 }, d: 'いかだの帆。毛皮で丈夫に仕上げる。' },
  { id: 'magnet', st: 'bench', up: 'magnet', bp: 'magnet', cost: { metal: 1, rope: 2 }, d: '拾える物を、調べるボタンの長押しで連続回収できる。' },
  { id: 'lumber', st: 'bench', build: 'lumber', cost: { wood: 10, gear: 2, ironplate: 3 }, d: '置いたまわり3×3マスの木を自動で切って、木材（1本3個）と木の枝（1本1個）をためる。燃料はいらない。' },   // v8b
  { id: 'houseKit', st: 'bench', build: 'houseKit', cost: { plank: 15, fiber: 30, nail: 5 }, d: '木造の家を建てるためのキット。島の上の5×5の空き地に建てると、ゲーム内の時計で12時間で完成する。1軒まで。' },   // v7c
];
const PROCESS = {
  bench: [
    { id: 'plank', in: { wood: 1 }, out: 'plank', n: 1, t: 8 },
    { id: 'dw', in: { driftwood: 1 }, out: 'wood', n: 1, t: 4 },
    { id: 'acc', in: { rareshell: 1, rope: 1 }, out: 'accessory', n: 1, t: 15 },
    { id: 'protein', in: { cleanwater: 1, berry: 2, coconut: 2, saliva: 1 }, out: 'protein', n: 1, t: 12, ret: { bowl: 1 } },   // v6a：器はできあがりと一緒に戻る
    // v7b：自動採掘機の部品（作業台強化で時間は半分）
    { id: 'gear', in: { ingot: 1, copper: 1 }, out: 'gear', n: 2, t: 15 },
    { id: 'part', in: { gear: 1, ironplate: 1, metal: 1 }, out: 'part', n: 1, t: 20 },   // v8b：自動採掘機のコストを下げた（部品も合わせて見直し）
    { id: 'motor', in: { copper: 2, gear: 1 }, out: 'motor', n: 1, t: 30 },
    { id: 'frame', in: { steel: 2, ironplate: 2, part: 1 }, out: 'frame', n: 1, t: 35 },
    { id: 'drill', in: { steel: 1, gear: 1, part: 1 }, out: 'drill', n: 1, t: 30 },
    { id: 'miner', in: { frame: 1, motor: 1, drill: 1, steel: 1, copper: 1, part: 1 }, out: 'miner', n: 1, t: 60 },
    { id: 'nail', in: { ingot: 1, crystal: 1, metal: 3 }, out: 'nail', n: 1, t: 25 },   // v7c：釘
  ],
  fire: [
    { id: 'grill', in: { fish: 1 }, out: 'grilledAji', n: 1, t: 6 },
    { id: 'grillBig', in: { bigfish: 1 }, out: 'grilledTai', n: 1, t: 9 },
    { id: 'water', in: { rawwater: 1 }, out: 'cleanwater', n: 1, t: 15 },
    { id: 'grillS', in: { sardine: 1 }, out: 'grilledSardine', n: 1, t: 5 },
    { id: 'grillO', in: { octopus: 1 }, out: 'grilledTako', n: 1, t: 7 },
    { id: 'grillK', in: { katsuo: 1 }, out: 'grilledKatsuo', n: 1, t: 12 },
    { id: 'grillF', in: { fugu: 1 }, out: 'grilledFugu', n: 1, t: 10 },
    { id: 'steak', in: { meat: 1 }, out: 'steak', n: 1, t: 8 },
    { id: 'grillC', in: { crabmeat: 1 }, out: 'grilledCrab', n: 1, t: 8 },
    { id: 'grillGold', in: { goldMeat: 1 }, out: 'goldSteak', n: 1, t: 20 },   // v7a：黄金の焼き肉
  ],
  furnace: [
    { id: 'ingot', in: { ironore: 1 }, out: 'ingot', n: 1, t: 12 },   // v8b：燃料（枝・木材）は材料から外した（炉の燃料ゲージを使う）
    { id: 'goldbar', in: { goldore: 2 }, out: 'goldbar', n: 1, t: 20 },
    // v7b：自動採掘機の素材
    { id: 'copper', in: { copperore: 1 }, out: 'copper', n: 1, t: 12 },
    { id: 'charcoal', in: { wood: 2 }, out: 'charcoal', n: 1, t: 15 },
    { id: 'ironplate', in: { ingot: 1, charcoal: 1 }, out: 'ironplate', n: 2, t: 12 },
    { id: 'steel', in: { ingot: 1, coal: 2 }, out: 'steel', n: 1, t: 18 },
  ],
};
const STATION_NAMES = { bench: '作業台', fire: '焚き火', furnace: '炉' };
const RAFT_COST = { wood: 10, plank: 6, rope: 6, cloth: 1 };
// 天気（毎朝きまる）
const WEATHER = { sun: { n: '晴れ' }, cloud: { n: 'くもり' }, rain: { n: '雨' }, storm: { n: '嵐' }, snow: { n: '雪' } };   // v8c：雪（いつも寒い）
// 返済の締め日：[期限に対する位置, その日までに必要な累計返済率]
const STAGE_PLAN = [[0.3, 0.15], [0.6, 0.4], [0.85, 0.7]];
const STAGE_PENALTY = 0.1;   // 未達のとき、残りの借金に上乗せされる割合
// 生き物・敵（kind: passive=逃げる / enemy=襲ってくる、at: day/night/any、where: sand/land/cave）
const MOBS = {
  crab:   { n: 'カニ', hp: 23, sp: 22, kind: 'passive', at: 'day', where: 'sand', cap: 3, drops: [['crabmeat', 1, 0.6], ['claw', 1, 0.2]] },
  rabbit: { n: 'ウサギ', hp: 17, sp: 42, kind: 'passive', at: 'day', where: 'land', cap: 3, drops: [['meat', 1], ['hide', 1, 0.35]] },
  dog:    { n: '野犬', hp: 67, sp: 47, kind: 'enemy', at: 'night', where: 'land', cap: 2, dmg: 6, sight: 96, drops: [['meat', 1], ['hide', 1, 0.5], ['saliva', 1, 0.3]] },   // v6a：澄んだ唾液（30%）
  gcrab:  { n: '大ガニ', hp: 109, sp: 20, kind: 'enemy', at: 'night', where: 'sand', cap: 2, dmg: 10, sight: 64, drops: [['claw', 1], ['claw', 1, 0.5], ['crabmeat', 1]] },
  scorpion: { n: 'サソリ', hp: 99, sp: 30, kind: 'enemy', at: 'any', where: 'cave', cap: 3, capWide: 3, dmg: 7, sight: 72, poison: 1, drops: [['crystal', 1]] },   // v6.1c：攻撃を受けると毒。ドロップは仮で水晶
  bat:    { n: 'コウモリ', hp: 113, sp: 38, kind: 'enemy', at: 'any', where: 'cave', cap: 3, dmg: 4, sight: 84, fly: 1, capWide: 4, drops: [['coin', 1, 0.15], ['crystal', 1, 0.1]] },   // v6.1d：capWide＝広い洞窟での数
  // v7a：noSpawn＝ふつうの抽選では出ない。drops の4つ目＝消えない落とし物
  grabbit: { n: '金のウサギ', hp: 5, sp: 125, smart: 1, kind: 'passive', at: 'day', where: 'land', cap: 0, noSpawn: 1, fleeR: 90, fleeSp: 100, fixedDmg: 1, gold: 1, drops: [['goldMeat', 1, null, 1], ['goldHide', 1, null, 1]] },   // ウサギが出る時に1%（1日1体まで）。どの武器でも1ダメージ（会心で2）
  bee:     { n: '蜂', hp: 35, sp: 88, kind: 'enemy', at: 'any', where: 'land', cap: 0, noSpawn: 1, dmg: 3, sight: 220, fly: 1, poison: 1, poisonP: 0.3, drops: [['honey', 1]] },
  hermit:  { n: 'ヤドカリ', hp: 16, sp: 14, kind: 'passive', calm: 1, at: 'day', hours: [6, 20], where: 'sand', cap: 3, drops: [], dropFn: () => [[chance(0.9) ? 'shell' : 'rareshell', 1]] },   // v8c：逃げない。貝殻（90%）か珍しい貝殻（10%）
  pbear:   { n: 'シロクマ', hp: 231, sp: 34, kind: 'neutral', at: 'day', hours: [6, 18], snow: 1, where: 'land', cap: 1, dmg: 18, sight: 160, dashSp: 131, prep: 0.5,   // v8e：10マス以内で突進（8→10マス、止まる1秒→0.5秒、速さ96→131）。v8f：攻撃されるまでは突進しない
    drops: [], dropFn: () => [['meat', 1], [pickW([['sardine', 30], ['fish', 30], ['bigfish', 25], ['katsuo', 15]]), 1], ['hide', 1]] },   // v8c：雪の日の6〜18時。攻撃されると怒って突進   // 木を切り始めた時に5%（1日3匹まで）。30%で毒
};
const STORAGE_CAP = 300;   // 小屋の倉庫に入る数
// ギャンブル（沈没船カジノ・ゼニ丸の勝負）
const LINER_REPAIR = { metal: 3, rope: 2, wood: 2 };
const BETS = [10, 50, 100, 500];
// スロット「ルナ・サンライズ」（ジャグラー風・完全オリジナル）
// レバーで抽選 → BB/RBに当選すると、ボーナスランプが点灯（先告知）。7・BARは目押し、小役は自動で揃う。設定の概念はなし
// v4：有効ラインは5本（上段・中段・下段・右下がり・右上がり）。ストップは左・中・右を好きな順番で押せる。ウェイトあり
const SLOT = {
  coinCost: 500,           // 貸しコイン：$500 = 23枚（現金にも同じ割合で戻せる）
  coinRate: 23,
  wait: 3,                 // ウェイト：前のゲームが回り出してから次のゲームが回り出すまでの秒数
  stopCd: 0.2,             // ストップボタンの連打防止（秒）
  bet: 3,                  // 1ゲーム3枚（MAX BET）
  prob: { BB: 1 / 120, RB: 1 / 200, replay: 1 / 7.3, grape: 1 / 6.06, cherry: 1 / 36.4, bell: 1 / 500 },   // 還元率 約88%
  pay: { BB: 80, RB: 32, bell: 10, grape: 8, cherry: 2 },
  speed: 16,               // 1秒に流れる図柄の数
  slide: 4,                // 目押しの引き込み（押した位置から何コマ先まで滑らせるか）
  name: { seven: '7', bar: 'BAR', bell: 'ベル', cherry: 'チェリー', grape: 'ブドウ', replay: 'リプレイ', BB: 'ビッグボーナス', RB: 'レギュラーボーナス' },
  reels: [
    ['seven', 'grape', 'replay', 'cherry', 'grape', 'bell', 'replay', 'grape', 'bar', 'replay', 'grape', 'cherry', 'bell', 'replay', 'grape', 'bell', 'replay', 'cherry', 'grape', 'bell', 'replay'],
    ['seven', 'replay', 'grape', 'bell', 'replay', 'grape', 'cherry', 'replay', 'grape', 'bar', 'bell', 'replay', 'grape', 'cherry', 'replay', 'grape', 'bell', 'replay', 'grape', 'cherry', 'bell'],
    ['seven', 'bar', 'grape', 'replay', 'bell', 'grape', 'replay', 'cherry', 'grape', 'replay', 'bell', 'grape', 'replay', 'cherry', 'grape', 'replay', 'bell', 'grape', 'cherry', 'replay', 'bell'],
  ],
};
const SLOT_LINES = [[0, 0, 0], [1, 1, 1], [2, 2, 2], [0, 1, 2], [2, 1, 0]];   // 5ライン：各リールの段（0=上段 1=中段 2=下段）
const ROU_RED = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];
const ZENI_BET = { win: 0.45, up: 1.8, down: 0.3, max: 3000 };   // 勝てば1.8倍、負ければ3割（期待値は1未満）

// req: 返済率（初期借金に対する返済額）
// v7a：設計図は最初から全部買える（返済率での解禁を廃止。req は0のまま残す）
const SHOP = [
  { id: 'bp_bag', n: '大きなかばんの設計図', p: 150, bp: 'bag', req: 0, d: '作業台で「大きなかばん」が作れる。' },
  { id: 'bp_magnet', n: 'アイテム回収機の設計図', p: 180, bp: 'magnet', req: 0, d: '作業台で「アイテム回収機」が作れる。拾い物を長押しで連続回収できる。' },
  { id: 'bp_benchUp', n: '作業台強化の設計図', p: 250, bp: 'benchUp', req: 0, d: '作業台の加工時間が半分になる。' },
  { id: 'bp_cart', n: '運搬カートの設計図', p: 350, bp: 'cart', req: 0, d: '持てる量が大幅に増える。' },
  { id: 'bp_furnace', n: '炉の設計図', p: 300, bp: 'furnace', req: 0, d: '鉱石を精錬できる設備。' },
  { id: 'bp_iron', n: '鉄の道具の設計図', p: 450, bp: 'iron', req: 0, d: '鉄の斧・鉄のつるはし・鉄の剣・鉄の防具が作れる。' },
  { id: 'canned', n: '缶詰', p: 45, item: 'canned', req: 0, d: '空腹+40・渇き+10。' },
  { id: 'medkit', n: '救急キット', p: 80, item: 'medkit', req: 0, d: '体力+50。' },
];

// 採集・設置物の定義
const OBJ = {
  tree:     { n: '木', block: 1, g: { act: '木を切る', cat: 'axe', hits: [6, 3, 2], sfx: 'chop', fx: 'wood', to: 'stump', regrow: 2,
              y: lv => lv === 0 ? [['wood', 1], ['branch', 1, 0.4]] : lv === 1 ? [['wood', 3], ['branch', 1, 0.6]] : [['wood', 4], ['branch', 1, 0.7]] } },
  stump:    { n: '切り株', block: 0, regrowInfo: 1 },
  palm:     { n: 'ヤシの木', block: 1, g: { act: '木をゆする', hits: [1, 1, 1], sfx: 'shake', fx: 'leaf', special: 'palm' } },
  bush:     { n: 'しげみ', block: 1, g: { act: 'ベリーを摘む', instant: 1, sfx: 'pick', fx: 'leaf', special: 'bush' } },
  grass:    { n: '草', block: 0, g: { act: '草を刈る', hits: [1, 1, 1], sfx: 'cut', fx: 'leaf', to: 'grassCut', regrow: 1, y: () => [['fiber', 2], ['fiber', 1, 0.3]] } },
  grassCut: { n: '刈った草', block: 0, regrowInfo: 1 },
  pebble:   { n: '小石', block: 0, g: { act: '拾う', instant: 1, sfx: 'pick', remove: 1, y: () => [['stone', 1]] } },
  twig:     { n: '木の枝', block: 0, g: { act: '拾う', instant: 1, sfx: 'pick', remove: 1, y: () => [['branch', 2]] } },
  driftwood:{ n: '流木', block: 0, g: { act: '拾う', instant: 1, sfx: 'pick', remove: 1, y: () => [['driftwood', 1]] } },
  shell:    { n: '貝殻', block: 0, g: { act: '拾う', instant: 1, sfx: 'pick', remove: 1, special: 'shell' } },
  crate:    { n: '漂着した木箱', block: 1, g: { act: 'こじ開ける', cat: 'axe', hits: [3, 2, 2], sfx: 'chop', fx: 'wood', remove: 1, special: 'crate' } },
  scrap:    { n: '難破船の残骸', block: 1, g: { act: '解体する', cat: 'pick', hits: [8, 4, 2], sfx: 'mine', fx: 'metal', remove: 1, y: lv => [['metal', lv > 0 ? 2 : 1]] } },
  boulder:  { n: '岩', block: 1, g: { act: '岩を砕く', cat: 'pick', need: 1, hits: [0, 4, 2], sfx: 'mine', fx: 'stone', to: 'rubble', regrow: 3,
              y: () => [['stone', 3], ['ironore', 1, 0.15], ['metal', 1, 0.08], ['coin', 1, 0.04]] } },
  rubble:   { n: '砕けた岩', block: 0, regrowInfo: 1 },
  ironVein: { n: '鉄鉱脈', block: 1, g: { act: '鉱石を掘る', cat: 'pick', need: 1, hits: [0, 5, 3], sfx: 'mine', fx: 'iron', to: 'ironVeinD', regrow: 2,
              y: () => [['ironore', 2], ['ironore', 1, 0.3], ['stone', 1, 0.3]] } },
  ironVeinD:{ n: '掘り尽くした鉱脈', block: 0, regrowInfo: 1 },
  // v7b：銅鉱脈（島の岩場）・石炭鉱脈（洞窟の入口の近く）。叩く回数・復活は鉄鉱脈と同じ
  copperVein: { n: '銅鉱脈', block: 1, g: { act: '鉱石を掘る', cat: 'pick', need: 1, hits: [0, 5, 3], sfx: 'mine', fx: 'iron', to: 'copperVeinD', regrow: 2, y: () => [['copperore', 2], ['copperore', 1, 0.3]] } },
  copperVeinD:{ n: '掘り尽くした鉱脈', block: 0, regrowInfo: 1 },
  coalVein:   { n: '石炭鉱脈', block: 1, g: { act: '石炭を掘る', cat: 'pick', need: 1, hits: [0, 5, 3], sfx: 'mine', fx: 'stone', to: 'coalVeinD', regrow: 2, y: () => [['coal', 2], ['coal', 1, 0.3]] } },
  coalVeinD:  { n: '掘り尽くした鉱脈', block: 0, regrowInfo: 1 },
  crystal:  { n: '水晶', block: 1, g: { act: '水晶を掘る', cat: 'pick', need: 1, hits: [0, 4, 2], sfx: 'crystal', fx: 'crystal', to: 'crystalD', regrow: 2,
              y: () => [['crystal', 1], ['crystal', 1, 0.5]] } },
  crystalD: { n: '掘り尽くした水晶', block: 0, regrowInfo: 1 },
  goldVein: { n: '金鉱脈', block: 1, g: { act: '金を掘る', cat: 'pick', need: 2, hits: [0, 0, 4], sfx: 'mine', fx: 'gold', to: 'goldVeinD', regrow: 3,
              y: () => [['goldore', 2], ['goldore', 1, 0.3]] } },
  goldVeinD:{ n: '掘り尽くした金鉱脈', block: 0, regrowInfo: 1 },
  hardRock: { n: '硬い岩', block: 1, g: { act: '硬い岩を砕く', cat: 'pick', need: 2, hits: [0, 0, 6], sfx: 'mine', fx: 'stone', remove: 1, y: () => [['stone', 2]] } },
  diary:    { n: '古いノート', block: 0, it: 'diary', act: 'ノートを読む' },
  shrine:   { n: '亀の祠', block: 1, it: 'shrine', act: '祠を調べる' },
  shrineEmpty: { n: '空の祠', block: 1, it: 'shrineEmpty', act: '祠を調べる' },
  stairsDown: { n: '地下への階段', block: 0, it: 'stairsDown', act: '地下2階へ下りる' },   // v5：空の祠をもう一度調べると現れる
  stairsUp:   { n: '上への階段', block: 0, it: 'stairsUp', act: '地下1階へ上る' },
  brazier:    { n: 'かがり火', block: 1, it: 'brazier', act: 'かがり火を見る' },
  cave:     { n: '洞窟', block: 1, it: 'cave', act: '洞窟に入る', fp: [[-1, 0], [0, 0], [1, 0], [-1, -1], [0, -1], [1, -1]] },
  exit:     { n: '出口', block: 0, it: 'exit', act: '外に出る' },
  box:      { n: '回収ボックス', block: 1, it: 'shop', act: 'ゼニ丸と取引する' },
  zeniH:    { n: 'ゼニ丸', block: 1, it: 'zeniTalk', act: 'ゼニ丸と話す' },   // v8b：家の中で、出口のそばにいるゼニ丸
  campfire: { n: '焚き火', block: 1, it: 'station', st: 'fire', act: '焚き火を使う' },
  workbench:{ n: '作業台', block: 1, it: 'station', st: 'bench', act: '作業台を使う' },
  furnace:  { n: '炉', block: 1, it: 'station', st: 'furnace', act: '炉を使う' },
  bed:      { n: '寝床', block: 1, it: 'bed', act: '寝床を使う' },
  chest:    { n: 'チェスト', block: 1, it: 'chest', act: 'チェストを開ける' },
  miner:    { n: '自動採掘機', block: 1, it: 'miner', act: '採掘機を調べる', fp: [[0, 0], [1, 0], [0, -1], [1, -1]] },   // v7b。v8b：2×2マス（左下が基準）
  lumber:   { n: '自動伐採機', block: 1, it: 'lumber', act: '伐採機を調べる' },   // v8b：まん中の1マス。まわり3×3の木を切る
  house:    { n: '木造の家', block: 1, it: 'house', act: '家を調べる' },   // v7c：3×3（左下が基準）。完成すると下の真ん中がドア
  hexit:    { n: '出入り口', block: 0 },   // v7c：家の中の出入り口（乗ると外に出る）
  ladder:   { n: '縄梯子', block: 0 },   // v6c：崖の壁に掛ける（その列が歩けるようになる。外せない）
  hut:      { n: '古い小屋', block: 1, it: 'hut', act: '小屋を調べる', fp: [[0, 0], [1, 0]] },
  wreck:    { n: '難破船', block: 1, it: 'wreck', act: '難破船を調べる', fp: [[0, 0], [1, 0], [2, 0], [0, -1], [1, -1], [2, -1]] },
  raft:     { n: 'いかだ置き場', block: 0, it: 'raft', act: 'いかだ置き場' },
  drop:     { n: '落とし物', block: 0, it: 'drop', act: '拾う' },
  liner:    { n: '豪華客船の残骸', block: 1, it: 'liner', act: '客船を調べる', fp: [[0, 0], [1, 0], [2, 0], [0, -1], [1, -1], [2, -1]] },   // 捨てた物・倒れた時に落とした物（id, n, lock）
};
const PLACE_SPR = { campfire: 'fire0', workbench: 'bench', bed: 'bed', furnace: 'furnace', chest: 'chest', miner: 'miner', lumber: 'lumber' };   // v7c：家（houseKit）は別に描く
const REVERT = { stump: 'tree', grassCut: 'grass', rubble: 'boulder', ironVeinD: 'ironVein', crystalD: 'crystal', goldVeinD: 'goldVein', copperVeinD: 'copperVein', coalVeinD: 'coalVein' };   // v7b：銅・石炭

/* ---------- 5. ストーリー ---------- */
const SPEAKERS = {
  me:   { name: () => game ? game.name : 'あなた', col: '#9fd3ff', por: 'me' },
  same: { name: () => '鮫島', col: '#ff8a7a', por: 'same' },
  zeni: { name: () => 'ゼニ丸', col: '#f2c440', por: 'zeni' },
  gen:  { name: () => 'ゲンの日誌', col: '#c8e6a0', por: 'gen' },
  sys:  { name: () => '', col: '#a9b6c8', por: null },
};
const PROLOGUE = [
  '「頼む、保証人になってくれ。\n絶対に迷惑はかけないから」',
  '——親友のその言葉を信じたのが、\n運の尽きだった。',
  '親友は姿を消し、残ったのは {debt} の借金だけ。\n貸主は、悪名高い「鮫島ファイナンス」。',
  '「返せねえなら、船で働いて返してもらうぜ」\n社長の鮫島に連れられ、\nあなたは遠洋漁船に乗せられた。',
  '出港から三日目の夜。\n船は突然の嵐に呑まれ——',
  '……波の音で、目が覚めた。',
];
const TALK = {
  intro: [
    ['me', '……ここは、どこだ？ 島……？'],
    ['me', '船は……みんなは……？'],
    ['sys', 'ポケットの防水無線機が、ザザッと鳴った。'],
    ['same', 'よう、生きてたか、{name}。俺だ、鮫島だ。'],
    ['same', '俺たちは救命ボートで本土に戻った。運が良かったぜ、ハッハッハ！'],
    ['same', 'さて、本題だ。船は沈んでも、お前の借金は沈まねえ。残り {debt}、利息は1日 {rate}% だ。'],
    ['same', 'その島はちょうどウチの社有地でな。島の物は石ころ一つまで買い取ってやる。'],
    ['same', '回収ドローンを送っておいた。拾った物はそいつに売って、その金で返済しろ。'],
    ['zeni', 'ピピッ！ 回収ドローン「ゼニ丸」デス！ 買取ト返済ノ受付ヲ担当シマス。ゼニ！'],
    ['same', '期限は {days}日目が終わるまでだ。返せなきゃ……迎えに行ってやるよ。'],
    ['same', '一生、マグロ船の上で働いてもらうがな。ハッハッハ！　……ブツッ'],
    ['me', '……やるしかない。まずは浜辺の物を拾って、売ってみよう。'],
    ['sys', '{controls}'],
  ],
  // デモプレイ（期限・利息なし）の導入
  introFree: [
    ['me', '……ここは、どこだ？ 島……？'],
    ['sys', 'ポケットの防水無線機が、ザザッと鳴った。'],
    ['same', 'よう、生きてたか、{name}。俺だ、鮫島だ。'],
    ['same', '船は沈んでも、お前の借金は沈まねえ。残り {debt} だ。'],
    ['same', 'その島はウチの社有地でな。島の物は石ころ一つまで買い取ってやる。回収ドローンに売って、その金で返済しろ。'],
    ['zeni', 'ピピッ！ 回収ドローン「ゼニ丸」デス！ 買取ト返済ノ受付ヲ担当シマス。ゼニ！'],
    ['same', '今回は特別だ。期限も利息もナシにしてやる。……気前がいいだろ？ ハッハッハ！　……ブツッ'],
    ['me', '……やるしかない。まずは浜辺の物を拾って、売ってみよう。'],
    ['sys', '{controls}'],
  ],
  firstSale: [
    ['zeni', 'マイドアリ！ 売上ハ「所持金」ニ入リマス。ゼニ！'],
    ['zeni', '同ジ品物ヲ売リ続ケルト、値段ガ下ガリマス。時間ガタツト元ニ戻リマス。毎朝ノ「特需」モ要チェックデス！'],
    ['zeni', '返済ハ「返済」タブカラ。利息ハ毎朝、残リノ借金ニカカリマス。'],
    ['me', 'すぐ返済するか、道具に投資するか……考えどころだな。'],
  ],
  firstRepay: [['zeni', '返済、確カニ受ケ取リマシタ。ゼニ！']],
  firstNight: [
    ['me', '暗くなってきた……。それに、冷える。'],
    ['sys', '夜は焚き火のそばにいないと体力が少しずつ減る。寝床があれば、夕方以降に眠って朝まで休める。'],
  ],
  m25: [
    ['same', 'ほう、ちゃんと返してるじゃねえか。いい心がけだ。'],
    ['same', 'その調子で稼いで、きっちり返しな。ゼニ丸の品ぞろえも、せいぜい役立てるんだな。……もちろんタダじゃねえぞ。'],
  ],
  m50: [
    ['same', 'チッ……半分も返しやがったか。'],
    ['same', '……それと、北東の洞窟の奥には近づくなよ。崩れやすいからな。'],
    ['me', '（今、少し声が焦っていたような……？）'],
  ],
  m75: [
    ['same', '……おい、{name}。お前、本当に全部返す気か？'],
    ['same', '島の暮らしも悪くねえだろ？ なあ、ずっとそこにいてもいいんだぜ？'],
    ['me', '（なぜか引き止められている気がする……）'],
  ],
  paid: [
    ['zeni', 'ピピーッ！ 借金、完済デス！ オメデトウゴザイマス！ ゼニ！'],
    ['same', '……チッ。完済だ。契約は終わりだよ。'],
    ['me', 'じゃあ、迎えの船を——'],
    ['same', '迎え？ 契約書にそんな項目はねえよ。自力で帰ってきな。……ブツッ'],
    ['me', '……やっぱりな。いかだを作って、この島を出よう。'],
  ],
  paidHint: [['me', 'そういえば、島の西に古い小屋があった。何か手がかりがあるかもしれない。']],
  halfBad: [['same', 'おいおい、もう半分過ぎたぞ。大丈夫かぁ？ ハッハッハ！']],
  halfGood: [['same', '……順調みてえだな。チッ、面白くねえ。']],
  lastDay: [['same', '明日の朝、迎えに行く。せいぜい準備しとけよ、{name}。']],
  diary1: [
    ['sys', '小屋の中に、古びたノートが落ちている。紙はすっかり黄ばんでいる。'],
    ['gen', '「漂流日誌　その1」'],
    ['gen', 'わしの名はゲン。鮫島海運に借金を返すため船に乗り、嵐で沈み、この島に流れ着いた。'],
    ['gen', '無線で社長は言った。「その島はウチの社有地だ」と。だが島の古い石碑には、この島は誰のものでもないと刻まれていた。'],
    ['gen', 'いつか帰る日のために、いかだの作り方を書き残しておく。帆は繊維を編んで作るといい。'],
    ['sys', 'いかだの設計図を手に入れた！（作業台で帆布が作れるようになった）'],
    ['me', '鮫島海運……鮫島ファイナンスの前身か？ この人も、同じ目に……'],
  ],
  diary2: [
    ['sys', '岩陰に、ノートの切れ端がはさまっている。'],
    ['gen', '「漂流日誌　その2」'],
    ['gen', '船が沈んだあの夜、甲板で社長の部下が何かを仕掛けているのを見た。あの沈没は事故ではない。保険金目当てだ。'],
    ['gen', '鮫島は借金を抱えた者を船に乗せて沈め、保険金と島の資源で二重に儲けているのだ。'],
    ['gen', '証拠の裏帳簿は、洞窟の奥の亀の祠に隠した。だが落盤で道がふさがってしまった。硬い岩を砕ける鉄の道具があれば……'],
    ['me', '……！ まさか、俺の乗っていた船も……'],
  ],
  diary3: [
    ['gen', '「漂流日誌　その3」'],
    ['gen', 'わしはもう長くない。これを読む誰かへ。'],
    ['gen', '祠の黄金の亀は、この島の守り神。その台座の下に、裏帳簿を隠してある。'],
    ['gen', 'どうか生きて島を出て、真実を明るみに出してくれ。……家族に、すまなかったと伝えてほしい。'],
  ],
  shrine: [
    ['sys', '黄金の亀像を手に入れた！'],
    ['sys', '台座の下から、古びた帳簿が出てきた。「鮫島海運 裏帳簿」——沈めた船の名前と、受け取った保険金の額がびっしり書かれている。'],
    ['me', 'これがあれば、鮫島の悪事を暴ける……！ 必ず持って帰ろう。'],
    ['sys', '無線機が、ザザッと鳴った。'],
    ['same', '……おい、{name}。今、洞窟で何か見つけたか？　……いや、なんでもねえ。'],
  ],
  cave: [
    ['me', 'ひんやりしている……。奥まで続いているみたいだ。'],
    ['sys', '洞窟の中は暗い。たいまつがあると広く照らせる。天井からの落石に注意！（地面に影が見えたら離れよう）'],
  ],
  hut: [['me', '古びた小屋だ。誰かがここで暮らしていたらしい……。']],
  liner: [
    ['me', 'こんな所に、大きな客船が打ち上げられている……！'],
    ['sys', '船体に、かすれた文字が見える。「鮫島海運　ルナ・マリーナ号」'],
    ['me', '鮫島の船……？ これも保険金のために沈めたのか……。'],
    ['me', '中はカジノになっているみたいだ。でも電源が落ちている。'],
    ['me', '奥の発電機を直せば、動くかもしれない。'],
  ],
  linerOpen: [
    ['sys', '発電機がうなりを上げ、船内にネオンが灯った！'],
    ['me', 'スロットにルーレット……。ここで一発当てれば、借金なんて……。'],
    ['gen', '（日誌の切れ端）賭けは魔物だ。俺はあの船で、帰りの金まで全部すった。'],
  ],
  zeniBet: [
    ['zeni', 'ピピッ！ ゼニ丸ノ「倍々チャンス」デス！ 素材ヲ1種類マルゴト賭ケテ、勝負シマセンカ？'],
    ['zeni', '勝テバ査定額ノ1.8倍デ買イ取リ！ 負ケタラ3割デ買イ叩キマス。1日1回マデ。ゼニ！'],
  ],
  wreck: [['me', '俺が乗っていた船の残骸だ……。使えそうな金属が転がっている。']],
  raftNoBp: [['me', 'ここなら、いかだを組み立てられそうだ。でも、作り方がわからない……。']],
  raftBuilt: [['sys', 'いかだが完成した！'], ['me', 'あとは食料を積んで、海に出るだけだ。']],
  faint: [['sys', '……気を失っていたようだ。気がつくと、浜辺に倒れていた。'], ['sys', '持ち物は倒れた場所に落としてきたらしい。所持金も少しなくしてしまった……。\n取りに戻ろう。']],
};
// v8f：エンディングは5種類。G（黒い宝玉）を削除し、一覧の上から A〜E に振り直した（旧B→A、旧C→B、旧E→C、旧A→D、旧D→E）
// 見た記録は設定の endV で一度だけ新しい記号に読み替える（loadSettings）
const ENDINGS = {
  A: { type: 'NORMAL END', title: '自由への航海', lines: [
    'いかだは波を越え、三日後、\nあなたは本土の港にたどり着いた。',
    '借金はもうない。\n手元にあるのは、島で鍛えた腕と、日焼けした肌だけ。',
    '時々、あの島の夢を見る。\nゼニ丸は今も、誰かの品物を買い取っているのだろうか。',
  ] },
  B: { type: 'TRUE END', title: '島が教えてくれた真実', lines: [
    'いかだは波を越え、三日後、\nあなたは本土の港にたどり着いた。',
    'あなたはその足で、裏帳簿を警察に届けた。',
    '数日後、ニュースが流れた。\n「鮫島ファイナンス社長を逮捕　保険金目当てに漁船を沈没させた疑い」',
    '不当な借金は無効となり、\nあなたが返した金も戻ってくることになった。',
    'そしてあなたは、ゲンの家族のもとへ、\n一冊の日誌を届けた。',
  ] },
  C: { type: 'SPECIAL END', title: '大逆転の夜逃げ', lines: [
    '借金を残したまま、あなたは夜の海へこぎ出した。',
    '三日後、本土の港。「よう、待ってたぜ」\n桟橋で鮫島が笑っていた。',
    'だがあなたは、黙って裏帳簿を突きつけた。\n鮫島の顔から、みるみる血の気が引いていく。',
    'その日のうちに鮫島は逮捕され、借金は無効になった。\n……少し、ずるい気もするけれど。',
  ] },
  D: { type: 'BAD END', title: '回収の朝', lines: [
    '{days1}日目の朝。水平線に、黒い船が現れた。',
    '「時間切れだぜ、{name}」\n鮫島が、サングラスの奥で笑っていた。',
    'あなたはマグロ船に乗せられ、\n二度と陸を踏むことはなかった——',
  ] },
  E: { type: 'BAD END', title: '逃げ切れなかった夜', lines: [
    '借金を残したまま、あなたは夜の海へこぎ出した。',
    '三日後、本土の港にたどり着いた、その時——',
    '「よう、待ってたぜ」\n桟橋で、鮫島が笑っていた。',
    '……ゼニ丸には、GPSが付いていたのだ。',
  ] },
  // v8e：嵐の日に出航するBAD END「嵐の海」は削除した。v8f：黒い宝玉のSECRET END（旧G）も削除（黒い宝玉は売る専用、ボスはやりこみ要素）
};
const ENDING_ORDER = ['A', 'B', 'C', 'D', 'E'];   // v6b：G（黒い宝玉）を追加して7種類。v8e：F（嵐の海）を削除して6種類。v8f：Gを削除して5種類、上からA〜E
const ENDING_OLD2NEW = { B: 'A', C: 'B', E: 'C', A: 'D', D: 'E' };   // v8f：v8eまでの記号 → 新しい記号

/* ---------- 6. ドット絵（すべてプログラムで描画） ---------- */
const P = {
  ol: '#1a1626', woodD: '#5a3a22', wood: '#8b5a2b', woodL: '#b07a3f',
  leafD: '#1f5e2e', leaf: '#2f8a3e', leafL: '#57b84a',
  stoneD: '#5d5f6e', stone: '#8a8d99', stoneL: '#b9bcc6',
  gold: '#f2c440', goldD: '#b8860b', goldL: '#fff2a8', iron: '#b9c2ca', ironL: '#eef2f6', ironD: '#7a8590',
};
function mkCanvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function painter(x) {
  return {
    r(X, Y, W, H, col) { x.fillStyle = col; x.fillRect(X, Y, W, H); },
    p(X, Y, col) { x.fillStyle = col; x.fillRect(X, Y, 1, 1); },
    e(cx, cy, rx, ry, col) {
      x.fillStyle = col;
      for (let yy = Math.floor(cy - ry); yy <= Math.ceil(cy + ry); yy++) for (let xx = Math.floor(cx - rx); xx <= Math.ceil(cx + rx); xx++) {
        const dx = (xx + 0.5 - cx) / rx, dy = (yy + 0.5 - cy) / ry; if (dx * dx + dy * dy <= 1) x.fillRect(xx, yy, 1, 1);
      }
    },
    l(x0, y0, x1, y1, col) {
      x.fillStyle = col; x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
      const dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1; let er = dx + dy;
      for (let i = 0; i < 400; i++) { x.fillRect(x0, y0, 1, 1); if (x0 === x1 && y0 === y1) break; const e2 = 2 * er; if (e2 >= dy) { er += dy; x0 += sx; } if (e2 <= dx) { er += dx; y0 += sy; } }
    },
    clear(X, Y, W, H) { x.clearRect(X, Y, W, H); },
  };
}
function addOutline(c, col) {
  const x = c.getContext('2d'), w = c.width, h = c.height, img = x.getImageData(0, 0, w, h), d = img.data, rgb = hexRgb(col), out = [];
  for (let y = 0; y < h; y++) for (let i = 0; i < w; i++) {
    const k = (y * w + i) * 4; if (d[k + 3] !== 0) continue;
    if ((i > 0 && d[k - 1] > 0) || (i < w - 1 && d[k + 7] > 0) || (y > 0 && d[k - w * 4 + 3] > 0) || (y < h - 1 && d[k + w * 4 + 3] > 0)) out.push(k);
  }
  for (const k of out) { d[k] = rgb[0]; d[k + 1] = rgb[1]; d[k + 2] = rgb[2]; d[k + 3] = 255; }
  x.putImageData(img, 0, 0);
}
function mk(w, h, fn, ol) { const c = mkCanvas(w, h); fn(painter(c.getContext('2d'))); if (ol !== false) addOutline(c, ol || P.ol); return c; }
function flipH(src) { const c = mkCanvas(src.width, src.height), x = c.getContext('2d'); x.translate(src.width, 0); x.scale(-1, 1); x.drawImage(src, 0, 0); return c; }

// v6b：鉄の防具（かぶと・胸当て・肩当て）を重ねる
function drawArmor(g, dir, f) {
  if (dir === 'dd') dir = 'down'; else if (dir === 'du') dir = 'up';   // v8d：斜めは前向き・後ろ向きの防具を使う
  const I = P.iron, L = P.ironL, D = P.ironD;
  if (dir === 'down') {
    g.r(5, 1, 6, 1, D); g.r(4, 2, 8, 2, I); g.r(5, 2, 4, 1, L); g.r(4, 4, 1, 2, D); g.r(11, 4, 1, 2, D); g.p(8, 1, L);
    g.r(4, 9, 8, 3, I); g.r(4, 9, 8, 1, L); g.r(4, 11, 8, 1, D); g.r(7, 10, 2, 1, D);
    g.r(3, 9 + (f === 1 ? 1 : 0), 1, 1, D); g.r(12, 9 + (f === 2 ? 1 : 0), 1, 1, D);
  } else if (dir === 'up') {
    g.r(5, 1, 6, 1, D); g.r(4, 2, 8, 4, I); g.r(5, 2, 6, 1, L); g.r(4, 5, 8, 1, D);
    g.r(4, 9, 8, 3, I); g.r(4, 9, 8, 1, L); g.r(4, 11, 8, 1, D); g.r(7, 9, 2, 3, D);
  } else {
    const ax = f === 1 ? 1 : f === 2 ? -1 : 0;
    g.r(5, 1, 6, 1, D); g.r(4, 2, 8, 2, I); g.r(6, 2, 4, 1, L); g.r(4, 4, 3, 2, D);
    g.r(5, 9, 6, 3, I); g.r(5, 9, 6, 1, L); g.r(5, 11, 6, 1, D); g.r(7 + ax, 9, 2, 1, D);
  }
}
function drawPlayer(g, dir, f) {
  const skin = '#f2c9a0', hair = '#4a2e1f', shirt = '#ece6d6', shirtD = '#c9bfa8', pants = '#3a62b8', pantsD = '#2a4a8c', shoe = '#4a3020';
  if (dir !== 'side') {
    g.r(5, 1, 6, 1, hair); g.r(4, 2, 8, 3, hair);
    if (dir === 'dd') {   // v8d：斜め下（右向き。左向きは反転）
      g.r(4, 4, 2, 3, hair); g.r(11, 4, 1, 2, hair);
      g.r(6, 4, 5, 4, skin); g.r(6, 4, 3, 1, hair); g.p(10, 4, hair);
      g.r(5, 7, 7, 1, skin); g.r(6, 8, 5, 1, skin);
      g.p(8, 6, P.ol); g.p(10, 6, P.ol); g.p(11, 7, '#f0a090');
    } else if (dir === 'down') {
      g.r(4, 4, 1, 3, hair); g.r(11, 4, 1, 3, hair);
      g.r(5, 4, 6, 4, skin); g.r(5, 4, 3, 1, hair); g.p(9, 4, hair);
      g.r(4, 7, 8, 1, skin); g.r(5, 8, 6, 1, skin);
      g.p(6, 6, P.ol); g.p(9, 6, P.ol); g.p(5, 7, '#f0a090'); g.p(10, 7, '#f0a090');
    } else if (dir === 'du') { g.r(4, 5, 8, 3, hair); g.r(5, 8, 6, 1, '#3a2418'); g.r(11, 5, 1, 2, skin); }   // v8d：斜め上（右向き。ほほが少し見える）
    else { g.r(4, 5, 8, 3, hair); g.r(5, 8, 6, 1, '#3a2418'); }
    g.r(4, 9, 8, 3, shirt); g.r(4, 11, 8, 1, shirtD);
    g.r(3, 9 + (f === 1 ? 1 : 0), 1, 3, skin); g.r(12, 9 + (f === 2 ? 1 : 0), 1, 3, skin);
    g.r(5, 12, 6, 2, pants); g.r(7, 13, 2, 1, pantsD);
    if (f === 2) g.r(5, 14, 2, 1, shoe); else { g.r(5, 14, 2, 1, skin); g.r(5, 15, 2, 1, shoe); }
    if (f === 1) g.r(9, 14, 2, 1, shoe); else { g.r(9, 14, 2, 1, skin); g.r(9, 15, 2, 1, shoe); }
  } else {
    g.r(5, 1, 6, 1, hair); g.r(4, 2, 8, 3, hair); g.r(4, 5, 3, 3, hair);
    g.r(7, 5, 5, 3, skin); g.r(8, 4, 3, 1, skin); g.p(12, 6, skin); g.r(7, 8, 4, 1, skin);
    g.p(10, 5, P.ol); g.p(11, 7, '#f0a090');
    g.r(5, 9, 6, 3, shirt); g.r(5, 11, 6, 1, shirtD);
    const ax = f === 1 ? 1 : f === 2 ? -1 : 0; g.r(7 + ax, 9, 2, 3, '#e0b088');
    g.r(5, 12, 6, 2, pants);
    if (f === 0) { g.r(6, 14, 2, 1, skin); g.r(6, 15, 3, 1, shoe); g.r(9, 14, 1, 1, skin); g.r(9, 15, 2, 1, shoe); }
    else if (f === 1) { g.r(5, 14, 2, 1, skin); g.r(4, 15, 3, 1, shoe); g.r(9, 14, 2, 1, skin); g.r(10, 15, 3, 1, shoe); }
    else { g.r(7, 14, 2, 1, skin); g.r(7, 15, 3, 1, shoe); g.r(8, 13, 2, 1, pantsD); }
  }
}

const SPR = {};
const PL = [[], [], [], [], [], [], [], []];   // v8d：斜め4つを追加（4左下 5右下 6左上 7右上）
const PLA = [[], [], [], [], [], [], [], []];   // v6b：防具を着た絵 // [dir][frame]
const ICON = {};      // canvas
const ICON_URL = {};  // dataURL
const POR = {};       // 立ち絵（会話用）

function buildSprites() {
  const S = SPR;
  const trunk = g => { g.r(6, 20, 4, 12, P.wood); g.r(6, 20, 1, 12, P.woodD); g.r(9, 21, 1, 9, P.woodL); g.r(5, 30, 6, 2, P.woodD); };
  S.treeA = mk(16, 32, g => { trunk(g); g.e(8, 12.5, 6.6, 8, P.leafD); g.e(7.6, 11.2, 5.8, 6.6, P.leaf); g.e(6.2, 8.4, 3.2, 2.8, P.leafL);
    for (const [x, y] of [[10, 14], [4, 13], [11, 9], [7, 16], [12, 12]]) g.p(x, y, P.leafD); g.p(9, 6, P.leafL); g.p(4, 9, P.leafL); });
  S.treeB = mk(16, 32, g => { trunk(g); g.e(8, 13, 6.8, 7.2, '#22663a'); g.e(8, 12, 5.8, 6, '#33904a'); g.e(6.5, 9.5, 2.8, 2.4, '#5cc057');
    for (const [x, y] of [[11, 15], [5, 14], [10, 9], [8, 17]]) g.p(x, y, '#22663a'); g.p(10, 7, '#5cc057'); });
  S.stump = mk(16, 16, g => { g.r(5, 10, 6, 5, P.wood); g.r(5, 10, 1, 5, P.woodD); g.e(8, 10.5, 3, 1.5, P.woodL); g.p(8, 10, P.wood); g.r(4, 14, 8, 1, P.woodD); });
  S.palm = mk(16, 32, g => {
    for (let i = 0; i < 21; i++) { const y = 31 - i, x = Math.round(6 + Math.sin(i / 6.5) * 1.6); g.r(x, y, 3, 1, i % 3 === 0 ? '#7a5530' : '#a87a4a'); g.p(x, y, '#7a5530'); }
    for (const [lx, ly] of [[1, 15], [2, 7], [7, 2], [13, 3], [15, 9], [14, 15]]) { g.l(8, 11, lx, ly + 1, '#1f6e2e'); g.l(8, 10, lx, ly, '#3ea24a'); if (ly < 10) g.l(8, 9, lx, ly - 1, '#6cc04a'); }
    g.e(8, 10, 2, 1.6, '#2f8a3e');
  });
  S.coco = mk(4, 4, g => { g.e(2, 2, 1.7, 1.7, '#6b4423'); g.p(1, 1, '#8a5a30'); }, false);
  const bush = g => { g.e(8, 10.5, 6.5, 4.8, P.leafD); g.e(7.6, 9.6, 5.6, 4, P.leaf); g.e(5.6, 8, 2.2, 1.6, P.leafL); g.p(10, 12, P.leafD); g.p(4, 11, P.leafD); };
  S.bush = mk(16, 16, bush);
  S.bushB = mk(16, 16, g => { bush(g); for (const [x, y] of [[5, 10], [9, 8], [11, 11], [7, 12], [12, 8]]) { g.r(x, y, 2, 2, '#d4304a'); g.p(x, y, '#ff8aa0'); } });
  S.grass = mk(16, 16, g => { g.l(4, 15, 2, 9, '#3f8f36'); g.l(5, 15, 6, 7, '#5cb84a'); g.l(7, 15, 8, 6, '#3f8f36'); g.l(9, 15, 10, 8, '#5cb84a'); g.l(10, 15, 13, 9, '#3f8f36'); g.l(12, 15, 14, 11, '#5cb84a'); }, '#24521f');
  S.grassCut = mk(16, 16, g => { for (const x of [4, 6, 8, 10, 12]) g.r(x, 13, 1, 2, '#4a9a3e'); }, '#24521f');
  S.pebble = mk(16, 16, g => { g.e(7, 12, 3, 2, P.stoneD); g.e(6.6, 11.5, 2.4, 1.4, P.stone); g.p(6, 11, P.stoneL); g.e(11, 13, 1.6, 1.1, P.stone); });
  S.twig = mk(16, 16, g => { g.l(3, 12, 12, 10, P.woodD); g.l(3, 11, 12, 9, P.wood); g.l(6, 13, 10, 8, P.wood); g.p(10, 8, P.leafL); });
  S.driftwood = mk(16, 16, g => { g.r(2, 10, 12, 3, '#a8957a'); g.r(2, 10, 12, 1, '#c9b89c'); g.r(2, 12, 12, 1, '#7d6c56'); g.p(6, 11, '#7d6c56'); g.r(13, 9, 2, 2, '#a8957a'); });
  S.shell = mk(16, 16, g => { g.e(8, 11, 3.5, 3, '#f6d6cc'); g.l(8, 13, 5, 9, '#e3a596'); g.l(8, 13, 8, 8, '#e3a596'); g.l(8, 13, 11, 9, '#e3a596'); g.r(7, 13, 3, 1, '#e3a596'); });
  S.crate = mk(16, 16, g => { g.r(3, 5, 10, 10, P.wood); g.r(3, 5, 10, 1, P.woodL); g.r(3, 9, 10, 1, P.woodD); g.r(3, 14, 10, 1, P.woodD); g.r(3, 5, 1, 10, P.woodD); g.r(12, 5, 1, 10, P.woodD); g.l(4, 6, 11, 13, P.woodD); for (const [x, y] of [[3, 5], [12, 5], [3, 14], [12, 14]]) g.p(x, y, '#9aa4ad'); });
  S.scrap = mk(16, 16, g => { g.e(8, 12, 6, 3, '#5c6670'); g.r(4, 7, 5, 6, '#8d98a2'); g.r(9, 6, 4, 7, '#7a8590'); g.r(4, 7, 5, 1, '#c8d0d8'); g.p(6, 10, '#b5643a'); g.p(11, 9, '#b5643a'); g.e(11.5, 11.5, 2, 2, '#a9b3bc'); g.p(11, 11, '#4a525a'); });
  const rock = (g, a, b, c) => { g.e(8, 10, 6.5, 5, a); g.e(7.5, 9, 5.5, 4, b); g.e(6, 7.5, 2.5, 1.5, c); };
  S.boulder = mk(16, 16, g => { rock(g, P.stoneD, P.stone, P.stoneL); g.l(9, 10, 11, 12, P.stoneD); });
  S.rubble = mk(16, 16, g => { g.e(5, 12, 2, 1.5, P.stone); g.e(10, 13, 2.5, 1.5, P.stoneD); g.e(8, 11, 1.5, 1, P.stone); });
  S.ironVein = mk(16, 16, g => { rock(g, '#5a5462', '#7a7280', '#9a92a0'); for (const [x, y] of [[5, 8], [9, 10]]) { g.r(x, y, 3, 3, '#d97a3a'); g.p(x, y, '#f0a060'); } });   // v8c：鉄＝大きな斑点2つ
  S.ironVeinD = mk(16, 16, g => { g.e(8, 11, 5.5, 3.6, '#4a4452'); g.e(7.5, 10.4, 4.5, 2.8, '#5f5868'); g.p(7, 11, '#8a5a3a'); });
  // v7b：銅鉱脈・石炭鉱脈・自動採掘機
  S.copperVein = mk(16, 16, g => { rock(g, '#5a5462', '#7a7280', '#9a92a0'); for (const [x, y] of [[4, 8], [7, 7], [10, 8], [5, 11], [8, 10], [11, 11], [6, 13], [10, 13], [9, 6]]) g.p(x, y, '#e08850'); for (const [x, y] of [[7, 7], [8, 10]]) g.p(x + 1, y, '#ffb070'); g.p(6, 12, '#5ab8a0'); g.p(12, 10, '#5ab8a0'); });   // v8c：銅＝小さな斑点がたくさん
  S.copperVeinD = mk(16, 16, g => { g.e(8, 11, 5.5, 3.6, '#4a4452'); g.e(7.5, 10.4, 4.5, 2.8, '#5f5868'); g.p(7, 11, '#b06a3a'); });
  S.coalVein = mk(16, 16, g => { rock(g, '#5a5462', '#7a7280', '#9a92a0'); for (const [x, y] of [[5, 9], [9, 8], [10, 11], [6, 11]]) g.r(x, y, 2, 2, '#1c1c22'); g.p(9, 8, '#5a5a66'); g.p(6, 11, '#4a4a56'); });
  S.coalVeinD = mk(16, 16, g => { g.e(8, 11, 5.5, 3.6, '#4a4452'); g.e(7.5, 10.4, 4.5, 2.8, '#5f5868'); g.p(7, 11, '#22222a'); });
  const minerArt = (lamp, d) => g => {
    g.r(2, 3, 12, 11, '#3a4250'); g.r(3, 4, 10, 9, '#6a7484'); g.r(3, 4, 10, 1, '#8a96a8');   // 本体
    for (let x = 3; x < 13; x += 3) { g.r(x, 9, 2, 1, '#f2c440'); g.r(x + 1, 10, 2, 1, '#2a2a30'); }   // 黄色と黒の帯
    g.r(5, 0, 6, 3, '#3a4250'); g.r(6, 1, 4, 1, '#8a96a8'); g.r(7, 1, 2, 1, lamp);   // 上のランプ
    g.r(5, 14, 6, 2, '#8a96a8'); g.r(6 + d, 15, 2, 2, '#c8d0d8'); g.p(9 - d, 17, '#9aa4b0'); g.p(7, 18, '#c8d0d8'); g.p(8, 18, '#6a7484');   // ドリル（回る）
    g.r(4, 5, 3, 2, '#2a3240'); g.p(5, 5, lamp);   // メーター
  };
  // v7c：木造の家（48×56。下の真ん中がドア）と建設中の4段階、家の中の出入り口
  const houseArt = st => g => {
    const W1 = '#8a5a30', W2 = '#a8703c', W3 = '#5e3c1e', R1 = '#a83c2c', R2 = '#c85a3a', R3 = '#7a2a1e', ST = '#8a8478', ST2 = '#a8a294';
    g.r(1, 50, 46, 6, ST); for (let x = 2; x < 46; x += 5) g.r(x, 51, 3, 2, ST2);   // 基礎
    if (st >= 1) { for (const x of [3, 22, 42]) g.r(x, 22, 3, 28, W3); g.r(2, 22, 44, 3, W3); }   // 柱と梁
    if (st === 0) { for (const x of [2, 44]) g.r(x, 40, 2, 10, W3); }   // 杭
    if (st >= 2) {
      const top = st >= 3 ? 24 : 34; g.r(3, top, 42, 50 - top, W1); for (let y = top + 3; y < 50; y += 4) g.r(3, y, 42, 1, W3); g.r(3, top, 42, 1, W2);   // 丸太の壁
      g.r(17, 34, 14, 16, '#2e1c10'); g.r(18, 35, 12, 15, '#4a2e18'); g.r(18, 35, 12, 1, '#6a4428'); g.p(27, 43, '#f2c440');   // ドア
      if (st >= 3) { for (const wx of [6, 33]) { g.r(wx, 30, 9, 8, W3); g.r(wx + 1, 31, 7, 6, '#a8d8f0'); g.r(wx + 4, 31, 1, 6, W3); g.r(wx + 1, 33, 7, 1, W3); } }   // 窓
    }
    if (st === 3) { for (let y = 2; y < 24; y += 3) { const hw = Math.round((y - 2) * 1.05) + 2; g.r(24 - hw, y, 1, 1, W3); g.r(23 + hw, y, 1, 1, W3); } g.r(22, 2, 4, 22, W3); }   // 屋根の骨組み
    if (st >= 4) {
      for (let y = 2; y < 26; y++) { const hw = Math.min(25, Math.round((y - 2) * 1.05) + 3); g.r(24 - hw, y, hw * 2, 1, y % 3 === 0 ? R3 : (y % 2 ? R1 : R2)); }   // 屋根
      g.r(0, 25, 48, 2, R3); g.r(34, 4, 5, 9, '#6a6a72'); g.r(34, 4, 5, 2, '#4a4a52');   // ひさし・煙突
      g.r(19, 31, 10, 2, R3);   // ドアのひさし
    }
  };
  for (let i = 0; i < 4; i++) S['houseB' + i] = mk(48, 56, houseArt(i)); S.house = mk(48, 56, houseArt(4));
  S.hexit = mk(16, 16, g => { g.r(2, 3, 12, 11, '#7a2a1e'); g.r(3, 4, 10, 9, '#a83c2c'); g.r(3, 4, 10, 1, '#c85a3a'); g.r(7, 6, 2, 4, '#f2e2b0'); g.r(5, 9, 6, 1, '#f2e2b0'); g.r(6, 10, 4, 1, '#f2e2b0'); g.p(7, 11, '#f2e2b0'); g.p(8, 11, '#f2e2b0'); });   // 外へ（下向きの矢印のマット）
  S.minerS = mk(16, 19, minerArt('#d94b4b', 0)); S.minerSOn = mk(16, 19, minerArt('#7fe08a', 0)); S.minerSOn2 = mk(16, 19, minerArt('#7fe08a', 1));   // 1マスの古い採掘機
  // v8b：自動採掘機（2×2マス・32×36）。キャタピラの車体・黄色と黒の帯・前のドリルアーム・上のランプとホッパー
  const minerArt2 = (lamp, d) => g => {
    const D = '#2a303c', B = '#4a5466', M = '#6a7484', L2 = '#8a96a8', Y = '#f2c440', K = '#1e1e24';
    g.r(1, 28, 30, 7, D); for (let x = 2; x < 30; x += 4) g.r(x + (d ? 2 : 0) % 4, 29, 2, 5, '#3c4452'); g.r(1, 28, 30, 1, '#4a5262'); g.r(1, 34, 30, 1, K);   // キャタピラ
    for (const cx of [5, 16, 27]) { g.e(cx, 31.5, 2.4, 2.4, '#5a6474'); g.p(cx, 31, L2); }
    g.r(3, 10, 22, 18, D); g.r(4, 11, 20, 16, B); g.r(4, 11, 20, 2, M); g.r(4, 11, 20, 1, L2);   // 車体
    for (let x = 4; x < 24; x += 4) { g.r(x, 23, 2, 2, Y); g.r(x + 2, 23, 2, 2, K); }   // 黄色と黒の帯
    g.r(6, 14, 7, 6, D); g.r(7, 15, 5, 4, '#a8d8f0'); g.r(7, 15, 5, 1, '#d8f0ff');   // 窓
    g.r(15, 15, 6, 4, '#2a3240'); g.p(16, 16, lamp); g.p(18, 16, Y); g.p(20, 16, '#5ab8f0');   // メーター
    g.r(8, 3, 12, 8, D); g.r(9, 4, 10, 6, M); g.r(9, 4, 10, 1, L2); g.r(10, 6, 8, 3, '#3a3430'); g.p(12, 7, '#8a7a6a'); g.p(15, 6, '#b06a3a'); g.p(14, 8, '#9aa4ae');   // ホッパー（掘った石と鉱石）
    g.r(12, 0, 4, 3, D); g.r(13, 1, 2, 1, lamp);   // 上のランプ
    g.r(24, 14, 4, 4, D); g.r(25, 15, 3, 2, M);   // アームのつけ根
    g.r(26, 17, 3, 9, D); g.r(27, 17, 1, 9, L2);   // アーム
    for (let i = 0; i < 6; i++) { const w = 6 - i; g.r(27 - Math.floor(w / 2) + 1, 26 + i, w, 1, (i + d) % 2 ? '#c8d0d8' : '#8a96a8'); }   // ドリル（回る）
    if (d) { g.p(24, 33, '#9a92a0'); g.p(31, 32, '#9a92a0'); } else { g.p(25, 34, '#9a92a0'); g.p(30, 33, '#7a7280'); }   // 石のくず
  };
  S.miner = mk(32, 36, minerArt2('#d94b4b', 0)); S.minerOn = mk(32, 36, minerArt2('#7fe08a', 0)); S.minerOn2 = mk(32, 36, minerArt2('#7fe08a', 1));
  // v8b：自動伐採機（16×22）。台の上に丸ノコとアーム
  const lumberArt = (lamp, d) => g => {
    const D = '#2a303c', B = '#5a6474', L2 = '#8a96a8', Y = '#f2c440', K = '#1e1e24', W = '#8b5a2b';
    g.r(2, 14, 12, 8, D); g.r(3, 15, 10, 6, B); g.r(3, 15, 10, 1, L2); for (let x = 3; x < 13; x += 4) { g.r(x, 19, 2, 1, Y); g.r(x + 2, 19, 2, 1, K); }   // 台
    g.r(6, 6, 3, 9, D); g.r(7, 6, 1, 9, L2);   // 柱
    g.r(4, 4, 9, 3, D); g.r(5, 5, 7, 1, L2);   // アーム
    g.e(12, 8, 3.6, 3.6, '#c8d0d8'); g.e(12, 8, 1.4, 1.4, D);   // 丸ノコ
    for (let a = 0; a < 6; a++) { const t = (a + d * 0.5) * Math.PI / 3; g.p(Math.round(12 + Math.cos(t) * 4), Math.round(8 + Math.sin(t) * 4), '#ffffff'); }
    g.r(4, 16, 3, 2, '#2a3240'); g.p(5, 16, lamp);   // ランプ
    g.r(9, 16, 3, 3, W); g.r(9, 16, 3, 1, '#b07a40');   // 木材
  };
  S.lumber = mk(16, 22, lumberArt('#d94b4b', 0)); S.lumberOn = mk(16, 22, lumberArt('#7fe08a', 0)); S.lumberOn2 = mk(16, 22, lumberArt('#7fe08a', 1));
  S.crystal = mk(16, 16, g => { g.e(8, 13, 6, 2.5, '#4a4452'); g.r(5, 6, 2, 7, '#5cc8e0'); g.p(5, 5, '#5cc8e0'); g.r(8, 3, 3, 10, '#7fe3f0'); g.r(9, 3, 1, 9, '#c8fbff'); g.p(9, 2, '#7fe3f0'); g.r(11, 7, 2, 6, '#5cc8e0'); g.p(11, 6, '#5cc8e0'); });
  S.crystalD = mk(16, 16, g => { g.e(8, 13, 6, 2.5, '#4a4452'); g.r(6, 11, 2, 2, '#5cc8e0'); g.r(10, 11, 2, 2, '#4aa8c0'); });
  S.goldVein = mk(16, 16, g => { rock(g, '#3e3646', '#564c60', '#6e6478'); for (const [x, y] of [[5, 9], [9, 7], [10, 11], [6, 12]]) g.r(x, y, 2, 2, P.gold); g.p(9, 7, P.goldL); g.p(5, 9, P.goldL); });
  S.goldVeinD = mk(16, 16, g => { g.e(8, 11, 5.5, 3.6, '#3e3646'); g.e(7.5, 10.4, 4.5, 2.8, '#4e4458'); g.p(8, 10, P.goldD); });
  S.hardRock = mk(16, 16, g => { g.e(8, 9, 7.2, 6.6, '#2e2833'); g.e(7.5, 8, 6, 5, '#463e50'); g.e(6, 6, 2.5, 1.5, '#625a6e'); g.l(5, 9, 8, 12, '#1a161e'); g.l(8, 12, 11, 9, '#1a161e'); g.l(10, 5, 11, 8, '#1a161e'); g.p(12, 11, '#8a3a3a'); g.p(4, 7, '#8a3a3a'); });
  S.diary = mk(16, 16, g => { g.r(4, 6, 8, 9, '#f3ead2'); g.r(4, 6, 8, 1, '#fffaf0'); for (const y of [8, 10, 12]) g.r(5, y, 6, 1, '#a89a7a'); g.p(11, 6, '#d0c4a6'); g.r(3, 7, 1, 8, '#c9a46a'); });
  const ped = g => { g.r(2, 15, 12, 8, P.stone); g.r(2, 15, 12, 1, P.stoneL); g.r(2, 22, 12, 1, P.stoneD); g.r(3, 17, 10, 1, P.stoneD); g.p(4, 19, P.stoneD); g.p(11, 20, P.stoneD); };
  S.shrine = mk(16, 24, g => { ped(g); g.e(8, 11.5, 5.2, 3.6, P.goldD); g.e(8, 11, 4.6, 3, P.gold); for (const [x, y] of [[6, 10], [8, 9], [10, 10], [7, 12], [9, 12]]) g.p(x, y, P.goldD); g.e(13.6, 11.5, 1.6, 1.3, P.gold); g.p(14, 11, '#3a2a10'); g.p(4, 14, P.goldD); g.p(11, 14, P.goldD); g.p(6, 9, P.goldL); });
  S.shrineEmpty = mk(16, 24, g => { ped(g); g.r(5, 14, 6, 1, P.stoneD); });
  S.stairsDown = mk(16, 16, g => { g.r(1, 1, 14, 14, '#08060c'); g.r(1, 1, 14, 1, '#8a8296'); g.r(1, 1, 1, 14, '#5a5266'); g.r(14, 1, 1, 14, '#5a5266'); for (let i = 0; i < 4; i++) g.r(2 + i, 3 + i * 3, 12 - i * 2, 2, ['#7a7086', '#5e5668', '#443e4e', '#2c2834'][i]); });
  S.stairsUp = mk(16, 16, g => { g.r(1, 1, 14, 14, '#2c2834'); for (let i = 0; i < 4; i++) g.r(1 + i, 12 - i * 3, 14 - i * 2, 3, ['#5e5668', '#7a7086', '#958ca0', '#b4aabe'][i]); g.r(6, 1, 4, 2, '#d8cfe0'); });
  S.cave = mk(32, 24, g => { g.e(16, 14, 15, 9.6, P.stoneD); g.e(15.5, 12.6, 13.6, 8.2, P.stone); g.e(10, 8, 4, 2, P.stoneL); g.e(22, 9, 3, 1.5, P.stoneL);
    g.p(6, 15, P.stoneD); g.p(25, 13, P.stoneD); g.p(4, 12, '#5a8a3a'); g.p(27, 16, '#5a8a3a'); g.e(16, 16.5, 6, 5.5, '#0d0b12'); g.r(10, 17, 12, 7, '#0d0b12'); });
  S.exit = mk(16, 16, g => { g.r(5, 0, 1, 16, P.woodL); g.r(10, 0, 1, 16, P.woodL); for (let y = 1; y < 16; y += 3) g.r(5, y, 6, 1, P.wood); });
  const fire = g => { g.e(8, 13, 6, 2.4, P.stoneD); g.e(8, 12.6, 4.8, 1.8, '#3a2a1a'); g.l(4, 13, 12, 11, P.woodD); g.l(4, 11, 12, 13, P.wood); for (const [x, y] of [[2, 13], [5, 15], [10, 15], [13, 13]]) g.r(x, y, 2, 1, P.stone); };
  S.fire0 = mk(16, 16, g => { fire(g); g.e(8, 8.5, 3, 4, '#e8602a'); g.e(8, 9.5, 2, 2.6, '#f2c440'); g.p(8, 4, '#e8602a'); g.p(7, 10, '#fff6c0'); });
  S.fire1 = mk(16, 16, g => { fire(g); g.e(7.6, 9, 3.2, 3.6, '#e8602a'); g.e(8, 9.6, 2, 2.4, '#f2c440'); g.p(7, 5, '#e8602a'); g.p(9, 4, '#e8602a'); g.p(8, 10, '#fff6c0'); });
  const bench = g => { g.r(2, 7, 12, 3, P.woodL); g.r(2, 7, 12, 1, '#d09a5a'); g.r(2, 10, 12, 1, P.woodD); g.r(3, 11, 2, 4, P.woodD); g.r(11, 11, 2, 4, P.woodD); g.r(5, 12, 6, 1, P.wood); g.r(8, 5, 5, 2, P.stoneL); g.p(12, 5, P.stoneD); g.r(4, 4, 1, 3, P.wood); g.r(3, 4, 3, 1, P.stoneD); };
  S.bench = mk(16, 16, bench);
  S.bench2 = mk(16, 16, g => { bench(g); g.r(2, 7, 12, 1, '#9aa4ad'); g.r(11, 4, 3, 3, '#6c7680'); g.p(12, 4, '#9aa4ad'); });
  S.bed = mk(16, 16, g => { g.r(1, 6, 14, 9, '#5f8f3a'); g.r(2, 7, 12, 7, '#7fb04a'); g.l(6, 9, 13, 9, '#6a9a40'); g.l(6, 11, 13, 11, '#6a9a40'); g.r(2, 7, 4, 3, '#e8d9b0'); g.p(2, 7, '#fff4d8'); });
  const fur = g => { g.r(10, 1, 3, 5, P.stoneD); g.r(10, 1, 3, 1, P.stone); g.e(8, 10, 6.6, 5.8, P.stoneD); g.e(7.6, 9.4, 5.6, 4.8, P.stone); g.p(5, 7, P.stoneL); g.p(9, 6, P.stoneL); g.r(6, 10, 4, 4, '#2a1a10'); };
  S.furnace = mk(16, 16, fur);
  S.furnaceOn = mk(16, 16, g => { fur(g); g.r(6, 11, 4, 3, '#ff8a2a'); g.r(7, 12, 2, 2, '#ffd060'); });
  S.box = mk(16, 16, g => { g.r(2, 5, 12, 10, '#e3a826'); g.r(2, 5, 12, 2, '#f6d660'); g.r(2, 14, 12, 1, '#a8781a'); g.r(1, 4, 14, 1, '#c58f1e');
    for (let i = 0; i < 12; i += 4) g.r(2 + i, 13, 2, 1, '#2a2010');
    const k = '#2a2010'; g.r(6, 7, 4, 1, k); g.p(6, 8, k); g.r(6, 9, 4, 1, k); g.p(9, 10, k); g.r(6, 11, 4, 1, k); g.r(8, 6, 1, 7, k); });
  const drone = g => { g.r(2, 3, 12, 1, '#6c7680'); g.r(7, 2, 2, 2, '#6c7680'); g.e(8, 7.5, 4.6, 3.6, '#d8d8e4'); g.e(8, 6.6, 3.8, 2.4, '#f4f4fa'); g.e(8, 7.6, 1.8, 1.8, P.gold); g.p(8, 7, '#fff8c0'); g.r(4, 10, 1, 2, '#6c7680'); g.r(11, 10, 1, 2, '#6c7680'); };
  S.drone0 = mk(16, 12, g => { drone(g); g.r(0, 1, 6, 1, '#b9bcc6'); g.r(10, 1, 6, 1, '#b9bcc6'); });
  S.drone1 = mk(16, 12, g => { drone(g); g.r(2, 1, 2, 1, '#b9bcc6'); g.r(12, 1, 2, 1, '#b9bcc6'); });
  S.hut = mk(32, 32, g => {
    g.r(4, 15, 24, 16, P.woodD); g.r(5, 16, 22, 14, P.wood);
    for (let y = 18; y < 30; y += 3) g.r(5, y, 22, 1, P.woodD);
    g.r(13, 20, 6, 11, '#21140c'); g.r(14, 21, 4, 10, '#2e1c10'); g.r(7, 19, 4, 4, '#21140c'); g.p(8, 20, '#4a3a2a');
    for (let y = 3; y < 16; y++) { const hw = Math.round((y - 3) * 1.15) + 2; g.r(16 - hw, y, hw * 2, 1, y % 2 ? '#b58a4a' : '#c9a46a'); }
    g.clear(19, 8, 3, 2); g.clear(20, 10, 2, 1); g.clear(9, 12, 2, 2); g.r(3, 15, 26, 1, '#8a6a3a');
  });
  S.wreck = mk(48, 32, g => {
    g.l(16, 15, 22, 1, P.woodD); g.l(17, 15, 23, 1, P.woodD);
    g.r(20, 4, 9, 6, '#d8d0b8'); g.clear(25, 7, 4, 3);
    for (let y = 14; y < 31; y++) { const x0 = Math.round(2 + (y - 14) * 0.25), x1 = Math.round(46 - (y - 14) * 0.9); g.r(x0, y, x1 - x0, 1, y % 3 === 0 ? '#4a2e1a' : '#6b4423'); }
    g.r(2, 14, 44, 2, '#8b5a2b'); g.r(2, 14, 44, 1, '#a87444'); g.e(31, 22, 4, 3, '#140c08'); g.e(12, 25, 2, 1.5, '#140c08');
    for (const [x, y] of [[8, 20], [38, 18], [20, 27]]) g.p(x, y, '#b5643a');
  });
  S.raftSpot = mk(16, 16, g => { g.r(3, 6, 2, 9, P.wood); g.r(11, 6, 2, 9, P.wood); g.r(3, 6, 2, 1, P.woodL); g.r(11, 6, 2, 1, P.woodL); g.l(5, 8, 10, 8, '#c9a46a'); g.l(5, 10, 10, 9, '#c9a46a'); });
  S.raft = mk(16, 28, g => {
    for (let i = 0; i < 5; i++) g.r(1 + i * 3, 15, 3, 12, i % 2 ? '#a06a35' : '#8b5a2b');
    g.r(1, 18, 15, 1, '#c9a46a'); g.r(1, 24, 15, 1, '#c9a46a');
    g.r(7, 1, 2, 16, P.woodD); for (let y = 2; y < 14; y++) g.r(9, y, Math.round((y - 1) * 0.5), 1, '#f3ead2');
  });
  S.rock = mk(8, 8, g => { g.e(4, 4, 3, 3, P.stoneD); g.e(3.6, 3.6, 2.4, 2.4, P.stone); g.p(3, 3, P.stoneL); });
  S.bob = mk(4, 4, g => { g.r(1, 0, 2, 2, '#e84a4a'); g.r(1, 2, 2, 1, '#f3f3f3'); }, false);
  // プレイヤー
  // v6b：鉄の防具を装備している時の絵
  for (let f = 0; f < 3; f++) {
    PLA[0][f] = mk(16, 16, g => { drawPlayer(g, 'down', f); drawArmor(g, 'down', f); });
    PLA[1][f] = mk(16, 16, g => { drawPlayer(g, 'up', f); drawArmor(g, 'up', f); });
    PLA[3][f] = mk(16, 16, g => { drawPlayer(g, 'side', f); drawArmor(g, 'side', f); });
    PLA[2][f] = flipH(PLA[3][f]);
    PLA[5][f] = mk(16, 16, g => { drawPlayer(g, 'dd', f); drawArmor(g, 'dd', f); }); PLA[4][f] = flipH(PLA[5][f]);   // v8d：斜め
    PLA[7][f] = mk(16, 16, g => { drawPlayer(g, 'du', f); drawArmor(g, 'du', f); }); PLA[6][f] = flipH(PLA[7][f]);
  }
  for (let f = 0; f < 3; f++) {
    PL[0][f] = mk(16, 16, g => drawPlayer(g, 'down', f));
    PL[1][f] = mk(16, 16, g => drawPlayer(g, 'up', f));
    PL[3][f] = mk(16, 16, g => drawPlayer(g, 'side', f));
    PL[2][f] = flipH(PL[3][f]);
    PL[5][f] = mk(16, 16, g => drawPlayer(g, 'dd', f)); PL[4][f] = flipH(PL[5][f]);   // v8d：斜め
    PL[7][f] = mk(16, 16, g => drawPlayer(g, 'du', f)); PL[6][f] = flipH(PL[7][f]);
  }
}

const ICONDRAW = {
  stone: g => { g.e(8, 9, 5.6, 4.6, P.stoneD); g.e(7.6, 8.4, 4.6, 3.6, P.stone); g.e(6, 7, 2, 1.2, P.stoneL); },
  branch: g => { g.l(3, 13, 13, 3, P.woodD); g.l(3, 12, 12, 3, P.wood); g.l(8, 8, 12, 10, P.wood); g.r(11, 9, 2, 2, P.leafL); },
  fiber: g => { g.l(4, 13, 8, 2, '#7aa84a'); g.l(6, 13, 10, 2, '#9ac46a'); g.l(8, 13, 12, 3, '#7aa84a'); g.l(10, 13, 13, 5, '#9ac46a'); g.r(5, 8, 7, 2, '#c9a46a'); },
  wood: g => { g.r(2, 6, 11, 6, P.wood); g.r(2, 6, 11, 1, P.woodL); g.r(2, 11, 11, 1, P.woodD); g.e(13, 9, 2.4, 3.2, '#d8a868'); g.p(13, 9, P.woodL); g.p(5, 8, P.woodD); g.p(9, 10, P.woodD); },
  driftwood: g => { g.r(2, 7, 12, 4, '#a8957a'); g.r(2, 7, 12, 1, '#c9b89c'); g.r(2, 10, 12, 1, '#7d6c56'); g.p(6, 8, '#7d6c56'); g.p(10, 9, '#7d6c56'); },
  plank: g => { g.r(2, 4, 12, 3, '#c99a5a'); g.r(2, 8, 12, 3, '#b5864a'); g.r(2, 12, 12, 2, '#c99a5a'); g.r(2, 7, 12, 1, '#7a5028'); g.r(2, 11, 12, 1, '#7a5028'); g.p(5, 5, '#9a6a38'); g.p(10, 9, '#9a6a38'); },
  rope: g => { g.e(8, 8, 5.6, 5.6, '#c9a46a'); g.e(8, 8, 3.6, 3.6, '#a8844a'); g.e(8, 8, 1.6, 1.6, '#c9a46a'); g.l(12, 12, 14, 14, '#c9a46a'); },
  coconut: g => { g.e(8, 9, 5.6, 5.2, '#6b4423'); g.e(7, 7.6, 3.4, 2.8, '#8a5a30'); g.p(7, 9, '#2a1a10'); g.p(9, 9, '#2a1a10'); g.p(8, 11, '#2a1a10'); },
  berry: g => { g.e(5.5, 9.5, 2.6, 2.6, '#c8304a'); g.e(10.5, 9.5, 2.6, 2.6, '#c8304a'); g.e(8, 12.5, 2.6, 2.6, '#c8304a'); g.p(5, 8, '#ff8aa0'); g.p(10, 8, '#ff8aa0'); g.p(7, 11, '#ff8aa0'); g.r(7, 4, 3, 2, P.leaf); g.p(8, 6, P.leafD); },
  fish: g => { g.e(7, 8, 5, 3, '#6aa8d0'); g.e(7, 9.4, 4, 1.4, '#cfe6f2'); g.l(11, 8, 14, 5, '#4a88b0'); g.l(11, 8, 14, 11, '#4a88b0'); g.r(13, 5, 1, 7, '#4a88b0'); g.p(4, 7, P.ol); g.p(7, 6, '#9fd0ee'); },
  bigfish: g => { g.e(7, 8, 5.5, 3.6, '#e0607a'); g.e(7, 9.6, 4.4, 1.6, '#f6c0c8'); g.l(12, 8, 15, 4, '#c04a60'); g.l(12, 8, 15, 12, '#c04a60'); g.r(14, 4, 1, 9, '#c04a60'); g.p(3, 7, P.ol); g.p(6, 5, '#ffa0b0'); },
  grilled: g => { g.l(1, 14, 15, 2, P.woodL); g.e(8, 8, 5, 3, '#b5703a'); g.e(8, 7, 4, 1.6, '#d08a4a'); g.l(6, 6, 6, 10, '#5a3a22'); g.l(9, 6, 9, 10, '#5a3a22'); g.p(4, 7, P.ol); },
  boot: g => { g.r(5, 2, 6, 9, '#5a4a3a'); g.r(5, 9, 9, 4, '#5a4a3a'); g.r(5, 13, 10, 1, '#2a2420'); g.r(6, 3, 4, 1, '#7a6a58'); },
  shell: g => { g.e(8, 9, 5, 4.4, '#f6d6cc'); g.l(8, 13, 4, 7, '#e0a090'); g.l(8, 13, 8, 5, '#e0a090'); g.l(8, 13, 12, 7, '#e0a090'); g.r(6, 13, 5, 1, '#e0a090'); },
  rareshell: g => { g.e(8, 9, 5, 4.6, '#f7b7d0'); g.e(7, 8, 2.6, 2.2, '#fde4ee'); g.l(5, 9, 9, 7, '#d06a9a'); g.l(9, 7, 10, 10, '#d06a9a'); g.l(12, 11, 14, 13, '#d06a9a'); g.p(6, 7, '#ffffff'); g.p(11, 6, '#9fe0ff'); },
  accessory: g => { for (let a = 0; a <= Math.PI + 0.01; a += 0.15) g.p(Math.round(8 + Math.cos(a) * 6), Math.round(3 + Math.sin(a) * 6), '#c9a46a'); g.e(8, 11.5, 2.6, 2.2, '#f7b7d0'); g.p(8, 11, '#ffffff'); g.p(4, 7, '#4aa3df'); g.p(12, 7, '#4aa3df'); },
  metal: g => { g.r(3, 5, 10, 7, '#9aa4ad'); g.r(3, 5, 10, 1, '#c8d0d8'); g.r(3, 11, 10, 1, '#6c7680'); g.p(5, 7, '#4a525a'); g.p(10, 7, '#4a525a'); g.p(7, 9, '#b5643a'); g.p(11, 10, '#b5643a'); g.r(12, 3, 2, 3, '#9aa4ad'); },
  ironore: g => { g.e(8, 9, 5.6, 4.6, '#6c6070'); g.e(7.6, 8.4, 4.6, 3.6, '#857a8a'); g.r(5, 7, 3, 3, '#d97a3a'); g.r(9, 9, 3, 3, '#d97a3a'); g.p(5, 7, '#f0a060'); g.p(9, 9, '#f0a060'); },   // v8c：鉄＝大きな斑点2つ
  ingot: g => { g.r(3, 8, 10, 4, '#8d98a2'); g.r(4, 7, 8, 1, P.iron); g.r(3, 11, 10, 1, '#5d6670'); g.p(5, 9, '#d8e0e8'); },
  crystal: g => { g.r(4, 6, 2, 8, '#5cc8e0'); g.p(4, 5, '#5cc8e0'); g.r(7, 3, 3, 11, '#7fe3f0'); g.r(8, 3, 1, 10, '#c8fbff'); g.p(8, 2, '#7fe3f0'); g.r(11, 7, 2, 7, '#5cc8e0'); g.p(11, 6, '#5cc8e0'); },
  goldore: g => { g.e(8, 9, 5.6, 4.6, '#5d5466'); g.e(7.6, 8.4, 4.6, 3.6, '#776c80'); g.r(5, 7, 2, 2, P.gold); g.r(9, 9, 2, 2, P.gold); g.p(9, 6, P.goldL); g.p(6, 10, P.gold); },
  goldbar: g => { g.r(2, 8, 12, 4, P.goldD); g.r(3, 7, 10, 1, P.goldL); g.r(2, 8, 12, 3, P.gold); g.r(4, 8, 3, 1, P.goldL); },
  coin: g => { g.e(8, 8, 5.2, 5.2, '#c8961e'); g.e(8, 8, 4.2, 4.2, P.gold); g.r(7, 6, 2, 4, P.goldD); g.p(6, 5, P.goldL); },
  canned: g => { g.r(4, 3, 8, 11, '#b9bcc6'); g.r(4, 3, 8, 1, '#e8e8f0'); g.r(4, 7, 8, 4, '#d94b4b'); g.r(5, 8, 3, 2, '#f3ead2'); g.r(4, 13, 8, 1, '#8a8d99'); },
  ladder: g => { g.r(4, 1, 2, 14, '#7a5a30'); g.r(10, 1, 2, 14, '#7a5a30'); g.r(4, 1, 1, 14, '#d8b878'); g.r(10, 1, 1, 14, '#d8b878'); for (let y = 3; y < 15; y += 3) { g.r(5, y, 5, 1, '#a06a35'); g.r(5, y + 1, 5, 1, '#5a3a1c'); } },
  saliva: g => { g.e(8, 10.5, 3.8, 3.8, '#a9dbe8'); g.r(7, 4, 2, 3, '#a9dbe8'); g.p(8, 3, '#a9dbe8'); g.e(8, 10.5, 2.8, 2.8, '#d4f1f8'); g.e(6.6, 9.4, 1, 1.4, '#ffffff'); g.p(10, 13, '#7fb8c9'); },
  protein: g => { g.r(5, 6, 6, 8, '#eef0f4'); g.r(5, 6, 1, 8, '#ffffff'); g.r(5, 9, 6, 3, '#c87a4a'); g.r(6, 10, 2, 1, '#e8a878'); g.r(5, 13, 6, 1, '#b8bcc6'); g.r(4, 3, 8, 3, '#2a6ad0'); g.r(4, 3, 8, 1, '#5a92f0'); g.r(7, 1, 2, 2, '#2a6ad0'); },
  medkit: g => { g.r(2, 5, 12, 8, '#f3f3f3'); g.r(2, 12, 12, 1, '#c8c8c8'); g.r(7, 6, 2, 6, '#d94b4b'); g.r(5, 8, 6, 2, '#d94b4b'); g.r(6, 3, 4, 2, '#9aa4ad'); },
  cloth: g => { g.r(3, 4, 10, 9, '#f3ead2'); g.r(3, 8, 10, 1, '#d8ccb0'); g.r(3, 12, 10, 1, '#c8bca0'); g.r(3, 4, 10, 1, '#fffaf0'); },
  grilledSardine: g => { g.l(1, 14, 15, 2, P.woodL); g.e(8, 8, 5, 2.6, '#9a7a5a'); g.e(8, 9, 4, 1, '#c8a888'); g.l(5, 7, 6, 9, '#3a1a08'); g.l(8, 7, 9, 9, '#3a1a08'); g.l(11, 7, 11, 9, '#3a1a08'); g.p(4, 7, '#1a0a04'); g.l(12, 8, 14, 6, '#9a7a5a'); g.l(12, 8, 14, 10, '#9a7a5a'); },
  grilledAji: g => { g.l(1, 14, 15, 2, P.woodL); g.e(8, 8, 5, 2.6, '#a8703a'); g.e(8, 9, 4, 1, '#d8a870'); g.l(5, 7, 6, 9, '#3a1a08'); g.l(8, 7, 9, 9, '#3a1a08'); g.l(11, 7, 11, 9, '#3a1a08'); g.p(4, 7, '#1a0a04'); g.l(12, 8, 14, 6, '#a8703a'); g.l(12, 8, 14, 10, '#a8703a'); },
  grilledTai: g => { g.l(1, 14, 15, 2, P.woodL); g.e(8, 8, 5, 2.6, '#c0603a'); g.e(8, 9, 4, 1, '#e8a070'); g.l(5, 7, 6, 9, '#3a1a08'); g.l(8, 7, 9, 9, '#3a1a08'); g.l(11, 7, 11, 9, '#3a1a08'); g.p(4, 7, '#1a0a04'); g.l(12, 8, 14, 6, '#c0603a'); g.l(12, 8, 14, 10, '#c0603a'); },
  grilledKatsuo: g => { g.l(1, 14, 15, 2, P.woodL); g.e(8, 8, 5, 2.6, '#6a4a3a'); g.e(8, 9, 4, 1, '#b08a70'); g.l(5, 7, 6, 9, '#3a1a08'); g.l(8, 7, 9, 9, '#3a1a08'); g.l(11, 7, 11, 9, '#3a1a08'); g.p(4, 7, '#1a0a04'); g.l(12, 8, 14, 6, '#6a4a3a'); g.l(12, 8, 14, 10, '#6a4a3a'); },
  grilledTako: g => { g.l(1, 14, 15, 2, P.woodL); g.e(8, 6, 4.4, 3.4, '#a8402a'); g.e(7, 5, 1.6, 1, '#d07050'); for (let i = 0; i < 4; i++) g.l(4 + i * 2.6, 9, 3 + i * 3, 13, '#8a3020'); g.l(6, 5, 7, 7, '#3a1a08'); g.l(9, 5, 10, 7, '#3a1a08'); },
  grilledFugu: g => { g.l(1, 14, 15, 2, P.woodL); g.e(8, 8, 4.8, 4.2, '#b08a48'); g.e(8, 10, 3.6, 1.6, '#e0c890'); g.l(5, 6, 6, 9, '#4a2a10'); g.l(9, 6, 10, 9, '#4a2a10'); g.p(5, 7, '#1a0a04'); g.l(13, 8, 15, 6, '#8a6a30'); g.l(13, 8, 15, 10, '#8a6a30'); },
  chest: g => { g.r(2, 5, 12, 9, '#8b5a2b'); g.r(2, 5, 12, 3, '#a06a35'); g.r(2, 8, 12, 1, '#4a2e1f'); g.r(2, 5, 1, 9, '#6b4423'); g.r(13, 5, 1, 9, '#6b4423'); g.r(7, 7, 2, 3, P.gold); g.p(7, 9, '#7a5a10'); g.r(3, 13, 10, 1, '#4a2e1f'); },
  turtle: g => { g.e(8, 9, 5.2, 3.6, P.goldD); g.e(8, 8.4, 4.6, 3, P.gold); for (const [x, y] of [[6, 7], [8, 6], [10, 7], [8, 9]]) g.p(x, y, P.goldD); g.e(13.6, 9, 1.6, 1.3, P.gold); g.p(14, 8, '#3a2a10'); g.p(4, 12, P.goldD); g.p(11, 12, P.goldD); g.p(6, 6, P.goldL); },
  ledger: g => { g.r(3, 2, 10, 12, '#4a2a2a'); g.r(4, 3, 8, 10, '#6b3a3a'); g.r(12, 3, 1, 11, '#e8dcc0'); g.r(5, 5, 6, 2, P.gold); g.r(5, 9, 5, 1, '#8a5a5a'); },
  stoneAxe: g => axeArt(g, P.stoneL, P.stone, P.stoneD, '#e4e6ee'),   // v6.2：マイクラ風の角ばった斧（以前は丸い刃）
  ironAxe: g => axeArt(g, P.ironL, P.iron, P.ironD, '#ffffff'),
  stonePick: g => { g.l(4, 14, 10, 4, P.woodD); g.l(5, 14, 11, 4, P.wood); g.l(3, 6, 8, 3, P.stone); g.l(8, 3, 14, 5, P.stone); g.l(3, 5, 8, 2, P.stoneL); g.l(8, 2, 14, 4, P.stoneL); },
  ironPick: g => { g.l(4, 14, 10, 4, P.woodD); g.l(5, 14, 11, 4, P.wood); g.l(3, 6, 8, 3, P.iron); g.l(8, 3, 14, 5, P.iron); g.l(3, 5, 8, 2, P.ironL); g.l(8, 2, 14, 4, P.ironL); },
  bow: g => { g.l(4, 2, 2, 6, P.woodD); g.l(2, 6, 2, 10, P.woodD); g.l(2, 10, 4, 14, P.woodD); g.l(5, 2, 3, 6, P.wood); g.l(3, 10, 5, 14, P.wood); g.r(2, 7, 2, 2, '#c9a46a'); g.l(5, 2, 12, 8, '#e8e8f0'); g.l(12, 8, 5, 14, '#e8e8f0'); },   // v8c：弓
  arrow: g => { g.l(3, 13, 12, 4, P.woodL); g.l(4, 13, 13, 4, P.wood); g.r(12, 2, 2, 2, P.stoneL); g.p(14, 2, P.stone); g.p(12, 4, P.stone); g.r(2, 12, 2, 1, '#f0f0f0'); g.r(3, 14, 1, 2, '#f0f0f0'); g.p(2, 14, '#d84a4a'); },   // v8c：矢
  rod: g => { g.l(2, 14, 12, 2, P.woodD); g.l(3, 14, 13, 2, P.wood); g.l(13, 2, 13, 11, '#e8e8f0'); g.r(12, 11, 3, 2, '#e84a4a'); },
  torch: g => { g.r(7, 7, 2, 8, P.wood); g.r(7, 7, 2, 1, P.woodD); g.e(8, 5, 2.6, 3.6, '#e8602a'); g.e(8, 6, 1.6, 2, P.gold); },
  bag: g => { g.e(8, 10, 5.6, 4.6, '#c9a46a'); g.r(4, 6, 8, 3, '#a8844a'); g.l(5, 6, 8, 2, '#8a6a3a'); g.l(8, 2, 11, 6, '#8a6a3a'); g.p(8, 8, P.gold); },
  cart: g => { g.r(2, 5, 11, 6, P.wood); g.r(2, 5, 11, 1, P.woodL); g.e(5, 12, 2.2, 2.2, P.woodD); g.e(11, 12, 2.2, 2.2, P.woodD); g.l(13, 6, 15, 3, P.woodD); },
  benchUp: g => { g.drawBench = 1; },
  bowl: g => { g.e(8, 10, 6, 3.6, '#8b5a2b'); g.e(8, 8.6, 5.4, 1.6, '#4a2e1f'); g.r(4, 13, 8, 1, '#6b4423'); g.p(4, 10, '#b07a45'); },
  rawwater: g => { g.e(8, 10, 6, 3.6, '#8b5a2b'); g.e(8, 8.6, 5.4, 1.6, '#6a8a6a'); g.p(6, 8, '#a8c098'); g.p(10, 9, '#4a6a4a'); g.r(4, 13, 8, 1, '#6b4423'); },
  cleanwater: g => { g.e(8, 10, 6, 3.6, '#8b5a2b'); g.e(8, 8.6, 5.4, 1.6, '#4ab0e8'); g.p(6, 8, '#e0f8ff'); g.p(10, 9, '#9fe0ff'); g.r(4, 13, 8, 1, '#6b4423'); },
  sardine: g => { g.e(7, 8, 5, 1.8, '#9fb4c8'); g.e(7, 9, 4, 0.8, '#e0eaf2'); g.r(4, 7, 6, 1, '#5a7090'); g.l(11, 8, 13, 6, '#6a8098'); g.l(11, 8, 13, 10, '#6a8098'); g.p(3, 7, P.ol); },
  katsuo: g => { g.e(7, 8, 6, 3.4, '#2a4a8a'); g.e(7, 9.8, 5, 1.4, '#c8d8e8'); for (const x of [5, 7, 9]) g.r(x, 9, 1, 2, '#4a6a9a'); g.l(12, 8, 15, 4, '#1a3a6a'); g.l(12, 8, 15, 12, '#1a3a6a'); g.r(14, 4, 1, 9, '#1a3a6a'); g.p(3, 7, '#ffffff'); },
  octopus: g => { g.e(8, 6, 4.6, 3.8, '#d0503a'); g.e(7, 4.6, 1.6, 1.2, '#f08a70'); for (let i = 0; i < 4; i++) g.l(4 + i * 2.6, 9, 3 + i * 3, 14, '#b0402a'); g.p(6, 7, '#ffffff'); g.p(10, 7, '#ffffff'); },
  fugu: g => { g.e(8, 8, 5, 4.6, '#d8c070'); g.e(8, 10, 4, 2, '#f6eecc'); for (const [x, y] of [[3, 4], [8, 2], [13, 4], [2, 9], [14, 9], [5, 13], [11, 13]]) g.p(x, y, '#8a7030'); g.p(5, 7, P.ol); g.l(13, 8, 15, 6, '#b8a050'); g.l(13, 8, 15, 10, '#b8a050'); },
  meat: g => { g.e(8, 9, 5.2, 4, '#c8505a'); g.e(7, 8, 3, 2, '#e8808a'); g.r(11, 4, 2, 5, '#f0e8d8'); g.e(12, 3.6, 1.6, 1.4, '#f0e8d8'); },
  steak: g => { g.e(8, 9, 5.4, 4, '#7a4022'); g.e(7, 8, 3.2, 2, '#a8602e'); g.l(5, 8, 10, 10, '#4a2810'); g.r(11, 4, 2, 5, '#f0e8d8'); g.e(12, 3.6, 1.6, 1.4, '#f0e8d8'); },
  bossGem: g => { g.e(8, 8, 5, 6, '#1e0c2a'); g.e(8, 8, 3.8, 4.8, '#5a2488'); g.e(7, 6, 1.6, 2, '#c890ff'); g.p(10, 10, '#e8d0ff'); g.p(6, 11, '#3a1858'); },
  crabmeat: g => { g.l(3, 12, 11, 5, '#d0503a'); g.l(4, 12, 12, 5, '#e0604a'); g.e(11, 5, 3, 2.4, '#f6e6dc'); g.e(10.4, 4.6, 1.6, 1.2, '#ffffff'); g.r(2, 12, 3, 2, '#a83a2a'); },
  grilledCrab: g => { g.l(1, 14, 15, 2, P.woodL); g.e(8, 8, 5, 3.4, '#c0502a'); g.e(8, 7, 3.6, 1.6, '#e88050'); g.p(6, 6, '#ffffff'); g.p(10, 6, '#ffffff'); g.l(3, 10, 1, 12, '#a03a1a'); g.l(13, 10, 15, 12, '#a03a1a'); g.l(6, 8, 6, 10, '#5a2a10'); g.l(10, 8, 10, 10, '#5a2a10'); },
  goldMeat: g => { g.e(8, 9, 5.2, 4, '#e0a020'); g.e(7, 8, 3, 2, '#ffe070'); g.r(11, 4, 2, 5, '#fff6d8'); g.e(12, 3.6, 1.6, 1.4, '#fff6d8'); g.p(5, 10, '#fff8c0'); g.p(3, 5, '#fff3a0'); },   // v7a
  goldSteak: g => { g.e(8, 9, 5.4, 4, '#b07810'); g.e(7, 8, 3.2, 2, '#f2c440'); g.l(5, 8, 10, 10, '#7a5008'); g.r(11, 4, 2, 5, '#fff6d8'); g.e(12, 3.6, 1.6, 1.4, '#fff6d8'); g.p(6, 7, '#fff8c0'); g.p(3, 3, '#fff8c0'); g.p(2, 4, '#ffe070'); },   // v7a
  goldHide: g => { g.r(3, 4, 10, 9, '#e0a828'); g.r(2, 6, 12, 5, '#e0a828'); g.r(4, 5, 8, 1, '#fff0a0'); g.p(6, 8, '#b07818'); g.p(10, 10, '#b07818'); g.p(8, 7, '#fff8d0'); g.p(12, 4, '#ffffff'); },   // v7a
  // v7b：新しい素材・部品
  nail: g => { g.r(4, 3, 8, 2, '#c8d0d8'); g.r(4, 3, 8, 1, '#eef2f6'); g.r(7, 5, 2, 8, '#9aa4b0'); g.p(7, 5, '#dce4f0'); g.r(7, 13, 2, 1, '#6a7484'); g.p(8, 14, '#6a7484'); g.p(12, 4, '#9fe8f6'); },   // v7c：釘
  houseKit: g => { g.r(1, 4, 14, 10, '#d8e8f8'); g.r(1, 4, 14, 1, '#ffffff'); g.r(1, 13, 14, 1, '#8aa0b8'); g.r(4, 8, 8, 5, '#3a6ab0'); for (let i = 0; i < 5; i++) g.r(8 - i, 4 + i, i * 2 + 1, 1, '#3a6ab0'); g.r(7, 10, 2, 3, '#d8e8f8'); g.r(12, 1, 2, 4, '#a8703c'); g.r(12, 1, 2, 1, '#c8a060'); },   // v7c：設計キット（図面）
  copperore: g => { g.e(8, 9, 5.4, 4.4, '#7a6a5e'); g.e(7, 8, 3.6, 2.6, '#9a8a7c'); for (const [x, y] of [[4, 8], [6, 6], [9, 7], [11, 9], [5, 11], [8, 10], [10, 12], [7, 13], [12, 11]]) g.p(x, y, '#e08850'); g.p(9, 7, '#ffb070'); g.p(6, 6, '#ffb070'); g.p(11, 11, '#5ab8a0'); },   // v8c：銅＝小さな斑点がたくさん
  coal: g => { g.e(8, 9, 5.4, 4.2, '#24242a'); g.e(7, 8, 3.6, 2.4, '#3a3a44'); g.p(6, 7, '#6a6a78'); g.p(10, 9, '#55555f'); g.p(8, 11, '#55555f'); },
  copper: g => { g.r(2, 7, 12, 5, '#a8582a'); g.r(3, 5, 10, 3, '#e08850'); g.r(4, 5, 7, 1, '#ffc090'); g.r(2, 11, 12, 1, '#7a3a18'); },
  charcoal: g => { g.r(3, 6, 10, 6, '#1e1e24'); g.r(4, 5, 8, 2, '#34343e'); g.r(5, 7, 1, 4, '#4a4a56'); g.r(9, 7, 1, 4, '#4a4a56'); g.p(12, 6, '#ff8a3a'); },
  ironplate: g => { g.r(2, 4, 12, 9, '#6a7484'); g.r(3, 5, 10, 7, '#9aa4b0'); g.r(3, 5, 10, 1, '#d0d8e0'); g.p(4, 6, '#3a4250'); g.p(11, 6, '#3a4250'); g.p(4, 10, '#3a4250'); g.p(11, 10, '#3a4250'); },
  steel: g => { g.r(2, 7, 12, 5, '#4a5262'); g.r(3, 5, 10, 3, '#8a96aa'); g.r(4, 5, 7, 1, '#dce4f0'); g.r(2, 11, 12, 1, '#2a303c'); g.p(12, 6, '#ffffff'); },
  gear: g => { for (let a = 0; a < 8; a++) { const t = a * Math.PI / 4; g.r(Math.round(8 + Math.cos(t) * 5.5) - 1, Math.round(8 + Math.sin(t) * 5.5) - 1, 2, 2, '#8a96a8'); } g.e(8, 8, 4.6, 4.6, '#9aa4b0'); g.e(8, 8, 3.4, 3.4, '#6a7484'); g.e(8, 8, 1.6, 1.6, '#2a303c'); g.p(6, 6, '#dce4f0'); },
  part: g => { g.r(2, 6, 12, 7, '#4a5262'); g.r(3, 7, 10, 5, '#6a7484'); g.e(6, 9.5, 2.6, 2.6, '#9aa4b0'); g.e(6, 9.5, 1, 1, '#2a303c'); g.r(10, 8, 3, 1, '#e08850'); g.r(10, 10, 3, 1, '#e08850'); g.r(5, 4, 6, 2, '#9aa4b0'); },
  motor: g => { g.r(2, 5, 10, 8, '#3a6aa8'); g.r(3, 6, 8, 6, '#5a8ad0'); g.r(3, 6, 8, 1, '#8ab4f0'); for (let y = 7; y < 12; y += 2) g.r(4, y, 6, 1, '#2a4a80'); g.r(12, 8, 3, 2, '#c8d0d8'); g.r(2, 13, 10, 1, '#2a303c'); },
  frame: g => { const c = '#6a7484', d = '#3a4250'; g.r(2, 2, 2, 12, c); g.r(12, 2, 2, 12, c); g.r(2, 2, 12, 2, c); g.r(2, 12, 12, 2, c); g.l(4, 4, 11, 11, d); g.l(11, 4, 4, 11, d); g.p(2, 2, '#dce4f0'); g.p(13, 13, d); },
  drill: g => { g.r(1, 6, 5, 5, '#3a4250'); g.r(2, 7, 3, 3, '#f2c440'); for (let x = 6; x < 15; x++) { const hh = Math.max(1, Math.round((15 - x) * 0.5)); g.r(x, Math.round(8.5 - hh / 2), 1, hh, (x % 2) ? '#c8d0d8' : '#8a96a8'); } g.p(14, 8, '#ffffff'); },
  honey: g => { g.r(4, 5, 8, 9, '#e8a020'); g.r(5, 6, 6, 7, '#f6c040'); g.r(5, 6, 1, 6, '#ffe08a'); g.r(4, 3, 8, 2, '#c8b8a0'); g.r(5, 2, 6, 1, '#a89880'); g.r(6, 9, 4, 1, '#c87a10'); },   // v7a
  hide: g => { g.r(3, 4, 10, 9, '#a07850'); g.r(2, 6, 12, 5, '#a07850'); g.r(4, 5, 8, 1, '#c09a70'); g.p(6, 8, '#7a5838'); g.p(10, 10, '#7a5838'); g.p(8, 7, '#7a5838'); },
  claw: g => { g.e(6, 9, 4, 3.4, '#c83a2a'); g.e(11, 5, 3, 2, '#c83a2a'); g.e(11, 9, 2.6, 1.6, '#c83a2a'); g.p(5, 8, '#f08070'); g.r(2, 11, 3, 2, '#a02a1a'); },
  stoneSword: g => { g.l(3, 13, 12, 4, P.stone); g.l(4, 13, 13, 4, P.stoneL); g.l(3, 10, 6, 13, P.woodD); g.r(2, 13, 2, 2, P.wood); },
  ironArmor: g => { g.r(3, 3, 10, 10, P.ironD); g.r(4, 4, 8, 8, P.iron); g.r(4, 4, 8, 1, P.ironL); g.r(2, 3, 3, 3, P.ironD); g.r(11, 3, 3, 3, P.ironD); g.r(2, 3, 3, 1, P.iron); g.r(11, 3, 3, 1, P.iron); g.r(6, 3, 4, 2, '#3a3f48'); g.r(7, 6, 2, 6, P.ironD); g.r(4, 12, 8, 1, '#5a636e'); g.p(5, 6, P.ironL); },
  ironSword: g => { g.l(3, 13, 13, 3, P.iron); g.l(4, 13, 14, 3, P.ironL); g.l(3, 10, 6, 13, P.gold); g.r(2, 13, 2, 2, P.woodD); },
  bp: g => { g.r(2, 3, 12, 10, '#3a6fb0'); g.r(2, 3, 12, 1, '#5a8fd0'); for (let i = 4; i < 13; i += 3) g.r(3, i, 10, 1, '#7fa8d8'); g.r(7, 4, 1, 8, '#7fa8d8'); g.r(13, 3, 1, 10, '#e8e8f0'); },
};

// v8a：斧の絵を描き直し。刃は柄の上の「前側」（右下）に付けて、持った時に刃が進む向きを向くようにした（以前は刃が顔の方を向いていた）。
// W＝刃先の光、L＝明るい所、M＝中間、K＝柄を通す穴、O＝ふち、h・H＝柄。持つ位置は（3,13）
const AXE_MAP = [
  '................',
  '................',
  '................',
  '................',
  '..........OhH...',
  '.........OKHOOO.',
  '........OKMLLLWO',
  '.......OKMLLLLWO',
  '.......hHLLLLLWO',
  '......hHOLLLLWO.',
  '.....hH.OLLLWWO.',
  '....hH..OLWWOO..',
  '...hH...OWOO....',
  '..hH.....O......',
  '.hH.............',
  'hH..............',
];
function axeArt(g, L, M, K, W) {
  const pal = { W, L, M, K: '#4a4652', O: K, h: P.wood, H: P.woodD };
  AXE_MAP.forEach((row, y) => { for (let x = 0; x < row.length; x++) { const c = pal[row[x]]; if (c) g.p(x, y, c); } });
}
function buildIcons() {
  for (const k in ICONDRAW) if (k !== 'benchUp') ICON[k] = mk(16, 16, ICONDRAW[k]);
  ICON.campfire = SPR.fire0; ICON.workbench = SPR.bench; ICON.bed = SPR.bed; ICON.furnace = SPR.furnaceOn; ICON.benchUp = SPR.bench2;
  ICON.miner = SPR.minerOn;   // v7b
  ICON.lumber = SPR.lumberOn;   // v8b
  ICON.uiZeni = mk(16, 16, g => { g.r(2, 3, 12, 1, '#6c7680'); g.r(7, 2, 2, 2, '#6c7680'); g.e(8, 9, 5.4, 4.4, '#d8d8e4'); g.e(8, 8, 4.4, 3, '#f4f4fa'); g.e(8, 9.4, 2.6, 2.6, P.gold); g.r(7, 7, 2, 5, '#7a5a10'); g.r(6, 8, 4, 1, '#7a5a10'); g.r(6, 10, 4, 1, '#7a5a10'); g.r(4, 13, 1, 2, '#6c7680'); g.r(11, 13, 1, 2, '#6c7680'); g.r(0, 1, 5, 1, '#b9bcc6'); g.r(11, 1, 5, 1, '#b9bcc6'); });   // v8b：ゼニ丸ボタン（$のドローン）
  SPR.chest = ICON.chest;   // チェストは置いた時も同じ絵
  SPR.chestL = mk(32, 16, g => { g.r(1, 4, 30, 10, '#8b5a2b'); g.r(1, 4, 30, 3, '#a06a35'); g.r(1, 7, 30, 1, '#4a2e1f'); g.r(1, 4, 1, 10, '#6b4423'); g.r(30, 4, 1, 10, '#6b4423'); g.r(15, 4, 2, 10, '#6b4423'); g.r(15, 6, 2, 4, P.gold); g.p(15, 9, '#7a5a10'); g.p(16, 9, '#7a5a10'); g.r(2, 13, 28, 1, '#4a2e1f'); g.r(4, 5, 1, 8, '#b07a40'); g.r(27, 5, 1, 8, '#b07a40'); });   // v8b：ラージチェスト（32×16）
  // メニューを開くボタン（アイテムバーの右）のバッグ
  ICON.uiBag = mk(16, 16, g => { g.r(6, 1, 4, 1, '#5a3a1c'); g.r(5, 2, 1, 2, '#5a3a1c'); g.r(10, 2, 1, 2, '#5a3a1c'); g.r(3, 4, 10, 10, '#8b5a2b'); g.r(4, 5, 1, 8, '#b07a40'); g.r(3, 4, 10, 4, '#a06a35'); g.r(3, 8, 10, 1, '#5a3a1c'); g.r(5, 10, 6, 3, '#7a4a22'); g.r(5, 10, 6, 1, '#a06a35'); g.r(7, 7, 2, 3, '#f2c440'); g.r(3, 13, 10, 1, '#4a2e14'); });
  ICON.raft = mk(16, 16, g => { for (let i = 0; i < 5; i++) g.r(1 + i * 3, 9, 3, 6, i % 2 ? '#a06a35' : '#8b5a2b'); g.r(7, 1, 2, 9, P.woodD); for (let y = 2; y < 9; y++) g.r(9, y, Math.round(y * 0.6), 1, '#f3ead2'); });
  // v7a：スマホのクラフトボタン（ハンマー）。オーナーの絵（16×16のドット）をそのまま使う
  { const pal = { a: '#000000', b: '#424242', c: '#bdbdbd', d: '#795548', e: '#757575', f: '#4e342e', g: '#212121' };
    const rows = ['......aaa.......', '..aa.abbca......', '.addabbceea.....', '.afabbceeba.....', '..abbceebba.....', '.aaaceebba......', 'agggaebba.......', 'aggggabafa......',
      'aggggaaffda.....', '.aggga.afdda....', '..aaa...afdda...', '.........afdda..', '..........afdda.', '...........afdda', '............affa', '.............aa.'];
    ICON.uiCraft = mk(16, 16, gg => rows.forEach((row, y) => { for (let x = 0; x < 16; x++) { const c = pal[row[x]]; if (c) gg.p(x, y, c); } })); }
  ICON.rodCast = mk(16, 16, g => { g.l(2, 14, 12, 2, P.woodD); g.l(3, 14, 13, 2, P.wood); g.p(13, 1, '#e8e8f0'); });   // v8f：釣りをしている間の竿（糸とうきは海へ投げているので、竿の先には描かない）
  for (const k in ICON) ICON_URL[k] = ICON[k].toDataURL();
}

function buildPortraits() {
  const skin = '#f2c9a0';
  POR.me = mk(24, 24, g => { g.e(12, 10, 8, 8, '#4a2e1f'); g.e(12, 13, 6.5, 6.5, skin); g.r(5, 5, 14, 4, '#4a2e1f'); g.r(5, 8, 3, 4, '#4a2e1f'); g.r(16, 8, 3, 4, '#4a2e1f');
    g.r(9, 12, 1, 2, P.ol); g.r(14, 12, 1, 2, P.ol); g.p(8, 15, '#f0a090'); g.p(16, 15, '#f0a090'); g.r(11, 17, 3, 1, '#b0604a'); g.r(4, 21, 16, 3, '#ece6d6'); g.r(10, 20, 4, 1, skin); });
  POR.same = mk(24, 24, g => { g.r(3, 20, 18, 4, '#2a2a38'); g.r(10, 20, 4, 4, '#d94b4b'); g.r(8, 21, 8, 1, P.gold); g.e(12, 9, 8, 6, '#3a3a46'); g.e(12, 13, 6.5, 7, '#e0b088'); g.r(5, 5, 14, 3, '#3a3a46'); g.l(6, 6, 17, 4, '#5a5a68');
    g.r(6, 11, 5, 3, '#111'); g.r(13, 11, 5, 3, '#111'); g.r(11, 12, 2, 1, '#111'); g.p(7, 11, '#fff'); g.p(14, 11, '#fff'); g.r(9, 17, 7, 2, '#fff'); g.p(11, 18, '#999'); g.p(13, 18, '#999'); g.l(16, 14, 18, 16, '#b07858'); });
  POR.zeni = mk(24, 24, g => { g.r(1, 4, 9, 1, '#b9bcc6'); g.r(14, 4, 9, 1, '#b9bcc6'); g.r(4, 6, 16, 1, '#6c7680'); g.e(12, 14, 9, 7, '#d8d8e4'); g.e(12, 12.5, 7, 5, '#f4f4fa');
    g.e(12, 14, 3.6, 3.6, P.gold); g.e(12, 14, 1.6, 1.6, '#8a6a1a'); g.p(11, 12, '#fff8c0'); g.r(6, 21, 2, 2, '#6c7680'); g.r(16, 21, 2, 2, '#6c7680'); });
  POR.gen = mk(24, 24, g => { g.r(2, 2, 20, 20, '#efe4c4'); g.r(2, 2, 20, 1, '#fffaf0'); for (let y = 6; y < 20; y += 3) g.r(4, y, 16, 1, '#b8a888'); g.r(2, 2, 2, 20, '#c9a46a'); g.e(16, 15, 3, 3, '#d8c8a0'); g.p(16, 15, '#a89870'); });
}

/* ---------- 7. マップ生成 ---------- */
// v6c：ver 2＝広い島（崖・台地つき）。ver 1＝v6bまでの島（古いセーブ用）
// v8a：マップの種。新しいゲームは毎回ちがう種（game.seed）で島と洞窟を作る。種のない古いセーブは、今までの島（CONFIG.islandSeed）のまま
let MAP_SEED = CONFIG.islandSeed;
function genIsland(ver) { return ver === 2 ? genIsland2() : genIsland1(); }
function genIsland1() {
  const W = 72, H = 56, seed = MAP_SEED, rng = mulberry32(seed);
  const t = new Uint8Array(W * H), D = new Float32Array(W * H), noObj = new Uint8Array(W * H);
  const cx = W / 2, cy = H / 2 + 1;
  const I = (x, y) => y * W + x, inb = (x, y) => x >= 0 && y >= 0 && x < W && y < H;
  const land = (x, y) => inb(x, y) && isLandT(t[I(x, y)]);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const dx = (x + 0.5 - cx) / (W * 0.36), dy = (y + 0.5 - cy) / (H * 0.36), a = Math.atan2(dy, dx);
    const rad = 1 + 0.10 * Math.sin(3 * a + 0.7) + 0.07 * Math.sin(5 * a + 2.1) + 0.04 * Math.sin(8 * a + 4.0);
    const d = Math.hypot(dx, dy) / rad + (vnoise(x / 5, y / 5, seed) - 0.5) * 0.12;
    D[I(x, y)] = d;
    t[I(x, y)] = d > 1.10 ? T.DEEP : d > 0.99 ? T.SHALLOW : d > 0.86 ? T.SAND : T.GRASS;
  }
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (t[I(x, y)] === T.GRASS && vnoise(x / 6 + 20, y / 6 + 20, seed + 1) > 0.56) t[I(x, y)] = T.FOREST;
  // 岩山（北東のしっかりした内陸）
  let hill = null, bs = -1e9;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (D[I(x, y)] < 0.5 && x > cx && y < cy) { const s = (x - cx) + (cy - y) * 1.3; if (s > bs) { bs = s; hill = { x, y }; } }
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const v = t[I(x, y)]; if (v !== T.GRASS && v !== T.FOREST) continue;
    if (Math.hypot(x - hill.x, y - hill.y) < 6.5 + (vnoise(x / 3, y / 3, seed + 2) - 0.5) * 3) t[I(x, y)] = T.ROCK;
  }
  const cave = { x: hill.x, y: hill.y };
  for (let y = cave.y - 3; y <= cave.y + 2; y++) for (let x = cave.x - 3; x <= cave.x + 3; x++) if (land(x, y)) t[I(x, y)] = T.ROCK;
  // 泉
  let spring = null, bd = 1e9;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (D[I(x, y)] < 0.42) { const d = Math.hypot(x - (cx - 3), y - (cy - 3)); if (d < bd) { bd = d; spring = { x, y }; } }
  for (let y = spring.y - 2; y <= spring.y + 3; y++) for (let x = spring.x - 2; x <= spring.x + 3; x++) if (land(x, y)) t[I(x, y)] = T.GRASS;
  for (let y = 0; y < 2; y++) for (let x = 0; x < 2; x++) t[I(spring.x + x, spring.y + y)] = T.SPRING;
  // 西の小屋
  let hut = null; let bx = 1e9;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (D[I(x, y)] < 0.55 && Math.abs(y - (cy - 2)) <= 5 && x < bx) { bx = x; hut = { x, y }; }
  for (let y = hut.y - 2; y <= hut.y + 2; y++) for (let x = hut.x - 1; x <= hut.x + 2; x++) if (land(x, y)) t[I(x, y)] = T.GRASS;
  // 南の浜辺（スタート地点）
  const sx = Math.floor(cx); let sy = Math.floor(cy); while (land(sx, sy + 1)) sy++;
  const spawn = { x: sx, y: sy - 1 };
  let box = { x: sx + 2, y: sy - 2 }; if (!land(box.x, box.y)) box = { x: sx - 2, y: sy - 2 };
  // 桟橋
  const px = sx - 6; let py = Math.floor(cy); while (land(px, py + 1)) py++;
  for (let y = py + 1; y <= py + 5; y++) if (inb(px, y)) t[I(px, y)] = T.PIER;
  const raft = { x: px, y: py + 5 };
  // 難破船
  const wx = sx + 9; let wy = Math.floor(cy); while (land(wx, wy + 1)) wy++;
  for (let y = wy - 1; y <= wy; y++) for (let x = wx; x <= wx + 2; x++) if (inb(x, y)) t[I(x, y)] = T.SAND;
  // 道
  const mark = (x, y, r) => { for (let yy = y - r; yy <= y + r; yy++) for (let xx = x - r; xx <= x + r; xx++) if (inb(xx, yy)) noObj[I(xx, yy)] = 1; };
  const carve = (a, b, keepSand) => {
    let x0 = a.x, y0 = a.y; const x1 = b.x, y1 = b.y, dx = Math.abs(x1 - x0), sxx = x0 < x1 ? 1 : -1, dy = -Math.abs(y1 - y0), syy = y0 < y1 ? 1 : -1; let er = dx + dy;
    for (let i = 0; i < 500; i++) {
      for (const [ox, oy] of [[0, 0], [1, 0], [0, 1]]) { const x = x0 + ox, y = y0 + oy; if (!land(x, y)) continue; if (!(keepSand && t[I(x, y)] === T.SAND)) t[I(x, y)] = T.PATH; }
      mark(x0, y0, 1);
      if (x0 === x1 && y0 === y1) break; const e2 = 2 * er; if (e2 >= dy) { er += dy; x0 += sxx; } if (e2 <= dx) { er += dx; y0 += syy; }
    }
  };
  carve(spawn, { x: spring.x, y: spring.y + 3 });
  carve({ x: spring.x - 1, y: spring.y }, { x: hut.x, y: hut.y + 2 });
  carve({ x: spring.x + 2, y: spring.y - 1 }, { x: cave.x, y: cave.y + 1 });
  carve(spawn, { x: px, y: py }, true);
  carve(spawn, { x: wx + 1, y: wy - 2 }, true);
  mark(spawn.x, spawn.y, 3); mark(box.x, box.y, 2); mark(hut.x, hut.y, 2); mark(hut.x + 1, hut.y, 2); mark(cave.x, cave.y, 2); mark(spring.x, spring.y, 2); mark(spring.x + 1, spring.y + 1, 2);
  mark(px, py, 1); mark(wx + 1, wy, 2);
  // 物の配置
  const objs = [];
  const add = (type, x, y, extra) => { const o = Object.assign({ t: type, x, y }, extra || {}); objs.push(o); return o; };
  const nearWater = (x, y) => DIRV.some(([dx, dy]) => inb(x + dx, y + dy) && isWater(t[I(x + dx, y + dy)]));
  for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
    if (noObj[I(x, y)]) continue; const v = t[I(x, y)], r = rng();
    if (v === T.FOREST) { if (r < 0.30) add('tree', x, y); else if (r < 0.35) add('bush', x, y, { n: 1 }); else if (r < 0.41) add('grass', x, y); else if (r < 0.46) add('twig', x, y); }
    else if (v === T.GRASS) { if (r < 0.05) add('tree', x, y); else if (r < 0.07) add('bush', x, y, { n: 1 }); else if (r < 0.15) add('grass', x, y); else if (r < 0.165) add('pebble', x, y); else if (r < 0.18) add('twig', x, y); }
    else if (v === T.SAND) { const nw = nearWater(x, y); if (!nw && r < 0.04) add('palm', x, y, { n: 1 + Math.floor(rng() * 3) }); else if (r < 0.06) add('shell', x, y); else if (r < 0.075) add('pebble', x, y); else if (nw && r < 0.12) add('driftwood', x, y); }
    else if (v === T.ROCK) { if (r < 0.12) add('boulder', x, y); else if (r < 0.145) add('ironVein', x, y); else if (r < 0.19) add('pebble', x, y); else if (r < 0.21) add('grass', x, y); }
  }
  // スタート地点のヤシ（最低3本）
  const occAt = (x, y) => objs.some(o => o.x === x && o.y === y);
  let palms = objs.filter(o => o.t === 'palm' && Math.hypot(o.x - spawn.x, o.y - spawn.y) < 9).length;
  for (const [ox, oy] of [[-4, -2], [4, -3], [-6, -1], [6, -1], [-3, -4], [3, -5]]) {
    if (palms >= 3) break; const x = spawn.x + ox, y = spawn.y + oy;
    if (inb(x, y) && t[I(x, y)] === T.SAND && !occAt(x, y) && !nearWater(x, y)) { add('palm', x, y, { n: 2 }); palms++; }
  }
  // ランドマーク
  add('box', box.x, box.y); add('hut', hut.x, hut.y); add('diary', hut.x, hut.y + 1, { page: 1 }); add('cave', cave.x, cave.y); add('raft', raft.x, raft.y); add('wreck', wx, wy);
  const lm = { spawn, box, hut, cave, spring, raft, wreck: { x: wx, y: wy }, pier: { x: px, y: py } };
  return { W, H, tiles: t, objs, lm };
}

// v6c：広い島（陸地は約75×58マス＝今までの約2倍）。台地は崖とふちに囲まれていて、縄梯子でだけ上り下りできる
function genIsland2() {
  const W = 104, H = 80, seed = MAP_SEED, rng = mulberry32(seed + 1);
  const t = new Uint8Array(W * H), D = new Float32Array(W * H), noObj = new Uint8Array(W * H);
  const cx = W / 2, cy = H / 2 + 1;
  // v8a：ランダムマップのゆらぎ（島の形・左右の反転・岩山／小屋／泉／スタート地点の位置）。今までの種では、すべて今までと同じ値になる
  const VAR = seed !== CONFIG.islandSeed, vr = mulberry32(seed + 9001);
  const fx = VAR && vr() < 0.5 ? -1 : 1;   // -1＝左右反転（岩山が北西・小屋が東・桟橋と難破船も入れかわる）
  const ph = VAR ? [vr() * 6.283, vr() * 6.283, vr() * 6.283] : [0.7, 2.1, 4.0];
  const am = VAR ? [0.06 + vr() * 0.06, 0.04 + vr() * 0.04, 0.02 + vr() * 0.03] : [0.10, 0.07, 0.04];
  const hillW = VAR ? 0.7 + vr() * 1.0 : 1.3, hutDy = VAR ? Math.round(-7 + vr() * 9) : -2;
  const sOff = VAR ? Math.round((vr() - 0.5) * 10) : 0, sprO = VAR ? [Math.round(-8 + vr() * 8), Math.round(-7 + vr() * 6)] : [-4, -4];
  const I = (x, y) => y * W + x, inb = (x, y) => x >= 0 && y >= 0 && x < W && y < H;
  const land = (x, y) => inb(x, y) && isLandT(t[I(x, y)]);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const dx = (x + 0.5 - cx) / (W * 0.36), dy = (y + 0.5 - cy) / (H * 0.36), a = Math.atan2(dy, dx);
    const rad = 1 + am[0] * Math.sin(3 * a + ph[0]) + am[1] * Math.sin(5 * a + ph[1]) + am[2] * Math.sin(8 * a + ph[2]);
    const d = Math.hypot(dx, dy) / rad + (vnoise(x / 6, y / 6, seed) - 0.5) * 0.12;
    D[I(x, y)] = d;
    t[I(x, y)] = d > 1.10 ? T.DEEP : d > 0.99 ? T.SHALLOW : d > 0.88 ? T.SAND : T.GRASS;
  }
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (t[I(x, y)] === T.GRASS && vnoise(x / 7 + 20, y / 7 + 20, seed + 1) > 0.56) t[I(x, y)] = T.FOREST;
  // 岩山（北東の内陸。洞窟の入口）
  let hill = null, bs = -1e9;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (D[I(x, y)] < 0.5 && (x - cx) * fx > 0 && y < cy) { const s = (x - cx) * fx + (cy - y) * hillW; if (s > bs) { bs = s; hill = { x, y }; } }
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const v = t[I(x, y)]; if (v !== T.GRASS && v !== T.FOREST) continue;
    if (Math.hypot(x - hill.x, y - hill.y) < 8.5 + (vnoise(x / 3, y / 3, seed + 2) - 0.5) * 4) t[I(x, y)] = T.ROCK;
  }
  const cave = { x: hill.x, y: hill.y };
  for (let y = cave.y - 3; y <= cave.y + 2; y++) for (let x = cave.x - 3; x <= cave.x + 3; x++) if (land(x, y)) t[I(x, y)] = T.ROCK;
  // 泉
  let spring = null, bd = 1e9;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (D[I(x, y)] < 0.42) { const d = Math.hypot(x - (cx + sprO[0] * fx), y - (cy + sprO[1])); if (d < bd) { bd = d; spring = { x, y }; } }
  for (let y = spring.y - 2; y <= spring.y + 3; y++) for (let x = spring.x - 2; x <= spring.x + 3; x++) if (land(x, y)) t[I(x, y)] = T.GRASS;
  for (let y = 0; y < 2; y++) for (let x = 0; x < 2; x++) t[I(spring.x + x, spring.y + y)] = T.SPRING;
  // 西の小屋
  let hut = null; let bx = 1e9;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (D[I(x, y)] < 0.55 && Math.abs(y - (cy + hutDy)) <= 7 && x * fx < bx) { bx = x * fx; hut = { x, y }; }
  for (let y = hut.y - 2; y <= hut.y + 2; y++) for (let x = hut.x - 1; x <= hut.x + 2; x++) if (land(x, y)) t[I(x, y)] = T.GRASS;
  // 南の浜辺（スタート地点）
  const sx = Math.floor(cx) + sOff; let sy = Math.floor(cy); while (land(sx, sy + 1)) sy++;
  const spawn = { x: sx, y: sy - 1 };
  let box = { x: sx + 2 * fx, y: sy - 2 }; if (!land(box.x, box.y)) box = { x: sx - 2 * fx, y: sy - 2 };
  // 桟橋
  const px = sx - 8 * fx; let py = Math.floor(cy); while (land(px, py + 1)) py++;
  for (let y = py + 1; y <= py + 5; y++) if (inb(px, y)) t[I(px, y)] = T.PIER;
  const raft = { x: px, y: py + 5 };
  // 難破船
  const wx = fx > 0 ? sx + 12 : sx - 14; let wy = Math.floor(cy); while (land(wx, wy + 1)) wy++;
  for (let y = wy - 1; y <= wy; y++) for (let x = wx; x <= wx + 2; x++) if (inb(x, y)) t[I(x, y)] = T.SAND;
  // 道
  const mark = (x, y, r) => { for (let yy = y - r; yy <= y + r; yy++) for (let xx = x - r; xx <= x + r; xx++) if (inb(xx, yy)) noObj[I(xx, yy)] = 1; };
  const carve = (a, b, keepSand) => {
    let x0 = a.x, y0 = a.y; const x1 = b.x, y1 = b.y, dx = Math.abs(x1 - x0), sxx = x0 < x1 ? 1 : -1, dy = -Math.abs(y1 - y0), syy = y0 < y1 ? 1 : -1; let er = dx + dy;
    for (let i = 0; i < 600; i++) {
      for (const [ox, oy] of [[0, 0], [1, 0], [0, 1]]) { const x = x0 + ox, y = y0 + oy; if (!land(x, y)) continue; if (!(keepSand && t[I(x, y)] === T.SAND)) t[I(x, y)] = T.PATH; }
      mark(x0, y0, 1);
      if (x0 === x1 && y0 === y1) break; const e2 = 2 * er; if (e2 >= dy) { er += dy; x0 += sxx; } if (e2 <= dx) { er += dx; y0 += syy; }
    }
  };
  carve(spawn, { x: spring.x, y: spring.y + 3 });
  carve({ x: spring.x - 1, y: spring.y }, { x: hut.x, y: hut.y + 2 });
  carve({ x: spring.x + 2, y: spring.y - 1 }, { x: cave.x, y: cave.y + 1 });
  carve(spawn, { x: px, y: py }, true);
  carve(spawn, { x: wx + 1, y: wy - 2 }, true);
  mark(spawn.x, spawn.y, 3); mark(box.x, box.y, 2); mark(hut.x, hut.y, 2); mark(hut.x + 1, hut.y, 2); mark(cave.x, cave.y, 2); mark(spring.x, spring.y, 2); mark(spring.x + 1, spring.y + 1, 2);
  mark(px, py, 1); mark(wx + 1, wy, 2);
  // 台地（崖）：道・建物から離れた草地や森に、最大3つ。南側は高さ2マスの崖の壁、ほかの縁は岩のふち
  const PL = new Uint8Array(W * H), plats = [];
  const lms = [spawn, box, hut, cave, spring, { x: px, y: py }, { x: wx + 1, y: wy }];
  const cands = [];
  for (let y = 5; y < H - 7; y++) for (let x = 5; x < W - 5; x++) { const v = t[I(x, y)]; if ((v === T.GRASS || v === T.FOREST) && D[I(x, y)] < 0.7 && !lms.some(a => Math.hypot(x - a.x, y - a.y) < 14)) cands.push({ x, y }); }
  for (let i = cands.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [cands[i], cands[j]] = [cands[j], cands[i]]; }
  const okT = ([x, y]) => inb(x, y) && (t[I(x, y)] === T.GRASS || t[I(x, y)] === T.FOREST) && !noObj[I(x, y)];
  for (const c of cands) {
    if (plats.length >= 3) break;
    if (plats.some(p => Math.hypot(p.x - c.x, p.y - c.y) < 24)) continue;
    const R = 4.6 + rng() * 1.8, B = [];
    for (let y = Math.floor(c.y - R - 2); y <= c.y + R + 2; y++) for (let x = Math.floor(c.x - R - 2); x <= c.x + R + 2; x++) {
      if (inb(x, y) && Math.hypot(x - c.x, (y - c.y) * 1.15) / R + (vnoise(x / 3 + 40, y / 3 + 40, seed + 9) - 0.5) * 0.4 < 1) B.push([x, y]);
    }
    if (B.length < 30) continue;
    const inB = new Set(B.map(([x, y]) => I(x, y))), face = [];
    for (const [x, y] of B) if (!inB.has(I(x, y + 1))) face.push([x, y + 1], [x, y + 2]);
    const faceS = new Set(face.map(([x, y]) => I(x, y))), rim = [];
    for (const [x, y] of B) for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const k = I(x + dx, y + dy); if (!inB.has(k) && !faceS.has(k)) rim.push([x + dx, y + dy]); }
    const below = face.filter(([x, y]) => !faceS.has(I(x, y + 1))).map(([x, y]) => [x, y + 1]);
    if (!B.concat(face, rim, below).every(okT)) continue;
    for (const [x, y] of face) t[I(x, y)] = T.CLIFF;
    for (const [x, y] of rim) if (t[I(x, y)] !== T.CLIFF) t[I(x, y)] = T.LEDGE;
    for (const [x, y] of B) PL[I(x, y)] = 1;   // v6.1e：台地の上（描く時に、少し明るい草地にする）
    plats.push({ x: c.x, y: c.y, B });
  }
  // 物の配置（密度は今までと同じ＝広さに比例して増える）
  const objs = [];
  const add = (type, x, y, extra) => { const o = Object.assign({ t: type, x, y }, extra || {}); objs.push(o); return o; };
  const nearWater = (x, y) => DIRV.some(([dx, dy]) => inb(x + dx, y + dy) && isWater(t[I(x + dx, y + dy)]));
  for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
    if (noObj[I(x, y)]) continue; const v = t[I(x, y)], r = rng();
    if (v === T.FOREST) { if (r < 0.30) add('tree', x, y); else if (r < 0.35) add('bush', x, y, { n: 1 }); else if (r < 0.41) add('grass', x, y); else if (r < 0.46) add('twig', x, y); }
    else if (v === T.GRASS) { if (r < 0.05) add('tree', x, y); else if (r < 0.07) add('bush', x, y, { n: 1 }); else if (r < 0.15) add('grass', x, y); else if (r < 0.165) add('pebble', x, y); else if (r < 0.18) add('twig', x, y); }
    else if (v === T.SAND) { const nw = nearWater(x, y); if (!nw && r < 0.04) add('palm', x, y, { n: 1 + Math.floor(rng() * 3) }); else if (r < 0.06) add('shell', x, y); else if (r < 0.075) add('pebble', x, y); else if (nw && r < 0.12) add('driftwood', x, y); }
    else if (v === T.ROCK) { if (r < 0.12) add('boulder', x, y); else if (r < 0.145) add('ironVein', x, y); else if (r < 0.19) add('pebble', x, y); else if (r < 0.21) add('grass', x, y); }
  }
  // 台地の上のごほうび：宝箱（中身つき）と鉱脈。崖の近く（梯子の出口）はふさがない
  const LOOT = [
    [{ id: 'ingot', n: 3 }, { id: 'rope', n: 4 }, { id: 'canned', n: 2 }, { id: 'medkit', n: 1 }],
    [{ id: 'goldore', n: 2 }, { id: 'plank', n: 4 }, { id: 'grilled', n: 3 }, { id: 'medkit', n: 1 }],
    [{ id: 'crystal', n: 2 }, { id: 'ironore', n: 4 }, { id: 'coin', n: 3 }, { id: 'protein', n: 1 }],
  ];
  plats.forEach((p, pi) => {
    const inner = p.B.filter(([x, y]) => PL[I(x, y + 1)] && PL[I(x, y + 2)] && PL[I(x, y - 1)] && PL[I(x - 1, y)] && PL[I(x + 1, y)]);
    const take = () => { if (!inner.length) return null; const k = Math.floor(rng() * inner.length), [x, y] = inner.splice(k, 1)[0]; for (let i = objs.length - 1; i >= 0; i--) if (objs[i].x === x && objs[i].y === y) objs.splice(i, 1); return [x, y]; };
    let q = take(); if (q) add('chest', q[0], q[1], { slots: LOOT[pi % LOOT.length].map(o => Object.assign({}, o)).concat([null, null]) });
    for (const kind of ['goldVein', 'ironVein', 'ironVein', 'boulder']) { q = take(); if (q) add(kind, q[0], q[1]); }
  });
  // スタート地点のヤシ（最低3本）
  const occAt = (x, y) => objs.some(o => o.x === x && o.y === y);
  let palms = objs.filter(o => o.t === 'palm' && Math.hypot(o.x - spawn.x, o.y - spawn.y) < 9).length;
  for (const [ox, oy] of [[-4, -2], [4, -3], [-6, -1], [6, -1], [-3, -4], [3, -5]]) {
    if (palms >= 3) break; const x = spawn.x + ox, y = spawn.y + oy;
    if (inb(x, y) && t[I(x, y)] === T.SAND && !occAt(x, y) && !nearWater(x, y)) { add('palm', x, y, { n: 2 }); palms++; }
  }
  // ランドマーク
  add('box', box.x, box.y); add('hut', hut.x, hut.y); add('diary', hut.x, hut.y + 1, { page: 1 }); add('cave', cave.x, cave.y); add('raft', raft.x, raft.y); add('wreck', wx, wy);
  const lm = { spawn, box, hut, cave, spring, raft, wreck: { x: wx, y: wy }, pier: { x: px, y: py }, plats: plats.map(p => ({ x: p.x, y: p.y })) };
  return { W, H, tiles: t, objs, lm, plat: PL, flip: fx };   // v6.1e：plat＝台地の上のマス
}
// v8a：ランダムマップの確認（スタート地点から、回収ボックス・小屋・泉・洞窟・桟橋・難破船へ歩いて行けるか。台地が2つ以上あるか。桟橋の先が海か）
function islandOk(d) {
  try {
    const { W, H, tiles: t, objs, lm } = d, I = (x, y) => y * W + x, inb = (x, y) => x >= 0 && y >= 0 && x < W && y < H;
    if (!lm || !lm.spawn || !lm.hut || !lm.spring || !lm.cave || !lm.raft || !lm.box) return false;
    if ((lm.plats || []).length < 2) return false;
    if (!inb(lm.raft.x, lm.raft.y + 1) || !isWater(t[I(lm.raft.x, lm.raft.y + 1)])) return false;
    if (lm.wreck.x < 2 || lm.wreck.x + 3 >= W) return false;
    const blk = new Uint8Array(W * H); for (const o of objs) { const od = OBJ[o.t]; if (od && od.block && inb(o.x, o.y)) blk[I(o.x, o.y)] = 1; }
    const pass = (x, y) => inb(x, y) && WALK[t[I(x, y)]] && !blk[I(x, y)];
    const seen = new Uint8Array(W * H), q = [[lm.spawn.x, lm.spawn.y]]; seen[I(lm.spawn.x, lm.spawn.y)] = 1;
    while (q.length) { const [x, y] = q.pop(); for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const nx = x + dx, ny = y + dy; if (pass(nx, ny) && !seen[I(nx, ny)]) { seen[I(nx, ny)] = 1; q.push([nx, ny]); } } }
    const near = (p, r) => { for (let y = p.y - r; y <= p.y + r; y++) for (let x = p.x - r; x <= p.x + r; x++) if (inb(x, y) && seen[I(x, y)]) return true; return false; };
    return near(lm.box, 1) && near(lm.hut, 2) && near(lm.spring, 2) && near(lm.cave, 1) && near(lm.pier, 1) && near({ x: lm.wreck.x + 1, y: lm.wreck.y }, 2);
  } catch (e) { return false; }
}
// v8a：新しいゲームの種を選ぶ（確認に通る島が出るまで引き直す。だめなら今までの島）
// v8d：種は数字5桁（10000〜99999）だった。v8f：シード値は4桁（0000〜9999）の1万通り。
// 番号ごとに「内部の種」を順に試し、島と洞窟の両方がちゃんと作れた最初の種を使う（同じ番号なら、いつも同じ島と洞窟）。だからどの番号でも遊べる
// 内部の種は game.seed、4桁の番号は game.seed4 に残す（v8eまでの5桁の種のセーブは、そのまま遊べる）
function seedMix(s4, k) {
  let x = (Math.imul(s4 + 1, 2654435761) ^ Math.imul(k + 7, 40503) ^ 0x9e3779b9) >>> 0;
  x ^= x >>> 16; x = Math.imul(x, 0x85ebca6b) >>> 0; x ^= x >>> 13; x = Math.imul(x, 0xc2b2ae35) >>> 0; x ^= x >>> 16;
  return 100000 + ((x >>> 0) % 2000000000);   // 正の整数（セーブの確認に通るように）
}
const seedText = n => String(n).padStart(4, '0');   // v8f：4桁で表示（7 → 0007）
function pickMapSeed(want) {
  const s4 = Number.isInteger(want) && want >= 0 && want <= 9999 ? want : Math.floor(Math.random() * 10000);
  for (let k = 0; k < 64; k++) { MAP_SEED = seedMix(s4, k); const d = genIsland(2); if (!islandOk(d) || !genCaveRandom()) continue; return { seed: MAP_SEED, seed4: s4, isl: d, cav: 3 }; }
  MAP_SEED = CONFIG.islandSeed; return { seed: null, seed4: null, isl: genIsland(2), cav: 2 };   // 万一どれも作れない時は旧マップ
}
// v8d：旧マップ（v7までの島。種なし）
function oldMapPick() { MAP_SEED = CONFIG.islandSeed; return { seed: null, isl: genIsland(2), cav: 2 }; }   // v8f：洞窟もv7の広い洞窟
// v6.1d：洞窟の種類（2＝広い洞窟。v6.1cまでのセーブは1＝今までの洞窟のまま）
function genCave(v) { return clearExitZone(v === 3 ? (genCaveRandom() || genCaveWide()) : v === 2 ? genCaveWide() : genCaveOld()); }   // v8f：3＝ランダム生成の洞窟。v8.1：どの洞窟も、はしごのまわり1マスを床に
// v8.1：はしご（出口）のまわり1マスを床にする（旧マップの洞窟も同じ。床を足すだけなので、今までのセーブの物はずれない）
function clearExitZone(c) {
  if (!c || !c.lm || !c.lm.exit) return c;
  const { W, H, tiles } = c, ex = c.lm.exit;
  for (let y = ex.y - 1; y <= ex.y + 1; y++) for (let x = ex.x - 1; x <= ex.x + 1; x++) if (x > 0 && y > 0 && x < W - 1 && y < H - 1 && tiles[y * W + x] === T.CWALL) tiles[y * W + x] = T.CFLOOR;
  return c;
}
// v6.1d：広い洞窟（72×56）。部屋と通路でできた、左右対称でない形。乱数は固定なので、毎回同じ形になる
function genCaveWide() {
  const W = 72, H = 56, t = new Uint8Array(W * H).fill(T.CWALL), rng = mulberry32(MAP_SEED + 4242);
  const R = (a, b) => a + rng() * (b - a), I = (x, y) => y * W + x, inside = (x, y) => x > 0 && y > 0 && x < W - 1 && y < H - 1;
  const set = (x, y, v) => { if (inside(x, y)) t[I(x, y)] = v; };
  const circ = (cx, cy, r, v) => { for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) if ((x - cx) ** 2 + (y - cy) ** 2 <= r * r) set(x, y, v == null ? T.CFLOOR : v); };
  // 部屋：いくつかの円を重ねて、でこぼこの形にする
  const room = (cx, cy, rx, ry, n) => { circ(cx, cy, Math.min(rx, ry) * 0.8); for (let k = 0; k < (n || 6); k++) { const a = R(0, Math.PI * 2), d = R(0.25, 0.6); circ(cx + Math.cos(a) * rx * d, cy + Math.sin(a) * ry * d, Math.min(rx, ry) * R(0.5, 0.78)); } };
  // 通路：曲がりながら進む（途中の点を少しずらす）
  const tunnel = (pts, r) => {
    for (let i = 0; i < pts.length - 1; i++) {
      const [x0, y0] = pts[i], [x1, y1] = pts[i + 1], L = Math.hypot(x1 - x0, y1 - y0), nx = -(y1 - y0) / (L || 1), ny = (x1 - x0) / (L || 1);
      const mids = Math.max(1, Math.round(L / 6)), path = [[x0, y0]];
      for (let k = 1; k <= mids; k++) { const f = k / (mids + 1), o = R(-1.6, 1.6); path.push([x0 + (x1 - x0) * f + nx * o, y0 + (y1 - y0) * f + ny * o]); }
      path.push([x1, y1]);
      for (let j = 0; j < path.length - 1; j++) { const [a0, b0] = path[j], [a1, b1] = path[j + 1], n = Math.ceil(Math.hypot(a1 - a0, b1 - b0) * 2); for (let s = 0; s <= n; s++) circ(a0 + (a1 - a0) * s / n, b0 + (b1 - b0) * s / n, r * R(0.92, 1.12)); }
    }
  };
  // ---- 部屋（名前は設計用）
  room(31, 48, 5, 4, 6);            // A 入口の広間
  room(13, 44, 6, 5, 8);            // B 鉄の坑道（西）
  room(35, 31, 8.5, 6.5, 10);       // C 中央の大空洞
  room(57, 37, 5.5, 4.5, 7);        // D 水晶の洞（東）
  room(65, 48, 3.5, 3, 5);          // E 水晶のくぼみ（行き止まり）
  room(14, 25, 6, 5, 8);            // F 地底の泉（西）
  room(58, 13, 5, 4, 7);            // G 金の鉱床（北東・行き止まり）
  room(33, 13, 4.5, 3.5, 6);        // H1 祠の前室
  room(35, 5, 6, 3.2, 7);           // H2 祠の間（いちばん奥）
  room(9, 11, 3.5, 3, 5);           // I 北西の小部屋（行き止まり）
  room(47, 50, 3.2, 2.6, 5);        // J 南東の小部屋（サソリの巣）
  room(24, 37, 3, 2.5, 4);          // K 中継の小部屋
  // ---- 通路
  tunnel([[31, 53], [31, 48]], 1.3);                         // 出口 → 入口の広間
  tunnel([[31, 46], [27, 41], [33, 37]], 1.4);               // 入口 → 中央（本道）
  tunnel([[27, 48], [20, 47], [13, 44]], 1.25);              // 入口 → 鉄の坑道
  tunnel([[35, 49], [42, 51], [47, 50]], 1.15);              // 入口 → 南東の小部屋
  tunnel([[13, 40], [9, 34], [12, 28]], 1.2);                // 鉄の坑道 → 地底の泉（西の回り道）
  tunnel([[18, 42], [24, 37], [28, 33]], 1.2);               // 鉄の坑道 → 中継 → 中央
  tunnel([[19, 25], [26, 27], [29, 29]], 1.3);               // 地底の泉 → 中央
  tunnel([[42, 32], [49, 35], [53, 36]], 1.35);              // 中央 → 水晶の洞
  tunnel([[59, 41], [63, 44], [65, 47]], 1.1);               // 水晶の洞 → 水晶のくぼみ
  tunnel([[60, 33], [65, 26], [62, 19], [58, 15]], 1.1);     // 水晶の洞 → 金の鉱床（長い曲がり道）
  tunnel([[13, 21], [11, 16], [9, 12]], 1.05);               // 地底の泉 → 北西の小部屋（細い）
  tunnel([[35, 25], [34, 20], [33, 16]], 1.25);              // 中央 → 祠の前室（硬い岩でふさがる）
  tunnel([[33, 11], [35, 7]], 1.3);                          // 前室 → 祠の間
  // ---- 中央の大空洞に、岩の柱（通れなくならない所だけ）
  const pillars = [[32, 29, 1.3], [39, 33, 1.1], [36, 27, 0.9], [30, 34, 0.8]];   // 置くのは、ふちを整えたあと
  // ---- ふちをでこぼこに（広い所だけ）。とがった壁は削り、壁を足すのは「まわりの床がつながったまま」の所だけ
  const ring = [[-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0]];
  const snap = t.slice(), isF = (a, x, y) => a[I(x, y)] !== T.CWALL;
  for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
    let n = 0; for (const [dx, dy] of ring) if (isF(snap, x + dx, y + dy)) n++;
    if (snap[I(x, y)] === T.CWALL && n >= 6) t[I(x, y)] = T.CFLOOR;
  }
  const localOk = (x, y) => {   // 真ん中を壁にしても、まわりの床どうしがつながっているか
    const f = ring.map(([dx, dy]) => t[I(x + dx, y + dy)] !== T.CWALL); let groups = 0;
    for (let k = 0; k < 8; k++) if (f[k] && !f[(k + 7) % 8] && !(k % 2 === 0 && false)) groups++;
    if (f.every(v => v)) groups = 1;
    // 角だけでつながる床は、上下左右でつながっていないので別のまとまり
    for (let k = 0; k < 8; k += 2) if (f[k] && !f[(k + 7) % 8] && !f[(k + 1) % 8]) return false;
    return groups === 1;
  };
  for (let y = 2; y < H - 2; y++) for (let x = 2; x < W - 2; x++) {
    if (t[I(x, y)] !== T.CFLOOR) continue; let n = 0; for (const [dx, dy] of ring) if (t[I(x + dx, y + dy)] !== T.CWALL) n++;
    if (n >= 5 && n <= 6 && rng() < 0.2 && localOk(x, y)) t[I(x, y)] = T.CWALL;
  }
  // ---- 出口からつながっているか調べる（blk：通れない所）
  const exit = { x: 31, y: 53 };
  const reach = blk => { const seen = new Uint8Array(W * H), q = [I(exit.x, exit.y)]; seen[q[0]] = 1; let n = 0;
    while (q.length) { const i = q.pop(); n++; const x = i % W, y = (i / W) | 0; for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const j = I(x + dx, y + dy); if (!seen[j] && t[j] === T.CFLOOR && !(blk && blk[j])) { seen[j] = 1; q.push(j); } } }
    return { seen, n }; };
  // つながっていない床は壁に戻す
  { const r = reach(); for (let i = 0; i < W * H; i++) if (t[i] === T.CFLOOR && !r.seen[i]) t[i] = T.CWALL; }
  const floorCount = () => { let n = 0; for (let i = 0; i < W * H; i++) if (t[i] === T.CFLOOR) n++; return n; };
  for (const [px, py, pr] of pillars) { const keep = t.slice(); circ(px, py, pr, T.CWALL); if (reach().n !== floorCount()) t.set(keep); }   // 柱で道が切れるなら置かない
  // ---- 地底の泉（調べると水を汲める）
  for (let y = 23; y <= 28; y++) for (let x = 9; x <= 16; x++) if (((x - 12.4) / 2.7) ** 2 + ((y - 25.4) / 1.7) ** 2 <= 1 && t[I(x, y)] === T.CFLOOR) t[I(x, y)] = T.SPRING;
  { const r = reach(); for (let i = 0; i < W * H; i++) if (t[i] === T.CFLOOR && !r.seen[i]) t[i] = T.CWALL; }
  // ---- 物を置く
  const objs = [], blk = new Uint8Array(W * H), solid = type => (OBJ[type] && OBJ[type].block) && type !== 'hardRock';
  const add = (type, x, y, extra) => { objs.push(Object.assign({ t: type, x, y }, extra || {})); if (solid(type)) blk[I(x, y)] = 1; };
  const floorN = (x, y) => { let n = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if ((dx || dy) && t[I(x + dx, y + dy)] === T.CFLOOR) n++; return n; };
  const taken = (x, y, d) => objs.some(o => Math.abs(o.x - x) <= d && Math.abs(o.y - y) <= d);
  let base = 0, solids = 0;
  // 通れなくならない所だけに置く（置くたびに、出口から行ける床がちょうど1マスだけ減ること）
  const tryPut = (type, x, y, extra) => {
    if (t[I(x, y)] !== T.CFLOOR || taken(x, y, 1)) return false;
    add(type, x, y, extra); if (!solid(type)) return true;
    if (reach(blk).n !== base - solids - 1) { objs.pop(); blk[I(x, y)] = 0; return false; }
    solids++; return true;
  };
  const scatter = (type, cx, cy, r, n, minNb) => { const c = []; for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) if (inside(x, y) && (x - cx) ** 2 + (y - cy) ** 2 <= r * r && t[I(x, y)] === T.CFLOOR && floorN(x, y) >= (minNb || 5)) c.push([x, y]);
    for (let i = c.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [c[i], c[j]] = [c[j], c[i]]; }
    let k = 0; for (const [x, y] of c) { if (k >= n) break; if (Math.hypot(x - exit.x, y - exit.y) < 4) continue; if (tryPut(type, x, y)) k++; } return k; };
  add('exit', exit.x, exit.y);
  // 祠（いちばん奥）と日誌
  const shrine = { x: 35, y: 3 }; for (let y = 2; y <= 6; y++) for (let x = 32; x <= 38; x++) if (inside(x, y)) t[I(x, y)] = T.CFLOOR;
  add('shrine', shrine.x, shrine.y); add('diary', 38, 4, { page: 3 });
  add('diary', 27, 46, { page: 2 });
  // 祠への道をふさぐ硬い岩（鉄のつるはしで砕ける）
  for (let y = 18; y <= 19; y++) for (let x = 29; x <= 39; x++) if (t[I(x, y)] === T.CFLOOR) add('hardRock', x, y);
  base = reach(blk).n;   // ここから下の物は、通り道をふさがない所にだけ置く
  // 鉱脈・水晶・岩
  scatter('ironVein', 13, 44, 6, 5); scatter('ironVein', 9, 11, 3.5, 2); scatter('ironVein', 35, 31, 8, 2); scatter('ironVein', 47, 50, 3, 1); scatter('ironVein', 31, 48, 5, 1);
  scatter('crystal', 57, 37, 5.5, 4); scatter('crystal', 65, 48, 3.5, 3, 4); scatter('crystal', 35, 31, 8, 1); scatter('crystal', 14, 25, 6.5, 2);
  scatter('goldVein', 58, 13, 5, 4, 4); scatter('goldVein', 35, 5, 5, 2, 4);
  scatter('boulder', 35, 31, 8.5, 3); scatter('boulder', 31, 48, 5, 1); scatter('boulder', 13, 44, 6, 1); scatter('boulder', 9, 11, 3.5, 1, 4); scatter('boulder', 47, 50, 3.2, 1, 4); scatter('boulder', 14, 25, 6, 1); scatter('boulder', 24, 37, 3, 1, 4);
  return { W, H, tiles: t, objs, lm: { exit: { x: exit.x, y: exit.y } } };
}
// v8f：ランダム生成の洞窟（72×56）。部屋の数・大きさ・場所・つなぎ方を、マップの種から決める（旧マップを選んだ時は、今までの広い洞窟 genCaveWide）
// 形：下に入口 → いくつもの部屋と曲がった通路（ループもある）→ 硬い岩でふさがった細い道 → 祠の前室 → 祠の間（いちばん上）
// 物：入口の近くは鉄、奥の行き止まりは金、遠い部屋ほど水晶。数は床の広さに合わせる。うまく作れなかった時は null（種を変えて作り直す）
const CAVE_REF_FLOOR = 988;   // 今までの広い洞窟の床の数（物の量の目安）
function genCaveRandom() {
  const W = 72, H = 56, t = new Uint8Array(W * H).fill(T.CWALL), rng = mulberry32(MAP_SEED + 5151);
  const R = (a, b) => a + rng() * (b - a), I = (x, y) => y * W + x, inside = (x, y) => x > 0 && y > 0 && x < W - 1 && y < H - 1;
  const set = (x, y, v) => { if (inside(x, y)) t[I(x, y)] = v; };
  const circ = (cx, cy, r, v) => { for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) if ((x - cx) ** 2 + (y - cy) ** 2 <= r * r) set(x, y, v == null ? T.CFLOOR : v); };
  const room = (cx, cy, rx, ry, n) => { circ(cx, cy, Math.min(rx, ry) * 0.8); for (let k = 0; k < (n || 6); k++) { const a = R(0, Math.PI * 2), d = R(0.25, 0.6); circ(cx + Math.cos(a) * rx * d, cy + Math.sin(a) * ry * d, Math.min(rx, ry) * R(0.5, 0.78)); } };
  const tunnel = (pts, r) => {
    for (let i = 0; i < pts.length - 1; i++) {
      const [x0, y0] = pts[i], [x1, y1] = pts[i + 1], L = Math.hypot(x1 - x0, y1 - y0), nx = -(y1 - y0) / (L || 1), ny = (x1 - x0) / (L || 1);
      const mids = Math.max(1, Math.round(L / 6)), path = [[x0, y0]];
      for (let k = 1; k <= mids; k++) { const f = k / (mids + 1), o = R(-1.6, 1.6); path.push([x0 + (x1 - x0) * f + nx * o, y0 + (y1 - y0) * f + ny * o]); }
      path.push([x1, y1]);
      for (let j = 0; j < path.length - 1; j++) { const [a0, b0] = path[j], [a1, b1] = path[j + 1], n = Math.ceil(Math.hypot(a1 - a0, b1 - b0) * 2); for (let s = 0; s <= n; s++) circ(a0 + (a1 - a0) * s / n, b0 + (b1 - b0) * s / n, r * R(0.92, 1.12)); }
    }
  };
  const ext = (rx, ry) => [0.6 * rx + 0.78 * Math.min(rx, ry) + 0.6, 0.6 * ry + 0.78 * Math.min(rx, ry) + 0.6];   // 部屋がはみ出す幅（横・縦）
  // ---- 入口と、上の区画（祠の間・前室。y 2〜14）
  const exit = { x: Math.round(R(16, 56)), y: 53 };
  const shX = Math.round(R(12, 60)), anX = clamp(Math.round(shX + R(-5, 5)), 8, 63), anY = 10.5;
  room(shX, 5, 6, 3.2, 7);              // 祠の間（いちばん奥）
  room(anX, anY, 4.5, 2.6, 6);          // 祠の前室
  tunnel([[anX, anY], [shX, 6]], 1.3);
  // ---- 下の区画（ふつうの部屋。y 18〜51）
  const rooms = [{ x: clamp(exit.x + R(-5, 5), 9, 62), y: 46.6, rx: 5, ry: 3.5, ent: 1 }];   // 0：入口の広間
  const want = 8 + Math.floor(rng() * 4);   // 入口のほかに 8〜11部屋
  for (let a = 0; a < 1500 && rooms.length < want + 1; a++) {
    const big = a < 60 && !rooms.some(o => o.big), rx = big ? R(7, 9) : R(3.2, 6.8), ry = big ? R(5.4, 6.6) : Math.min(rx, R(2.6, 5.2)), [ex, ey] = ext(rx, ry);   // 大空洞を1つ
    if (18 + ey > 51 - ey) continue;
    const x = R(ex + 1.5, W - 2.5 - ex), y = R(18 + ey, 51 - ey);
    if (rooms.some(o => { const [ox, oy] = ext(o.rx, o.ry); return Math.abs(o.x - x) < (ox + ex) * 0.82 + 1.5 && Math.abs(o.y - y) < (oy + ey) * 0.82 + 1.5; })) continue;
    rooms.push({ x, y, rx, ry, big });
  }
  if (rooms.length < 8) return null;
  for (const r of rooms) room(r.x, r.y, r.rx, r.ry, Math.round(4 + Math.min(r.rx, r.ry)));
  // ---- 部屋をつなぐ（いちばん短いつなぎ方＋近い部屋どうしを少し足してループに）
  const dist = (a, b) => Math.hypot(rooms[a].x - rooms[b].x, rooms[a].y - rooms[b].y);
  const edges = [], conn = new Set([0]);
  while (conn.size < rooms.length) { let best = null; for (const i of conn) for (let j = 0; j < rooms.length; j++) if (!conn.has(j)) { const d = dist(i, j); if (!best || d < best[2]) best = [i, j, d]; } conn.add(best[1]); edges.push(best); }
  const linked = (i, j) => edges.some(e => (e[0] === i && e[1] === j) || (e[0] === j && e[1] === i));
  const cand = []; for (let i = 0; i < rooms.length; i++) for (let j = i + 1; j < rooms.length; j++) if (!linked(i, j) && dist(i, j) < 26) cand.push([i, j, dist(i, j)]);
  cand.sort((a, b) => a[2] - b[2]); const loops = 2 + Math.floor(rng() * 2);
  for (let k = 0, n = 0; k < cand.length && n < loops; k++) if (rng() < 0.55) { edges.push(cand[k]); n++; }
  const deg = rooms.map((_, i) => edges.filter(e => e[0] === i || e[1] === i).length);
  for (const [i, j, d] of edges) {
    const a = rooms[i], b = rooms[j], nx = -(b.y - a.y) / (d || 1), ny = (b.x - a.x) / (d || 1), o = R(-0.22, 0.22) * d;
    tunnel([[a.x, a.y], [clamp((a.x + b.x) / 2 + nx * o, 4, W - 5), clamp((a.y + b.y) / 2 + ny * o, 21, 50)], [b.x, b.y]], R(1.15, 1.5));
  }
  tunnel([[exit.x, 53], [rooms[0].x, rooms[0].y]], 1.3);   // 出口 → 入口の広間
  // ---- 上と下の間（y 14〜16）は、いったん全部壁にして、祠への道だけを通す
  for (let y = 14; y <= 16; y++) for (let x = 0; x < W; x++) t[I(x, y)] = T.CWALL;
  let tgt = 1, tb = 1e9; for (let i = 1; i < rooms.length; i++) { const r = rooms[i], s = Math.abs(r.x - anX) + (r.y - 18) * 1.4; if (s < tb) { tb = s; tgt = i; } }
  const TG = rooms[tgt]; tunnel([[anX, anY + 1], [clamp((anX + TG.x) / 2 + R(-2, 2), 4, W - 5), 18.5], [TG.x, TG.y]], 1.2);
  // ---- ふちをでこぼこに（genCaveWide と同じやり方）
  const ring = [[-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0]];
  const snap = t.slice(), isF = (a, x, y) => a[I(x, y)] !== T.CWALL;
  for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) { let n = 0; for (const [dx, dy] of ring) if (isF(snap, x + dx, y + dy)) n++; if (snap[I(x, y)] === T.CWALL && n >= 6) t[I(x, y)] = T.CFLOOR; }
  const localOk = (x, y) => {
    const f = ring.map(([dx, dy]) => t[I(x + dx, y + dy)] !== T.CWALL); let groups = 0;
    for (let k = 0; k < 8; k++) if (f[k] && !f[(k + 7) % 8]) groups++;
    if (f.every(v => v)) groups = 1;
    for (let k = 0; k < 8; k += 2) if (f[k] && !f[(k + 7) % 8] && !f[(k + 1) % 8]) return false;
    return groups === 1;
  };
  for (let y = 2; y < H - 2; y++) for (let x = 2; x < W - 2; x++) {
    if (t[I(x, y)] !== T.CFLOOR || (y >= 13 && y <= 17)) continue; let n = 0; for (const [dx, dy] of ring) if (t[I(x + dx, y + dy)] !== T.CWALL) n++;
    if (n >= 5 && n <= 6 && rng() < 0.2 && localOk(x, y)) t[I(x, y)] = T.CWALL;
  }
  // v8.1：はしご（出口）のまわり1マス。床にするのは、物を置き終わった最後（下の「はしごのまわりを床に」）。
  // ここで床にすると、物の場所の乱数がずれて島や洞窟が変わってしまうため
  const exitZone = (x, y) => Math.abs(x - exit.x) <= 1 && Math.abs(y - exit.y) <= 1;
  const exitZoneFloor = () => { for (let y = exit.y - 1; y <= exit.y + 1; y++) for (let x = exit.x - 1; x <= exit.x + 1; x++) if (!inside(x, y) || t[I(x, y)] !== T.CFLOOR) return false; return true; };
  // ---- 出口からつながっているか
  const reach = blk => { const seen = new Uint8Array(W * H), q = [I(exit.x, exit.y)]; seen[q[0]] = 1; let n = 0;
    while (q.length) { const i = q.pop(); n++; const x = i % W, y = (i / W) | 0; for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const j = I(x + dx, y + dy); if (!seen[j] && t[j] === T.CFLOOR && !(blk && blk[j])) { seen[j] = 1; q.push(j); } } }
    return { seen, n }; };
  if (t[I(exit.x, exit.y)] !== T.CFLOOR) return null;
  { const r = reach(); for (let i = 0; i < W * H; i++) if (t[i] === T.CFLOOR && !r.seen[i]) t[i] = T.CWALL; }
  const floorCount = () => { let n = 0; for (let i = 0; i < W * H; i++) if (t[i] === T.CFLOOR) n++; return n; };
  const nearFloor = (cx, cy, r) => { for (let y = Math.round(cy - r); y <= Math.round(cy + r); y++) for (let x = Math.round(cx - r); x <= Math.round(cx + r); x++) if (inside(x, y) && t[I(x, y)] === T.CFLOOR) return true; return false; };
  if (!rooms.every(r => nearFloor(r.x, r.y, 1.5)) || !nearFloor(shX, 5, 1.5) || !nearFloor(anX, anY, 1.5)) return null;   // 部屋が切れてしまった
  // ---- いちばん大きい部屋に、岩の柱（道が切れない所だけ）
  const big = rooms.slice(1).sort((a, b) => b.rx * b.ry - a.rx * a.ry)[0];
  if (big && Math.min(big.rx, big.ry) >= 4) for (let k = 0; k < 3; k++) { const keep = t.slice(); circ(big.x + R(-big.rx, big.rx) * 0.5, big.y + R(-big.ry, big.ry) * 0.5, R(0.8, 1.3), T.CWALL); if (reach().n !== floorCount()) t.set(keep); }
  // ---- 地底の泉（入口・祠への道の部屋以外の、ある程度広い部屋）
  const order = rooms.map((r, i) => i).filter(i => i !== 0 && i !== tgt && Math.min(rooms[i].rx, rooms[i].ry) >= 3.4).sort((a, b) => dist(0, b) - dist(0, a));
  let springRoom = -1;
  for (const i of order.slice(Math.floor(order.length / 3)).concat(order.slice(0, Math.floor(order.length / 3)))) {
    const r = rooms[i], ax = Math.min(r.rx * 0.45, 2.8), ay = Math.min(r.ry * 0.34, 1.8), keep = t.slice(); let n = 0;
    for (let y = Math.floor(r.y - ay - 1); y <= Math.ceil(r.y + ay + 1); y++) for (let x = Math.floor(r.x - ax - 1); x <= Math.ceil(r.x + ax + 1); x++) if (inside(x, y) && ((x - r.x) / ax) ** 2 + ((y - r.y) / ay) ** 2 <= 1 && t[I(x, y)] === T.CFLOOR) { t[I(x, y)] = T.SPRING; n++; }
    const before = floorCount(), rr = reach();
    if (n >= 6 && rr.n === before && rooms.every((q, k) => k === i || nearFloor(q.x, q.y, 1.5))) { springRoom = i; break; }
    t.set(keep);
  }
  if (springRoom < 0) return null;
  const fc = floorCount(); if (fc < CAVE_REF_FLOOR * 0.72 || fc > CAVE_REF_FLOOR * 1.4) return null;
  // ---- 物を置く（通れなくならない所だけ）
  const objs = [], blk = new Uint8Array(W * H), solid = type => (OBJ[type] && OBJ[type].block) && type !== 'hardRock';
  const add = (type, x, y, extra) => { objs.push(Object.assign({ t: type, x, y }, extra || {})); if (solid(type)) blk[I(x, y)] = 1; };
  const floorN = (x, y) => { let n = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if ((dx || dy) && t[I(x + dx, y + dy)] === T.CFLOOR) n++; return n; };
  const taken = (x, y, d) => objs.some(o => Math.abs(o.x - x) <= d && Math.abs(o.y - y) <= d);
  let base = 0, solids = 0;
  const tryPut = (type, x, y, extra) => {
    if (t[I(x, y)] !== T.CFLOOR || taken(x, y, 1)) return false;
    add(type, x, y, extra); if (!solid(type)) return true;
    if (reach(blk).n !== base - solids - 1) { objs.pop(); blk[I(x, y)] = 0; return false; }
    solids++; return true;
  };
  const scatter = (type, cx, cy, r, n, minNb) => { if (n <= 0) return 0; const c = []; for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) if (inside(x, y) && (x - cx) ** 2 + (y - cy) ** 2 <= r * r && t[I(x, y)] === T.CFLOOR && floorN(x, y) >= (minNb || 5)) c.push([x, y]);
    for (let i = c.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [c[i], c[j]] = [c[j], c[i]]; }
    let k = 0; for (const [x, y] of c) { if (k >= n) break; if (Math.hypot(x - exit.x, y - exit.y) < 4) continue; if (tryPut(type, x, y)) k++; } return k; };
  add('exit', exit.x, exit.y);
  // 祠（いちばん奥）と日誌
  for (let y = 2; y <= 6; y++) for (let x = shX - 3; x <= shX + 3; x++) if (inside(x, y) && t[I(x, y)] === T.CWALL && nearFloor(x, y, 1)) t[I(x, y)] = T.CFLOOR;
  t[I(shX, 3)] = T.CFLOOR; add('shrine', shX, 3);
  { let dp = null; for (const [dx, dy] of [[3, 1], [-3, 1], [2, 2], [-2, 2], [3, 2], [-3, 2]]) if (t[I(shX + dx, 3 + dy)] === T.CFLOOR) { dp = [shX + dx, 3 + dy]; break; } if (!dp) return null; add('diary', dp[0], dp[1], { page: 3 }); }
  // 入口の広間に、2冊目の日誌
  { const e = rooms[0]; let dp = null; for (let r = 1; r <= 4 && !dp; r++) for (let dy = -r; dy <= r && !dp; dy++) for (let dx = -r; dx <= r && !dp; dx++) { const x = Math.round(e.x) + dx, y = Math.round(e.y) + dy; if (inside(x, y) && t[I(x, y)] === T.CFLOOR && floorN(x, y) >= 7 && Math.hypot(x - exit.x, y - exit.y) >= 3) dp = [x, y]; } if (!dp) return null; add('diary', dp[0], dp[1], { page: 2 }); }
  // 祠への道をふさぐ硬い岩（鉄のつるはしで砕ける）。上と下の間（y 15〜16）の床を全部ふさぐ
  let hr = 0; for (let y = 15; y <= 16; y++) for (let x = 1; x < W - 1; x++) if (t[I(x, y)] === T.CFLOOR) { add('hardRock', x, y); hr++; }
  if (!hr) return null;
  { const hb = new Uint8Array(W * H); for (const o of objs) if (o.t === 'hardRock') hb[I(o.x, o.y)] = 1; const r1 = reach(), r2 = reach(hb);
    if (!r1.seen[I(shX, 4)] && !r1.seen[I(shX - 1, 4)] && !r1.seen[I(shX + 1, 4)]) return null;   // 祠まで行けない
    if (r2.seen[I(shX, 4)] || r2.seen[I(anX, Math.round(anY))]) return null; }   // 岩を砕かずに祠へ行けてしまう
  base = reach(blk).n;
  // ---- 部屋の役わり：入口からの道のりで決める（近い＝鉄、遠い行き止まり＝金、遠い＝水晶）
  const k = clamp(fc / CAVE_REF_FLOOR, 0.8, 1.3), nn = v => Math.max(1, Math.round(v * k));
  const ids = rooms.map((r, i) => i).filter(i => i !== 0), far = ids.slice().sort((a, b) => dist(0, b) - dist(0, a));
  const goldR = far.find(i => deg[i] === 1 && i !== tgt && i !== springRoom) ?? far.find(i => i !== tgt && i !== springRoom) ?? far[0];
  const crysR = far.filter(i => i !== goldR && i !== springRoom).slice(0, 2), ironR = ids.slice().sort((a, b) => dist(0, a) - dist(0, b)).filter(i => i !== goldR && !crysR.includes(i));
  const rr = r => Math.max(r.rx, r.ry) * 0.95;
  const G = rooms[goldR], cnt = { ironVein: 0, crystal: 0, goldVein: 0, boulder: 0 }, put = (type, r, n, nb) => { cnt[type] += scatter(type, r.x, r.y, rr(r), n, nb); };
  put('goldVein', G, nn(4), 4); cnt.goldVein += scatter('goldVein', shX, 5, 5, 2, 4);
  if (crysR[0] != null) put('crystal', rooms[crysR[0]], nn(4), 4); if (crysR[1] != null) put('crystal', rooms[crysR[1]], nn(3), 4);
  put('crystal', rooms[springRoom], nn(2), 5); if (big) put('crystal', big, 1);
  if (ironR[0] != null) put('ironVein', rooms[ironR[0]], nn(5)); if (ironR[1] != null) put('ironVein', rooms[ironR[1]], nn(2)); put('ironVein', rooms[0], 1);
  for (const i of ironR.slice(2)) if (cnt.ironVein < nn(11)) put('ironVein', rooms[i], 1 + (rng() < 0.4 ? 1 : 0));
  if (big) put('boulder', big, nn(3)); put('boulder', rooms[0], 1);
  for (const i of ids) if (cnt.boulder < nn(9) && rooms[i] !== big) put('boulder', rooms[i], 1, 4);
  if (cnt.goldVein < 4 || cnt.crystal < 5 || cnt.ironVein < 6) return null;
  // v8.1：はしごのまわりを床に。はしご（出口）のまわり1マスを、かならず床にする（入った時に壁に埋まらないように）。
  // 物を置き終わってから床を足すだけなので、まわり1マス以外の形・物の場所は今までと同じ（今までのセーブの物もずれない）
  for (let y = exit.y - 1; y <= exit.y + 1; y++) for (let x = exit.x - 1; x <= exit.x + 1; x++) if (inside(x, y)) t[I(x, y)] = T.CFLOOR;
  // 最後にもう一度、はしごのまわり1マスが床で、物がないかを確かめる（だめなら、この種は使わない）
  if (!exitZoneFloor() || objs.some(o => o.t !== 'exit' && exitZone(o.x, o.y))) return null;
  return { W, H, tiles: t, objs, lm: { exit: { x: exit.x, y: exit.y } } };
}
// v6.1cまでの洞窟（40×30）
function genCaveOld() {
  const W = 40, H = 30, t = new Uint8Array(W * H).fill(T.CWALL);
  const set = (x, y) => { if (x > 0 && y > 0 && x < W - 1 && y < H - 1) t[y * W + x] = T.CFLOOR; };
  const circ = (cx, cy, r) => { for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) if ((x - cx) ** 2 + (y - cy) ** 2 <= r * r) set(x, y); };
  const line = (x0, y0, x1, y1, r) => { const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0) * 2); for (let i = 0; i <= n; i++) circ(x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, r); };
  circ(20, 24, 4); line(20, 24, 20, 27, 1);
  circ(9, 20, 4); line(20, 23, 9, 20, 1.2);
  circ(31, 19, 4); line(20, 23, 31, 19, 1.2);
  circ(20, 14, 4); line(9, 20, 20, 14, 1.2); line(31, 19, 20, 14, 1.2);
  circ(8, 10, 3); line(20, 14, 8, 10, 1.2);
  circ(20, 4, 3.2); circ(13, 4, 2.4); circ(27, 4, 2.4); line(13, 4, 27, 4, 1);
  line(20, 6, 20, 11, 1);
  const objs = []; const add = (type, x, y, extra) => objs.push(Object.assign({ t: type, x, y }, extra || {}));
  for (let y = 8; y <= 9; y++) for (let x = 14; x <= 26; x++) if (t[y * W + x] === T.CFLOOR) add('hardRock', x, y);
  add('exit', 20, 27); add('diary', 17, 24, { page: 2 });
  for (const [x, y] of [[7, 22], [6, 18], [11, 22], [33, 17], [34, 20], [30, 22]]) add('ironVein', x, y);
  for (const [x, y] of [[7, 9], [9, 12], [23, 16], [17, 12], [33, 21]]) add('crystal', x, y);
  for (const [x, y] of [[23, 26], [12, 19], [29, 17]]) add('boulder', x, y);
  for (const [x, y] of [[12, 4], [28, 4], [17, 5], [23, 5]]) add('goldVein', x, y);
  add('shrine', 20, 2); add('diary', 22, 3, { page: 3 });
  return { W, H, tiles: t, objs, lm: { exit: { x: 20, y: 27 } } };
}

/* ---------- 8. 地形の描画（一度だけ） ---------- */
const TC = {
  [T.DEEP]: ['#2b5f9e', '#25558f', '#3a6fae'], [T.SHALLOW]: ['#4aa0d6', '#3f93c9', '#66b6e2'],
  [T.SAND]: ['#ecd9a0', '#dcc589', '#f6e8c0'], [T.GRASS]: ['#63b350', '#559f44', '#78c460'],
  [T.FOREST]: ['#418c3d', '#377a34', '#4f9c48'], [T.ROCK]: ['#a59c8c', '#918877', '#bbb2a2'],
  [T.SPRING]: ['#66c8ec', '#52b6de', '#9ae0f6'], [T.PIER]: ['#a87440', '#7a5028', '#c08a50'],
  [T.PATH]: ['#c8a36a', '#b58f58', '#d6b47e'], [T.CFLOOR]: ['#4b4352', '#40384a', '#575062'],
  [T.CWALL]: ['#2a2430', '#221d28', '#3a3242'],
  [T.CLIFF]: ['#857a66', '#6e6352', '#a39680'], [T.LEDGE]: ['#8a6a3e', '#7a5a32', '#9a7a48'],
  [T.WFLOOR]: ['#b98a54', '#a87a46', '#c99a62'], [T.WWALL]: ['#6a4a2a', '#5a3e22', '#7a5a34'],   // v7c：木造の家   // v6c。v6.1e：ふちは茶色（地図・ミニマップでは台地の縁取りに見える）
};
// v6.1e：台地の上の草地（まわりより少し明るい）
const TC_UP = { [T.GRASS]: ['#74c25a', '#66b04e', '#8ad06e'], [T.FOREST]: ['#4f9c48', '#448a3e', '#5eab55'] };
function renderTerrain(map) {
  const { W, H, tiles } = map, c = mkCanvas(W * 16, H * 16), x = c.getContext('2d'), img = x.createImageData(c.width, c.height), d = img.data;
  const at = (tx, ty) => (tx < 0 || ty < 0 || tx >= W || ty >= H) ? (map.name === 'cave' || map.name === 'cave2' ? T.CWALL : map.name === 'house' ? T.WWALL : T.DEEP) : tiles[ty * W + tx];
  const put = (px, py, col) => { const k = (py * c.width + px) * 4, rgb = hexRgb(col); d[k] = rgb[0]; d[k + 1] = rgb[1]; d[k + 2] = rgb[2]; d[k + 3] = 255; };
  // v6.1e：台地（上の草地・ふち・崖の壁）かどうか
  const onPlat = (x, y) => !!(map.plat && x >= 0 && y >= 0 && x < W && y < H && map.plat[y * W + x]);
  const isPlat = (x, y) => { const v = at(x, y); return v === T.LEDGE || v === T.CLIFF || onPlat(x, y); };
  for (let ty = 0; ty < H; ty++) for (let tx = 0; tx < W; tx++) {
    const v = at(tx, ty), pal = (v === T.GRASS || v === T.FOREST) && onPlat(tx, ty) ? TC_UP[v] : TC[v];   // v6.1e：台地の上は明るめ
    const nN = at(tx, ty - 1), nS = at(tx, ty + 1), nW = at(tx - 1, ty), nE = at(tx + 1, ty);
    for (let py = 0; py < 16; py++) for (let px = 0; px < 16; px++) {
      const gx = tx * 16 + px, gy = ty * 16 + py, h = hash2(gx, gy, 7);
      let col = h < 0.08 ? pal[1] : h > 0.94 ? pal[2] : pal[0];
      const edge = (n, dist) => (n && dist);
      if (isWater(v)) {
        const near = (isLandT(nN) || nN === T.PIER) && py < 3 || (isLandT(nS) && py > 12) || (isLandT(nW) && px < 3) || (isLandT(nE) && px > 12);
        const near2 = (isLandT(nN) && py < 1) || (isLandT(nS) && py > 14) || (isLandT(nW) && px < 1) || (isLandT(nE) && px > 14);
        if (near2 && h < 0.9) col = '#e4f6fb'; else if (near && h < 0.45) col = '#bfe4f2';
        if (v === T.DEEP && (nN === T.SHALLOW || nS === T.SHALLOW || nW === T.SHALLOW || nE === T.SHALLOW) && h < 0.3) col = '#3a7cbc';
      } else if (v === T.SAND) {
        if ((isWater(nN) && py < 2) || (isWater(nS) && py > 13) || (isWater(nW) && px < 2) || (isWater(nE) && px > 13)) col = h < 0.5 ? '#d6be82' : '#cdb478';
      } else if (v === T.GRASS || v === T.FOREST) {
        if (nN === T.CLIFF && py < 4) col = py < 2 ? '#2f6a2a' : '#3d7a33';   // v6c：崖の壁の下の影
        else if (nN === T.LEDGE && py < 2 && !onPlat(tx, ty)) col = py === 0 ? '#3f7f35' : '#4a8f3c';   // v6.1e：台地のふちの下に、うすい影
        else if (edge(nN === T.SAND || nN === T.PATH, py < 1) || edge(nS === T.SAND || nS === T.PATH, py > 14) || edge(nW === T.SAND || nW === T.PATH, px < 1) || edge(nE === T.SAND || nE === T.PATH, px > 14)) col = '#4c973f';
        else if (h > 0.996) col = hash2(gx, gy, 9) < 0.5 ? '#f6f0a0' : '#f4b0c8';
        else if (v === T.GRASS && (px + py * 3) % 7 === 0 && h > 0.7) col = '#6fbe58';
      } else if (v === T.ROCK) {
        if (edge(nN !== T.ROCK && nN !== T.PATH, py < 1) || edge(nS !== T.ROCK && nS !== T.PATH, py > 14) || edge(nW !== T.ROCK && nW !== T.PATH, px < 1) || edge(nE !== T.ROCK && nE !== T.PATH, px > 14)) col = '#8a8170';
        else if ((px * 7 + py * 13 + tx * 5 + ty * 3) % 23 === 0) col = '#7d7464';
      } else if (v === T.PIER) {
        col = py % 4 === 3 ? '#7a5028' : (h < 0.15 ? '#9a6a38' : '#a87440');
        if (px === 0 || px === 15) col = '#5a3a22';
        if ((px === 2 || px === 13) && py % 4 === 1) col = '#3a2a1a';
      } else if (v === T.SPRING) {
        if ((nN !== T.SPRING && py < 1) || (nS !== T.SPRING && py > 14) || (nW !== T.SPRING && px < 1) || (nE !== T.SPRING && px > 14)) col = '#8a8d99';
      } else if (v === T.CWALL) {
        const open = n => n === T.CFLOOR || n === T.SPRING;
        if (open(nS)) { if (py >= 10) col = py === 10 ? '#4a4054' : py === 15 ? '#1a1520' : (h < 0.15 ? '#332b3c' : '#3d3446'); if (py >= 11 && py <= 14 && hash2(gx, ty, 31) < 0.07) col = '#2a2330'; }   // v6.1d：壁の面に、すじ（しみ）
        else if (h < 0.1) col = '#1e1a24';
        else if (vnoise(gx / 9, gy / 9, 17) > 0.72 && h < 0.5) col = '#2e2836';   // v6.1d：岩肌のむら
        if (open(nN) && py < 2) col = py === 0 ? '#3d3446' : '#332b3c';   // v6.1d：上が床なら、壁の上のふち
        if (open(nW) && px < 2 && !(open(nS) && py >= 10)) col = px === 0 ? '#3a3242' : '#2f2836';   // 左右のふち
        if (open(nE) && px > 13 && !(open(nS) && py >= 10)) col = px === 15 ? '#3a3242' : '#2f2836';
      } else if (v === T.WFLOOR) {   // v7c：木の床（板の継ぎ目）
        const row = Math.floor(py / 4), seam = (px + row * 6 + tx * 5) % 16 === 0;
        if (py % 4 === 3) col = '#8a6034'; else if (seam) col = '#946a3c'; else if (h < 0.06) col = '#a87a46'; else if (py % 4 === 0) col = '#c99a62';
      } else if (v === T.WWALL) {   // v7c：丸太の壁（下が床なら壁の面、上のふちは暗く）
        const open = n => n === T.WFLOOR;
        if (open(nS)) { col = py % 5 === 4 ? '#4a321a' : (py % 5 === 0 ? '#8a6a44' : '#6e4e2c'); if (tx % 4 === 2 && py >= 3 && py <= 10 && px >= 4 && px <= 11) col = (px === 4 || px === 11 || py === 3 || py === 10 || px === 7 || px === 8) ? '#4a321a' : '#a8d8f0'; }   // ところどころに窓
        else col = h < 0.15 ? '#3a2814' : '#4a3420';
        if (open(nW) && px < 2) col = '#4a321a'; if (open(nE) && px > 13) col = '#4a321a';
      } else if (v === T.CLIFF) {   // v6c：崖の壁（地層の縞・上のふちは草・根もとは影）
        const top = nN !== T.CLIFF, bot = nS !== T.CLIFF, ry = (top ? 0 : 16) + py;
        if ((ry + (tx * 3) % 5) % 6 === 0) col = '#6a5f4e';
        if ((px === 0 && nW !== T.CLIFF) || (px === 15 && nE !== T.CLIFF)) col = '#5a5040';
        if (top && py < 2) col = py === 0 ? '#4c973f' : '#b5a88e';
        if (bot && py > 12) col = py === 15 ? '#3e372c' : '#5e5446';
        if (hash2(gx * 3, gy, 11) > 0.985) col = '#4e4538';
      } else if (v === T.LEDGE) {   // v6c：台地のふち。v6.1e：岩のブロックをやめて、台地の草地＋外側に細い茶色の線（歩けないのは今まで通り）
        const up = TC_UP[T.GRASS]; col = h < 0.08 ? up[1] : h > 0.94 ? up[2] : up[0];
        const oN = !isPlat(tx, ty - 1), oS = !isPlat(tx, ty + 1), oW = !isPlat(tx - 1, ty), oE = !isPlat(tx + 1, ty);
        const LD = '#4a2e16', LB = '#9a6232';   // 線の外側（こげ茶）と内側（茶）
        if (oN && py < 2) col = py === 0 ? LD : LB;
        if (oS && py > 13) col = py === 15 ? LD : LB;
        if (oW && px < 2) col = px === 0 ? LD : LB;
        if (oE && px > 13) col = px === 15 ? LD : LB;
        // ななめの角：上下左右は台地なのに、角の外だけ地面の時は、角を少し描いて線をつなぐ
        if (!oN && !oW && !isPlat(tx - 1, ty - 1) && px < 2 && py < 2) col = px === 0 && py === 0 ? LD : LB;
        if (!oN && !oE && !isPlat(tx + 1, ty - 1) && px > 13 && py < 2) col = px === 15 && py === 0 ? LD : LB;
        if (!oS && !oW && !isPlat(tx - 1, ty + 1) && px < 2 && py > 13) col = px === 0 && py === 15 ? LD : LB;
        if (!oS && !oE && !isPlat(tx + 1, ty + 1) && px > 13 && py > 13) col = px === 15 && py === 15 ? LD : LB;
      } else if (v === T.CFLOOR) {
        // v6.1d：しめった所のむら・小石・ひび・壁ぎわの影・泉のまわりのこけ
        if (vnoise(gx / 40, gy / 40, 13) > 0.64) col = h < 0.08 ? '#3a3342' : h > 0.94 ? '#4e4758' : '#443c4b';
        const pb = hash2(tx, ty, 21), pxh = 2 + Math.floor(hash2(tx, ty, 22) * 11), pyh = 3 + Math.floor(hash2(ty, tx, 23) * 10);
        if (pb < 0.22 && py === pyh && (px === pxh || px === pxh + 1)) col = px === pxh ? '#6c6476' : '#5c5466';
        else if (pb < 0.22 && py === pyh + 1 && (px === pxh || px === pxh + 1)) col = '#352e3c';
        if (hash2(tx, ty, 25) < 0.07 && Math.abs((px - 3) - (py - 5) * 0.8) < 0.6 && px > 2 && px < 12 && py > 4 && py < 13) col = '#383141';
        if ((nN === T.SPRING || nS === T.SPRING || nW === T.SPRING || nE === T.SPRING) && h < 0.35) col = h < 0.12 ? '#3f5a48' : '#4a5c4e';
        if (nN === T.CWALL && py < 2) col = '#2e2834';
        else if (nN === T.CWALL && py < 4 && h < 0.5) col = '#3b3442';
        else if ((nW === T.CWALL && px < 1) || (nE === T.CWALL && px > 14)) col = '#3a3342';
        else if (h > 0.985) col = '#6a6274';
      }
      put(gx, gy, col);
    }
  }
  x.putImageData(img, 0, 0);
  return c;
}

/* ---------- 9. マップ管理 ---------- */
const maps = {};
function buildMap(name, data, objs) {
  const m = { name, W: data.W, H: data.H, tiles: data.tiles, lm: data.lm, objs, occ: new Array(data.W * data.H).fill(null), plat: data.plat || null };   // v6.1e：台地の上のマス
  m.terrain = typeof document !== 'undefined' ? renderTerrain(m) : null;
  rebuildOcc(m);
  if (name === 'island') buildSpawnLists(m);
  return m;
}
const HOUSE_FP = [[0, 0], [2, 0], [0, -1], [1, -1], [2, -1], [0, -2], [1, -2], [2, -2]];   // v7c：完成した家（下の真ん中＝ドアは通れる）
function fpOf(o) { if (o.t === 'miner' && o.small) return [[0, 0]]; if (o.t === 'house') return o.done ? HOUSE_FP : HOUSE_FP.concat([[1, 0]]); if (o.t === 'ladder') return Array.from({ length: Math.max(1, o.h | 0) }, (_, i) => [0, i]); return OBJ[o.t] && OBJ[o.t].fp || [[0, 0]]; }   // v6c：縄梯子は崖の高さぶん
function rebuildOcc(m) { m.occ.fill(null); for (const o of m.objs) occAdd(m, o); }
function occAdd(m, o) { for (const [dx, dy] of fpOf(o)) { const x = o.x + dx, y = o.y + dy; if (x >= 0 && y >= 0 && x < m.W && y < m.H) m.occ[y * m.W + x] = o; } }
function occDel(m, o) { for (const [dx, dy] of fpOf(o)) { const x = o.x + dx, y = o.y + dy; if (x >= 0 && y >= 0 && x < m.W && y < m.H && m.occ[y * m.W + x] === o) m.occ[y * m.W + x] = null; } }
function addObj(m, o) { m.objs.push(o); occAdd(m, o); return o; }
function removeObj(m, o) { const i = m.objs.indexOf(o); if (i >= 0) m.objs.splice(i, 1); occDel(m, o); }
function tileAt(m, x, y) { if (x < 0 || y < 0 || x >= m.W || y >= m.H) return m.name === 'cave' || m.name === 'cave2' ? T.CWALL : T.DEEP; return m.tiles[y * m.W + x]; }
function objAt(m, x, y) { if (x < 0 || y < 0 || x >= m.W || y >= m.H) return null; return m.occ[y * m.W + x]; }
function isBlocked(m, x, y) { const v = tileAt(m, x, y); if (!WALK[v]) { const lo = objAt(m, x, y); return !(lo && lo.t === 'ladder'); } const o = objAt(m, x, y); return !!(o && OBJ[o.t] && OBJ[o.t].block); }   // v6c：縄梯子のある崖は通れる
function buildSpawnLists(m) {
  const L = { sand: [], shore: [], land: [], wreck: [] }, lm = m.lm;
  for (let y = 1; y < m.H - 1; y++) for (let x = 1; x < m.W - 1; x++) {
    const v = m.tiles[y * m.W + x]; if (!isLandT(v) || v === T.PATH) continue;
    const near = (a, r) => Math.abs(x - a.x) <= r && Math.abs(y - a.y) <= r;
    if (near(lm.spawn, 3) || near(lm.box, 2) || near(lm.cave, 2) || near(lm.hut, 2) || near(lm.spring, 2)) continue;
    L.land.push([x, y]);
    if (v === T.SAND) {
      L.sand.push([x, y]);
      if (DIRV.some(([dx, dy]) => isWater(tileAt(m, x + dx, y + dy)))) L.shore.push([x, y]);
      if (Math.hypot(x - lm.wreck.x - 1, y - lm.wreck.y) < 7) L.wreck.push([x, y]);
    }
  }
  m.spawn = L;
}

/* ---------- 10. 設定（セーブとは別保存） ---------- */
const settings = { swapAB: false, swapXY: false, se: true, vol: 6, touchSize: 1, shake: true, endings: [], slotAssist: true, tutorial: true, craftBench: false, qeTabs: false, keyGuide: true, bgm: true, bgmVol: 5, autoTool: true, uiBig: false, dayDay: 210, dayNight: 90, zeniTr: false, endV: 0 };   // v8f：endV＝エンディングの記号の版（2＝A〜Eに振り直した後）   // v8e：zeniTr＝ゼニ丸翻訳   // v6.2：dayDay・dayNight＝1日の昼と夜の長さ（秒。タイトルのデバッグで変更）   // v6.1e：uiBig＝UIを大きめに   // v6b：autoTool＝道具・武器の自動切り替え
function loadSettings() {
  const SETTINGS_DEF = JSON.parse(JSON.stringify(settings));   // v8e：設定の初期値（壊れた項目を戻す用）
  try { const s = JSON.parse(localStorage.getItem(CONFIG.settingsKey) || '{}'); Object.assign(settings, s); if (!Array.isArray(settings.endings)) settings.endings = []; } catch (e) { /* 破損時は既定値 */ }
if (settings.endV !== 2) { settings.endings = [...new Set(settings.endings.map(k => ENDING_OLD2NEW[k]).filter(Boolean))]; settings.endV = 2; try { localStorage.setItem(CONFIG.settingsKey, JSON.stringify(settings)); } catch (e) { /* 保存できなくても続ける */ } }   // v8f：v8eまでの記録を新しい記号に読み替える（F・Gは外れる）
settings.endings = settings.endings.filter(k => ENDING_ORDER.includes(k));   // v8e：削除したエンディング（F）の記録は外す
for (const k in SETTINGS_DEF) if (typeof settings[k] !== typeof SETTINGS_DEF[k] || (typeof settings[k] === 'number' && !isFinite(settings[k]))) settings[k] = SETTINGS_DEF[k];   // v8e：設定データの一部が壊れていても、その項目だけ初期値に戻して起動する
  settings.uiBig = settings.uiBig === true;   // v6.1e
  // v6.2：1日の長さ（壊れた値は初期値に戻す）
  const dd = Math.round(+settings.dayDay), dn = Math.round(+settings.dayNight);
  settings.dayDay = Number.isFinite(dd) ? clamp(dd, 60, 900) : 210; settings.dayNight = Number.isFinite(dn) ? clamp(dn, 30, 600) : 90;
  applyDayLen();
}
// v6.2：1日の長さを反映する（昼＝6:00〜20:00、夜＝20:00〜翌6:00）
function applyDayLen() { CONFIG.dayPart = settings.dayDay; CONFIG.dayLength = settings.dayDay + settings.dayNight; }
const fmtDur = sec => { sec = Math.round(sec); const m = Math.floor(sec / 60), r = sec % 60; return m ? `${m}分${r ? r + '秒' : ''}` : `${r}秒`; };
function saveSettings() { try { localStorage.setItem(CONFIG.settingsKey, JSON.stringify(settings)); } catch (e) { /* 容量不足など */ } }
function applySettings() {
  document.documentElement.style.setProperty('--tb', String(settings.touchSize));
  if (canvas) resize();   // v6.1e：UIの大きさを反映
  Sound.setVol(); BGM.setVol();
  document.body.classList.toggle('kg-on', !!settings.keyGuide);   // キーボード操作ガイド（画面下）
  setTimeout(layoutTouch, 0);
}

/* ---------- 11. ゲーム状態 ---------- */
let game = null;
const player = { x: 0, y: 0, dir: 0, anim: 0, moving: false, lunge: 0 };
const state = {
  scene: 'boot', target: null, gather: { o: null, prog: 0, hits: 0 }, holdCd: 0, fishing: null,
  rocks: [], rockTimer: 20, particles: [], floats: [], shake: 0, autosave: 0, fading: false, faintLock: false,
  warn: {}, pendingTalks: [], time: 0, titleT: 0, capToast: 0, drinkCd: 0,
  place: null, cam: { x: 0, y: 0 }, konami: 0, konamiGo: false, god: false, hotName: 0,
  stIdle: 0, boltT: 15, flash: 0, conds: [], condHtml: null,
  mobs: [], mobT: 2, atkCd: 0, invuln: 0, swing: 0, noMobs: false,
  infSt: false, timeStop: false, noclip: false, dbgTap: 0,   // v6a：デバッグ（スタミナ無限・時間停止・壁貫通）と、地図の隠しタップ
  lmb: false, aim: null,   // v6b：左クリックを押している間・マウスの位置（攻撃の向き）
};
let curSlot = 1;

function newGameData(opt) {
  const pk = opt.map === 'old' ? oldMapPick() : pickMapSeed(opt.seed), isl = pk.isl, cav = genCave(pk.cav || 2);   // v8f：ランダム生成は洞窟もランダム（cav 3）
  isl.objs = isl.objs.filter(o => o.t !== 'box');   // v8f：回収ボックスはなくした（売買はついてくるゼニ丸で）。場所（lm.box）は地形づくりの目印として残す   // v6c：新しいゲームは広い島。v6.1d：広い洞窟。v8a：毎回ちがう島（種はセーブに残す）
  const g = {
    v: CONFIG.saveVersion, name: opt.name, contract: { debt: opt.debt, days: opt.days, rate: opt.rate, free: !!opt.free },
    day: 1, time: hourToTime(7), money: 0,   /* v6.2：1日目は7:00から */ debt: opt.debt, repaid: 0, interestPaid: 0,
    hp: 100, hunger: 85, thirst: 75,
    inv: { coconut: 2 }, tools: {}, keyItems: {},   // v8a：器は作業台で作る（初期の持ち物から外した）
    slots: [{ id: 'coconut', n: 2 }].concat(new Array(CONFIG.slotsBase - 1).fill(null)), up: {}, bp: {}, market: { m: {}, ev: null },
    map: 'island', px: isl.lm.spawn.x * 16 + 8, py: isl.lm.spawn.y * 16 + 12, dir: 0,
    objs: { island: isl.objs, cave: cav.objs, cave2: genCave2().objs },
    flags: {}, stats: { earned: 0, sold: 0, gathered: 0, crafted: 0, fish: 0, spent: 0 },
    raftBuilt: false, diaries: [], turtleSold: false,
    mode: opt.mode === 'hard' ? 'hard' : 'normal', hotSel: 0, savedAt: 0,
    stamina: 100, exhaust: false, sick: 0, weather: 'sun', rainAcc: 0, stageI: 0, penalty: 0, storage: {},
    awake: 0, caveSeen: null,   // v6a：覚醒の残り秒数／洞窟の地図（歩いて見た所）
    off: null,   // v6b：左手（オフハンド）
    tdef: [CONFIG.dayPart, CONFIG.dayLength], rainPlan: null,   // v6.2：時刻を測った1日の長さ／雨水の予定
    isl: 2,   // v6c：島の種類（2＝広い島。古いセーブは1）
    cav: 2,   // v6.1d：洞窟の種類（2＝広い洞窟。古いセーブは1）
    casino: { open: false, net: 0, plays: 0, coins: 0, pend: null, replay: false, reel: [1, 3, 5], bb: 0, rb: 0 },
  };
  if (pk.seed) g.seed = pk.seed;   // v8a：マップの種（v8d：旧マップは種なし＝今までの島）
  if (pk.seed4 != null) g.seed4 = pk.seed4;   // v8f：4桁のシード値（表示用）
  g.cav = pk.cav || 2;   // v8f：ランダム生成は洞窟もランダム（3）。旧マップはv7の広い洞窟（2）
  return g;
}
// v7a：崖の壁の真下にあるしげみは消す（縄梯子を掛けても登れず、無駄になるため。古いセーブも読み込み時に消す）
function dropCliffBush(m) { for (const o of m.objs.slice()) if (o.t === 'bush' && tileAt(m, o.x, o.y - 1) === T.CLIFF) removeObj(m, o); }
// v7b：銅鉱脈（島の岩場に4か所）・石炭鉱脈（洞窟の入口の近くに4か所）。今までのマップの乱数は使わず、別の乱数で最後に置く。古いセーブにも1回だけ足す
function addV7Veins() {
  const g = game; if (g.flags.v7veins) return; g.flags.v7veins = 1;
  const rnd2 = mulberry32(MAP_SEED + 77);
  const pick = (m, cands, n, gap, kind) => {
    for (let i = cands.length - 1; i > 0; i--) { const j = Math.floor(rnd2() * (i + 1)); [cands[i], cands[j]] = [cands[j], cands[i]]; }
    const got = [];
    for (const [x, y] of cands) { if (got.length >= n) break; if (objAt(m, x, y) || got.some(p => Math.hypot(p[0] - x, p[1] - y) < gap)) continue; addObj(m, { t: kind, x, y }); got.push([x, y]); }
    return got.length;
  };
  const open4 = (m, x, y, ok) => [[1, 0], [-1, 0], [0, 1], [0, -1]].filter(([dx, dy]) => ok(tileAt(m, x + dx, y + dy)) && !objAt(m, x + dx, y + dy)).length;
  // 島：岩場の空いたマス。道のそばや、スタート・ボックス・洞窟の入口などの近くは避ける
  { const m = maps.island, lm = m.lm || {}, keep = ['spawn', 'box', 'hut', 'cave', 'spring', 'raft', 'wreck', 'pier'].map(k => lm[k]).filter(Boolean), c = [];
    for (let y = 2; y < m.H - 2; y++) for (let x = 2; x < m.W - 2; x++) {
      if (tileAt(m, x, y) !== T.ROCK || objAt(m, x, y) || (m.plat && m.plat[y * m.W + x])) continue;
      if ([[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => tileAt(m, x + dx, y + dy) === T.PATH)) continue;
      if (keep.some(p => Math.hypot(p.x - x, p.y - y) < 4)) continue;
      if (open4(m, x, y, v => WALK[v]) < 3) continue;   // 通り道をふさがない
      c.push([x, y]);
    }
    pick(m, c, 4, 5, 'copperVein'); }
  // 洞窟：入口（出口）から3〜10マスの、開けた床
  { const m = maps.cave, ex = (m.lm && m.lm.exit) || null, c = [];
    if (ex) for (let y = 1; y < m.H - 1; y++) for (let x = 1; x < m.W - 1; x++) {
      if (tileAt(m, x, y) !== T.CFLOOR || objAt(m, x, y)) continue;
      const d = Math.hypot(ex.x - x, ex.y - y); if (d < 3 || d > 10) continue;
      let fl = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if ((dx || dy) && tileAt(m, x + dx, y + dy) === T.CFLOOR && !objAt(m, x + dx, y + dy)) fl++;
      if (fl < 7) continue;   // 開けた所だけ（通路はふさがない）
      c.push([x, y]);
    }
    pick(m, c, 4, 3, 'coalVein'); }
}
// v8b：古いセーブの採掘機（1マス）を2×2に広げる。元のマスを含む2×2で、岩場かつ設備のない所を探す（自然の物はどかす）
function widenMiners() {
  const m = maps.island; if (!m) return;
  for (const o of m.objs.slice()) {
    if (o.t !== 'miner' || o.w2) continue;
    o.w2 = 1; occDel(m, o); o.small = 1;
    for (const [ax, ay] of [[0, 0], [-1, 0], [0, 1], [-1, 1]]) {
      const nx = o.x + ax, ny = o.y + ay, cells = OBJ.miner.fp.map(([dx, dy]) => [nx + dx, ny + dy]);
      if (!cells.every(([x, y]) => tileAt(m, x, y) === T.ROCK && (!objAt(m, x, y) || isNatural(objAt(m, x, y))))) continue;
      for (const [x, y] of cells) { const q = objAt(m, x, y); if (q && q !== o) removeObj(m, q); }
      o.x = nx; o.y = ny; delete o.small; break;
    }
    occAdd(m, o);
  }
}
function setupMaps() {
  MAP_SEED = Number.isInteger(game.seed) && game.seed > 0 ? game.seed : CONFIG.islandSeed;   // v8a
  const isl = genIsland(game.isl === 2 ? 2 : 1), cav = genCave(game.cav === 3 ? 3 : game.cav === 2 ? 2 : 1);   // v6.1d。v8f：3＝ランダム生成の洞窟
  maps.island = buildMap('island', isl, game.objs.island);
  dropCliffBush(maps.island);   // v7a
  for (const o of maps.island.objs.slice()) if (o.t === 'box') removeObj(maps.island, o);   // v8f：古いセーブの回収ボックスも消す
  maps.cave = buildMap('cave', cav, game.objs.cave);
  if (!game.objs.cave2) game.objs.cave2 = genCave2().objs;   // v5：地下2階（古いセーブにも追加）
  maps.cave2 = buildMap('cave2', genCave2(), game.objs.cave2);
  if (!game.objs.house) game.objs.house = genHouse().objs;   // v7c：木造の家の中（古いセーブにも追加）
  if (!game.flags.house7) { fixHouseObjs(game.objs.house); game.flags.house7 = 1; }   // v8b：家の中を縦7×横11にした
  maps.house = buildMap('house', genHouse(), game.objs.house);
  addV7Veins(); ensureDebtLog();   // v7b
  widenMiners();   // v8b
  ensureCaveSeen();
  ensureLiner();
  rebuildStations();
}
// 沈没船カジノを浜辺に置く（島の形から毎回同じ場所に決まる。古いセーブにも追加される）
const linerUnlocked = () => !!(game && (game.flags.m25 || game.flags.linerSeen || game.casino.open));
function ensureLiner() {
  const mp = maps.island, ex = mp.objs.find(o => o.t === 'liner');
  if (!linerUnlocked()) { if (ex) removeObj(mp, ex); return; }   // v5：借金を25%返すまでは、客船は現れない
  if (ex) return;
  const rng = mulberry32(MAP_SEED + 77), c = mp.spawn.sand.slice();
  for (let i = c.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [c[i], c[j]] = [c[j], c[i]]; }
  const sp = mp.lm.spawn, wr = mp.lm.wreck;
  for (const [x, y] of c) {
    if (Math.hypot(x - sp.x, y - sp.y) < 14 || Math.hypot(x - wr.x, y - wr.y) < 10) continue;
    let ok = true;
    for (const [dx, dy] of OBJ.liner.fp) { const tx = x + dx, ty = y + dy; if (tileAt(mp, tx, ty) !== T.SAND || objAt(mp, tx, ty)) { ok = false; break; } }
    if (ok && (isBlocked(mp, x + 1, y + 1) || isBlocked(mp, x - 1, y) && isBlocked(mp, x + 3, y))) ok = false;
    if (ok) { addObj(mp, { t: 'liner', x, y }); return; }
  }
}
// v6a：洞窟の地図は、歩いて見た所だけ描く（1＝見た）。v5以前のセーブで洞窟に入ったことがあれば、全部見えた状態から始める
function ensureCaveSeen() {
  const N = maps.cave.W * maps.cave.H, full = !!game._fogAll; delete game._fogAll;
  if (!Array.isArray(game.caveSeen) || game.caveSeen.length !== N) game.caveSeen = new Array(N).fill(full ? 1 : 0);
  else if (full) game.caveSeen.fill(1);
}
function revealCave() {
  if (!game || game.map !== 'cave' || !Array.isArray(game.caveSeen)) return;
  const m = maps.cave, r = torchLit() ? 5 : 3, cx = Math.floor(player.x / 16), cy = Math.floor((player.y - 4) / 16);
  for (let y = cy - r; y <= cy + r; y++) for (let x = cx - r; x <= cx + r; x++) {
    if (x < 0 || y < 0 || x >= m.W || y >= m.H || (x - cx) * (x - cx) + (y - cy) * (y - cy) > r * r + r) continue;
    game.caveSeen[y * m.W + x] = 1;
  }
}
const caveSeenAt = (m, x, y) => m.name !== 'cave' || !game || !Array.isArray(game.caveSeen) || !!game.caveSeen[y * m.W + x];
let stations = [];
function rebuildStations() { stations = []; for (const k in maps) for (const o of maps[k].objs) if (OBJ[o.t] && OBJ[o.t].it === 'station') stations.push(o); }
const curMap = () => maps[game.map];

/* ---------- 12. セーブ／ロード ---------- */
const slotKey = n => CONFIG.slotKey + n;
function readSlot(n) { try { const t = localStorage.getItem(slotKey(n)); return t ? JSON.parse(t) : null; } catch (e) { return null; } }
const slotValid = g => !!(g && g.v >= 1 && g.v <= CONFIG.saveVersion && g.objs && g.objs.island);
function slotInfo(n) {
  const g = readSlot(n); if (!slotValid(g)) return null;
  return { name: g.name || '？', day: g.day || 1, days: g.contract ? g.contract.days : 0, debt: Math.max(0, g.debt || 0), mode: g.mode === 'hard' ? 'hard' : 'normal', savedAt: g.savedAt || 0 };
}
function hasSave(n) { if (n) return !!slotInfo(n); for (let i = 1; i <= CONFIG.slots; i++) if (slotInfo(i)) return true; return false; }
// v1の単一セーブをスロット1へ移す（スロット1が空の時だけ）
function migrateLegacySave() {
  try {
    const old = localStorage.getItem(CONFIG.saveKey); if (!old) return;
    if (!localStorage.getItem(slotKey(1))) { localStorage.setItem(slotKey(1), old); localStorage.removeItem(CONFIG.saveKey); }
  } catch (e) { /* noop */ }
}
function saveGame(silent) {
  if (!game || state.scene !== 'play') return false;
  game.px = player.x; game.py = player.y; game.dir = player.dir; game.savedAt = Date.now(); game.tdef = [CONFIG.dayPart, CONFIG.dayLength];   // v6.2：1日の長さも記録
  try {
    if (game.demo) return false;   // デモプレイはセーブしない
    localStorage.setItem(slotKey(curSlot), JSON.stringify(game, (k, v) => (k && k[0] === '_') ? undefined : v)); state.dirty = false;
    if (!silent) toast(`スロット${curSlot}にセーブしました`, 'good');
    return true;
  } catch (e) { if (!silent) toast('セーブに失敗しました（容量不足の可能性）', 'bad'); return false; }
}
function loadGame(n) {
  try {
    const g = readSlot(n);
    if (!slotValid(g)) return false;
    g.inv = g.inv || {}; g.tools = g.tools || {}; g.up = g.up || {}; g.bp = g.bp || {}; g.flags = g.flags || {};
    g.market = g.market || { m: {}, ev: null }; g.market.m = g.market.m || {}; g.stats = g.stats || {}; g.diaries = g.diaries || [];
    // v1 → v2 の移行
    g.mode = g.mode === 'hard' ? 'hard' : 'normal';
    // v3：個数式の持ち物 → 枠（スロット）式へ
    // v4：アイテムバー6→8枠。旧セーブは「アイテムバー6＋空き2」の後ろに持ち物を並べ直す
    if (Array.isArray(g.slots) && g.v < 7) g.slots = g.slots.slice(0, 6).concat([null, null], g.slots.slice(6));
    if (!Array.isArray(g.slots)) migrateToSlots(g);
    g.keyItems = g.keyItems || {};
    if (g.inv.turtle && !g.keyItems.turtle && !g.slots.some(x => x && x.id === 'turtle')) g.keyItems.turtle = g.inv.turtle;
    for (let i = 0; i < g.slots.length; i++) { const x = g.slots[i]; if (x && (!(ITEMS[x.id] || TOOLS[x.id]) || (ITEMS[x.id] && ITEMS[x.id].key))) { if (ITEMS[x.id] && ITEMS[x.id].key) g.keyItems[x.id] = (g.keyItems[x.id] || 0) + x.n; g.slots[i] = null; } }
    g.hotSel = clamp(g.hotSel | 0, 0, CONFIG.hotSize - 1);
    // v2b：スタミナ・天気・締め日・水
    if (g.v < 3 && !g.inv.bowl && !g.inv.rawwater && !g.inv.cleanwater) g.inv.bowl = 1;
    g.stamina = g.stamina != null ? g.stamina : 100; g.exhaust = !!g.exhaust; g.sick = g.sick || 0; g.rainAcc = g.rainAcc || 0; g.penalty = g.penalty || 0;
    g.poison = +g.poison > 0 ? Math.min(CONFIG.poison.sec, +g.poison) : 0;   // v6.1c：毒の残り時間（壊れていたら0）
    if (!WEATHER[g.weather]) g.weather = 'sun';
    g.storage = g.storage || {}; g.stats.kills = g.stats.kills || 0;
    g.casino = g.casino || { open: false, net: 0, plays: 0 };
    if (g.casino.coins == null) Object.assign(g.casino, { coins: 0, pend: null, replay: false, reel: [1, 3, 5], bb: 0, rb: 0 });
    if (g.stageI == null) { const st = stagesOf(g.contract); g.stageI = st.findIndex(x => x.day >= g.day); if (g.stageI < 0) g.stageI = st.length; }
    fixTorches(g);
    // v6a：覚醒（プロテイン）と洞窟の地図。壊れた値でも起動できるようにする
    g.awake = Number.isFinite(g.awake) ? clamp(g.awake, 0, CONFIG.awakeSec) : 0;
    g.happy = Number.isFinite(g.happy) ? clamp(g.happy, 0, CONFIG.happySec) : 0;   // v7a
    // v6.2：1日の長さが変わっても「何時か」がずれないよう、セーブした時の長さ（tdef。古いセーブは昼120秒・1日180秒）から今の長さへ直す
    { const td = Array.isArray(g.tdef) && +g.tdef[0] > 0 && +g.tdef[1] > +g.tdef[0] ? [+g.tdef[0], +g.tdef[1]] : [120, 180];
      const t0 = Number.isFinite(+g.time) ? clamp(+g.time, 0, td[1]) : 0, hr = t0 < td[0] ? 6 + t0 * (14 / td[0]) : 20 + (t0 - td[0]) * (10 / (td[1] - td[0]));
      g.time = clamp(hourToTime(hr % 24), 0, CONFIG.dayLength - 0.01); g.tdef = [CONFIG.dayPart, CONFIG.dayLength]; }
    // v6.2：チェストは8枠（古いチェストも広げる）。雨水の予定がおかしければ作り直す
    for (const k in g.objs || {}) for (const o of g.objs[k] || []) if (o && o.t === 'chest') { if (!Array.isArray(o.slots)) o.slots = []; while (o.slots.length < 8) o.slots.push(null); }
    if (!(g.rainPlan && typeof g.rainPlan === 'object' && Array.isArray(g.rainPlan.at))) g.rainPlan = null;
    if (g.v < 8) g._fogAll = !!g.flags.cave;
    if (g.caveSeen != null && !Array.isArray(g.caveSeen)) g.caveSeen = null;
    // v6b：左手（オフハンド）と防具。おかしな値は外す
    if (!(g.off && typeof g.off === 'object' && offOk(g.off.id) && g.off.n > 0)) g.off = null;
    else { g.off.n = clamp(g.off.n | 0 || 1, 1, stackOf(g.off.id)); if (g.off.id === 'torch' && !(g.off.dur > 0)) g.off.dur = TOOLS.torch.dur; delete g.off.eq; }
    g.isl = g.isl === 2 ? 2 : 1;   // v6c：v6bまでのセーブは、今までの島のまま
    if (!(Number.isInteger(g.seed) && g.seed > 0)) delete g.seed;   // v8a：種がない・壊れている時は、今までの島
    if (!(Number.isInteger(g.seed4) && g.seed4 >= 0 && g.seed4 <= 9999 && g.seed)) delete g.seed4;   // v8f：4桁のシード値（表示用）
    g.cav = g.cav === 3 && Number.isInteger(g.seed) && g.seed > 0 ? 3 : g.cav === 2 || g.cav === 3 ? 2 : 1;   // v6.1d：v6.1cまでのセーブは、今までの洞窟のまま（置いた物・地図がずれないように）。v8f：3＝ランダム生成の洞窟（種がない時は広い洞窟）
    let eqN = 0; for (const x of g.slots) if (x && x.eq) { if (!(TOOLS[x.id] && TOOLS[x.id].cat === 'armor') || eqN++) delete x.eq; }
    if (g.v < 16 && g.tut >= 7) g.tut += 2;
    if (g.v < 17) for (const k in g.objs || {}) for (const o of g.objs[k] || []) if (o && o.t === 'furnace' && o.fuel == null) o.fuel = CONFIG.furnaceFuel.max;   // v8b：置いてある炉は燃料満タンにする
    for (const o of (g.objs && g.objs.island) || []) if (o && o.t === 'miner' && !o.w2) o.small = 1;   // v8b：古い採掘機は、まず1マスとして読み込む（あとで2×2に広げる）   // v8a：「作業台を置こう」「器を作ろう」を足した
    g.v = CONFIG.saveVersion;
    game = g; curSlot = n; ensureSlots(); syncInv(); setupMaps();
    if (g._moved) { delete g._moved; setTimeout(() => toast('持ち物の枠に入りきらない分は、小屋の倉庫に移しました', 'bad'), 1500); }
    player.x = g.px; player.y = g.py; player.dir = g.dir || 0;
    if (rectBlocked(player.x, player.y)) { const s = g.map === 'cave' ? maps.cave.lm.exit : g.map === 'cave2' ? maps.cave2.lm.up : maps.island.lm.spawn; player.x = s.x * 16 + 8; player.y = s.y * 16 + 12; }
    return true;
  } catch (e) { console.error(e); return false; }
}
function deleteSave(n) { try { localStorage.removeItem(slotKey(n)); } catch (e) { /* noop */ } }

/* ---------- 13. 効果音（WebAudio） ---------- */
const Sound = {
  ctx: null, master: null, noiseBuf: null, last: {},
  init() {
    try {
      if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
      const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
      this.ctx = new AC(); this.master = this.ctx.createGain(); this.master.connect(this.ctx.destination);
      const len = this.ctx.sampleRate * 0.5, buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate), d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.noiseBuf = buf; this.setVol();
    } catch (e) { this.ctx = null; }
  },
  setVol() { if (this.master) this.master.gain.value = settings.se ? (settings.vol / 10) * 0.5 : 0; },
  tone(f, dur, type, vol, slide, delay) {
    const c = this.ctx, t0 = c.currentTime + (delay || 0), o = c.createOscillator(), g = c.createGain();
    o.type = type || 'square'; o.frequency.setValueAtTime(f, t0); if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f + slide), t0 + dur);
    g.gain.setValueAtTime(vol || 0.2, t0); g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    o.connect(g); g.connect(this.master); o.start(t0); o.stop(t0 + dur + 0.02);
  },
  noise(dur, vol, freq, type, delay) {
    const c = this.ctx, t0 = c.currentTime + (delay || 0), s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.noiseBuf; f.type = type || 'lowpass'; f.frequency.value = freq || 1200;
    g.gain.setValueAtTime(vol || 0.3, t0); g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    s.connect(f); f.connect(g); g.connect(this.master); s.start(t0); s.stop(t0 + dur + 0.02);
  },
  play(n) {
    if (!this.ctx || !settings.se) return;
    const now = performance.now(); if (this.last[n] && now - this.last[n] < 40) return; this.last[n] = now;
    switch (n) {
      case 'ui': this.tone(660, 0.04, 'square', 0.08); break;
      case 'pick': this.tone(880, 0.05, 'square', 0.12); this.tone(1320, 0.06, 'square', 0.1, 0, 0.05); break;
      case 'chop': this.noise(0.08, 0.35, 900); this.tone(180, 0.06, 'triangle', 0.25, -60); break;
      case 'mine': this.noise(0.06, 0.3, 3000, 'highpass'); this.tone(420, 0.05, 'square', 0.12, -120); break;
      case 'crystal': this.tone(1760, 0.12, 'sine', 0.15); this.tone(2350, 0.1, 'sine', 0.1, 0, 0.04); break;
      case 'cut': this.noise(0.07, 0.25, 4000, 'highpass'); break;
      case 'shake': this.noise(0.15, 0.25, 700); break;
      case 'coin': this.tone(988, 0.07, 'square', 0.12); this.tone(1319, 0.14, 'square', 0.12, 0, 0.07); break;
      case 'craft': [523, 659, 784, 1047].forEach((f, i) => this.tone(f, 0.08, 'square', 0.1, 0, i * 0.06)); break;
      case 'error': this.tone(150, 0.14, 'square', 0.15); break;
      case 'eat': this.noise(0.05, 0.2, 1500); this.noise(0.05, 0.2, 1500, 'lowpass', 0.09); break;
      case 'drink': this.tone(500, 0.08, 'sine', 0.2, 300); this.tone(600, 0.08, 'sine', 0.18, 300, 0.1); break;
      case 'tut': this.tone(784, 0.07, 'square', 0.1); this.tone(1047, 0.07, 'square', 0.1, 0, 0.07); this.tone(1568, 0.16, 'square', 0.09, 0, 0.14); break;   // v6.1e：チュートリアルの項目クリア
      case 'poison': this.tone(260, 0.09, 'sine', 0.14, -90); this.tone(190, 0.11, 'sine', 0.11, -60, 0.07); break;   // v6.1c：毒のダメージ
      case 'splash': this.noise(0.2, 0.25, 2500, 'highpass'); break;
      case 'bite': this.tone(1200, 0.06, 'square', 0.16); this.tone(1200, 0.06, 'square', 0.16, 0, 0.1); break;
      case 'catch': [784, 988, 1175].forEach((f, i) => this.tone(f, 0.09, 'square', 0.12, 0, i * 0.07)); break;
      case 'hurt': this.tone(300, 0.2, 'sawtooth', 0.2, -200); break;
      case 'thud': this.noise(0.12, 0.3, 400); break;
      case 'sleep': [392, 330, 262].forEach((f, i) => this.tone(f, 0.3, 'sine', 0.15, 0, i * 0.2)); break;
      case 'door': this.noise(0.3, 0.2, 600); break;
      case 'unlock': [659, 784, 988, 1319].forEach((f, i) => this.tone(f, 0.1, 'triangle', 0.15, 0, i * 0.08)); break;
      case 'talk': this.tone(520 + Math.random() * 80, 0.025, 'square', 0.04); break;
      case 'warn': this.tone(880, 0.1, 'square', 0.12); this.tone(660, 0.12, 'square', 0.12, 0, 0.12); break;
    }
  },
};
function sfx(n) { try { Sound.play(n); } catch (e) { /* noop */ } }
// 曲や画像など、zipの外（versions.json と同じフォルダ）に置くファイルの候補URL
function assetUrls(f) {
  const out = [], add = (u, base) => { try { const s = new URL(u, base || document.baseURI).href; if (/^(https?|file):/.test(s) && !out.includes(s)) out.push(s); } catch (e) { /* 相対URLにできない場所 */ } };
  add('./' + f);
  try { const p = window.parent && window.parent !== window ? window.parent.location.href : null; if (p) { add(f, p); add('new/' + f, p); add('test/new/' + f, p); } } catch (e) { /* 別オリジン */ }
  try { if (document.referrer) { add(f, document.referrer); add('new/' + f, document.referrer); } } catch (e) { /* noop */ }
  add('https://h1ro223.github.io/DRIFT_ISLE/test/new/' + f);
  return out;
}
/* BGM：Game.mp3 をずっとループ再生（ブラウザの仕様で、最初のタップ・キー入力から流れ始める）
   v5：①起動時に置き場所を探す ②読めなければ次の候補を最後まで試す ③流れ始めてから音量の仕組み（WebAudio）につなぐ
   v6.2：iPhoneのDynamic Islandに再生中の表示（波形）が出ないよう、曲をWebAudioで鳴らす（ファイルを読み込んで、ずっとループ）。
         WebAudioで読めない時（ファイルを直接開いた時など）は、今までの<audio>で鳴らす */
const BGM = {
  el: null, gain: null, node: null, urls: [], ui: 0, failed: false, hidden: false, want: false, playing: false, probing: false,
  mode: 'wa', raw: null, buf: null, src: null, decoding: false, off: 0, t0: 0, url: null,
  init() { if (this.urls.length || this.el || this.probing) return; this.urls = assetUrls(CONFIG.bgm); this.probe(); },
  async probe() {
    this.probing = true;
    for (const u of this.urls) {
      try { const r = await fetch(u); if (r.ok) { const ab = await r.arrayBuffer(); if (ab && ab.byteLength > 1000) { this.raw = ab; this.url = u; break; } } } catch (e) { /* 次の候補へ */ }
    }
    this.probing = false;
    if (!this.raw) { this.toElement(); return; }
    this.decode();
  },
  // 曲を音のデータにする（AudioContextは最初のタップ・キー入力で作られるので、それまで待つ）
  decode() {
    if (this.buf || this.decoding || !this.raw || !Sound.ctx) return;
    this.decoding = true; const raw = this.raw; this.raw = null; let fin = false;
    const ok = b => { if (fin) return; fin = true; this.decoding = false; this.buf = b; if (this.want) this.play(); };
    const ng = () => { if (fin) return; fin = true; this.decoding = false; console.warn('BGMをWebAudioで読めなかったので、<audio>で再生します'); this.toElement(); };
    try { const p = Sound.ctx.decodeAudioData(raw, ok, ng); if (p && p.then) p.then(ok, ng); } catch (e) { ng(); }
  },
  // WebAudioが使えない時は、今までの<audio>での再生に切り替える
  toElement() {
    this.mode = 'el';
    if (this.url) this.urls = [this.url].concat(this.urls.filter(x => x !== this.url));
    this.ui = 0; this.makeEl(); if (this.want) this.play();
  },
  makeEl() {
    const a = new Audio(); a.loop = true; a.preload = 'auto'; this.el = a;
    a.addEventListener('error', () => this.next());
    a.addEventListener('playing', () => { this.playing = true; this.connect(); });
    this.setSrc();
  },
  setSrc() {
    const u = this.urls[this.ui]; if (!u) { this.failed = true; return; }
    try { this.el.crossOrigin = new URL(u).origin !== location.origin ? 'anonymous' : null; } catch (e) { /* noop */ }
    this.el.src = u; try { this.el.load(); } catch (e) { /* noop */ }
  },
  next() {
    if (this.playing) return;
    this.ui++; if (this.ui >= this.urls.length) { this.failed = true; console.warn('BGM（' + CONFIG.bgm + '）を読み込めませんでした：', this.urls); return; }
    this.setSrc(); if (this.want) this.play();
  },
  connect() {
    if (this.node || !Sound.ctx || !this.el || !this.playing) return;
    try { this.node = Sound.ctx.createMediaElementSource(this.el); this.gain = Sound.ctx.createGain(); this.node.connect(this.gain); this.gain.connect(Sound.ctx.destination); this.el.volume = 1; } catch (e) { this.node = null; this.gain = null; }
    this.setVol();
  },
  kick() {
    if (!settings.bgm) return; this.want = true;
    if (this.mode === 'el') { if (!this.el) return; this.connect(); if (this.el.paused) this.play(); return; }
    if (!this.urls.length) { this.init(); return; }
    if (this.raw && !this.buf) this.decode();
    this.play();
  },
  play() {
    this.want = true; if (this.hidden || !settings.bgm) return;
    if (this.mode === 'el') { if (!this.el || this.failed) return; try { const p = this.el.play(); if (p && p.catch) p.catch(() => { /* 次の操作でもう一度 */ }); } catch (e) { /* noop */ } return; }
    const c = Sound.ctx; if (!c || !this.buf || this.src) return;
    try {
      if (c.state !== 'running') { const r = c.resume(); if (r && r.catch) r.catch(() => { /* noop */ }); }
      if (!this.gain) { this.gain = c.createGain(); this.gain.connect(c.destination); }
      const sn = c.createBufferSource(), du = this.buf.duration; sn.buffer = this.buf; sn.loop = true; sn.connect(this.gain);
      const off = ((this.off % du) + du) % du;
      sn.start(0, off); this.t0 = c.currentTime - off; this.src = sn; this.playing = true; this.setVol(true);
    } catch (e) { this.src = null; }
  },
  // 止める（続きから流せるよう、位置を覚えておく）
  stopSrc() {
    if (!this.src) return; const c = Sound.ctx;
    try { if (c && this.buf) this.off = (c.currentTime - this.t0) % this.buf.duration; this.src.stop(); } catch (e) { /* noop */ }
    try { this.src.disconnect(); } catch (e) { /* noop */ }
    this.src = null;
  },
  setVol(noPlay) {
    const v = settings.bgm ? clamp(settings.bgmVol, 0, 10) / 10 * 0.6 : 0;
    if (this.gain) this.gain.gain.value = v; else if (this.el) this.el.volume = clamp(v, 0, 1);
    if (this.mode === 'el') { if (!this.el) return; if (!settings.bgm) this.el.pause(); else if (this.el.paused && this.want && !this.hidden) this.play(); return; }
    if (noPlay) return;
    if (!settings.bgm) this.stopSrc(); else if (!this.src && this.want && !this.hidden) this.play();
  },
  hide(h) {
    this.hidden = h;
    if (this.mode === 'el') { if (!this.el) return; if (h) this.el.pause(); else if (settings.bgm && this.want) this.play(); return; }
    if (h) this.stopSrc(); else if (settings.bgm && this.want) this.play();
  },
  status() { return this.failed ? `曲ファイル（${CONFIG.bgm}）が見つかりませんでした。versions.json と同じフォルダに置いてください` : this.playing ? '再生中（ゲーム中ずっと流れます）' : (this.probing || this.decoding) ? '曲を読み込み中…' : 'ゲーム中ずっと流れます'; },
};
/* ---------- 14. 持ち物・お金 ---------- */
/* 持ち物は「枠（スロット）」で管理する。先頭の CONFIG.hotSize 枠がアイテムバー。
   game.slots[i] = null | { id, n } | 道具なら { id, n: 1, dur }。大切なもの（鍵アイテム）は game.keyItems に別で持つ。
   game.inv（id→個数）と game.tools（id→耐久）は、枠から作り直す読み取り用の写し（syncInv）。 */
const isTool = id => !!TOOLS[id];
const isPlace = id => !!(ITEMS[id] && ITEMS[id].place);
const itemName = id => ITEMS[id] ? ITEMS[id].n : TOOLS[id] ? TOOLS[id].n : id;
const isStackTool = id => isTool(id) && (TOOLS[id].stack || 1) > 1;   // 重ねて持てる道具（たいまつ）
const stackOf = id => isTool(id) ? (TOOLS[id].stack || 1) : isPlace(id) ? 1 : (ITEMS[id] && ITEMS[id].stack) || CONFIG.stackMax;   // v6a：プロテインは1枠に1個
const durText = sl => `${Math.ceil(Math.max(0, sl.dur))}/${TOOLS[sl.id].dur}`;
const slotCount = () => CONFIG.slotsBase + (game.up.bag ? CONFIG.slotsUp : 0) + (game.up.cart ? CONFIG.slotsUp : 0);
function ensureSlots() { if (!Array.isArray(game.slots)) game.slots = []; while (game.slots.length < slotCount()) game.slots.push(null); }
function syncInv() {
  const inv = {}, tools = {};
  for (const sl of game.slots) if (sl) { inv[sl.id] = (inv[sl.id] || 0) + sl.n; if (isTool(sl.id)) tools[sl.id] = Math.max(tools[sl.id] || 0, sl.dur || 1); }
  for (const k in game.keyItems) if (game.keyItems[k] > 0) inv[k] = (inv[k] || 0) + game.keyItems[k];
  game.inv = inv; game.tools = tools;
}
const invCount = () => game.slots.reduce((a, sl, i) => a + (sl && i < slotCount() ? 1 : 0), 0);   // 使っている枠の数
const capacity = () => slotCount();
const invFull = () => { for (let i = 0; i < slotCount(); i++) { const sl = game.slots[i]; if (!sl || sl.n < stackOf(sl.id)) return false; } return true; };
function roomFor(id) {
  if (ITEMS[id] && ITEMS[id].key) return Infinity;
  const mx = stackOf(id); let r = 0;
  for (let i = 0; i < slotCount(); i++) { const sl = game.slots[i]; if (!sl) r += mx; else if (sl.id === id && (!isTool(id) || isStackTool(id))) r += mx - sl.n; }
  return r;
}
const has = (id, n) => (game.inv[id] || 0) >= (n || 1);
const hasAll = cost => Object.keys(cost).every(k => has(k, cost[k]));
// 持ち物に入れる。入りきらない分は force のときだけ足元に置く（消えない）
function addItem(id, n, force, dur) {
  if (!(n > 0)) return 0;
  if (ITEMS[id] && ITEMS[id].key) { game.keyItems[id] = (game.keyItems[id] || 0) + n; syncInv(); return n; }
  if (isStackTool(id)) return addStackTool(id, n, force, dur);
  const mx = stackOf(id), N = slotCount(); let left = n;
  if (!isTool(id)) for (let i = 0; i < N && left > 0; i++) { const sl = game.slots[i]; if (sl && sl.id === id && sl.n < mx) { const a = Math.min(mx - sl.n, left); sl.n += a; left -= a; } }
  for (let i = 0; i < N && left > 0; i++) if (!game.slots[i]) {
    if (isTool(id)) { game.slots[i] = { id, n: 1, dur: dur != null ? dur : (TOOLS[id].dur || 0) }; left--; }
    else { const a = Math.min(mx, left); game.slots[i] = { id, n: a }; left -= a; }
  }
  let added = n - left;
  if (left > 0 && force && game.map && maps[game.map]) {
    const [tx, ty] = playerTile(); let ok = true;
    if (isTool(id)) { for (let k = 0; k < left; k++) ok = spawnDrop(curMap(), tx, ty, id, 1, 0, dur) && ok; } else ok = spawnDrop(curMap(), tx, ty, id, left, 0);
    if (ok) { added = n; toast(`持ち物がいっぱいなので、${itemName(id)}を足元に置いた`, 'bad'); }
  }
  syncInv(); return added;
}
// 重ねて持てる道具（たいまつ）：dur は1本目の残り、2本目以降は新品。使いかけ同士は同じ枠にまとめない
// 新品から先に入れ、使いかけは最後に入れる（state._partialLeft：使いかけが入りきらなかった）
function addStackTool(id, n, force, dur) {
  const F = TOOLS[id].dur, mx = stackOf(id), N = slotCount(), part = dur != null && dur < F ? Math.max(0.01, dur) : null, units = [];
  for (let k = 0; k < n - (part != null ? 1 : 0); k++) units.push(F);
  if (part != null) units.push(part);
  const rest = [];
  for (const u of units) {
    let done = false;
    for (let i = 0; i < N && !done; i++) { const sl = game.slots[i]; if (!sl || sl.id !== id || sl.n >= mx) continue; if (u >= F) { sl.n++; done = true; } else if (sl.dur >= F) { sl.n++; sl.dur = u; done = true; } }
    for (let i = 0; i < N && !done; i++) if (!game.slots[i]) { game.slots[i] = { id, n: 1, dur: u }; done = true; }
    if (!done) rest.push(u);
  }
  state._partialLeft = rest.some(u => u < F);
  let added = n - rest.length;
  if (rest.length && force && game.map && maps[game.map]) {
    const [tx, ty] = playerTile(); let ok = true;
    for (const u of rest) ok = spawnDrop(curMap(), tx, ty, id, 1, 0, u) && ok;
    if (ok) { added = n; toast(`持ち物がいっぱいなので、${itemName(id)}を足元に置いた`, 'bad'); }
  }
  syncInv(); return added;
}
// 取り出す（持ち物欄の後ろから減らすので、アイテムバーはなるべく残る）
function takeItem(id, n) {
  if (ITEMS[id] && ITEMS[id].key) { game.keyItems[id] = Math.max(0, (game.keyItems[id] || 0) - n); if (!game.keyItems[id]) delete game.keyItems[id]; syncInv(); return; }
  for (let i = game.slots.length - 1; i >= 0 && n > 0; i--) { const sl = game.slots[i]; if (!sl || sl.id !== id) continue; const a = Math.min(sl.n, n); sl.n -= a; n -= a; if (sl.n <= 0) game.slots[i] = null; }
  syncInv();
}
function takeFromSlot(i, n) { const sl = game.slots[i]; if (!sl) return 0; const a = Math.min(sl.n, n); sl.n -= a; if (sl.n <= 0) game.slots[i] = null; syncInv(); return a; }
// 重ねて持てる道具：AからBへ移せる本数（使いかけ同士は混ぜない）
function stackToolMergeN(A, B) {
  const F = TOOLS[A.id].dur, cap = stackOf(A.id) - B.n; if (cap <= 0) return 0;
  return Math.min(cap, (A.dur >= F || B.dur >= F) ? A.n : A.n - 1);
}
// 枠どうしの入れ替え・まとめ（持ち物画面・チェスト・ドラッグ）
function moveSlot(arrA, i, arrB, j) {
  const A = arrA[i], B = arrB[j]; if (!A || (arrA === arrB && i === j)) return;
  if (arrA !== arrB && ((A.eq && arrA === game.slots) || (B && B.eq && arrB === game.slots))) { sfx('error'); toast('装備中の防具は、外してからしまおう', 'bad'); return; }   // v6b
  if (B && B.id === A.id && !isTool(A.id)) { const mx = stackOf(A.id), a = Math.min(mx - B.n, A.n); if (a > 0) { B.n += a; A.n -= a; if (A.n <= 0) arrA[i] = null; return; } }
  if (B && B.id === A.id && isStackTool(A.id)) {
    const a = stackToolMergeN(A, B);
    if (a > 0) {
      const F = TOOLS[A.id].dur, fulls = A.dur >= F ? A.n : A.n - 1, f1 = Math.min(a, fulls);
      B.n += f1; A.n -= f1;
      if (a > f1) { B.n += 1; B.dur = A.dur; A.n -= 1; }   // 使いかけの1本は、Bが新品ばかりの時だけ移す
      if (A.n <= 0) arrA[i] = null;
      return;
    }
  }
  arrA[i] = B || null; arrB[j] = A;
}
// アイテムバー
const heldSlot = () => game.slots[game.hotSel] || null;
const hotItem = () => { const sl = heldSlot(); return sl ? sl.id : null; };
function hotSelect(i) { i = ((i % CONFIG.hotSize) + CONFIG.hotSize) % CONFIG.hotSize; if (game.hotSel !== i) { game.hotSel = i; state.hotName = 1.6; sfx('ui'); } }
// 道具は「手に持っている（アイテムバーで選んでいる）」時だけ効果がある
const heldTool = cat => { const sl = heldSlot(); return sl && isTool(sl.id) && TOOLS[sl.id].cat === cat ? sl.id : null; };
function toolLv(cat) { const k = heldTool(cat); return k ? TOOLS[k].lv : 0; }
function bestTool(cat) { return heldTool(cat); }
// v6b：防具（装備中の枠）と左手（オフハンド：たいまつ・回復アイテム）
function armorSlot() { if (!game) return null; for (let i = 0; i < slotCount(); i++) { const sl = game.slots[i]; if (sl && sl.eq && TOOLS[sl.id] && TOOLS[sl.id].cat === 'armor') return sl; } return null; }
const offOk = id => id === 'torch' || !!(ITEMS[id] && (ITEMS[id].food || ITEMS[id].heal || ITEMS[id].buff) && !ITEMS[id].noQuick);
const offUsable = () => !!(game && game.off && ITEMS[game.off.id] && (ITEMS[game.off.id].food || ITEMS[game.off.id].heal || ITEMS[game.off.id].buff));
const torchLit = () => !!(game && (heldTool('torch') || (game.off && game.off.id === 'torch')));
const offNote = () => '左手に持てるのは、たいまつと回復アイテム（食べ物・飲み物・救急キット・プロテイン）だけ';
function toOffhand(i) {
  const sl = game.slots[i]; if (!sl) return false;
  if (!offOk(sl.id)) { sfx('error'); toast(offNote(), 'bad'); return false; }
  const o = game.off;
  if (!o) { game.off = sl; game.slots[i] = null; }
  else if (o.id === sl.id && !isTool(sl.id) && o.n < stackOf(sl.id)) { const a = Math.min(stackOf(sl.id) - o.n, sl.n); o.n += a; sl.n -= a; if (sl.n <= 0) game.slots[i] = null; }
  else { game.off = sl; game.slots[i] = o; }
  syncInv(); sfx('pick'); return true;
}
function fromOffhand() {
  const o = game.off; if (!o) return false;
  if (roomFor(o.id) < o.n) { sfx('error'); toast('持ち物に空きがありません', 'bad'); return false; }
  game.off = null; addItem(o.id, o.n, false, o.dur); sfx('pick'); return true;
}
// 左手の物を、持ち物の枠 i に置く（枠の物が左手に持てる物なら入れ替え）
function offToSlot(i) {
  const o = game.off, sl = game.slots[i]; if (!o) return false;
  if (sl && !offOk(sl.id)) { sfx('error'); toast(offNote(), 'bad'); return false; }
  game.slots[i] = o; game.off = sl || null; syncInv(); sfx('pick'); return true;
}
// Fキー：手に持っている物と左手を入れ替える
function swapOffhand() {
  const i = game.hotSel, sl = game.slots[i];
  if (!sl && !game.off) { sfx('error'); toast('左手に持ちたい物をアイテムバーで選んで、Fキー'); return; }
  if (sl && !offOk(sl.id)) { sfx('error'); toast(offNote(), 'bad'); return; }
  game.slots[i] = game.off || null; game.off = sl || null; syncInv(); sfx('pick');
}
function toggleEquip(i) {
  const sl = game.slots[i]; if (!sl || !TOOLS[sl.id] || TOOLS[sl.id].cat !== 'armor') return;
  if (sl.eq) { delete sl.eq; sfx('ui'); toast(`${TOOLS[sl.id].n}を外した`); }
  else { for (const x of game.slots) if (x && x !== sl) delete x.eq; sl.eq = 1; sfx('craft'); toast(`${TOOLS[sl.id].n}を装備した（受けるダメージ-${Math.round(TOOLS[sl.id].def * 100)}%）`, 'good'); }
}
// v6b：攻撃する時、剣を持っていなければアイテムバーの剣へ持ち替える（設定でOFFにできる）
// v6.1a：剣がなければ斧・つるはしへ（優先：武器 ＞ 道具 ＞ それ以外）。剣が無い時、斧・つるはしを持っていればそのまま
function autoWeapon() {
  if (!settings.autoTool || heldTool('sword')) return;
  const i = atkPickIndex(); if (i < 0) return;
  if (TOOLS[game.slots[i].id].cat !== 'sword' && heldAtk()) return;
  hotSelect(i);
}
// v6.1a：攻撃に使える道具（剣・斧・つるはし）。ここに無い物を持っている時は素手あつかい
const atkTool = id => !!(id && TOOLS[id] && TOOLS[id].atk);
function heldAtk() { const sl = heldSlot(); return sl && isTool(sl.id) && atkTool(sl.id) ? sl.id : null; }
// アイテムバーで自動持ち替えに選ぶ位置（剣を最優先、同じ種類なら攻撃力補正が高い方）。無ければ -1
function atkPickIndex() {
  let best = -1, bs = -1;
  for (let i = 0; i < CONFIG.hotSize; i++) { const sl = game.slots[i]; if (!sl || !atkTool(sl.id)) continue; const t = TOOLS[sl.id], sc = (t.cat === 'sword' ? 1000 : 0) + t.atk; if (sc > bs) { bs = sc; best = i; } }
  return best;
}
// 攻撃した時に使われる道具（自動持ち替えも含む）。素手なら null
function atkWillUse() {
  const hd = heldAtk(); if (hd && TOOLS[hd].cat === 'sword') return hd;
  if (!settings.autoTool) return hd;
  const i = atkPickIndex(); if (i < 0) return hd;
  return TOOLS[game.slots[i].id].cat !== 'sword' && hd ? hd : game.slots[i].id;
}
// ダメージの幅 [最小, 最大]（会心なし）
function atkRange(id) { const t = atkTool(id) ? TOOLS[id] : null, w = t ? t.atk : 0, r = t ? t.rng : CONFIG.atk.handRng; return [CONFIG.atk.base + w - r, CONFIG.atk.base + w + r]; }
const atkRangeText = id => { const [lo, hi] = atkRange(id); return `${lo}〜${hi}`; };
// ダメージを決める：D = round((P + W + R) × C)
function rollAtk(id) {
  const A = CONFIG.atk, t = atkTool(id) ? TOOLS[id] : null, w = t ? t.atk : 0, r = t ? t.rng : A.handRng, crit = chance(A.crit);
  return { dmg: Math.max(1, Math.round((A.base + w + rndi(-r, r)) * (crit ? A.critMul : 1))), crit };
}
// ダメージの数字（会心は金色＋「会心！」）
function hitText(x, y, dmg, crit) {
  if (!crit) { floatText(x, y, `-${dmg}`, '#ffffff'); return; }
  floatText(x, y, `-${dmg}!`, '#ffd84a'); floatText(x, y - 9, '会心！', '#ffd84a');
  burst(x, y + 6, P.gold, 7); state.shake = Math.max(state.shake || 0, 0.18);
}
// v6b：回復アイテムを使う（手に持っている物 → 左手の順）。PCのSpaceで使う
function useHeal() {
  const sl = heldSlot(), id = sl && sl.id;
  if (id && ITEMS[id] && (ITEMS[id].food || ITEMS[id].heal || ITEMS[id].buff)) { consume(id, game.hotSel); return true; }
  if (offUsable()) { consume(game.off.id, 'off'); return true; }
  return false;
}
// アイテムバーの中で、その種類のいちばん良い道具の位置（無ければ -1）
function hotbarTool(cat, need) { let best = -1, lv = 0; for (let i = 0; i < CONFIG.hotSize; i++) { const sl = game.slots[i], t = sl && TOOLS[sl.id]; if (t && t.cat === cat && t.lv >= (need || 0) && t.lv > lv) { lv = t.lv; best = i; } } return best; }
const toolInBag = cat => game.slots.some((sl, i) => i >= CONFIG.hotSize && sl && isTool(sl.id) && TOOLS[sl.id].cat === cat);
// 採掘・伐採の時、アイテムバーに適した道具があれば自動で持ち替える
function autoTool(cat, need) {
  const i = hotbarTool(cat, need); if (i < 0) return false;
  const cur = heldSlot(), ct = cur && TOOLS[cur.id], bt = TOOLS[game.slots[i].id];
  if (!(ct && ct.cat === cat && ct.lv >= bt.lv)) hotSelect(i);
  return true;
}
function useTool(cat) {
  const sl = heldSlot(); if (!sl || !isTool(sl.id) || TOOLS[sl.id].cat !== cat || !TOOLS[sl.id].dur) return;
  sl.dur--; if (sl.dur <= 0) breakHeld(sl);
  syncInv();
}
// 手に持っている道具の耐久が0になった（重ねて持っていれば次の1本へ）
function breakHeld(sl) {
  const t = TOOLS[sl.id], gone = sl.id === 'torch' ? '燃え尽きた' : '壊れた';
  if (sl.n > 1) { sl.n--; sl.dur = Math.max(0.01, sl.dur + t.dur); toast(`${t.n}が${gone}（残り${sl.n}${sl.id === 'torch' ? '本' : '個'}）`); }
  else { const i = game.slots.indexOf(sl); if (i >= 0) game.slots[i] = null; toast(`${t.n}が${gone}！`, 'bad'); sfx('error'); }
}
// v4：たいまつに耐久（60）。古いセーブの「壊れないたいまつ」は新品にする
function fixTorches(g) {
  const F = TOOLS.torch.dur, fix = sl => { if (sl && sl.id === 'torch') { if (!(sl.dur > 0)) sl.dur = F; sl.n = clamp((sl.n | 0) || 1, 1, TOOLS.torch.stack); } };
  (g.slots || []).forEach(fix);
  for (const k in g.objs || {}) for (const o of g.objs[k] || []) { if (o.t === 'chest' && Array.isArray(o.slots)) o.slots.forEach(fix); if (o.t === 'drop' && o.id === 'torch' && !(o.dur > 0)) o.dur = F; }
}
// 道具・設置物の売値：作るのに使った素材の基本価格の4割（道具は残りの耐久の割合も掛ける）
function recipeValue(id) { const r = RECIPES.find(x => x.tool === id || x.build === id); return r ? Object.keys(r.cost).reduce((a, k) => a + (ITEMS[k] ? ITEMS[k].p * r.cost[k] : 0), 0) : 0; }
function toolPrice(sl) { const t = TOOLS[sl.id], v = recipeValue(sl.id) * 0.4, f = t.dur ? Math.max(0, sl.dur) / t.dur : 1; return Math.max(1, Math.round(v * f + v * Math.max(0, (sl.n || 1) - 1))); }
function sellToolSlot(i) {
  const sl = game.slots[i]; if (!sl || !isTool(sl.id) || sl.eq) return;   // v6b：装備中は売れない
  const v = toolPrice(sl); game.slots[i] = null; syncInv();
  game.money += v; game.stats.earned += v; game.stats.sold++;
  sfx('coin'); toast(`${TOOLS[sl.id].n}${sl.n > 1 ? '×' + sl.n : ''}を ${fmt$(v)} で売った`, 'money'); saveGame(true);
}
// v4：採集で「必ず手に入る物」が全部入る時だけ採集できる（確率で出るおまけは、入らなければ足元に置く）
function gatherRoomOk(o, g, lv) {
  let ys;
  if (g.special === 'palm') ys = [['coconut', Math.max(1, o.n || 0)]];
  else if (g.special === 'bush') ys = [['berry', 2]];
  else if (g.special === 'shell') ys = [['shell', 1]];
  else if (g.special === 'crate') ys = [['wood', 2]];
  else if (g.y) ys = g.y(lv); else return true;
  const need = {}; for (const [id, n, p] of ys) if (p == null) need[id] = (need[id] || 0) + n;
  return Object.keys(need).every(id => roomFor(id) >= need[id]);
}
// 古いセーブ（個数式の持ち物・道具）を枠に入れ直す。入りきらない分は小屋の倉庫へ
function migrateToSlots(g) {
  g.keyItems = g.keyItems || {}; g.slots = []; const N = CONFIG.slotsBase + (g.up.bag ? CONFIG.slotsUp : 0) + (g.up.cart ? CONFIG.slotsUp : 0);
  for (let i = 0; i < N; i++) g.slots.push(null);
  let p = 0; const put = sl => { while (p < N && g.slots[p]) p++; if (p >= N) return false; g.slots[p] = sl; return true; };
  for (const k of ['stoneAxe', 'ironAxe', 'stonePick', 'ironPick', 'stoneSword', 'ironSword', 'rod', 'torch']) if (g.tools && g.tools[k] != null) put({ id: k, n: 1, dur: g.tools[k] });
  for (const k of sortItems(Object.keys(g.inv || {}))) {
    const it = ITEMS[k]; let n = g.inv[k] | 0; if (!it || n <= 0) continue;
    if (it.key) { g.keyItems[k] = (g.keyItems[k] || 0) + n; continue; }
    while (n > 0) { const a = Math.min(CONFIG.stackMax, n); if (!put({ id: k, n: a })) break; n -= a; }
    if (n > 0) { g.storage = g.storage || {}; g.storage[k] = (g.storage[k] || 0) + n; g._moved = true; }
  }
  delete g.hot;
}
// 落とし物
function freeDropTile(m, sx, sy, id, dur) {
  for (let r = 0; r <= 3; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
    if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
    const x = sx + dx, y = sy + dy; if (!WALK[tileAt(m, x, y)]) continue;
    const o = objAt(m, x, y);
    if (!o) return { x, y, o: null };
    if (o.t === 'drop' && o.id === id && dur == null && o.dur == null) return { x, y, o };
  }
  return null;
}
// v6.2：地面に出た物は、出てから丸1日（CONFIG.dropLife）で消える。keep＝消えない（ボスの報酬・倒れた時に落とした物・黒い宝玉）
const dayNow = () => game ? (game.day - 1) + clamp(game.time / CONFIG.dayLength, 0, 1) : 0;
function spawnDrop(m, tx, ty, id, n, lock, dur, keep) {
  const sp = freeDropTile(m, tx, ty, id, dur); if (!sp) return false;
  const exp = dayNow() + CONFIG.dropLife, kp = !!keep || id === 'bossGem';
  if (sp.o) { sp.o.n += n; sp.o.lock = Math.max(sp.o.lock || 0, lock || 0); sp.o.exp = Math.max(sp.o.exp || 0, exp); if (kp) sp.o.keep = 1; }
  else { const o = { t: 'drop', x: sp.x, y: sp.y, id, n, lock: lock || 0, exp }; if (kp) o.keep = 1; if (dur != null) o.dur = dur; addObj(m, o); }
  return true;
}
// v6.2：消える日時を過ぎた落とし物を消す（古いセーブの落とし物は、読み込んでから丸1日）
function expireDrops() {
  const now = dayNow();
  for (const k in maps) {
    const m = maps[k]; if (!m || !m.objs) continue;
    for (const o of m.objs.slice()) if (o.t === 'drop' && !o.keep) { if (!(o.exp > 0)) o.exp = now + CONFIG.dropLife; else if (now >= o.exp) removeObj(m, o); }
  }
}
// 枠から足元へ捨てる（大切なものは枠に入らないので捨てられない）
function dropFromSlot(i, n) {
  const sl = game.slots[i]; if (!sl) return 0; n = Math.min(n, sl.n);
  if (sl.eq) { sfx('error'); toast('装備中の防具は捨てられない（持ち物画面で外せます）', 'bad'); return 0; }   // v6b
  const m = curMap(), [vx, vy] = DIRV[player.dir], [ptx, pty] = playerTile();
  // 目の前が空いていればそこへ、何かあれば足元へ落とす（拾いやすい場所）
  let tx = ptx + vx, ty = pty + vy; const fo = objAt(m, tx, ty);
  if (!WALK[tileAt(m, tx, ty)] || isBlocked(m, tx, ty) || (fo && !(fo.t === 'drop' && fo.id === sl.id && !isTool(sl.id)))) { tx = ptx; ty = pty; }
  const dd = isTool(sl.id) ? (isStackTool(sl.id) && n < sl.n ? TOOLS[sl.id].dur : sl.dur) : undefined;   // たいまつを一部だけ落とす時は新品から
  if (!spawnDrop(m, tx, ty, sl.id, n, CONFIG.dropLock, dd)) { sfx('error'); toast('ここには落とせない', 'bad'); return 0; }
  takeFromSlot(i, n); sfx('pick');
  floatText(tx * 16 + 8, ty * 16 - 2, `-${n} ${itemName(sl.id)}`, '#ffd0c0');
  return n;
}
function pickDrop(o, press) {
  if (o.lock > 0) { if (press) { sfx('error'); toast(`まだ拾えない（あと${Math.ceil(o.lock)}秒）`); } return; }
  const a = addItem(o.id, o.n, false, o.dur);
  if (a <= 0) { if (state.capToast <= 0) { state.capToast = 2.5; sfx('error'); toast('持ち物がいっぱい！', 'bad'); } return; }
  floatText(o.x * 16 + 8, o.y * 16 - 2, `+${a} ${itemName(o.id)}`, '#ffffff');
  o.n -= a; if (isStackTool(o.id) && !state._partialLeft) o.dur = TOOLS[o.id].dur;   // 使いかけを拾えたら、残りは新品
  if (o.n <= 0) removeObj(curMap(), o); else toast('持ち物がいっぱいで、全部は拾えなかった', 'bad');
  sfx('pick'); state.lastInstant = null;
}
function payCost(cost) { for (const k in cost) takeItem(k, cost[k]); }
function costSize(cost) { let n = 0; for (const k in cost) if (!ITEMS[k].key) n += cost[k]; return n; }
// v6.2：返済率＝返した額 ÷（返した額＋残りの借金）。利息・遅延損害金で増えた分も含めた総額に対する割合（以前は初期の借金だけで割っていた）
const repaidRatio = () => game.debt <= 0 ? 1 : Math.min(1, game.repaid / Math.max(1, game.repaid + game.debt));
function stagesOf(c) {
  const out = []; if (c.free) return out;   // デモプレイ（期限なし）は締め日なし
  for (const [f, r] of STAGE_PLAN) { const d = Math.max(1, Math.round(c.days * f)); if (d < c.days && !out.some(x => x.day >= d)) out.push({ day: d, need: Math.ceil(c.debt * r) }); }
  return out;
}
const nextStage = () => { if (!game || game.debt <= 0) return null; const st = stagesOf(game.contract); return game.stageI < st.length ? st[game.stageI] : null; };
function price(id) {
  const it = ITEMS[id]; let m = game.market.m[id] != null ? game.market.m[id] : 1; const ev = game.market.ev;
  if (ev && ev.up === id && !it.noEv) m *= 1.5; if (ev && ev.dn === id && !it.noEv) m *= 0.6;   // v6b：noEv＝特需・値崩れの対象外
  return Math.max(1, Math.round(it.p * m));
}
function sellEstimate(id, n) {
  let m = game.market.m[id] != null ? game.market.m[id] : 1, total = 0; const ev = game.market.ev, it = ITEMS[id];
  for (let i = 0; i < n; i++) { let mm = m; if (ev && ev.up === id && !it.noEv) mm *= 1.5; if (ev && ev.dn === id && !it.noEv) mm *= 0.6; total += Math.max(1, Math.round(it.p * mm)); m = Math.max(0.3, m - DROP[it.c]); }
  return total;
}
function sellItem(id, n) {
  n = Math.min(n, game.inv[id] || 0); if (n <= 0 || ITEMS[id].key) return;
  const total = sellEstimate(id, n), it = ITEMS[id];
  let m = game.market.m[id] != null ? game.market.m[id] : 1; m = Math.max(0.3, m - DROP[it.c] * n); game.market.m[id] = m;
  takeItem(id, n); game.money += total; game.stats.earned += total; game.stats.sold += n;
  if (id === 'turtle') game.turtleSold = true;
  sfx('coin'); toast(`${it.n}×${n} を ${fmt$(total)} で売った`, 'money');
  if (!game.flags.firstSale) { game.flags.firstSale = 1; queueTalk(TALK.firstSale); }
  saveGame(true);
}
function rollMarketEvent() {
  const pool = Object.keys(ITEMS).filter(k => !ITEMS[k].key && !ITEMS[k].place && !ITEMS[k].noEv && k !== 'grilled' && !['turtle', 'boot', 'canned', 'medkit', 'bowl', 'rawwater', 'cleanwater'].includes(k));
  const up = pool[Math.floor(Math.random() * pool.length)]; let dn = up;
  while (dn === up) dn = pool[Math.floor(Math.random() * pool.length)];
  game.market.ev = { up, dn };
}

/* ---------- 15. 入力（キーボード／コントローラー／タッチ） ---------- */
const KEYMAP = {
  Space: ['A'], KeyZ: ['A'], KeyJ: ['A'], Enter: ['A'], NumpadEnter: ['A'],
  KeyK: ['B'], KeyX: ['B'], Backspace: ['B'], Escape: ['START'],
  KeyE: ['INV'], Tab: ['INV'], KeyQ: ['DROP'],   // v6.2：メニューを廃止。E＝持ち物（B・Iでも開ける）
  KeyB: ['INV'], KeyI: ['INV'], KeyC: ['CRAFT'], KeyM: ['MAP'], ShiftLeft: ['DASH'], ShiftRight: ['DASH'],
  KeyF: ['OFF'],   // v6b：左手と入れ替え
  KeyR: ['ZENI'],   // v8b：ついてくるゼニ丸を呼ぶ（売買の画面）
  Digit1: ['H1'], Digit2: ['H2'], Digit3: ['H3'], Digit4: ['H4'], Digit5: ['H5'], Digit6: ['H6'], Digit7: ['H7'], Digit8: ['H8'],
  ArrowUp: ['UP'], KeyW: ['UP'], ArrowDown: ['DOWN'], KeyS: ['DOWN'], ArrowLeft: ['LEFT'], KeyA: ['LEFT'], ArrowRight: ['RIGHT'], KeyD: ['RIGHT'],
};
const Input = {
  mode: 'key', keys: {}, pressed: new Set(), padPrev: {}, pad: {}, padVec: [0, 0],
  touch: { A: false, B: false, X: false, Y: false }, stick: { id: null, ox: 0, oy: 0, vx: 0, vy: 0 }, padIndex: -1,
  down(b) {
    if (this.pad[b] || this.touch[b]) return true;
    for (const code in this.keys) if (this.keys[code] && KEYMAP[code] && KEYMAP[code].includes(b)) return true;
    return false;
  },
  press(b) { return this.pressed.has(b); },
  consume(b) { this.pressed.delete(b); },
  moveVec() {
    let x = 0, y = 0;
    if (this.down('LEFT')) x -= 1; if (this.down('RIGHT')) x += 1; if (this.down('UP')) y -= 1; if (this.down('DOWN')) y += 1;
    if (!this.pad.LEFT && !this.pad.RIGHT && !this.pad.UP && !this.pad.DOWN && (this.padVec[0] || this.padVec[1])) { x = this.padVec[0]; y = this.padVec[1]; }
    if (this.stick.vx || this.stick.vy) { x = this.stick.vx; y = this.stick.vy; }
    const l = Math.hypot(x, y); if (l > 1) { x /= l; y /= l; }
    return [x, y];
  },
  poll() {
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    let gp = null; for (const p of pads) if (p && p.connected) { gp = p; break; }
    const cur = {}; this.padVec = [0, 0];
    if (gp) {
      const b = i => !!(gp.buttons[i] && (gp.buttons[i].pressed || gp.buttons[i].value > 0.5));
      cur.A = b(settings.swapAB ? 1 : 0); cur.B = b(settings.swapAB ? 0 : 1);
      cur.X = b(settings.swapXY ? 3 : 2); cur.Y = b(settings.swapXY ? 2 : 3);
      cur.LB = b(4); cur.RB = b(5); cur.TABL = cur.LB; cur.TABR = cur.RB; cur.START = b(9); cur.ZENI = b(8);   // v8c：−（セレクト）＝ゼニ丸
      cur.ZL = b(6); cur.ZR = b(7); cur.Y = cur.Y || cur.ZL;   // v8c：ZL＝使う（Yと同じ）、ZR＝攻撃・採掘
      const ax = gp.axes[0] || 0, ay = gp.axes[1] || 0, dz = 0.25;
      cur.UP = b(12); cur.DOWN = b(13); cur.LEFT = b(14); cur.RIGHT = b(15);
      const mag = Math.hypot(ax, ay);
      if (mag > dz) { const k = Math.min(1, (mag - dz) / (1 - dz)) / mag; this.padVec = [ax * k, ay * k]; }
      cur.NUP = ay < -0.55; cur.NDOWN = ay > 0.55; cur.NLEFT = ax < -0.55; cur.NRIGHT = ax > 0.55;
      let active = mag > 0.4; for (const k in cur) if (cur[k] && !this.padPrev[k]) active = true;
      if (active) setInputMode('pad');
    }
    for (const k in cur) if (cur[k] && !this.padPrev[k]) {
      if (k[0] === 'N') this.pressed.add(k.slice(1)); else this.pressed.add(k);
    }
    this.pad = { A: cur.A, B: cur.B, X: cur.X, Y: cur.Y, LB: cur.LB, RB: cur.RB, START: cur.START, ZR: cur.ZR, ZL: cur.ZL, ZENI: cur.ZENI, UP: cur.UP || cur.NUP, DOWN: cur.DOWN || cur.NDOWN, LEFT: cur.LEFT || cur.NLEFT, RIGHT: cur.RIGHT || cur.NRIGHT };
    this.padPrev = cur;
  },
  endFrame() { this.pressed.clear(); },
  clearAll() { this.keys = {}; this.touch = { A: false, B: false, X: false, Y: false }; this.stick.vx = this.stick.vy = 0; this.pressed.clear(); },
};
function setInputMode(m) {
  if (Input.mode === m) return;
  Input.mode = m; const b = document.body;
  b.classList.remove('mode-key', 'mode-pad', 'mode-touch'); b.classList.add('mode-' + m);
  updateTouchVisibility(); state.hintHtml = undefined; setTimeout(layoutTouch, 0);
}
function updateTouchVisibility() {
  const el = $('touch'); if (!el) return;
  el.classList.toggle('hidden', !(Input.mode === 'touch' && state.scene === 'play'));
}
function keyLabel(b) {
  if (Input.mode === 'key') return { A: 'Space', B: 'K', X: 'E', Y: '右クリック', START: 'Esc', DROP: 'Q' }[b] || b;
  return b;
}
const kb = b => `<span class="kb">${keyLabel(b)}</span>`;
function isTyping() { const a = document.activeElement; return a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA'); }

// v8f：F2キーで、画面の表示（時間・ステータス・地図・アイテムバー・ヒントなど）を消す／戻す。
// 消している間も、手に持った物は見えて、ホイール・数字キーでの持ち替えや、E・C・Mなどで画面を開くのはそのまま使える
function toggleHudHide(force) {
  if (state.scene !== 'play' && force == null) return;
  state.hudHide = force != null ? !!force : !state.hudHide; document.body.classList.toggle('hud-off', state.hudHide);
  if (force == null) { const ts = $('toasts'); if (ts) { ts.innerHTML = ''; } if (!state.hudHide) toast('UIを表示しました（F2で消す）'); }
}
function setupInput() {
  window.addEventListener('keydown', e => {
    Sound.init(); BGM.kick();
    if (isTyping()) { if (e.code === 'Enter' || e.code === 'Escape') document.activeElement.blur(); return; }
    if (konamiKey(e)) { e.preventDefault(); return; }   // 隠しコマンドの B・A はメニュー操作として扱わない
    if (e.code === 'F2') { e.preventDefault(); if (!e.repeat) toggleHudHide(); return; }   // v8f：F2でUIを消す／戻す
    let m = KEYMAP[e.code]; if (!m) return;
    if (e.code === 'KeyQ' && (e.ctrlKey || e.metaKey)) m = ['DROPALL'];
    // 設定「Q/Eでタブ切り替え」：タブのある画面ではQ＝左・E＝右（メニューはEsc・Tabで閉じる）
    if (settings.qeTabs && (e.code === 'KeyQ' || e.code === 'KeyE') && !e.ctrlKey && !e.metaKey && !Dialog.active) { const t = UI.top(); if (t && t.tabs) m = [e.code === 'KeyQ' ? 'TABL' : 'TABR']; }
    e.preventDefault();
    setInputMode('key');
    if (!e.repeat) { Input.keys[e.code] = true; for (const b of m) Input.pressed.add(b); }
    else if (UI.isOpen() || Dialog.active) for (const b of m) if (['UP', 'DOWN', 'LEFT', 'RIGHT'].includes(b)) Input.pressed.add(b);
  });
  window.addEventListener('keyup', e => { Input.keys[e.code] = false; });
  window.addEventListener('blur', () => { Input.clearAll(); state.lmb = false; });
  window.addEventListener('pointerup', e => { if (e.pointerType === 'mouse' && e.button === 0) state.lmb = false; });   // v6b：左クリックを離した
  document.addEventListener('visibilitychange', () => { if (document.hidden) { Input.clearAll(); saveGame(true); BGM.hide(true); } else BGM.hide(false); });
  window.addEventListener('pagehide', () => saveGame(true));
  window.addEventListener('pointerdown', e => {
    Sound.init(); BGM.kick();
    if (e.pointerType === 'touch') setInputMode('touch'); else if (e.pointerType === 'mouse' && Input.mode === 'touch') setInputMode('key');
  }, true);
  // スマホ（Safari）は指を離した時でないと音を出せないので、ここでも開始する
  window.addEventListener('pointerup', () => { Sound.init(); BGM.kick(); }, true);
  window.addEventListener('touchend', () => { Sound.init(); BGM.kick(); }, true);
  // 持ち物の枠のドラッグ（スマホは長押しから）
  window.addEventListener('pointermove', e => { if (Drag.st && e.pointerId === Drag.st.id) { dragMove(e.clientX, e.clientY); if (Drag.st && Drag.st.active) e.preventDefault(); } }, { passive: false });
  window.addEventListener('pointerup', e => { if (Drag.st && e.pointerId === Drag.st.id) dragEnd(e.clientX, e.clientY); });
  window.addEventListener('pointercancel', e => { if (Drag.st && e.pointerId === Drag.st.id) dragCancel(); });
  // 長押しで食べる：指が動いたり離れたりしたらやめる
  window.addEventListener('pointermove', e => { const hu = state.holdUse; if (hu && e.pointerId === hu.id && Math.hypot(e.clientX - hu.x, e.clientY - hu.y) > 14) cancelHold(); });
  for (const ev of ['pointerup', 'pointercancel']) window.addEventListener(ev, e => { if (state.holdUse && e.pointerId === state.holdUse.id) cancelHold(); });
  // 長押しメニュー・ダブルタップ拡大・ピンチ拡大を防止
  document.addEventListener('contextmenu', e => { if (!isTyping()) e.preventDefault(); });
  document.addEventListener('selectstart', e => { if (!(e.target && e.target.closest && e.target.closest('input,textarea'))) e.preventDefault(); });
  document.addEventListener('dblclick', e => e.preventDefault(), { passive: false });
  // マウスホイールでアイテムバーを選ぶ
  let wheelT = 0;
  window.addEventListener('wheel', e => {
    if (state.scene !== 'play' || !game || UI.isOpen() || Dialog.active || state.place) return;
    e.preventDefault(); const now = performance.now(); if (Math.abs(e.deltaY) < 1 || now - wheelT < 70) return;
    wheelT = now; hotSelect(game.hotSel + (e.deltaY > 0 ? 1 : -1));
  }, { passive: false });
  // 設置モード：画面のマスをクリック／タップ
  const cv = $('game');
  cv.addEventListener('pointermove', e => { if (state.place && e.pointerType === 'mouse') placeCursorFromScreen(e.clientX, e.clientY); if (e.pointerType === 'mouse') state.aim = [e.clientX, e.clientY]; });
  cv.addEventListener('pointerdown', e => {
    if (!state.place) {   // 右クリック：持っている物を使う（食べる・飲む・置く）
      if (e.button === 2 && state.scene === 'play' && game && !state.fading && !UI.isOpen() && !Dialog.active) { e.preventDefault(); useSelected(false); }
      else if (e.button === 0 && e.pointerType === 'mouse' && state.scene === 'play' && game && !state.fading && !UI.isOpen() && !Dialog.active) { e.preventDefault(); state.lmb = true; state.aim = [e.clientX, e.clientY]; Input.pressed.add('ATK'); }   // v6b：左クリックで攻撃
      else if (e.pointerType !== 'mouse' && state.scene === 'play' && game && !state.fading && !UI.isOpen() && !Dialog.active) startHoldUse(e);   // スマホ：画面の長押しで食べる
      return;
    }
    if (state.fading || UI.isOpen() || Dialog.active) return;
    e.preventDefault();
    if (e.button === 2) { cancelPlace(); return; }
    placeCursorFromScreen(e.clientX, e.clientY);
    if (state.place.id === 'houseKit' || state.place.id === 'lumber') { state.placeDrag = e.pointerId; try { cv.setPointerCapture(e.pointerId); } catch (er) { } return; }   // v8b：押したまま動かして、離すと決定
    confirmPlace();
  });
  // v8b：家・伐採機は、押したまま動かして位置を合わせ、指（ボタン）を離すと「ここに建てますか？」
  cv.addEventListener('pointermove', e => { if (state.place && state.placeDrag === e.pointerId) { e.preventDefault(); placeCursorFromScreen(e.clientX, e.clientY); } });
  const placeDragEnd = e => { if (state.placeDrag == null || state.placeDrag !== e.pointerId) return;   // v8e：名前が持ち物のドラッグ（dragEnd）と同じで、持ち物を別の枠へ移せなくなっていたので改名
    state.placeDrag = null; if (state.place && e.type === 'pointerup' && !UI.isOpen() && !Dialog.active) { placeCursorFromScreen(e.clientX, e.clientY); confirmPlace(); } };
  cv.addEventListener('pointerup', placeDragEnd); cv.addEventListener('pointercancel', placeDragEnd);
  for (const ev of ['gesturestart', 'gesturechange', 'gestureend']) document.addEventListener(ev, e => e.preventDefault(), { passive: false });
  let lastTouchEnd = 0;
  document.addEventListener('touchend', e => {
    const now = Date.now();
    if (now - lastTouchEnd < 320 && !(e.target.closest && e.target.closest('button,input,.slot,.tbtn,#dialog,.story'))) e.preventDefault();
    lastTouchEnd = now;
  }, { passive: false });
  document.addEventListener('touchmove', e => { if (e.touches.length > 1 || (Drag.st && Drag.st.active)) e.preventDefault(); }, { passive: false });
  window.addEventListener('gamepadconnected', () => { toast('コントローラーを接続しました'); setInputMode('pad'); });
  window.addEventListener('gamepaddisconnected', () => { toast('コントローラーが切断されました'); if (Input.mode === 'pad') setInputMode(matchMedia('(pointer: coarse)').matches ? 'touch' : 'key'); });

  // スティック
  const zone = $('stick-zone'), base = $('stick-base'), knob = $('stick-knob'), S = Input.stick;
  const R = () => 50 * settings.touchSize;
  const resetStick = () => { S.id = null; S.vx = S.vy = 0; base.classList.remove('active'); base.style.left = ''; base.style.top = ''; base.style.bottom = ''; knob.style.transform = ''; };
  zone.addEventListener('pointerdown', e => {
    // v4：アイテムバーの上を押した時は、スティックではなくアイテムバーの操作にする
    const hi = hotbarSlotAt(e.clientX, e.clientY); if (hi >= 0) { e.preventDefault(); setInputMode('touch'); hotbarTap(hi, e.pointerType); return; }
    e.preventDefault(); setInputMode('touch'); S.id = e.pointerId; S.ox = e.clientX; S.oy = e.clientY;
    try { zone.setPointerCapture(e.pointerId); } catch (er) { /* noop */ }
    const r = zone.getBoundingClientRect(), half = 64 * settings.touchSize;
    base.style.left = (e.clientX - r.left - half) + 'px'; base.style.top = (e.clientY - r.top - half) + 'px'; base.style.bottom = 'auto';
    base.classList.add('active');
  });
  zone.addEventListener('pointermove', e => {
    if (e.pointerId !== S.id) return; e.preventDefault();
    let dx = e.clientX - S.ox, dy = e.clientY - S.oy; const l = Math.hypot(dx, dy), r = R();
    if (l > r) { dx *= r / l; dy *= r / l; }
    knob.style.transform = `translate(${dx}px,${dy}px)`;
    const m = Math.min(1, l / r); if (m < 0.15) { S.vx = S.vy = 0; } else { S.vx = dx / r; S.vy = dy / r; }
  });
  for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture']) zone.addEventListener(ev, e => { if (e.pointerId === S.id) resetStick(); });
  // ボタン
  document.querySelectorAll('.tbtn').forEach(el => {
    const b = el.dataset.b;
    el.addEventListener('pointerdown', e => { e.preventDefault(); setInputMode('touch'); try { el.setPointerCapture(e.pointerId); } catch (er) { /* noop */ } Input.touch[b] = true; Input.pressed.add(b); el.classList.add('on'); });
    const up = () => { Input.touch[b] = false; el.classList.remove('on'); };
    for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture']) el.addEventListener(ev, up);
  });
  { const root = $('modal-root');   // v8f：メニューの中を押しているか（押している間は、時間での描き直しを待つ）
    const dn = e => { if (root && root.contains(e.target)) UI.ptr = true; }, up = () => { if (UI.ptr) { UI.ptr = false; UI.ptrUp = performance.now(); } };
    window.addEventListener('pointerdown', dn, true); window.addEventListener('pointerup', up, true); window.addEventListener('pointercancel', up, true); window.addEventListener('blur', up); }
  $('minimap').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); if (state.scene === 'play' && !UI.isOpen() && !Dialog.active && !state.fading && !state.place) openMainMenu('map'); });
  // v6.2：右上の体力などを押すと、くわしいステータス。スマホはハンマーのボタンでクラフト
  $('clock-intro').addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); closeClockIntro(); });   // v6.2：時計の説明は、画面のどこかを押すと閉じる
  $('hud-gauges').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); openStatus(); });
  // v7a：スマホのクラフトのボタンは、アイテムバーのバッグの右へ移した（buildHotbar）
  $('hud-menu').addEventListener('click', e => { e.preventDefault(); if (state.scene === 'play' && !UI.isOpen() && !Dialog.active && !state.fading) { if (state.place) cancelPlace(); openPause(); } });
  const dlg = $('dialog');
  dlg.addEventListener('click', e => { e.preventDefault(); if (Dialog.ffUsed) { Dialog.ffUsed = false; return; } Dialog.advance(); });
  dlg.addEventListener('pointerdown', e => { if (e.target.closest && e.target.closest('#dlg-skip')) return; Dialog.ptrHold = true; Dialog.ffUsed = false; });
  for (const ev of ['pointerup', 'pointercancel', 'pointerleave']) dlg.addEventListener(ev, () => { Dialog.ptrHold = false; });
  $('dlg-skip').addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); Dialog.skipAll(); });
  document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('button'); if (b) b.blur(); });
}

/* ---------- 16. UI（メニュー層） ---------- */
const $ = id => document.getElementById(id);
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) for (const k in attrs) {
    const v = attrs[k]; if (v == null || v === false) continue;
    if (k === 'class') el.className = v; else if (k === 'text') el.textContent = v; else if (k === 'html') el.innerHTML = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v); else if (k === 'style') el.style.cssText = v; else el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of kids.flat()) { if (c == null || c === false) continue; el.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c); }
  return el;
}
function icon(id, sm) { return h('img', { class: 'icon' + (sm ? ' sm' : ''), src: ICON_URL[id] || ICON_URL.bp, alt: '', draggable: 'false' }); }
function btn(label, fn, o) {
  o = o || {};
  const b = h('button', { class: 'btn f ' + (o.cls || '') + (o.disabled ? ' dis' : ''), 'data-k': o.key || (typeof label === 'string' ? label : ''), tabindex: '-1', type: 'button' }, label);
  b.addEventListener('click', e => {
    e.preventDefault(); e.stopPropagation();
    const L = UI.top(); if (L) { const fe = b.closest('.f'); L.focusKey = fe ? fe.dataset.k : b.dataset.k; }
    if (o.disabled) { sfx('error'); if (o.why) toast(o.why, 'bad'); return; }
    if (!o.silent) sfx('ui');
    fn(e);
  });
  return b;
}
const UI = {
  stack: [],
  root: null,
  isOpen() { return this.stack.length > 0; },
  top() { return this.stack[this.stack.length - 1]; },
  // v8f：時間で描き直す画面（自動伐採機・採掘機・作業台・炉・ステータスなど）は、画面を押している間は描き直さない。
  // 押した瞬間と離した瞬間でボタンが作り直されると「クリック」にならず、×や閉じるボタンが1回で反応しないことがあった
  ptr: false, ptrUp: 0, inTick: false,
  holdRefresh() { return this.inTick && (this.ptr || performance.now() - this.ptrUp < 150); },
  open(opts) {
    const el = h('div', { class: 'modal ' + (opts.cls || '') });
    const below = this.top(); if (below) { below.el.classList.add('under'); below.el.querySelectorAll('.focus').forEach(e => e.classList.remove('focus')); }
    this.root.appendChild(el);
    const L = Object.assign({ el, focusKey: null, onBack: () => UI.close() }, opts);
    this.stack.push(L); this.refresh(L); return L;
  },
  close(L) {
    L = L || this.top(); if (!L) return; hideTip(); if (Drag.st && Drag.st.L === L) dragCancel();
    const i = this.stack.indexOf(L); if (i >= 0) this.stack.splice(i, 1);
    L.el.remove();
    if (this.top()) this.top().el.classList.remove('under');
    if (L.onClose) L.onClose();
    if (this.top()) this.applyFocus(this.top());
  },
  closeAll() { while (this.stack.length) this.close(); },
  refresh(L) {
    L = L || this.top(); if (!L) return;
    if (this.holdRefresh()) { L._pend = true; return; }   // v8f：押している最中は、離してから描き直す
    L._pend = false; hideTip();
    const body = L.el.querySelector('.win-body'), st = body ? body.scrollTop : 0;
    L.el.innerHTML = ''; L.render(L.el, L);
    const nb = L.el.querySelector('.win-body'); if (nb) nb.scrollTop = st;
    this.applyFocus(L);
  },
  focusables(L) { return [...L.el.querySelectorAll('.f')].filter(e => e.offsetParent !== null); },
  applyFocus(L) {
    const list = this.focusables(L); L.el.querySelectorAll('.focus').forEach(e => e.classList.remove('focus'));
    let el = L.focusKey != null ? list.find(e => e.dataset.k === L.focusKey) : null;
    if (!el) el = list.find(e => e.classList.contains('primary')) || list.find(e => !e.classList.contains('btn-close') && !e.classList.contains('tab')) || list[0];
    if (el) { el.classList.add('focus'); L.focusKey = el.dataset.k; }
  },
  focused(L) { L = L || this.top(); return L ? L.el.querySelector('.f.focus') : null; },
  nav(dir) {
    const L = this.top(); if (!L) return;
    const cur = this.focused(L), list = this.focusables(L); if (!list.length) return;
    if (!cur) { this.applyFocus(L); return; }
    if (cur.dataset.stepper && (dir === 'LEFT' || dir === 'RIGHT')) { const t = cur.querySelector(dir === 'LEFT' ? '.st-dn' : '.st-up'); if (t) t.click(); return; }
    const a = cur.getBoundingClientRect(), ax = a.left + a.width / 2, ay = a.top + a.height / 2;
    let best = null, bs = 1e9;
    for (const e of list) {
      if (e === cur) continue; const r = e.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2, dx = x - ax, dy = y - ay;
      let main, side;
      if (dir === 'UP') { if (r.bottom > a.top + 2 && dy >= -2) continue; main = -dy; side = Math.abs(dx); }
      else if (dir === 'DOWN') { if (r.top < a.bottom - 2 && dy <= 2) continue; main = dy; side = Math.abs(dx); }
      else if (dir === 'LEFT') { if (dx >= -2) continue; main = -dx; side = Math.abs(dy); if (side > Math.max(a.height, r.height)) continue; }
      else { if (dx <= 2) continue; main = dx; side = Math.abs(dy); if (side > Math.max(a.height, r.height)) continue; }
      const s = main + side * 2.2; if (s < bs) { bs = s; best = e; }
    }
    if (best) { cur.classList.remove('focus'); best.classList.add('focus'); L.focusKey = best.dataset.k; best.scrollIntoView({ block: 'nearest', inline: 'nearest' }); sfx('ui'); }
  },
  isLive() { return this.stack.length > 0 && this.stack.every(l => l.live); },   // 時間が進むメニューだけ開いている
  update(dt) {
    const L = this.top(); if (!L) return;
    if (L.onTick) { this.inTick = true; try { L.onTick(dt, L); } finally { this.inTick = false; } }
    if (L._pend && !this.ptr && performance.now() - this.ptrUp >= 150 && UI.top() === L) this.refresh(L);   // v8f：押している間に待たせた描き直し
    if ((L.pauseMenu || L.titleSet) && state.konamiGo) { state.konamiGo = false; konamiActivate(L); this.refresh(L); return; }
    if (L.mainMenu) {   // v6.2：同じキーで閉じる。別のキーでその画面へ切り替える（コントローラーはLB/RBでも）
      const sc = ['INV', 'CRAFT', 'MAP'].find(k => Input.press(k));
      if (sc) { const tab = { INV: 'inv', CRAFT: 'craft', MAP: 'map' }[sc]; if (tab === 'map' && game && game.map === 'house') { sfx('error'); toast('家の中では地図は見られない', 'bad'); return; } sfx('ui'); if (L.tab === tab) L.onBack(); else { L.tab = tab; L.focusKey = null; L.sel = null; this.refresh(L); } return; }
      if (Input.press('TABL') || Input.press('TABR')) { const ids = game && game.map === 'house' ? ['inv', 'craft'] : ['inv', 'craft', 'map'], i = Math.max(0, ids.indexOf(L.tab)); L.tab = ids[(i + (Input.press('TABL') ? ids.length - 1 : 1)) % ids.length]; L.focusKey = null; L.sel = null; sfx('ui'); this.refresh(L); return; }   // v8b：家の中は地図を飛ばす
      for (let i = 1; i <= CONFIG.hotSize; i++) if (Input.press('H' + i)) { hotSelect(i - 1); this.refresh(L); return; }
    }
    for (const d of ['UP', 'DOWN', 'LEFT', 'RIGHT']) if (Input.press(d)) this.nav(d);
    // スティック長押しでの連続移動
    const held = ['UP', 'DOWN', 'LEFT', 'RIGHT'].find(d => Input.pad[d]);
    if (held) { this.rep = (this.rep || 0) + dt; if (this.rep > 0.4) { this.rep = 0.3; this.nav(held); } } else this.rep = 0;
    if (Input.press('A')) { const f = this.focused(L); if (f) { if (f.tagName === 'INPUT') f.focus(); else f.click(); } }
    else if (Input.press('B') || Input.press('START') || (L.toggleX && Input.press('X') && !Input.press('TABR'))) { sfx('ui'); L.onBack(); }
    else if (Input.press('TABL') && L.tabs) this.switchTab(L, -1);
    else if (Input.press('TABR') && L.tabs) this.switchTab(L, 1);
  },
  switchTab(L, d) { const ids = L.tabs.map(t => t.id); let i = ids.indexOf(L.tab); i = (i + d + ids.length) % ids.length; L.tab = ids[i]; L.focusKey = 'tab-' + L.tab; sfx('ui'); this.refresh(L); },
};
function windowEl(L, o) {
  const w = h('div', { class: 'window ' + (o.cls || '') });
  w.appendChild(h('div', { class: 'win-head' }, h('div', { class: 'win-title' }, o.title), o.noClose ? null : btn('×', () => L.onBack(), { key: 'close', cls: 'btn-close' })));
  if (o.tabs) {
    L.tabs = o.tabs; const tb = h('div', { class: 'tabs' });
    for (const t of o.tabs) tb.appendChild(btn(t.label, () => { L.tab = t.id; L.focusKey = 'tab-' + t.id; UI.refresh(L); }, { key: 'tab-' + t.id, cls: 'tab' + (L.tab === t.id ? ' on' : '') }));
    w.appendChild(tb);
  }
  if (o.sub) w.appendChild(o.sub);
  const b = h('div', { class: 'win-body' }); o.body(b); w.appendChild(b);
  if (o.foot && o.foot.length) w.appendChild(h('div', { class: 'win-foot' }, ...o.foot));
  return w;
}
function confirmBox(msg, yes, opt) {
  opt = opt || {};
  UI.open({
    render: (el, L) => el.appendChild(windowEl(L, {
      title: opt.title || '確認', cls: 'small', body: b => { b.appendChild(h('p', { class: 'note', style: 'font-size:15px;color:var(--text);white-space:pre-wrap' }, msg)); if (opt.note) b.appendChild(h('p', { class: 'note confirm-note', style: 'white-space:pre-wrap' }, opt.note)); },   // v8d：opt.note＝下に小さく出す説明
      foot: [btn(opt.no || 'やめる', () => UI.close(), { key: 'no' }), btn(opt.yes || 'はい', () => { UI.close(); yes(); }, { key: 'yes', cls: opt.danger ? 'danger' : 'primary' })],
    })),
  });
}
function stepper(key, label, value, onDn, onUp) {
  const wrap = h('div', { class: 'stepper f', 'data-k': key, 'data-stepper': '1' },
    btn('◀', onDn, { key: key + '-dn', cls: 'small st-dn' }), h('span', { class: 'val' }, value), btn('▶', onUp, { key: key + '-up', cls: 'small st-up' }));
  wrap.querySelectorAll('.btn').forEach(b => b.classList.remove('f'));
  return h('div', { class: 'set-row' }, h('div', { class: 'lbl', html: label }), wrap);
}

/* ---------- 17. トースト・ヒント・会話・フェード ---------- */
function toast(text, type) {
  const box = $('toasts'); if (!box) return;
  const el = h('div', { class: 'toast ' + (type || '') }, text); box.appendChild(el);
  while (box.children.length > 4) box.firstChild.remove();
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 450); }, 2600);
}
function fmtText(s) {
  const g = game || {}, c = g.contract || {};
  return s.replace(/\{name\}/g, g.name || 'あなた').replace(/\{debt\}/g, fmt$(c.debt || 0)).replace(/\{rate\}/g, String(c.rate != null ? c.rate : 0))
    .replace(/\{days\}/g, String(c.days || 0)).replace(/\{days1\}/g, String((c.days || 0) + 1)).replace(/\{controls\}/g, stripHl(controlsText().split('\f').join('\n')));
}
// v6.2：操作説明は3つに分ける（\f で区切る）。{{k|…}}＝操作キーの色
function controlsText() {
  if (Input.mode === 'touch') return '操作①　移動：左下のスティック（{{k|B}}を押したままでダッシュ）\n{{k|A}}：調べる・拾う・採集（木や岩は長押し）・攻撃\n{{k|Y}}：手に持った物を使う（食べる・置く）'
    + '\f操作②　{{k|X}}：持ち物　バッグの右のハンマー：クラフト　ミニマップ：地図\n右上の{{k|≡}}：ポーズ（記録もここ）\n下のアイテムバーはタップで選び、もう一度タップで使えます。'
    + '\f操作③　右上の体力などを押すと、くわしい状態が見られます。\n会話は長押しで早送り、右上の「スキップ」で飛ばせます。';
  if (Input.mode === 'pad') return '操作①　移動：スティック（{{k|B}}を押したままでダッシュ）\n{{k|A}}：決定・調べる・拾う　{{k|ZR}}：攻撃・採掘・伐採（長押し）\n{{k|Y}}／{{k|ZL}}：手に持った物を使う（食べる・置く・設備を開く）'   // v8c：操作を変更
    + '\f操作②　{{k|X}}：持ち物（{{k|LB}}／{{k|RB}}でクラフト・地図に切り替え）\n{{k|START}}：ポーズ（記録もここ）　{{k|−}}：ゼニ丸\n{{k|LB}}／{{k|RB}}：アイテムバーの持ち替え'
    + '\f操作③　道具は手に持つと使えます。\n会話は{{k|A}}の長押しで早送り、{{k|START}}でスキップ。';
  return '操作①　移動：{{k|WASD}}／矢印キー（{{k|Shift}}を押したままでダッシュ）\n調べる・拾う・採集：{{k|Space}}（木や岩は長押し）\n攻撃：{{k|左クリック}}か{{k|Space}}（向いている方へ）　採掘・伐採は{{k|左クリック}}でもOK'
    + '\f操作②　使う（食べる・置く）：{{k|右クリック}}\n画面：{{k|E}}持ち物／{{k|C}}クラフト／{{k|M}}地図／{{k|Esc}}ポーズ（記録もここ）\nアイテムバー：{{k|1}}〜{{k|8}}かホイール　捨てる：{{k|Q}}　左手：{{k|F}}'
    + '\f操作③　道具は手に持つと使えます（アイテムバーに入れておくと自動で持ち替え）。\n右上の体力などを押すと、くわしい状態が見られます。\n会話は{{k|Space}}長押しで早送り、{{k|Esc}}でスキップ。';
}
// v6.2：会話の{controls}は、操作説明の数だけ会話に分ける
function expandControls(lines) {
  const out = [];
  for (const ln of lines) { if (typeof ln[1] === 'string' && ln[1].includes('{controls}')) for (const p of controlsText().split('\f')) out.push([ln[0], ln[1].replace('{controls}', p)]); else out.push(ln); }
  return out;
}
// v6.2：会話の大事な言葉に色をつける。{{k|…}}＝操作キー、{{i|…}}＝アイテム、{{n|…}}＝数字・お金、{{p|…}}＝人物・場所、{{r|…}}＝危険・注意
// タグのない所も、決まった言葉（お金・数字・キー・危険・アイテム名・人物と場所）は自動で色をつける
let HL_RE = null, HL_CLS = null;
function hlBuild() {
  const esc = t => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), skip = ['タイ', 'アジ', 'タコ', 'フグ'], names = new Set();
  for (const o of [ITEMS, TOOLS]) for (const k in o) { const n = o[k].n; if (n && n.length >= 2 && !skip.includes(n) && !/[（）()]/.test(n)) names.add(n); }
  names.add('泉の水'); names.add('生水');
  const by = a => a.slice().sort((x, y) => y.length - x.length).map(esc).join('|');
  const groups = [
    ['n', '\\$[\\d,]+|[+＋]\\d+|\\d+(?:\\.\\d+)?(?:%|％|日目|日|分|秒|個|枠|時|回|倍)'],
    ['k', by(['WASD', 'Space', 'Shift', 'Esc', 'START', 'LB/RB', 'Ctrl+Q', '左クリック', '右クリック', '矢印キー'])],
    ['r', by(['ゼロ・バースト', '遅延損害金', '返済期限', '締め日', '借金', '利息', '猛毒', '毒', '嵐', '腹痛'])],
    ['i', by([...names])],
    ['p', by(['鮫島', 'ゼニ丸', 'ゲン', BOSS.name, '回収ボックス', '回収ドローン', 'カジノ船', '豪華客船', '地下2階', '洞窟', '祠', '泉'])],
  ];
  HL_CLS = groups.map(g => g[0]); HL_RE = new RegExp(groups.map(g => '(' + g[1] + ')').join('|'), 'g');
}
function richParse(str) {
  if (!HL_RE) hlBuild();
  const out = [], push = (t, c) => { if (t) out.push({ t, c: c || null }); };
  const auto = t => {
    HL_RE.lastIndex = 0; let last = 0, m;
    while ((m = HL_RE.exec(t))) { if (!m[0]) { HL_RE.lastIndex++; continue; } push(t.slice(last, m.index)); let gi = 1; while (gi < m.length && m[gi] === undefined) gi++; push(m[0], HL_CLS[gi - 1]); last = m.index + m[0].length; }
    push(t.slice(last));
  };
  const re = /\{\{([kinpr])\|([^}]*)\}\}/g; let last = 0, m;
  while ((m = re.exec(str))) { auto(str.slice(last, m.index)); push(m[2], m[1]); last = re.lastIndex; }
  auto(str.slice(last));
  return out;
}
const escHtml = t => t.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
const stripHl = t => t.replace(/\{\{[kinpr]\|([^}]*)\}\}/g, '$1');
// v8e：ゼニ丸翻訳。ゼニ丸のカタカナ交じりの話し方を、ひらがな＋漢字に直す（「ドローン」「チャンス」など本来カタカナの言葉はそのまま）
const ZENI_KANA_KEEP = ['ピピーッ', 'ピピッ', 'ドローン', 'ゼニ', 'チェック', 'タブ', 'チャンス', 'ロボット', 'ボディ', 'フカヒレ', 'カジノ', 'スロット', 'ルーレット', 'レース', 'ボックス', 'ガチャ', 'ドリンク', 'プロテイン', 'コイン', 'メダル', 'ヤドカリ', 'シロクマ', 'キー', 'ボタン', 'タップ'].sort((a, b) => b.length - a.length);
function zeniTr(text) {
  let out = '', i = 0; const s = String(text || '');
  while (i < s.length) {
    const c = s.charCodeAt(i);
    if (c >= 0x30a1 && c <= 0x30fa || c === 0x30fc) {   // カタカナ（ーを含む）
      const w = ZENI_KANA_KEEP.find(k => s.startsWith(k, i));
      if (w) { out += w; i += w.length; continue; }
      out += c === 0x30fc ? 'ー' : c >= 0x30f7 ? s[i] : String.fromCharCode(c - 0x60); i++; continue;
    }
    out += s[i]; i++;
  }
  return out;
}
const Dialog = {
  active: false, lines: [], i: 0, full: '', shown: 0, cb: null, acc: 0,
  start(lines, cb) {
    this.lines = expandControls(lines); this.i = 0; this.cb = cb || null; this.active = true; this.holdT = 0; this.ffT = 0;
    $('dialog').classList.remove('hidden'); this.show();
  },
  show() {
    const [who, raw] = this.lines[this.i], sp = SPEAKERS[who] || SPEAKERS.sys;
    this.segs = richParse(fmtText(raw)); this.full = this.segs.map(x => x.t).join(''); this.shown = 0; this.acc = 0;   // v6.2：大事な言葉に色をつける
    const nm = $('dlg-name'); nm.textContent = sp.name(); nm.style.color = sp.col;
    const pc = $('dlg-portrait'), x = pc.getContext('2d');
    if (sp.por && POR[sp.por]) { pc.classList.remove('none'); x.clearRect(0, 0, 24, 24); x.drawImage(POR[sp.por], 0, 0); } else pc.classList.add('none');
    const tr = $('dlg-tr'); if (tr) { this.tr = who === 'zeni' && settings.zeniTr ? `（${zeniTr(this.full)}）` : ''; tr.textContent = this.tr; tr.classList.add('hidden'); }   // v8e：ゼニ丸翻訳（話し終わったら下に出す）
    this.paint(0); $('dlg-next').style.visibility = 'hidden';
    const sk = $('dlg-skip'); if (sk) sk.textContent = Input.mode === 'key' ? 'スキップ（Esc）' : Input.mode === 'pad' ? 'スキップ（START）' : 'スキップ ▶▶';
  },
  // v6.2：n文字目まで、色つきで表示する
  paint(n) {
    let left = n, html = '';
    for (const x of this.segs || []) { if (left <= 0) break; const t = x.t.length <= left ? x.t : x.t.slice(0, left); left -= t.length; html += x.c ? `<span class="hl hl-${x.c}">${escHtml(t)}</span>` : escHtml(t); }
    $('dlg-text').innerHTML = html;
    const tr = $('dlg-tr'); if (tr) tr.classList.toggle('hidden', !(this.tr && n >= this.full.length));   // v8e：ゼニ丸翻訳
  },
  update(dt) {
    if (!this.active) return;
    if (this.shown < this.full.length) {
      this.acc += dt * 45; const n = Math.floor(this.acc);
      if (n > 0) { this.acc -= n; const before = this.shown; this.shown = Math.min(this.full.length, this.shown + n); this.paint(this.shown); if (Math.floor(before / 3) !== Math.floor(this.shown / 3)) sfx('talk'); }
      if (this.shown >= this.full.length) $('dlg-next').style.visibility = 'visible';
    }
    if (Input.press('START')) { this.skipAll(); return; }
    if (Input.press('A') || Input.press('B')) this.advance();
    // 長押しで早送り（A・B・画面の長押し）
    const hold = Input.down('A') || Input.down('B') || this.ptrHold;
    if (!hold) { this.holdT = 0; this.ffT = 0; return; }
    this.holdT += dt; if (this.holdT < 0.35 || !this.active) return;
    this.ffT -= dt; if (this.ffT > 0) return;
    this.ffT = 0.09; this.ffUsed = true; this.advance();
  },
  advance() {
    if (!this.active) return;
    if (this.shown < this.full.length) { this.shown = this.full.length; this.paint(this.full.length); $('dlg-next').style.visibility = 'visible'; return; }
    this.i++;
    if (this.i >= this.lines.length) this.finish();
    else this.show();
  },
  finish() { this.active = false; $('dialog').classList.add('hidden'); const cb = this.cb; this.cb = null; Input.clearAll(); this.holdT = 0; if (cb) cb(); },
  // スキップ：今の会話と、すでに順番待ちしている会話をまとめて飛ばす（会話のあとの処理は行う）
  skipAll() {
    if (!this.active) return;
    let n = state.pendingTalks.length; this.finish(); sfx('ui');
    while (n-- > 0 && state.pendingTalks.length && !UI.isOpen() && state.scene === 'play') { const t = state.pendingTalks.shift(); if (t.cb) { try { t.cb(); } catch (e) { console.error(e); } } }
  },
};
function queueTalk(lines, cb) { state.pendingTalks.push({ lines, cb }); }
function processTalks() {
  if (Dialog.active || UI.isOpen() || state.fading || state.clockIntro || !state.pendingTalks.length || state.scene !== 'play') return;
  const t = state.pendingTalks.shift(); Dialog.start(t.lines, t.cb);
}
// v6.1b：opt.hold＝暗いままの最短時間(ms)、opt.until＝これがtrueになるまで暗いまま（opt.maxで打ち切り）、opt.slow＝ゆっくり明るくする
function fade(mid, after, opt) {
  opt = opt || {};
  state.fading = true; const f = $('fade'); f.classList.add('on');
  setTimeout(() => {
    try { mid && mid(); } catch (e) { console.error(e); }
    const reveal = () => { if (opt.slow) f.classList.add('slow'); f.classList.remove('on'); setTimeout(() => { state.fading = false; f.classList.remove('slow'); after && after(); }, opt.slow ? 1000 : 450); };
    if (!opt.until && !opt.hold) { setTimeout(reveal, 250); return; }
    const t0 = performance.now(), hold = opt.hold || 250, max = opt.max || 3000;
    const wait = () => { const el = performance.now() - t0; if (el >= hold && (!opt.until || opt.until() || el >= max)) reveal(); else setTimeout(wait, 50); };
    wait();
  }, 520);
}

/* ---------- 18. メニュー画面 ---------- */
const ITEM_ORDER = Object.keys(ITEMS);
const sortItems = ids => ids.sort((a, b) => ITEM_ORDER.indexOf(a) - ITEM_ORDER.indexOf(b));
function sec(title, ...kids) { return h('div', { class: 'sec' }, h('div', { class: 'sec-title' }, title), ...kids); }
function statusSub(extra) {
  return h('div', { class: 'win-sub' }, h('span', null, '所持金 ', h('b', null, fmt$(game.money))), h('span', null, '借金 ', h('b', null, fmt$(game.debt))),
    h('span', null, '持ち物 ', h('b', null, `${invCount()}/${capacity()}枠`)), extra || null);
}
function costEls(cost, mult) {
  return h('div', { class: 'costs' }, ...Object.keys(cost).map(k => { const need = cost[k] * (mult || 1), hv = game.inv[k] || 0; return h('span', { class: hv >= need ? 'ok' : 'ng' }, icon(k, true), ` ${ITEMS[k].n} ${hv}/${need}`); }));
}
function nearStation(st) {
  const m = curMap(); for (const o of m.objs) { const d = OBJ[o.t]; if (d && d.st === st && Math.hypot(o.x * 16 + 8 - player.x, o.y * 16 + 10 - player.y) < 44) return o; } return null;
}
// v6.2：メニューを廃止。持ち物（E）・クラフト（C）・地図（M）は、それぞれ単体の画面。記録はポーズ画面へ
const MM_TITLE = { inv: '持ち物', craft: 'クラフト', map: '地図' };
function openMainMenu(tab) {
  if (tab === 'map' && game && game.map === 'house') { sfx('error'); toast('家の中では地図は見られない', 'bad'); return; }   // v8b
  if (game && !game.flags.menuHint) { game.flags.menuHint = 1; setTimeout(() => toast('持ち物・クラフト・地図を開いている間も、時間は進みます（ポーズ中は止まります）'), 300); }
  sfx('ui'); stopFishing();
  if (!MM_TITLE[tab]) tab = 'inv';
  UI.open({ tab, toggleX: true, mainMenu: true, live: true, render: (el, L) => {
    el.appendChild(windowEl(L, {
      title: MM_TITLE[L.tab], cls: 'mm-' + L.tab, sub: statusSub(Input.mode === 'pad' ? h('span', { class: 'mm-hint' }, 'LB／RBで切り替え') : null),
      body: b => ({ inv: renderInv, craft: renderCraft, map: renderMap })[L.tab](b, L),
    }));
  } });
}
// v6.2：記録（ポーズ画面から開く。見ている間は時間が止まる）
function openLog() { sfx('ui'); UI.open({ render: (el, L) => el.appendChild(windowEl(L, { title: '記録', sub: statusSub(), body: b => renderLog(b, L) })) }); }
// v6.2：くわしいステータス（右上の体力などを押す）。開いている間も時間は進む
function openStatus() {
  if (state.scene !== 'play' || !game || UI.isOpen() || Dialog.active || state.fading || state.place || state.clockIntro) return;
  sfx('ui');
  UI.open({ live: true, onTick: (dt, L) => { L._st = (L._st || 0) + dt; if (L._st >= 0.25) { L._st = 0; UI.refresh(L); } },
    render: (el, L) => el.appendChild(windowEl(L, { title: 'ステータス', cls: 'small', body: b => renderStatus(b) })) });
}
const fmtLeft = sec => { sec = Math.max(0, Math.ceil(sec)); return sec >= 60 ? `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}` : `${sec}秒`; };
function condDetails() {
  const g = game, f = state.condFlags || {}, out = [], add = (n, cls, d, left) => out.push({ n, cls, d, left });
  if (g.awake > 0) add('覚醒', 'buff', 'プロテインの効果。スタミナの消費が半分・スタミナの回復が25%速い・移動が30%速い。', g.awake);
  if (g.happy > 0) add('幸福', 'buff', '黄金の焼き肉の効果。体力の自然回復が2倍（空腹・渇きが両方50より上で毎秒+1、両方90以上で毎秒+2）。', g.happy);   // v7a
  if (g.poison > 0) add('毒', 'poison', `${CONFIG.poison.every}秒ごとに体力が${CONFIG.poison.dmg}減る（体力1より下がらない）。救急キットか、眠ると治る。`, g.poison);
  if (g.hp < 25) add('重傷', 'bad', '体力が25未満。移動が少し遅くなる。食べて休むか、救急キットで回復しよう。');
  if (f.cold) add('寒い', 'bad', '夜に外にいて、焚き火や小屋の近くにいない。体力が少しずつ減る（濡れているともっと減る）。');
  if (f.wet) add('濡れ', 'bad', '雨に濡れている。スタミナの回復が遅くなり、夜の寒さのダメージが増える。焚き火や小屋の近くなら濡れない。');
  if (f.hot) add('暑い', 'warn', '晴れの日の11時〜15時は、渇きが早く減る。');
  if (g.sick > 0) add('腹痛', 'bad', 'お腹を壊している。空腹が1.5倍の速さで減り、スタミナの回復が半分になる。', g.sick);
  if (g.hunger < 20) add('空腹', 'bad', '空腹が20未満。移動と採集が遅くなる。0になると体力が減る。');
  if (g.thirst < 20) add('脱水', 'bad', '渇きが20未満。移動と採集が遅くなる。0になると体力が減る。');
  if (g.exhaust) add('息切れ', 'warn', 'スタミナを使い切った。25まで戻るまでダッシュできない（0の間は攻撃と採集も遅い）。');
  if (!out.length) add('快適', 'ok', '問題なし。空腹と渇きがどちらも50より上なら、体力が少しずつ回復する。');
  return out;
}
function renderStatus(b) {
  const g = game, bar = (lbl, v, col) => [h('div', { class: 'st-lbl' }, lbl), h('div', { class: 'st-bar' }, h('i', { style: `width:${clamp(Math.round(v), 0, 100)}%;background:${col}` })), h('div', { class: 'st-num' }, String(Math.max(0, Math.ceil(v))))];
  b.appendChild(sec('体力・空腹・渇き・スタミナ', h('div', { class: 'st-grid' }, bar('体力', g.hp, g.poison > 0 ? '#7cc048' : '#e2574c'), bar('空腹', g.hunger, '#f0a03c'), bar('渇き', g.thirst, '#4aa3df'), bar('スタミナ', g.stamina, '#7ad070'))));
  b.appendChild(sec('いまの状態', ...condDetails().map(c => h('div', { class: 'st-cond' }, h('div', { class: 'nm ' + c.cls }, c.n, c.left != null ? h('span', { class: 'left' }, '残り ' + fmtLeft(c.left)) : null), h('div', { class: 'note' }, c.d)))));
  b.appendChild(h('p', { class: 'note', style: 'margin-top:6px' }, 'この画面を開いている間も、時間は進みます。'));
}
function renderInv(b, L) {
  // 上：持ち物欄（8枠ずつ）、下：アイテムバー（8枠）。ドラッグ（スマホは長押し）で移動・入れ替え（v8f：選んで別の枠を押す移動は、コントローラーだけ）
  const N = slotCount(), hs = CONFIG.hotSize;
  const cell = i => {
    const sl = game.slots[i], sel = L.sel === i, held = i === game.hotSel && i < hs;
    const c = h('button', { class: 'islot f' + (sel ? ' sel' : '') + (held ? ' held' : '') + (i < hs ? ' hb' : '') + (sl && sl.eq ? ' eq' : ''), 'data-k': 'sl-' + i, tabindex: '-1', type: 'button' },
      i < hs ? h('span', { class: 'hn' }, String(i + 1)) : null, sl && sl.eq ? h('span', { class: 'eqb' }, '装備') : null, sl ? icon(sl.id) : null, sl && sl.n > 1 ? h('span', { class: 'hc' }, String(sl.n)) : null,
      sl && isTool(sl.id) && TOOLS[sl.id].dur ? h('span', { class: 'dbar' }, h('i', { style: `width:${Math.round(sl.dur / TOOLS[sl.id].dur * 100)}%;background:${durColor(sl.dur / TOOLS[sl.id].dur)}` })) : null);
    c.addEventListener('click', e => {
      e.preventDefault(); if (dragJustEnded()) return; L.focusKey = 'sl-' + i;
      const pad = Input.mode === 'pad';   // v8f：PC・スマホは、押すと説明を見るだけ（移すのはドラッグ＆ドロップ）。コントローラーはドラッグできないので、選んでから別の枠で移す
      if (pad && L.sel === 'off') { if (offToSlot(i)) L.sel = null; UI.refresh(L); return; }   // v6b：左手の物をこの枠へ
      if (pad && L.sel != null && L.sel !== i && game.slots[L.sel]) { moveSlot(game.slots, L.sel, game.slots, i); syncInv(); L.sel = null; sfx('pick'); }
      else { L.sel = L.sel === i ? null : (sl ? i : null); sfx('ui'); }
      UI.refresh(L);
    });
    slotDnD(c, L, 'inv', i);
    return c;
  };
  // v4：左に枠（持ち物＋アイテムバー）、右に説明（縦画面は下）。枠が最大の32枠でも1画面に収まる大きさ
  const grid = h('div', { class: 'inv-slots' }), side = h('div', { class: 'inv-side' });
  grid.appendChild(h('div', { class: 'inv-lbl' }, `持ち物（${N - hs}枠）`));
  for (let r = hs; r < N; r += 8) grid.appendChild(h('div', { class: 'slot-row8' }, ...Array.from({ length: Math.min(8, N - r) }, (_, k) => cell(r + k))));
  grid.appendChild(h('div', { class: 'inv-lbl' }, 'アイテムバー（画面の下・1〜8キー）'));
  grid.appendChild(h('div', { class: 'slot-row8 hbrow' }, ...Array.from({ length: hs }, (_, k) => cell(k))));
  // v6b：左手（オフハンド）の枠
  const of = game.off, oc = h('button', { class: 'islot f offslot' + (L.sel === 'off' ? ' sel' : ''), 'data-k': 'sl-off', tabindex: '-1', type: 'button' },
    of ? icon(of.id) : null, of && of.n > 1 ? h('span', { class: 'hc' }, String(of.n)) : null,
    of && of.id === 'torch' ? h('span', { class: 'dbar' }, h('i', { style: `width:${Math.round(of.dur / TOOLS.torch.dur * 100)}%;background:${durColor(of.dur / TOOLS.torch.dur)}` })) : null);
  oc.addEventListener('click', e => {
    e.preventDefault(); if (dragJustEnded()) return; L.focusKey = 'sl-off';
    if (Input.mode === 'pad' && typeof L.sel === 'number' && game.slots[L.sel]) { toOffhand(L.sel); L.sel = null; }   // v8f：PC・スマホはドラッグで左手へ（「左手に持つ」ボタンも使える）
    else { L.sel = L.sel === 'off' ? null : (game.off ? 'off' : null); sfx('ui'); }
    UI.refresh(L);
  });
  slotDnD(oc, L, 'off', 0);   // v6.2：持ち物から左手の枠へドラッグ（左手から持ち物の枠へも）
  side.appendChild(h('div', { class: 'inv-off' }, h('div', { class: 'inv-lbl' }, '左手（たいまつ・回復アイテム）'),
    h('div', { class: 'off-row' }, oc, h('span', { class: 'note' }, of ? `${itemName(of.id)}${of.n > 1 ? ' ×' + of.n : ''}` : `空き：持ち物を選んで「左手に持つ」か、ここへ${Input.mode === 'touch' ? '長押しで' : 'ドラッグで'}運ぶ${Input.mode === 'key' ? '（Fキーでも入れ替え）' : ''}`))));
  if (L.sel === 'off' && game.off) side.appendChild(offDetail(L));
  else if (typeof L.sel === 'number' && game.slots[L.sel]) side.appendChild(itemDetail(L.sel, L));
  else { L.sel = null; side.appendChild(h('p', { class: 'note' }, Input.mode === 'pad' ? '枠を選ぶと説明が出ます（選んでから別の枠で移動）。' : `枠を押すと説明が出ます（移すのは${Input.mode === 'touch' ? '長押しして' : ''}ドラッグ＆ドロップで）。`)); }
  const keys = Object.keys(game.keyItems || {}).filter(k => game.keyItems[k] > 0);
  if (keys.length) side.appendChild(h('div', { class: 'inv-keys' }, h('div', { class: 'inv-lbl' }, '大切なもの'), ...keys.map(k => h('div', { class: 'inv-key' }, icon(k, true), h('span', null, ITEMS[k].n)))));
  const ups = [];
  for (const k in UP_NAMES) if (game.up[k]) ups.push(UP_NAMES[k]);
  const bps = [];
  const BPN = { bag: '大きなかばん', magnet: 'アイテム回収機', cart: '運搬カート', furnace: '炉', iron: '鉄の道具', benchUp: '作業台強化', raft: 'いかだ' };
  for (const k in BPN) if (game.bp[k]) bps.push(BPN[k]);
  side.appendChild(h('div', { class: 'inv-ups' }, h('div', { class: 'inv-lbl' }, '強化・設計図'), h('p', { class: 'note' }, '強化：' + (ups.join('、') || 'なし')), h('p', { class: 'note' }, '設計図：' + (bps.join('、') || 'なし'))));
  b.appendChild(h('div', { class: 'inv-layout' }, grid, side));
}
// v6b：左手の物の説明とボタン
function offDetail(L) {
  const o = game.off, id = o.id, it = ITEMS[id], d = h('div', { class: 'detail' });
  d.appendChild(h('div', { class: 'hd' }, icon(id), h('div', null, h('div', { class: 'name' }, `${itemName(id)}${o.n > 1 ? ' ×' + o.n : ''}（左手）`), h('div', { class: 'note' }, id === 'torch' ? `耐久 ${durText(o)}` : `今の買取価格 ${fmt$(price(id))}`))));
  d.appendChild(h('div', { class: 'note' }, id === 'torch' ? '左手に持っている間も、手に持っている時と同じように明るく照らす（燃えて減る）。' : `${it.d}　${Input.mode === 'key' ? '右クリック・Space' : keyLabel('Y') + 'ボタン'}で使える（手に別の物を持っていても）。`));
  const bs = h('div', { class: 'btns' });
  if (it && (it.food || it.heal || it.buff)) bs.appendChild(btn(it.food ? (it.food.h ? '食べる' : '飲む') : it.buff ? '飲む' : '使う', () => { consume(id, 'off'); if (!game.off) L.sel = null; UI.refresh(L); }, { key: 'use', cls: 'primary', silent: true }));
  bs.appendChild(btn('持ち物に戻す', () => { if (fromOffhand()) L.sel = null; UI.refresh(L); }, { key: 'offback', silent: true }));
  d.appendChild(bs); return d;
}
function itemDetail(i, L) {
  const sl = game.slots[i], id = sl.id, it = ITEMS[id], tl = TOOLS[id], d = h('div', { class: 'detail' }), hs = CONFIG.hotSize;
  const priceTxt = tl ? `売値 ${fmt$(toolPrice(sl))}` : `今の買取価格 ${fmt$(price(id))}`;
  d.appendChild(h('div', { class: 'hd' }, icon(id), h('div', null, h('div', { class: 'name' }, `${itemName(id)}${sl.n > 1 ? ' ×' + sl.n : ''}`), h('div', { class: 'note' }, priceTxt))));
  if (tl) {
    const kind = { axe: `木を切る（攻撃にも使える：ダメージ${atkRangeText(id)}）`, pick: `岩や鉱脈を掘る（攻撃にも使える：ダメージ${atkRangeText(id)}）`, rod: '水辺で釣りをする', torch: '夜や洞窟を明るく照らす（手に持っている間だけ1秒に1減る）', sword: `動物や敵を攻撃する（ダメージ${atkRangeText(id)}）`, armor: `装備すると、受けるダメージが${Math.round((tl.def || 0) * 100)}%減る（必殺技は防げない）` }[tl.cat];
    d.appendChild(h('div', { class: 'note' }, tl.cat === 'armor' ? `${kind}。攻撃を受けるたびに耐久が1減ります。${sl.eq ? '（装備中：売る・捨てるには外してください）' : ''}` : `${kind}。手に持っている時だけ効果があります。`));
    d.appendChild(tl.dur ? h('div', null, h('div', { class: 'note' }, `耐久 ${durText(sl)}` + (sl.n > 1 ? `（残り${sl.n}本・使っている1本の耐久）` : '')), h('div', { class: 'dur' }, h('i', { style: `width:${Math.round(Math.max(0, sl.dur) / tl.dur * 100)}%` }))) : h('div', { class: 'note' }, '壊れない'));
  } else {
    d.appendChild(h('div', { class: 'note' }, it.d));
    if (it.food) d.appendChild(h('div', { class: it.food.poison ? 'note ng' : 'note ok' }, it.food.poison ? '生は猛毒（食べると体力-25）。焚き火で焼けば食べられる' : [it.food.h ? `空腹+${it.food.h}` : '', it.food.t ? `渇き+${it.food.t}` : ''].filter(Boolean).join('　') + (it.food.raw ? '（生：お腹を壊すことも）' : '') + (it.ret ? '（器は残る）' : '')));
    if (it.place) d.appendChild(h('div', { class: 'note ok' }, `アイテムバーで持って、${Input.mode === 'key' ? '右クリック' : 'Yボタン'}で置けます。`));
    if (it.buff) d.appendChild(h('div', { class: 'note ok' }, `飲むと2分間「覚醒」：スタミナの消費が半分・スタミナの回復が25%速い・移動が30%速い（続けて飲んでも残り2分に戻るだけ）`));
  }
  const bs = h('div', { class: 'btns' });
  if (it && (it.food || it.heal || it.buff)) bs.appendChild(btn(it.food ? (it.food.h ? '食べる' : '飲む') : it.buff ? '飲む' : '使う', () => { consume(id, i); if (!game.slots[i]) L.sel = null; UI.refresh(L); }, { key: 'use', cls: 'primary', silent: true }));
  if (it && it.place && i < hs) bs.appendChild(btn('置く', () => { L.sel = null; startPlace(i); }, { key: 'place', cls: 'primary' }));
  if (tl && tl.cat === 'armor') bs.appendChild(btn(sl.eq ? '装備を外す' : '装備する', () => { toggleEquip(i); UI.refresh(L); }, { key: 'equip', cls: sl.eq ? '' : 'primary', silent: true }));   // v6b
  if (offOk(id)) bs.appendChild(btn('左手に持つ', () => { toOffhand(i); L.sel = game.slots[i] ? i : null; UI.refresh(L); }, { key: 'tooff', silent: true }));   // v6b
  const to = i < hs ? 'bag' : 'bar', fi = to === 'bar' ? game.slots.findIndex((x, k) => k < hs && !x) : game.slots.findIndex((x, k) => k >= hs && k < slotCount() && !x);
  bs.appendChild(btn(to === 'bar' ? 'アイテムバーへ' : '持ち物欄へ', () => { if (fi < 0) { sfx('error'); toast(to === 'bar' ? `アイテムバーに空きがありません（入れ替えは${Input.mode === 'pad' ? '枠を選んで' : 'ドラッグで'}）` : '持ち物欄に空きがありません', 'bad'); return; } moveSlot(game.slots, i, game.slots, fi); syncInv(); L.sel = fi; L.focusKey = 'sl-' + fi; sfx('pick'); UI.refresh(L); }, { key: 'mv', silent: true }));
  bs.appendChild(btn('1個捨てる', () => { dropFromSlot(i, 1); if (!game.slots[i]) L.sel = null; UI.refresh(L); }, { key: 'drop1', silent: true, disabled: !!sl.eq, why: '装備を外すと捨てられます' }));
  if (sl.n > 1) bs.appendChild(btn('全部捨てる', () => confirmBox(`${itemName(id)}を${sl.n}個すべて足元に捨てますか？\n（すぐに拾い直せます）`, () => { dropFromSlot(i, sl.n); L.sel = null; UI.refresh(L); }, { danger: true, yes: '捨てる' }), { key: 'dropall', cls: 'danger' }));
  d.appendChild(bs); return d;
}
const durColor = r => r > 0.5 ? '#6fd06a' : r > 0.25 ? '#f2c440' : '#ff5a4a';
const recipeName = r => r.tool ? TOOLS[r.tool].n : r.build ? (BUILD_NAMES[r.build] || itemName(r.build)) :   /* v8a：木造の家（設計キット）の名前が出ない・undefinedになるのを直した */ r.up ? UP_NAMES[r.up] : ITEMS[r.out].n + (r.n > 1 ? '×' + r.n : '');
const recipeIcon = r => r.tool || r.build || r.up || r.out;
function recipeState(r, nearBench) {
  if (r.bp && !game.bp[r.bp]) return { ok: false, label: '設計図が必要', why: '設計図を持っていません' };
  if (r.st === 'bench' && !nearBench) return { ok: false, label: '作業台で作る', why: '作業台の近くで作れます' };
  if (r.up && game.up[r.up]) return { ok: false, label: '作成済み', why: 'すでに持っています' };
  if (!hasAll(r.cost)) return { ok: false, label: '素材不足', why: '素材が足りません' };
  return { ok: true, label: '作る' };
}
// v4：種類の切り替え（すべて・素材・道具・武器・設置物・強化）＋2列のカード。作れる物を上に並べる
const CRAFT_CATS = [{ id: 'all', n: 'すべて' }, { id: 'mat', n: '素材' }, { id: 'tool', n: '道具・武器' }, { id: 'place', n: '設置物' }, { id: 'up', n: '強化' }];
const craftCat = r => r.tool ? 'tool' : r.build ? 'place' : r.up ? 'up' : 'mat';
function renderCraft(b, L, atBench) {
  const nb = atBench || !!nearStation('bench');
  if (!CRAFT_CATS.some(c => c.id === L.ccat)) L.ccat = 'all';
  const all = RECIPES.map((r, k) => ({ r, k, s: recipeState(r, nb), locked: !!(r.bp && !game.bp[r.bp]) })).filter(x => !(x.r.up && game.up[x.r.up]));   // v6a：作成済みの強化は出さない
  const tg = tutGoal(), tgId = tg && tg.craft;   // v8a：チュートリアルで作る物は一番上に
  const rank = x => x.r.id === tgId ? -1 : x.s.ok ? 0 : x.locked ? 4 : (x.r.up && game.up[x.r.up]) ? 3 : (x.r.st === 'bench' && !nb) ? 1 : 2;
  b.appendChild(h('div', { class: 'ccats' }, ...CRAFT_CATS.map(c => {
    const n = all.filter(x => x.s.ok && (c.id === 'all' || craftCat(x.r) === c.id)).length;
    return btn(c.n + (n ? `（${n}）` : ''), () => { L.ccat = c.id; UI.refresh(L); }, { key: 'cc-' + c.id, cls: L.ccat === c.id ? 'on' : '' });
  })));
  // v5：作業台の近くにいない時は、作業台が必要なレシピを出すか選べる（初期は出さない）
  if (!nb) b.lastChild.appendChild(btn(`${settings.craftBench ? '☑' : '☐'} 作業台が必要なレシピ`, () => { settings.craftBench = !settings.craftBench; saveSettings(); UI.refresh(L); }, { key: 'cc-bench', cls: 'ccheck' + (settings.craftBench ? ' on' : '') }));
  const list = all.filter(x => (L.ccat === 'all' || craftCat(x.r) === L.ccat) && (nb || settings.craftBench || x.r.st !== 'bench' || x.r.id === tgId)).sort((a, c) => rank(a) - rank(c) || a.k - c.k);
  if (!list.length) b.appendChild(h('p', { class: 'note' }, L.ccat === 'up' && RECIPES.every(r => !r.up || game.up[r.up]) ? '強化はすべて作成済みです。' : '作業台の近くで作れる物だけです。'));
  b.appendChild(h('div', { class: 'craft-grid' }, ...list.map(({ r, s, locked }) => h('div', { class: 'ccard' + (s.ok ? ' ok' : locked ? ' locked' : ' ng') }, icon(recipeIcon(r)),
    h('div', { class: 'cm' }, h('div', { class: 'nm' }, recipeName(r), r.st === 'bench' ? h('small', null, '作業台') : null), h('div', { class: 'ds' }, r.d), costEls(r.cost)),
    btn(s.label, () => { craft(r); UI.refresh(L); if (UI.top() !== L) L.el.querySelectorAll('.focus').forEach(e => e.classList.remove('focus')); }, { key: 'cr-' + r.id, cls: s.ok ? 'primary' : '', disabled: !s.ok, why: s.why, silent: true })))));
}
function renderMap(b) {
  const m = curMap(), s = (m.name === 'cave' || m.name === 'cave2') ? 6 : 4, c = mkCanvas(m.W * s, m.H * s), x = c.getContext('2d');
  for (let y = 0; y < m.H; y++) for (let xx = 0; xx < m.W; xx++) { const v = m.tiles[y * m.W + xx]; x.fillStyle = v === T.CWALL ? '#15121a' : TC[v][0]; x.fillRect(xx * s, y * s, s, s); }
  const dot = (o, col, sz) => { x.fillStyle = col; x.fillRect(o.x * s + (s - sz) / 2, o.y * s + (s - sz) / 2, sz, sz); };
  for (const o of m.objs) {
    if (!caveSeenAt(m, o.x, o.y)) continue;
    if (o.t === 'tree' || o.t === 'palm') dot(o, '#1f5e2e', s - 1);
    else if (o.t === 'boulder' || o.t === 'ironVein' || o.t === 'hardRock') dot(o, '#4a4452', s - 1);
    else if (o.t === 'copperVein') dot(o, '#c87040', s - 1); else if (o.t === 'coalVein') dot(o, '#22222a', s - 1);   // v7b
    else if (o.t === 'goldVein') dot(o, P.gold, s - 1);
    else if (o.t === 'ladder') { x.fillStyle = '#d8b878'; x.fillRect(o.x * s + 1, o.y * s, s - 2, s * (o.h || 1)); }   // v6c
    else if (o.t === 'crystal') dot(o, '#7fe3f0', s - 1);
  }
  const mark = (o, col) => { if (!o || !caveSeenAt(m, o.x, o.y)) return; x.fillStyle = P.ol; x.fillRect(o.x * s - 2, o.y * s - 2, s + 4, s + 4); x.fillStyle = col; x.fillRect(o.x * s - 1, o.y * s - 1, s + 2, s + 2); };
  for (const o of m.objs) {
    if (o.t === 'box') mark(o, P.gold); else if (o.t === 'workbench' || o.t === 'furnace' || o.t === 'campfire' || o.t === 'bed') mark(o, '#f08a3c'); else if (o.t === 'miner' || o.t === 'lumber') mark(o, '#7fe08a');   // v7b：採掘機。v8b：伐採機
    else if (o.t === 'house') mark({ x: o.x + 1, y: o.y - 1 }, '#e8b060');   // v7c：木造の家
    else if (o.t === 'cave' || o.t === 'exit' || o.t === 'stairsDown' || o.t === 'stairsUp') mark(o, '#c040c0'); else if (o.t === 'hut') mark(o, '#c8a36a'); else if (o.t === 'raft') mark(o, '#ffffff'); else if (o.t === 'liner') mark(o, '#ff5ac8');
    else if (o.t === 'diary') mark(o, '#c8e6a0'); else if (o.t === 'shrine') mark(o, P.gold);
  }
  if (m.name === 'cave') { x.fillStyle = '#07060c'; for (let y = 0; y < m.H; y++) for (let xx = 0; xx < m.W; xx++) if (!caveSeenAt(m, xx, y)) x.fillRect(xx * s, y * s, s, s); }   // v6a：まだ見ていない所は黒く
  const px = Math.floor(player.x / 16), py = Math.floor((player.y - 4) / 16);
  x.fillStyle = '#ffffff'; x.fillRect(px * s - 3, py * s - 3, s + 6, s + 6); x.fillStyle = '#e2574c'; x.fillRect(px * s - 1, py * s - 1, s + 2, s + 2);
  c.className = 'map-canvas';
  if (m.name === 'island') c.addEventListener('pointerdown', e => mapSecretTap(e, c, m));
  const lg = (col, t) => h('span', null, h('i', { style: 'background:' + col }), t);
  b.appendChild(h('div', { class: 'map-layout' }, h('div', { class: 'map-wrap' }, c), h('div', { class: 'legend' }, lg('#e2574c', '現在地'), lg('#f08a3c', '設備'), lg('#c040c0', '洞窟・階段'), lg('#c8a36a', '古い小屋'), lg('#ff5ac8', 'カジノ船'), lg('#ffffff', 'いかだ置き場'), lg('#c8e6a0', 'ノート'))));
}
// v6a：地図の隠しタップ（左上→右上→左下→右下→中央の泉）でデバッグボタンを出す。地図の大きさに合わせて、割合で判定する
const DBG_TAPS = ['tl', 'tr', 'bl', 'br', 'spring'];
function mapSecretTap(e, c, m) {
  const r = c.getBoundingClientRect(); if (!r.width || !r.height) return;
  const fx = (e.clientX - r.left) / r.width, fy = (e.clientY - r.top) / r.height, E = 0.22, sp = m.lm && m.lm.spring;
  let z = null;
  if (fx < E && fy < E) z = 'tl'; else if (fx > 1 - E && fy < E) z = 'tr'; else if (fx < E && fy > 1 - E) z = 'bl'; else if (fx > 1 - E && fy > 1 - E) z = 'br';
  else if (sp && Math.abs(fx * m.W - (sp.x + 1)) <= 3 && Math.abs(fy * m.H - (sp.y + 1)) <= 3) z = 'spring';
  const i = state.dbgTap || 0;
  state.dbgTap = z && z === DBG_TAPS[i] ? i + 1 : z === 'tl' ? 1 : 0;
  if (state.dbgTap >= DBG_TAPS.length) { state.dbgTap = 0; if (!settings.debug) { settings.debug = true; saveSettings(); } }
}
function renderLog(b) {
  b.appendChild(sec('いまの目標', h('p', { class: 'note', style: 'color:var(--text);font-size:15px' }, objectiveText())));
  const left = game.contract.days - game.day + 1;
  const stl = stagesOf(game.contract);
  b.appendChild(sec('返済の締め日', stl.length ? h('div', null, ...stl.map((x, i) => h('p', { class: 'note' + (i < game.stageI ? '' : game.repaid >= x.need ? ' ok' : i === game.stageI ? ' warn' : '') },
    `${x.day}日目の終わりまでに 累計 ${fmt$(x.need)}${i < game.stageI ? '（判定済み）' : game.repaid >= x.need ? '（達成）' : `（あと ${fmt$(x.need - game.repaid)}）`}`)),
    h('p', { class: 'note' }, `届かないと、残りの借金の${Math.round(STAGE_PENALTY * 100)}%が遅延損害金として上乗せされます。これまでの損害金：${fmt$(game.penalty || 0)}`)) : h('p', { class: 'note' }, '締め日はありません。')));
  b.appendChild(sec('契約', h('p', { class: 'note' }, `借金 ${fmt$(game.debt)}（初期 ${fmt$(game.contract.debt)}）／利息 1日${game.contract.rate}%／` + (game.contract.free ? `期限なし（${game.debt > 0 ? 'デモプレイ' : '完済済み'}）` : `期限 ${game.contract.days}日目の終わりまで（${game.debt > 0 ? (left > 0 ? 'あと' + left + '日' : '今日まで') : '完済済み'}）`)),
    h('p', { class: 'note' }, `返済済み ${fmt$(game.repaid)}（${Math.floor(repaidRatio() * 100)}%）／支払った利息 ${fmt$(game.interestPaid)}`)));
  b.appendChild(sec('借金の推移', debtChartEl()));   // v7b
  const dl = [1, 2, 3].filter(n => game.diaries.includes(n));
  b.appendChild(sec('ゲンの日誌', dl.length ? h('div', { class: 'btns', style: 'display:flex;gap:6px;flex-wrap:wrap' }, ...dl.map(n => btn(`その${n}を読む`, () => { UI.closeAll(); queueTalk(TALK['diary' + n].filter(l => l[0] === 'gen')); }, { key: 'dia' + n }))) : h('p', { class: 'note' }, 'まだ見つけていない。')));
  const st = game.stats;
  b.appendChild(sec('記録', h('p', { class: 'note' }, `総売上 ${fmt$(st.earned || 0)}／売った数 ${st.sold || 0}／採集 ${st.gathered || 0}／クラフト ${st.crafted || 0}／釣果 ${st.fish || 0}／たおした数 ${st.kills || 0}／ギャンブル収支 ${fmtNet(st.gamble || 0)}`)));
  b.appendChild(sec(`エンディング ${settings.endings.length}/${ENDING_ORDER.length}`, h('p', { class: 'note' }, ENDING_ORDER.map(k => settings.endings.includes(k) ? `${k}【${ENDINGS[k].type}】${ENDINGS[k].title}` : `${k}　？？？？`).join('\n')), ));
  b.lastChild.querySelector('.note').style.whiteSpace = 'pre-wrap';
}
function renderSettings(b, L, fromTitle) {
  const tg = (key, label, sub) => h('div', { class: 'set-row' }, h('div', { class: 'lbl', html: label + (sub ? `<small>${sub}</small>` : '') }),
    btn(settings[key] ? 'ON' : 'OFF', () => { settings[key] = !settings[key]; saveSettings(); applySettings(); UI.refresh(L); }, { key: 'set-' + key, cls: settings[key] ? 'gold' : '' }));
  // 操作説明のボタンは、タイトルの設定だけ（ゲーム中はポーズ画面の「設定」の下にある）
  b.appendChild(sec(fromTitle === true ? '操作説明' : 'チュートリアル', h('div', { class: 'btns' }, fromTitle === true ? btn('操作説明・遊び方を見る', () => openHowTo(), { key: 'howto', cls: 'primary' }) : null,
    fromTitle === 'pause' && game && !(game.tut >= 0) ? btn('チュートリアルを最初から', () => { game.tut = 0; state.tutT = 0; toast('チュートリアルを表示します'); }, { key: 'tut0' }) : null),
    tg('tutorial', 'チュートリアル', '「はじめから」で遊ぶ時に、やることを順番に表示します（デモプレイでは常に表示）')));
  b.appendChild(sec('ゼニ丸', tg('zeniTr', 'ゼニ丸翻訳', 'ONにすると、ゼニ丸のセリフの下に、カタカナをひらがなに直した訳を（）で表示します')));   // v8e
  b.appendChild(sec('操作', tg('autoTool', '道具・武器の自動切り替え', 'ONの間、木を切る・岩を掘る・攻撃する時に、アイテムバーの道具や剣へ自動で持ち替えます')));   // v6b
  b.appendChild(sec('キーボード', tg('qeTabs', 'Q/Eで画面のタブを切り替え', 'ONの間、タブのある画面（ゼニ丸など）ではQ＝左・E＝右。画面はEscで閉じます'),
    tg('keyGuide', '画面下のキー操作ガイド', 'キーボードで遊んでいる時だけ表示します')));
  b.appendChild(sec('コントローラー', tg('swapAB', 'A/Bボタンの入れ替え', '決定とキャンセルを入れ替えます（Switch配置など）'), tg('swapXY', 'X/Yボタンの入れ替え', '持ち物と「使う」を入れ替えます')));
  const sizes = [0.85, 1, 1.2], sizeName = ['小', '中', '大'], si = Math.max(0, sizes.indexOf(settings.touchSize));
  b.appendChild(sec('サウンド・画面', tg('bgm', 'BGM', BGM.status()),
    stepper('bgmVol', 'BGMの音量', String(settings.bgmVol), () => { settings.bgmVol = clamp(settings.bgmVol - 1, 0, 10); saveSettings(); applySettings(); UI.refresh(L); }, () => { settings.bgmVol = clamp(settings.bgmVol + 1, 0, 10); saveSettings(); applySettings(); UI.refresh(L); }),
    tg('se', '効果音'),
    stepper('vol', '効果音の音量', String(settings.vol), () => { settings.vol = clamp(settings.vol - 1, 0, 10); saveSettings(); applySettings(); sfx('ui'); UI.refresh(L); }, () => { settings.vol = clamp(settings.vol + 1, 0, 10); saveSettings(); applySettings(); sfx('ui'); UI.refresh(L); }),
    stepper('tsize', 'タッチボタンの大きさ', sizeName[si], () => { settings.touchSize = sizes[Math.max(0, si - 1)]; saveSettings(); applySettings(); UI.refresh(L); }, () => { settings.touchSize = sizes[Math.min(2, si + 1)]; saveSettings(); applySettings(); UI.refresh(L); }),
    stepper('uisize', 'UIの大きさ', settings.uiBig ? '大きめ' : '通常', () => { settings.uiBig = false; saveSettings(); applySettings(); UI.refresh(L); }, () => { settings.uiBig = true; saveSettings(); applySettings(); UI.refresh(L); }),   // v6.1e：画面の大きいPC向け（スマホでは画面に入る大きさまで）
    tg('shake', '画面のゆれ')));
  if (fromTitle === true) {
    b.appendChild(sec('データ', h('p', { class: 'note' }, 'セーブデータの削除は、タイトルの「つづきから」で各スロットごとに行えます。')));
    b.appendChild(sec('バックアップ', h('p', { class: 'note' }, 'ブラウザのデータを消すとセーブも消えます。3つのスロットと設定を、ファイルに書き出して保管できます。'),
      h('div', { class: 'btns' }, btn('バックアップを書き出す', () => exportBackup(), { key: 'bk-out', cls: 'primary' }), btn('バックアップを読み込む', () => importBackup(), { key: 'bk-in' }))));
    // v6.2：タイトルのデバッグ（設定を開いて ↑↑↓↓←→←→BA）。1日の長さを調整できる
    if (settings.debug) b.appendChild(sec('デバッグ', h('div', { class: 'btns' }, btn('デバッグ（1日の長さ）', () => openTitleDebug(), { key: 'debug', cls: 'gold' }))));
  }
}
/* デバッグ（メニューで ↑↑↓↓←→←→BA） */
const KONAMI = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'KeyB', 'KeyA'];
// キーボードの ↑ ↑ ↓ ↓ ← → ← → B A だけを受け付ける（コントローラー・WASD・K/Spaceなどでは開かない）。
// メインメニューを開いている間だけ判定し、最後の B・A は持ち物ショートカット／左移動として扱わない。
function konamiKey(e) {
  const top = UI.top();
  if (!top || !(top.pauseMenu || top.titleSet)) { state.konami = 0; return false; }   // v6.2：タイトルの設定でも
  if (e.repeat || ['ShiftLeft', 'ShiftRight', 'ControlLeft', 'ControlRight', 'AltLeft', 'AltRight', 'MetaLeft', 'MetaRight'].includes(e.code)) return false;
  if (e.ctrlKey || e.altKey || e.metaKey || e.shiftKey) { state.konami = 0; return false; }
  if (e.code === KONAMI[state.konami]) {
    state.konami++;
    if (state.konami >= KONAMI.length) { state.konami = 0; state.konamiGo = true; }
    return e.code === 'KeyB' || e.code === 'KeyA';   // B・Aは「持ち物」「左移動」として働かせない
  }
  state.konami = e.code === KONAMI[0] ? 1 : 0;      // 順番を間違えたら最初から（↑から始め直しはOK）
  return false;
}
function konamiActivate(L) {
  if (!settings.debug) { settings.debug = true; saveSettings(); sfx('unlock'); toast('デバッグボタンを表示しました', 'good'); }
  L.focusKey = 'debug';
}
function hourToTime(hr) { return hr >= 6 && hr < 20 ? (hr - 6) / 14 * CONFIG.dayPart : CONFIG.dayPart + ((hr - 20 + 24) % 24) / 10 * (CONFIG.dayLength - CONFIG.dayPart); }
// v6.2：デバッグ：時計をn時間進める（翌朝6:00をまたぐ時は、日付も進める）
function addHours(n) {
  const g = game, h2 = hourOf(g.time) + n;
  if (h2 < 30) { g.time = clamp(hourToTime(h2 % 24), 0, CONFIG.dayLength - 0.01); return true; }
  UI.closeAll(); if (!newDay('natural') || state.scene !== 'play') return false;
  g.time = clamp(hourToTime(6 + (h2 - 30)), 0, CONFIG.dayLength - 0.01); toast('[DEBUG] 日付をまたいで ' + clockText(g.time) + ' になった', 'good'); return false;
}
// v8a：デバッグ画面を作り直し（タブで分けて、小さめのボタンを並べる。1画面に収まる大きさ）
const DBG_TABS = [{ id: 'item', label: 'お金・持ち物' }, { id: 'state', label: '状態・時間' }, { id: 'move', label: '移動' }, { id: 'mob', label: '生き物' }, { id: 'etc', label: 'カジノ・他' }];
function renderDebug(b, L) {
  const g = game, ok = msg => { toast('[DEBUG] ' + msg, 'good'); UI.refresh(L); };
  if (!DBG_TABS.some(t => t.id === L.tab)) L.tab = 'item';
  const grid = (...bs) => h('div', { class: 'dbg-grid' }, ...bs.filter(Boolean));
  const hd = t => h('div', { class: 'dbg-h' }, t);
  const tg = (on, label, fn, key) => btn(`${label}：${on ? 'ON' : 'OFF'}`, fn, { key, cls: on ? 'gold' : '' });
  b.classList.add('dbg-body');
  if (L.tab === 'item') {
    b.appendChild(hd('お金・借金'));
    b.appendChild(grid(
      btn('+$1,000', () => { g.money += 1000; ok('所持金+$1,000'); }, { key: 'd-m1' }),
      btn('+$10,000', () => { g.money += 10000; ok('所持金+$10,000'); }, { key: 'd-m2' }),
      btn('借金-$1,000', () => { const a = Math.min(1000, g.debt); g.debt -= a; g.repaid += a; checkMilestones(); ok('借金-$1,000'); }, { key: 'd-d1' }),
      btn('借金を完済', () => { g.repaid += Math.max(0, g.debt); g.debt = 0; checkMilestones(); ok('完済しました'); }, { key: 'd-d2' })));
    b.appendChild(hd('持ち物'));
    b.appendChild(grid(
      btn('アイテム付与', () => openDbgItems(), { key: 'd-i1', cls: 'primary' }),
      btn('全部の道具', () => { for (const k of ['ironAxe', 'ironPick', 'ironSword', 'rod', 'ironArmor']) addItem(k, 1, true, TOOLS[k].dur); addItem('torch', 5, true); addItem('ladder', 3, true); for (const k of ['medkit', 'canned']) addItem(k, 5, true); addItem('protein', 1, true); ok('鉄の道具・鉄の防具・釣り竿・たいまつ5本・縄梯子3・救急キット5・缶詰5・プロテインを追加（入らない分は足元）'); }, { key: 'd-i2' }),
      btn('採掘機・伐採機', () => { for (const [k, n] of [['copperore', 10], ['coal', 10], ['copper', 10], ['charcoal', 10], ['ironplate', 10], ['steel', 10], ['gear', 10], ['part', 5], ['motor', 1], ['frame', 1], ['drill', 1], ['miner', 1], ['lumber', 1]]) addItem(k, n, true); ok('採掘機・伐採機の素材を追加'); }, { key: 'd-v7b' }),
      btn('家の素材', () => { for (const [k, n] of [['plank', 15], ['fiber', 30], ['nail', 5], ['ingot', 3], ['crystal', 3], ['metal', 9]]) addItem(k, n, true); ok('家の素材を追加'); }, { key: 'd-v7c' }),
      btn('全部の設計図', () => { for (const k of ['bag', 'magnet', 'cart', 'furnace', 'iron', 'benchUp', 'raft']) g.bp[k] = true; ok('設計図を追加'); }, { key: 'd-i3' }),
      btn('全部の強化', () => { for (const k in UP_NAMES) g.up[k] = true; ensureSlots(); syncInv(); ok('強化を追加'); }, { key: 'd-i4' }),
      btn('持ち物をクリア', () => confirmBox('持ち物（アイテムバー・持ち物・左手）を全部消します。\n大事な物（ノートなど）は消えません。', () => { for (let i = 0; i < g.slots.length; i++) g.slots[i] = null; g.off = null; syncInv(); toast('[DEBUG] 持ち物をクリアしました', 'good'); const t = UI.top(); if (t) UI.refresh(t); }, { title: '持ち物をクリア', yes: 'クリア', danger: true }), { key: 'd-i5', cls: 'danger' })));
  } else if (L.tab === 'state') {
    b.appendChild(hd('状態'));
    b.appendChild(grid(
      btn('全回復', () => { g.hp = g.hunger = g.thirst = g.stamina = 100; g.sick = 0; g.exhaust = false; g.poison = 0; ok('全回復'); }, { key: 'd-s1' }),
      tg(state.god, '無敵', () => { state.god = !state.god; ok('無敵 ' + (state.god ? 'ON' : 'OFF')); }, 'd-s2'),
      tg(state.infSt, 'スタミナ無限', () => { state.infSt = !state.infSt; ok('スタミナ無限 ' + (state.infSt ? 'ON' : 'OFF')); }, 'd-s3'),
      tg(state.timeStop, '時間停止', () => { state.timeStop = !state.timeStop; ok('時間停止 ' + (state.timeStop ? 'ON（時計と空腹・渇きが止まる）' : 'OFF')); }, 'd-s4')));
    b.appendChild(hd(`時間（今 ${clockText(g.time)}）`));
    b.appendChild(grid(
      btn('1時間進める', () => { if (addHours(1)) ok('1時間進めた（' + clockText(g.time) + '）'); }, { key: 'd-t1' }),
      btn('3時間進める', () => { if (addHours(3)) ok('3時間進めた（' + clockText(g.time) + '）'); }, { key: 'd-t2' }),
      btn('翌朝にする', () => { UI.closeAll(); newDay('sleep'); }, { key: 'd-t3' })));
    b.appendChild(hd('天気（今日だけ変更）'));
    b.appendChild(grid(...Object.keys(WEATHER).map(k => btn(WEATHER[k].n, () => { g.weather = k; g.rainAcc = 0; ok('天気：' + WEATHER[k].n); }, { key: 'd-w' + k, cls: g.weather === k ? 'gold' : '' }))));
  } else if (L.tab === 'move') {
    b.appendChild(hd('場所'));
    b.appendChild(grid(
      btn('スタート地点へ', () => { UI.closeAll(); const sp = maps.island.lm.spawn; state.mobs = []; game.map = 'island'; player.x = sp.x * 16 + 8; player.y = sp.y * 16 + 12; state.rocks = []; }, { key: 'd-w1' }),
      btn('洞窟に入る', () => { UI.closeAll(); if (game.map !== 'cave') enterCave(); }, { key: 'd-w2' }),
      tg(state.noclip, '壁貫通', () => { state.noclip = !state.noclip; if (!state.noclip) unstickPlayer(); ok('壁貫通 ' + (state.noclip ? 'ON（地図の外には出られない）' : 'OFF')); }, 'd-w3')));
    b.appendChild(hd(`移動速度（今 x${state.dbgSpd || 1}）`));
    b.appendChild(grid(...[1, 2, 3, 5].map(v => btn(`x${v}`, () => { state.dbgSpd = v; ok(`移動速度 x${v}`); }, { key: 'd-sp' + v, cls: (state.dbgSpd || 1) === v ? 'gold' : '' }))));
    b.appendChild(h('p', { class: 'note' }, `マップ：${Number.isInteger(g.seed) ? 'ランダム生成（シード値 ' + (Number.isInteger(g.seed4) ? seedText(g.seed4) : g.seed) + '）' : '旧マップ'}`));
  } else if (L.tab === 'mob') {
    const spawnNear = t => { const d = MOBS[t]; for (let a = 0; a < 20; a++) { const x = player.x + rnd(-48, 48), y = player.y + rnd(-48, 48); if (Math.hypot(x - player.x, y - player.y) > 24 && !mobBlocked(curMap(), d, x, y)) { spawnMob(t, x, y); return true; } } return false; };
    b.appendChild(hd('近くに出す'));
    b.appendChild(grid(...Object.keys(MOBS).map(t => btn(MOBS[t].n, () => { UI.closeAll(); if (!spawnNear(t)) toast('出せる場所がない', 'bad'); }, { key: 'd-m' + t }))));
    b.appendChild(hd('出現'));
    b.appendChild(grid(
      tg(!state.noMobs, '自然に出る', () => { state.noMobs = !state.noMobs; ok('モブの出現 ' + (state.noMobs ? 'OFF' : 'ON')); }, 'd-mn'),
      btn('全部消す', () => { state.mobs = []; ok('モブを全部消した'); }, { key: 'd-mc', cls: 'danger' }),
      btn(!g.flags.bossDown ? 'ボス再戦（討伐後）' : g.flags.bossRematch ? 'ボス再戦：準備OK' : 'ボス再戦', () => {
        if (!g.flags.bossDown) { sfx('error'); toast('ボスを倒したあとに使えます', 'bad'); return; }
        g.flags.bossRematch = 1; ok(g.map === 'cave2' ? 'ボス再戦の準備OK：いったん地下1階に戻って、もう一度下りてください' : 'ボス再戦の準備OK：地下2階に入ると再戦できます');
      }, { key: 'd-boss', cls: g.flags.bossDown && g.flags.bossRematch ? 'gold' : '' }),
      btn('ボス(第2形態)出現', () => debugGaming(), { key: 'd-boss2', cls: 'danger' })));   // v8.2
  } else {
    b.appendChild(hd('カジノ'));
    b.appendChild(grid(
      btn('カジノ船の前へ', () => { const o = maps.island.objs.find(x => x.t === 'liner'); if (!o) { sfx('error'); toast('まだカジノ船がありません（発電機を直す）', 'bad'); return; } UI.closeAll(); if (game.map !== 'island') { state.mobs = []; game.map = 'island'; } player.x = o.x * 16 + 24; player.y = (o.y + 1) * 16 + 12; player.dir = 1; }, { key: 'd-c1' }),
      btn('発電機を直す', () => { g.flags.linerSeen = 1; g.casino.open = true; ensureLiner(); ok('カジノを開けた'); }, { key: 'd-c2' }),
      btn('ゼニ丸の勝負リセット', () => { g.flags.zeniDay = 0; ok('今日の勝負をリセット'); }, { key: 'd-c3' }),
      btn('次でBB当選', () => { state.slotForce = 'BB'; ok('次のスロットでBBに当選します'); }, { key: 'd-c4' }),
      btn('次でRB当選', () => { state.slotForce = 'RB'; ok('次のスロットでRBに当選します'); }, { key: 'd-c5' }),
      btn('コイン+46枚', () => { ensureCasino(); g.casino.coins += 46; ok('コイン+46枚'); }, { key: 'd-c6' })));
    b.appendChild(hd('エンディング'));
    b.appendChild(grid(
      ...ENDING_ORDER.map(k => btn(k + ' を見る', () => { UI.closeAll(); endGame(k); }, { key: 'd-e' + k })),
      btn('記録を全部解放', () => { settings.endings = ENDING_ORDER.slice(); saveSettings(); ok('エンディング記録を全解放'); }, { key: 'd-e1' }),
      btn('記録をリセット', () => { settings.endings = []; saveSettings(); ok('エンディング記録をリセット'); }, { key: 'd-e2', cls: 'danger' })));
    b.appendChild(hd('表示'));
    b.appendChild(grid(btn('デバッグボタンを隠す', () => { settings.debug = false; saveSettings(); UI.close(L); const t = UI.top(); if (t) UI.refresh(t); }, { key: 'd-h' })));
  }
}
// v8a：好きな素材+5。v8e：「アイテム付与」に改名。ゲーム内の全アイテム（大切なものも）を並べ、「持ち物に追加」で1スロット分（石などは5個、設置物などは1個）
const dbgCat = id => TOOLS[id] ? 'tool' : isPlace(id) ? 'tool' : ITEMS[id] && ITEMS[id].key ? 'key' : ITEMS[id] && (ITEMS[id].food || ITEMS[id].heal || ITEMS[id].buff || ITEMS[id].drink) ? 'food' : 'mat';   // v8e：プロテイン（buff）は食べ物・薬
const dbgN = id => ITEMS[id] && ITEMS[id].key ? 1 : stackOf(id);   // v8e：付与する数＝1スロット分（大切なものは1個）
function openDbgItems() {
  const ids = Object.keys(ITEMS).concat(Object.keys(TOOLS).filter(k => !ITEMS[k]));   // v8e：大切なものも含めて全部
  const cats = [{ id: 'all', n: 'すべて' }, { id: 'mat', n: '素材' }, { id: 'food', n: '食べ物・薬' }, { id: 'tool', n: '道具・設置物' }, { id: 'key', n: '大切なもの' }];
  UI.open({ dcat: 'all', render: (el, L) => el.appendChild(windowEl(L, { title: 'アイテム付与', cls: 'dbg-items-win', body: b => {
    b.appendChild(h('div', { class: 'ccats' }, ...cats.map(c => btn(c.n, () => { L.dcat = c.id; UI.refresh(L); }, { key: 'dc-' + c.id, cls: L.dcat === c.id ? 'on' : '' }))));
    b.appendChild(h('div', { class: 'dbg-items' }, ...ids.filter(id => L.dcat === 'all' || dbgCat(id) === L.dcat).map(id => btn(h('span', { class: 'dbg-it' }, icon(id), h('span', null, itemName(id))), () => openDbgItem(id), { key: 'di-' + id }))));
  } })) });
}
function openDbgItem(id) {
  const tl = TOOLS[id], it = ITEMS[id], rc = RECIPES.find(r => r.tool === id || r.build === id || r.out === id), d = (it && it.d) || (tl && tl.d) || (rc && rc.d) || '';   // 道具はレシピの説明を使う
  UI.open({ render: (el, L) => el.appendChild(windowEl(L, { title: 'アイテム', cls: 'small', body: b => {
    b.appendChild(h('div', { class: 'dbg-item-detail' }, icon(id), h('div', null, h('div', { class: 'name' }, itemName(id)), h('div', { class: 'desc' }, d), h('div', { class: 'desc', style: 'color:var(--gold)' }, `持っている数：${game.inv[id] || 0}`))));
  }, foot: [btn('閉じる', () => UI.close(L), { key: 'no' }), btn(`持ち物に追加（${dbgN(id)}個）`, () => { const a = addItem(id, dbgN(id), true, tl ? tl.dur : undefined); toast(a ? `[DEBUG] ${itemName(id)}を${a}個追加` : '[DEBUG] 持ち物に空きがありません', a ? 'good' : 'bad'); UI.refresh(L); }, { key: 'yes', cls: 'primary' })] })) });
}
function openTitleDebug() {
  UI.open({ render: (el, L) => el.appendChild(windowEl(L, { title: 'デバッグ（タイトル）', cls: 'small', body: b => {
    const set = (k, d, lo, hi) => { settings[k] = clamp(settings[k] + d, lo, hi); saveSettings(); applyDayLen(); UI.refresh(L); };
    b.appendChild(h('p', { class: 'note warn' }, '開発用の機能です。試験中の調整用で、すべてのスロットに反映されます（時刻は「何時か」を保ったまま直します）。'));
    b.appendChild(sec('1日の長さ（現実の時間）',
      stepper('dd', '昼（6:00〜20:00）', fmtDur(settings.dayDay), () => set('dayDay', -30, 60, 900), () => set('dayDay', 30, 60, 900)),
      stepper('dn', '夜（20:00〜翌6:00）', fmtDur(settings.dayNight), () => set('dayNight', -30, 30, 600), () => set('dayNight', 30, 30, 600)),
      h('p', { class: 'note' }, `今の設定：ゲーム内の1日＝現実の${fmtDur(CONFIG.dayLength)}（初期値は昼3分30秒・夜1分30秒の5分）`),
      h('div', { class: 'btns' }, btn('初期値に戻す', () => { settings.dayDay = 210; settings.dayNight = 90; saveSettings(); applyDayLen(); UI.refresh(L); }, { key: 'dd-reset' }))));
    b.appendChild(sec('表示', h('div', { class: 'btns' }, btn('デバッグボタンを隠す', () => { settings.debug = false; saveSettings(); UI.close(L); const t = UI.top(); if (t) UI.refresh(t); }, { key: 'd-h' }))));
  } })) });
}
function openSettingsLayer(ctx) { UI.open({ titleSet: ctx === undefined, render: (el, L) => el.appendChild(windowEl(L, { title: '設定', body: b => renderSettings(b, L, ctx === undefined ? true : ctx) })) }); }
/* ポーズ画面（Esc・START・≡）：時間が止まる */
function openPause() {
  sfx('ui'); stopFishing(); if (state.place) cancelPlace(true);
  UI.open({ pauseMenu: true, render: (el, L) => el.appendChild(windowEl(L, { title: 'ポーズ', cls: 'small', body: b => {
    const demo = !!game.demo;
    b.appendChild(h('div', { class: 'pause-btns' },
      btn('ゲームに戻る', () => UI.close(L), { key: 'resume', cls: 'primary big' }),
      h('div', { class: 'pause-row' },   // v8a：記録と設定は横に並べる（スマホの横画面でも1画面に収まるように）
        btn('記録', () => openLog(), { key: 'log', cls: 'big' }),   // v6.2：メニューの「記録」はポーズ画面へ（見ている間は時間が止まる）
        btn('設定', () => openSettingsLayer('pause'), { key: 'settings', cls: 'big' })),
      btn('操作説明・遊び方', () => openHowTo(), { key: 'howto', cls: 'big' }),
      btn(demo ? 'セーブ（デモでは使えません）' : `セーブ（スロット${curSlot}）`, () => { if (saveGame(false)) UI.refresh(L); }, { key: 'save', cls: 'big', disabled: demo, why: 'デモプレイではセーブできません' }),
      btn('タイトルに戻る', () => backToTitle(), { key: 'title', cls: 'big' }),
      settings.debug ? btn('デバッグ', () => openDebugLayer(), { key: 'debug', cls: 'big' }) : null));
    b.appendChild(h('p', { class: 'note', style: 'text-align:center;margin-top:8px' }, demo ? 'デモプレイ中です（セーブはできません）' : state.dirty ? '最後にセーブした後の進行は、まだ保存されていません' : 'セーブ済みです'));
  } })) });
}
function backToTitle() {
  const go = () => { UI.closeAll(); showTitle(); };
  if (game.demo) confirmBox('デモプレイを終了して、タイトルに戻りますか？', go, { yes: 'タイトルへ' });
  else if (state.dirty) confirmBox('セーブされていませんが、よろしいですか？\n（最後にセーブした後の進行は失われます）', go, { yes: 'タイトルに戻る', danger: true });
  else go();
}
function openDebugLayer() { UI.open({ tab: 'item', render: (el, L) => el.appendChild(windowEl(L, { title: 'デバッグ', cls: 'dbg-win', tabs: DBG_TABS, sub: h('div', { class: 'win-sub' }, h('span', null, '所持金 ', h('b', null, fmt$(game.money))), h('span', null, '借金 ', h('b', null, fmt$(game.debt))), h('span', null, h('b', null, `${game.day}日目 ${clockText(game.time)}`)), h('span', { class: 'ng' }, '開発用：セーブの内容が変わります')), body: b => renderDebug(b, L) })) }); }   // v8a：タブで分ける

/* 作業台・焚き火・炉 */
const findProc = (st, id) => PROCESS[st].find(r => r.id === id);
const procTime = (st, rec) => rec.t * (st === 'bench' && game.up.benchUp ? 0.5 : 1);
function openStation(o) {
  const st = OBJ[o.t].st; collectOutput(o);
  UI.open({ tab: st === 'bench' ? 'craft' : 'proc', live: true, onClose: () => saveGame(true), onTick: (dt, L) => stationTick(L, o, st), render: (el, L) => {
    el.appendChild(windowEl(L, {
      title: STATION_NAMES[st] + (st === 'bench' && game.up.benchUp ? '（強化済み）' : ''), sub: statusSub(), cls: st === 'furnace' ? 'furn-win' : '',
      tabs: st === 'bench' ? [{ id: 'craft', label: 'クラフト' }, { id: 'proc', label: '加工' }] : null,
      body: b => { if (L.tab === 'craft') renderCraft(b, L, true); else if (st === 'furnace') renderFurnace(b, L, o); else renderProcess(b, L, o, st); },   // v8b：炉は燃料つきの画面
    }));
  } });
}
// v6.2：焚き火は、今できる加工を上に並べる（クラフトと同じ）。v8a：作業台・炉も同じく、作れる物を上に
const procList = st => PROCESS[st].map((r, i) => ({ r, i, ok: Object.keys(r.in).every(k => (game.inv[k] || 0) >= r.in[k]) })).sort((a, c) => (c.ok - a.ok) || a.i - c.i).map(x => x.r);
function renderProcess(b, L, o, st) {
  if (st === 'fire') b.appendChild(h('p', { class: 'note' }, '焚き火の近くにいると、夜でも体が冷えません。'));
  const out = o.out && Object.keys(o.out).filter(k => o.out[k] > 0);
  if (out && out.length) b.appendChild(sec('できあがり', h('div', { class: 'row-item' }, h('div', { class: 'grow' }, ...out.map(k => h('span', { style: 'margin-right:10px' }, icon(k, true), ` ${ITEMS[k].n}×${o.out[k]}`))),
    btn('受け取る', () => { collectOutput(o); UI.refresh(L); }, { key: 'collect', cls: 'primary' }))));
  if (o.q && o.q.length) b.appendChild(queueSec(o, st, L));   // v8b：入れた順に1行ずつ
  b.appendChild(sec('加工する', ...procList(st).map(rec => {
    const maxN = Math.min(...Object.keys(rec.in).map(k => Math.floor((game.inv[k] || 0) / rec.in[k])));
    const outV = ITEMS[rec.out].p * (rec.n || 1), inV = Object.keys(rec.in).reduce((s, k) => s + ITEMS[k].p * rec.in[k], 0);
    return h('div', { class: 'row-item' }, icon(rec.out), h('div', { class: 'grow' },
      h('div', { class: 'name' }, `${ITEMS[rec.out].n}${rec.n > 1 ? '×' + rec.n : ''}`),
      h('div', { class: 'desc' }, `1個 ${procTime(st, rec)}秒　基本価値 ${fmt$(inV)} → ${fmt$(outV)}`), costEls(rec.in)),
      h('div', { class: 'btns' },
        btn('+1', () => { enqueue(o, st, rec, 1); UI.refresh(L); }, { key: 'q1-' + rec.id, disabled: maxN < 1, why: '素材が足りません', silent: true }),
        btn('+5', () => { enqueue(o, st, rec, 5); UI.refresh(L); }, { key: 'q5-' + rec.id, disabled: maxN < 1, why: '素材が足りません', silent: true }),
        btn('最大', () => { enqueue(o, st, rec, 999); UI.refresh(L); }, { key: 'qm-' + rec.id, cls: maxN > 0 ? 'primary' : '', disabled: maxN < 1, why: '素材が足りません', silent: true })));
  })));
  b.appendChild(sec('設置物', h('p', { class: 'note' }, '回収すると、持ち物に戻して別の場所に置き直せます（加工中は回収できません）。'), pickupBtn(o)));
}
// v8b：加工中の表示。入れた順に、同じ物が続く所はまとめて「名前×個数」と進み具合（いま加工している行だけ進む）
function queueGroups(o) { const gs = []; for (const j of o.q || []) { const g = gs[gs.length - 1]; if (g && g.id === j.id) g.n++; else gs.push({ id: j.id, n: 1 }); } return gs; }
function queueSec(o, st, L) {
  const gs = queueGroups(o), job = o.q[0], tt = procTime(st, findProc(st, job.id)), pr = clamp(1 - job.left / tt, 0, 1);
  return sec(`加工中（入れた順・開いたままでも進みます）`, ...gs.map((g, k) => { const rec = findProc(st, g.id), outN = (rec.n || 1) * g.n;
    return h('div', { class: 'row-item qrow' + (k ? ' wait' : '') }, icon(rec.out), h('div', { class: 'grow' }, h('div', { class: 'name' }, `${ITEMS[rec.out].n}×${outN}` + (k ? '　（待ち）' : '　（加工中）')), h('div', { class: 'qbar' + (k ? ' wait' : '') }, h('i', { style: `width:${k ? 0 : Math.round(pr * 100)}%` })))); }),
    h('div', { class: 'btns', style: 'margin-top:4px' }, btn('全部キャンセル', () => { cancelQueue(o, st); UI.refresh(L); }, { key: 'cancelq', cls: 'danger' })));
}
// v8b：炉の燃料を入れる（持ち物の枠から1個だけ。2個以上あっても、残りは元の枠に残る）
const FUEL_IDS = ['branch', 'charcoal', 'coal'];
function furnaceFuelIn(o, si) {
  const F = CONFIG.furnaceFuel, sl = game.slots[si];
  if (!sl || !FUEL_IDS.includes(sl.id)) { sfx('error'); toast('燃料にできるのは、木の枝（+2）・木炭（+8）・石炭（+10）です', 'bad'); return false; }
  if ((o.fuel || 0) >= F.max) { sfx('error'); toast('燃料は満タンです', 'bad'); return false; }
  const id = sl.id; takeFromSlot(si, 1); syncInv();
  const before = o.fuel || 0; o.fuel = Math.min(F.max, before + F[id]); o.fuelFx = { id, t: performance.now() };
  sfx('craft'); toast(`${itemName(id)}を燃料にした（燃料 ${before}→${o.fuel}）`, 'good'); return true;
}
// v8b：炉の画面（左上：燃料ゲージと燃料投入スロット、左下：持ち物、右：加工中とレシピ）
function renderFurnace(b, L, o) {
  const F = CONFIG.furnaceFuel, fuel = o.fuel || 0, hs = CONFIG.hotSize, N = slotCount();
  const lay = h('div', { class: 'furn-layout' }), left = h('div', { class: 'furn-left' }), right = h('div', { class: 'furn-right' }); lay.appendChild(left); lay.appendChild(right); b.appendChild(lay);
  const fx = o.fuelFx && performance.now() - o.fuelFx.t < 900 ? o.fuelFx.id : null;
  const slot = h('div', { class: 'islot fuel-slot' + (fx ? ' burn' : '') }, fx ? icon(fx) : h('span', { class: 'fs-lbl' }, '燃料'));
  left.appendChild(h('div', { class: 'furn-fuel' },
    slot,
    h('div', { class: 'grow' },
      h('div', { class: 'name' }, `燃料 ${fuel}/${F.max}`, h('small', null, `　あと${fuel}回加工できる`)),
      h('div', { class: 'fuel-gauge' }, ...Array.from({ length: F.max }, (_, i) => h('i', { class: i < fuel ? 'on' : '' }))),
      h('div', { class: 'desc' }, `下の持ち物の 木の枝（+${F.branch}）・木炭（+${F.charcoal}）・石炭（+${F.coal}）を押すと、1個ずつ燃料になる`))));
  const cell = i => { const sl = game.slots[i], fuelOk = sl && FUEL_IDS.includes(sl.id);
    const c = h('button', { class: 'islot f' + (i < hs ? ' hb' : '') + (sl && !fuelOk ? ' dim' : '') + (fuelOk ? ' fuel' : ''), 'data-k': 'fs-' + i, tabindex: '-1', type: 'button' },
      i < hs ? h('span', { class: 'hn' }, String(i + 1)) : null, sl ? icon(sl.id) : null, sl && sl.n > 1 ? h('span', { class: 'hc' }, String(sl.n)) : null);
    c.addEventListener('click', e => { e.preventDefault(); L.focusKey = 'fs-' + i; if (!game.slots[i]) return; if (furnaceFuelIn(o, i)) UI.refresh(L); });
    return c; };
  const inv = h('div', { class: 'furn-inv' });
  inv.appendChild(h('div', { class: 'inv-lbl' }, '持ち物（燃料にできる物は明るく表示）'));
  for (let r = hs; r < N; r += 8) inv.appendChild(h('div', { class: 'slot-row8' }, ...Array.from({ length: Math.min(8, N - r) }, (_, k) => cell(r + k))));
  inv.appendChild(h('div', { class: 'inv-lbl' }, 'アイテムバー'));
  inv.appendChild(h('div', { class: 'slot-row8 hbrow' }, ...Array.from({ length: hs }, (_, k) => cell(k))));
  left.appendChild(inv);
  b = right;
  const out = o.out && Object.keys(o.out).filter(k => o.out[k] > 0);
  if (out && out.length) b.appendChild(sec('できあがり', h('div', { class: 'row-item' }, h('div', { class: 'grow' }, ...out.map(k => h('span', { style: 'margin-right:10px' }, icon(k, true), ` ${ITEMS[k].n}×${o.out[k]}`))),
    btn('受け取る', () => { collectOutput(o); UI.refresh(L); }, { key: 'collect', cls: 'primary' }))));
  if (o.q && o.q.length) b.appendChild(queueSec(o, 'furnace', L));
  if (fuel <= 0) b.appendChild(h('p', { class: 'note warn' }, '燃料がありません。左の持ち物から、木の枝・木炭・石炭を押して燃料を入れよう。'));
  b.appendChild(sec('加工する', ...procList('furnace').map(rec => {
    const mat = Math.min(...Object.keys(rec.in).map(k => Math.floor((game.inv[k] || 0) / rec.in[k]))), maxN = Math.min(mat, fuel), why = fuel <= 0 ? '燃料がありません' : '素材が足りません';
    const outV = ITEMS[rec.out].p * (rec.n || 1), inV = Object.keys(rec.in).reduce((s, k) => s + ITEMS[k].p * rec.in[k], 0);
    return h('div', { class: 'row-item' + (fuel <= 0 ? ' gray' : '') }, icon(rec.out), h('div', { class: 'grow' },
      h('div', { class: 'name' }, `${ITEMS[rec.out].n}${rec.n > 1 ? '×' + rec.n : ''}`),
      h('div', { class: 'desc' }, `1個 ${procTime('furnace', rec)}秒・燃料1　基本価値 ${fmt$(inV)} → ${fmt$(outV)}`), costEls(rec.in)),
      h('div', { class: 'btns' },
        btn('+1', () => { enqueue(o, 'furnace', rec, 1); UI.refresh(L); }, { key: 'q1-' + rec.id, disabled: maxN < 1, why, silent: true }),
        btn('+5', () => { enqueue(o, 'furnace', rec, 5); UI.refresh(L); }, { key: 'q5-' + rec.id, disabled: maxN < 1, why, silent: true }),
        btn('最大', () => { enqueue(o, 'furnace', rec, 999); UI.refresh(L); }, { key: 'qm-' + rec.id, cls: maxN > 0 ? 'primary' : '', disabled: maxN < 1, why, silent: true })));
  })));
  b.appendChild(sec('設置物', h('p', { class: 'note' }, '回収すると、持ち物に戻して別の場所に置き直せます（加工中は回収できません）。'), pickupBtn(o)));
}
// 置いた物を拾ってアイテムに戻す（加工中・受け取り前・中身がある時はできない）
function pickupPlaced(o) {
  if (o.t === 'miner' && ((o.fuel || 0) > 0 || minerStored(o) > 0)) { sfx('error'); toast('燃料を使い切って、保管を空にすると回収できる', 'bad'); return false; }   // v7b
  if (o.t === 'lumber' && lumberStored(o) > 0) { sfx('error'); toast('保管を空にすると回収できる', 'bad'); return false; }   // v8b
  if ((o.q && o.q.length) || (o.out && Object.keys(o.out).some(k => o.out[k] > 0))) { sfx('error'); toast('加工中や受け取り前の物があると回収できない', 'bad'); return false; }
  if (o.slots && o.slots.some(Boolean)) { sfx('error'); toast('中身を全部出すと回収できる', 'bad'); return false; }
  if (roomFor(o.t) < 1) { sfx('error'); toast('持ち物がいっぱいです', 'bad'); return false; }
  removeObj(curMap(), o); stations = stations.filter(x => x !== o); addItem(o.t, 1);
  sfx('pick'); toast(`${itemName(o.t)}を回収した`, 'good'); UI.closeAll(); saveGame(true); return true;
}
const pickupBtn = o => btn(`${itemName(o.t)}を回収する`, () => confirmBox(`${itemName(o.t)}を回収して、持ち物に戻しますか？`, () => pickupPlaced(o), { yes: '回収する' }), { key: 'pickup' });
// 加工画面を開いている間、進み具合を更新する（数が変わった時だけ作り直す）
function stationTick(L, o, st) {
  L._t = (L._t || 0) + 1; if (L._t % 6) return;
  const qn = o.q ? o.q.length : 0, on = o.out ? Object.values(o.out).reduce((a, b) => a + b, 0) : 0;
  if (L._qn == null) { L._qn = qn; L._on = on; }
  if (qn !== L._qn || on !== L._on) { L._qn = qn; L._on = on; UI.refresh(L); return; }
  if (o.fuelFx && L._fx !== o.fuelFx.t && performance.now() - o.fuelFx.t > 950) { L._fx = o.fuelFx.t; UI.refresh(L); return; }   // v8b：燃料の燃える演出を消す
  const bar = L.el.querySelector('.qbar i'); if (bar && qn) { const job = o.q[0], tt = procTime(st, findProc(st, job.id)); bar.style.width = Math.round(clamp(1 - job.left / tt, 0, 1) * 100) + '%'; }
}
// v7b：自動採掘機 ------------------------------------------------------------
const minerStored = o => Object.values(o.store || {}).reduce((a, b) => a + (b || 0), 0);
const minerFull = o => CONFIG.miner.cap - minerStored(o) < CONFIG.miner.stopFree;
const minerOn = o => (o.fuel || 0) > 0 && !minerFull(o);
// v8b：自動伐採機 ------------------------------------------------------------
const lumberStored = o => Object.values(o.store || {}).reduce((a, b) => a + (b || 0), 0);
const lumberTrees = o => { const m = maps.island, r = []; if (!m) return r; for (let y = o.y - 1; y <= o.y + 1; y++) for (let x = o.x - 1; x <= o.x + 1; x++) { const t = objAt(m, x, y); if (t && t.t === 'tree' && t !== o) r.push(t); } return r; };
const lumberOn = o => lumberStored(o) < CONFIG.lumber.cap && lumberTrees(o).length > 0;
function updateLumbers(dt) {
  const C = CONFIG.lumber; if (!maps.island) return;
  for (const o of maps.island.objs) {
    if (o.t !== 'lumber') continue;
    if (!lumberOn(o)) { o.tm = C.every; continue; }   // 木がない・保管がいっぱいの時は待つ
    o.tm = (o.tm == null ? C.every : o.tm) - dt;
    if (o.tm > 0) continue;
    o.tm = C.every; const tr = lumberTrees(o)[0];
    tr.t = 'stump'; tr.r = game.day + OBJ.tree.g.regrow;   // 手で切った時と同じく、切り株になって生え直す
    o.store = o.store || {}; o.store.wood = (o.store.wood || 0) + C.wood; o.store.branch = (o.store.branch || 0) + C.branch; o.cut = (o.cut || 0) + 1;
    if (game.map === 'island' && Math.hypot(tr.x * 16 + 8 - player.x, tr.y * 16 + 8 - player.y) < 200) { burst(tr.x * 16 + 8, tr.y * 16 + 6, P.woodL, 8); sfx('chop'); }
  }
}
function openLumber(o) {
  sfx('ui');
  UI.open({ live: true, onClose: () => saveGame(true), onTick: (dt, L) => { L._mt = (L._mt || 0) + dt; if (L._mt >= 0.25) { L._mt = 0; UI.refresh(L); } },
    render: (el, L) => el.appendChild(windowEl(L, { title: '自動伐採機', sub: statusSub(), cls: 'small miner-win', body: b => renderLumber(b, L, o) })) });
}
function renderLumber(b, L, o) {
  const C = CONFIG.lumber, st = lumberStored(o), trees = lumberTrees(o).length, on = lumberOn(o);
  const why = on ? '稼働中' : st >= C.cap ? '停止中（保管がいっぱい。回収しよう）' : '待機中（まわりに切れる木がない。生え直すとまた切る）';
  const cols = h('div', { class: 'two-cols' }), cA = h('div', { class: 'col' }), cB = h('div', { class: 'col' }); cols.appendChild(cA); cols.appendChild(cB); b.appendChild(cols);
  const pr = on ? clamp(1 - (o.tm == null ? C.every : o.tm) / C.every, 0, 1) : 0;
  cA.appendChild(sec('状態',
    h('p', { class: 'note ' + (on ? 'ok' : 'warn'), style: 'font-size:15px' }, why),
    h('div', { class: 'name', style: 'font-size:13px' }, on ? `次の伐採まで あと${Math.ceil(o.tm == null ? C.every : o.tm)}秒` : '次の伐採：止まっています'),
    h('div', { class: 'qbar' + (on ? '' : ' wait') }, h('i', { style: `width:${Math.round(pr * 100)}%` })),
    h('p', { class: 'note' }, `範囲（まわり3×3）の木：${trees}本　${C.every}秒ごとに1本切る（燃料はいらない）`)));
  const ids = Object.keys(o.store || {}).filter(k => o.store[k] > 0);
  cB.appendChild(sec(`保管 ${st}/${C.cap}`,
    ids.length ? h('div', null, ...ids.map(id => h('div', { class: 'row-item' }, icon(id), h('div', { class: 'grow' }, h('div', { class: 'name' }, `${itemName(id)} ×${o.store[id]}`))))) : h('p', { class: 'note' }, 'まだ何も切っていません。'),
    h('div', { class: 'btns', style: 'margin-top:6px' }, btn('全部回収する', () => { lumberCollect(o); UI.refresh(L); }, { key: 'lcol', cls: 'primary', disabled: !st, why: '保管は空です' }))));
  b = cB;   // 説明は右の列に
  b.appendChild(h('p', { class: 'note' }, `木1本で木材${C.wood}個・木の枝${C.branch}個。保管が${C.cap}個になると止まります。切った木は切り株になり、${OBJ.tree.g.regrow}日で生え直すと、また切ってくれます。これまでに${o.cut || 0}本切りました。範囲の中は歩いて通れます。`));
  if (!st) b.appendChild(h('div', { class: 'btns', style: 'margin-top:8px' }, pickupBtn(o)));
}
function lumberCollect(o) {
  let total = 0; for (const id of Object.keys(o.store || {})) { const n = o.store[id] || 0; if (n > 0) { addItem(id, n, true); total += n; } }
  o.store = {}; if (total) { sfx('pick'); toast(`伐採機から${total}個を回収した`, 'good'); saveGame(true); }
}
// 置いた物・持ち物・加工中・できあがりの合計（1台までの判定）
function minerTotal() {
  let n = (game.inv.miner || 0) + (maps.island ? maps.island.objs.filter(o => o.t === 'miner').length : 0);
  for (const o of stations) { n += (o.q || []).filter(j => j.id === 'miner').length + ((o.out && o.out.miner) || 0); }
  return n;
}
function updateMiners(dt) {
  const C = CONFIG.miner; if (!maps.island) return;
  for (const o of maps.island.objs) {
    if (o.t !== 'miner' || !minerOn(o)) continue;
    o.tm = (o.tm == null ? C.every : o.tm) - dt;
    while (o.tm <= 0 && minerOn(o)) {
      o.tm += C.every; o.fuel--; o.store = o.store || {};
      o.store.stone = (o.store.stone || 0) + 1;   // 石は必ず1個
      for (const [id, p] of C.loot) if (chance(p)) o.store[id] = (o.store[id] || 0) + 1;   // 鉱石はそれぞれ独立に抽選
      o.mined = (o.mined || 0) + 1;
    }
    if (o.tm <= 0) o.tm = C.every;
  }
}
function openMiner(o) {
  sfx('ui');
  UI.open({ live: true, onClose: () => saveGame(true), onTick: (dt, L) => { L._mt = (L._mt || 0) + dt; if (L._mt >= 0.25) { L._mt = 0; UI.refresh(L); } },
    render: (el, L) => el.appendChild(windowEl(L, { title: '自動採掘機', sub: statusSub(), cls: 'small miner-win', body: b => renderMiner(b, L, o) })) });
}
function renderMiner(b, L, o) {
  const C = CONFIG.miner, st = minerStored(o), on = minerOn(o), fuel = o.fuel || 0, coal = game.inv.charcoal || 0, ckc = game.inv.coal || 0, cap = C.fuelMax * C.fuelPer, room = fuel + C.fuelPer <= cap, roomC = fuel + C.fuelCoal <= cap;
  const why = on ? '稼働中' : fuel <= 0 ? '停止中（燃料切れ。木炭か石炭を入れよう）' : '停止中（保管がいっぱい。回収しよう）';
  const pr = on ? clamp(1 - (o.tm == null ? C.every : o.tm) / C.every, 0, 1) : 0;   // v8b：次の採掘までの進み具合
  const b0 = b, cols = h('div', { class: 'two-cols' }), cA = h('div', { class: 'col' }), cB = h('div', { class: 'col' }); cols.appendChild(cA); cols.appendChild(cB); b0.appendChild(cols); b = cA;   // v8a：スマホの横画面は「状態」と「保管」を左右に並べる
  b.appendChild(sec('状態',
    h('p', { class: 'note ' + (on ? 'ok' : 'warn'), style: 'font-size:15px' }, why),
    h('div', { class: 'name', style: 'font-size:13px' }, on ? `次の採掘まで あと${Math.ceil(o.tm == null ? C.every : o.tm)}秒（${C.every}秒ごとに1回）` : '次の採掘：止まっています'),
    h('div', { class: 'qbar' + (on ? '' : ' wait') }, h('i', { style: `width:${Math.round(pr * 100)}%` })),
    h('p', { class: 'note' }, `燃料：あと${fuel}回（最大${cap}回）　木炭1個＝${C.fuelPer}回・石炭1個＝${C.fuelCoal}回`),
    h('div', { class: 'miner-fuel' }, h('i', { style: `width:${Math.round(fuel / cap * 100)}%` })),
    h('p', { class: 'note' }, `持っている数：木炭${coal}個・石炭${ckc}個`),
    h('div', { class: 'btns', style: 'display:flex;gap:6px;flex-wrap:wrap' },
      btn('木炭を入れる', () => { minerFuel(o, 1, 'charcoal'); UI.refresh(L); }, { key: 'mf1', cls: 'gold', disabled: !coal || !room, why: !coal ? '木炭を持っていない（炉で木材2個から作れる）' : '燃料は満タンです' }),
      btn('石炭を入れる', () => { minerFuel(o, 1, 'coal'); UI.refresh(L); }, { key: 'mfc', cls: 'gold', disabled: !ckc || !roomC, why: !ckc ? '石炭を持っていない（洞窟の入口の近くの石炭鉱脈で掘れる）' : '燃料は満タンです' }),
      btn('最大まで入れる', () => { minerFuel(o, 99); UI.refresh(L); }, { key: 'mfm', disabled: !(coal && room) && !(ckc && roomC), why: !coal && !ckc ? '木炭も石炭も持っていない' : '燃料は満タンです' }))));
  const ids = Object.keys(o.store || {}).filter(k => o.store[k] > 0);
  b = cB;
  b.appendChild(sec(`保管 ${st}/${C.cap}`,
    ids.length ? h('div', null, ...ids.map(id => h('div', { class: 'row-item' }, icon(id), h('div', { class: 'grow' }, h('div', { class: 'name' }, `${itemName(id)} ×${o.store[id]}`))))) : h('p', { class: 'note' }, 'まだ何も掘っていません。'),
    h('div', { class: 'btns', style: 'margin-top:6px' }, btn('全部回収する', () => { minerCollect(o); UI.refresh(L); }, { key: 'mcol', cls: 'primary', disabled: !st, why: '保管は空です' }))));
  b = cB;   // v8b：説明は右の列に（スマホの横画面で1画面に収める）
  b.appendChild(h('p', { class: 'note' }, `1回の採掘で、石1個に加えて、鉄鉱石${Math.round(C.loot[0][1] * 100)}%・銅鉱石${Math.round(C.loot[1][1] * 100)}%・金鉱石${Math.round(C.loot[2][1] * 100)}%・水晶${Math.round(C.loot[3][1] * 100)}%。保管の空きが${C.stopFree}個未満になるか、燃料が切れると止まります。これまでに${o.mined || 0}回掘りました。`));
  if (!fuel && !st) b.appendChild(h('div', { class: 'btns', style: 'margin-top:8px' }, pickupBtn(o)));
  b = b0;
}
// v8b：燃料は木炭（10回）か石炭（15回）。kind なし＝木炭から先に、入るだけ
function minerFuel(o, n, kind) {
  const C = CONFIG.miner, cap = C.fuelMax * C.fuelPer, per = { charcoal: C.fuelPer, coal: C.fuelCoal }, kinds = kind ? [kind] : ['charcoal', 'coal'], used = { charcoal: 0, coal: 0 };
  let cnt = 0;
  for (const k of kinds) while (cnt < n && has(k) && (o.fuel || 0) + per[k] <= cap) { takeItem(k, 1); o.fuel = (o.fuel || 0) + per[k]; used[k]++; cnt++; }
  if (cnt) { if (o.tm == null || o.tm <= 0) o.tm = C.every; sfx('craft'); toast(`${[used.charcoal ? `木炭${used.charcoal}個` : '', used.coal ? `石炭${used.coal}個` : ''].filter(Boolean).join('と')}を入れた（あと${o.fuel}回掘れる）`, 'good'); }
  else { sfx('error'); toast(kinds.every(k => !has(k)) ? (kind === 'coal' ? '石炭を持っていない' : kind ? '木炭を持っていない（炉で木材2個から作れる）' : '木炭も石炭も持っていない') : '燃料は満タンです', 'bad'); }
}
function minerCollect(o) {
  let total = 0; for (const id of Object.keys(o.store || {})) { const n = o.store[id] || 0; if (n > 0) { addItem(id, n, true); total += n; } }
  o.store = {}; if (total) { sfx('pick'); toast(`採掘機から${total}個を回収した`, 'good'); saveGame(true); }
}
function enqueue(o, st, rec, n) {
  if (rec.out === 'miner' && minerTotal() > 0) { sfx('error'); toast('自動採掘機は1台までです', 'bad'); return; }   // v7b
  if (rec.out === 'miner') n = 1;
  const maxN = Math.min(...Object.keys(rec.in).map(k => Math.floor((game.inv[k] || 0) / rec.in[k])));
  o.q = o.q || []; n = Math.min(n, maxN, CONFIG.queueMax - o.q.length);
  const fu = st === 'furnace';   // v8b：炉は燃料ゲージ1につき1個
  if (fu && (o.fuel || 0) <= 0) { sfx('error'); toast('燃料がありません（燃料投入スロットに木の枝・木炭・石炭を入れよう）', 'bad'); return; }
  if (fu) n = Math.min(n, o.fuel | 0);
  if (n <= 0) { sfx('error'); toast(o.q.length >= CONFIG.queueMax ? '予約がいっぱいです' : '素材が足りません', 'bad'); return; }
  for (const k in rec.in) takeItem(k, rec.in[k] * n);
  if (fu) o.fuel -= n;
  for (let i = 0; i < n; i++) o.q.push(fu ? { id: rec.id, left: procTime(st, rec), f: 1 } : { id: rec.id, left: procTime(st, rec) });
  sfx('craft'); toast(`${ITEMS[rec.out].n}の加工を${n}個開始した`, 'good');   // v6.2：「予約した」→「開始した」
}
function cancelQueue(o, st) {
  if (!o.q) return;
  let fb = 0; for (const job of o.q) { const rec = findProc(st, job.id); for (const k in rec.in) addItem(k, rec.in[k], true); if (job.f) fb++; }
  if (fb) o.fuel = Math.min(CONFIG.furnaceFuel.max, (o.fuel || 0) + fb);   // v8b：炉の燃料も戻す（最大まで）
  o.q = []; toast('加工をキャンセルして素材を戻した');
}
function collectOutput(o) {
  if (!o.out) return; const got = [];
  for (const k of Object.keys(o.out)) { const n = addItem(k, o.out[k]); if (n > 0) { o.out[k] -= n; got.push(`${ITEMS[k].n}×${n}`); } if (o.out[k] <= 0) delete o.out[k]; }
  if (got.length) { sfx('pick'); toast('受け取った：' + got.join('、'), 'good'); }
  if (Object.keys(o.out).length) toast('持ち物がいっぱいで受け取れない分があります', 'bad');
  return got.length;
}

/* ゼニ丸の売買（ショップ）。v8f：浜辺の回収ボックスはなくした */
// v8b：ゼニ丸（ドローン）はプレイヤーについてくる。Rキー（スマホは右下の$ボタン）で、どこでも売買の画面を開ける
const ZENI_TALK = [
  'ゼニ丸ハ、イツデモアナタノ後ロヲ飛ンデイマス。Rキーデ呼ンデクダサイ。ゼニ！',
  '石コロデモ、木ノ枝デモ、ゼニ丸ガ査定シマス。島ノ物ハ、全部オ金ニナリマス。ゼニ！',
  '同ジ物バカリ売ルト、値段ガ下ガリマス。時間ガタツト、元ニ戻リマス。ゼニ！',
  '毎朝、利息ガ増エマス。早メノ返済ガ、オスス メデス……失礼、オススメデス。ゼニ！',
  '道具ハ「投資」デス。良イ道具ホド、早ク稼ゲマス。ゼニ！',
  '夜ハ寒クテ、獣ガ出マス。焚キ火カ、コノ家ノ中ガ安全デス。ゼニ！',
  '炉ノ燃料ハ、木ノ枝・木炭・石炭デス。石炭ガ一番長持チシマス。ゼニ！',
  '自動採掘機ト自動伐採機ハ、アナタガ寝テイル間モ働キマス。働キ者デス。ゼニ丸ト同ジデス。ゼニ！',
  'ゼニ丸ハ、鮫島サマガ作ッタ回収ロボットデス。ボディハ防水デス。自慢デス。ゼニ！',
  '鮫島サマハ、怖イ顔デスガ、締メ日ハ必ズ守ル人デス。ゼニ丸モ守リマス。ゼニ！',
  '鮫島サマノ好物ハ、フカヒレ……デハナク、オ金デス。ゼニ！',
  'ゼニ丸ノ名前ハ「銭」ト「丸儲ケ」カラ来テイマス。縁起ガ良イデス。ゼニ！',
  '洞窟ノ奥ニハ、何カガイマス。準備ハ、念入リニ。ゼニ！',
  '家ノ中デハ、オ腹モ喉モ、減リガ半分デス。休ムナラ、ココガ一番デス。ゼニ！',
];
function callZeni() {
  if (state.scene !== 'play' || !game || UI.isOpen() || Dialog.active || state.fading || state.place) return;
  if (state.boss && game.map === 'cave2') { sfx('error'); toast('ゼニ丸は、戦いがこわくて隠れている……', 'bad'); return; }
  if (state.zeni) state.zeni.hop = 0.35;
  openShop();
}
function zeniTalk() {
  const g = game; g.flags.zeniTalkN = (g.flags.zeniTalkN || 0) + 1;
  let i = Math.floor(Math.random() * ZENI_TALK.length); if (i === g.flags.zeniLast) i = (i + 1) % ZENI_TALK.length; g.flags.zeniLast = i;
  const lines = [['zeni', ZENI_TALK[i]]]; if (g.flags.zeniTalkN === 1) lines.push(['sys', `売買はRキー${Input.mode === 'touch' ? '（スマホは右下の$ボタン）' : ''}で、いつでもどこでもできる。`]);
  queueTalk(lines);
}
// 毎フレーム：プレイヤーの少し後ろ・上をふわふわ飛ぶ
function updateZeni(dt) {
  if (!game) return; const z = state.zeni || (state.zeni = { x: player.x, y: player.y - 10, hop: 0 });
  const [vx, vy] = DIRV[player.dir], tx = player.x - vx * 16 + (vy ? 12 : 0), ty = player.y - vy * 12 - (vx ? 4 : 0);
  if (z.map !== game.map || Math.hypot(tx - z.x, ty - z.y) > 180) { z.x = tx; z.y = ty; z.map = game.map; }
  const k = 1 - Math.exp(-dt * 4); z.x += (tx - z.x) * k; z.y += (ty - z.y) * k; z.hop = Math.max(0, (z.hop || 0) - dt);
}
function drawZeniFollow(time) {
  const z = state.zeni; if (!z) return; const hop = z.hop > 0 ? Math.sin(z.hop / 0.35 * Math.PI) * 6 : 0;
  const bx = Math.round(z.x - 8), by = Math.round(z.y - 26 + Math.sin(time * 2.4) * 2 - hop);
  ctx.fillStyle = 'rgba(0,0,0,0.2)'; ctx.fillRect(Math.round(z.x) - 4, Math.round(z.y) - 1, 8, 2);
  ctx.drawImage(Math.floor(time * 12) % 2 ? SPR.drone1 : SPR.drone0, bx, by);
}
function openShop() {
  UI.open({ tab: 'sell', onClose: () => saveGame(true), render: (el, L) => {
    const ev = game.market.ev;
    const sub = statusSub(ev ? h('span', null, '本日の特需 ', h('b', { class: 'ok' }, ITEMS[ev.up].n + '×1.5'), '　値崩れ ', h('b', { class: 'ng' }, ITEMS[ev.dn].n + '×0.6')) : null);
    el.appendChild(windowEl(L, {
      title: 'ゼニ丸（売買）', sub, tabs: [{ id: 'sell', label: '売る' }, { id: 'repay', label: '返済' }, { id: 'buy', label: '購入' }, { id: 'bet', label: '勝負' }],
      body: b => ({ sell: renderSell, repay: renderRepay, buy: renderBuy, bet: renderZeniBet })[L.tab](b, L),
    }));
  } });
}
// v6b：黒い宝玉を売る時は確認する。v8f：エンディングの条件ではなくなった（売る専用）
function sellCheck(id, n, L) {
  if (id === 'bossGem') { confirmBox('黒い宝玉を売りますか？（宝玉はもう手に入りません）', () => { sellItem(id, n); UI.refresh(L); }, { yes: '売る' }); return; }   // v8f：特別なエンディングはなくなった（売る専用）
  sellItem(id, n); UI.refresh(L);
}
function renderSell(b, L) {
  const ids = sortItems(Object.keys(game.inv).filter(k => game.inv[k] > 0 && ITEMS[k] && !ITEMS[k].key));
  const tls = game.slots.map((x, i) => [x, i]).filter(([x]) => x && isTool(x.id));
  if (!ids.length && !tls.length) { b.appendChild(h('p', { class: 'note' }, '売れる物を持っていません。')); return; }
  if (tls.length) b.appendChild(sec('道具・武器（作った素材の約4割×残りの耐久）', h('div', null, ...tls.map(([x, i]) => { const t = TOOLS[x.id];
    return h('div', { class: 'row-item' }, icon(x.id), h('div', { class: 'grow' }, h('div', { class: 'name' }, t.n + (x.n > 1 ? ` ×${x.n}` : '')), h('div', { class: 'desc' }, t.dur ? `耐久 ${durText(x)}` : '壊れない')),
      h('div', { class: 'btns' }, btn(x.eq ? '装備中' : `売る ${fmt$(toolPrice(x))}`, () => confirmBox(`${t.n}${x.n > 1 ? '×' + x.n : ''}を ${fmt$(toolPrice(x))} で売りますか？`, () => { sellToolSlot(i); UI.refresh(L); }, { yes: '売る' }), { key: 'sellt-' + i, cls: x.eq ? '' : 'gold', disabled: !!x.eq, why: '装備を外すと売れます（持ち物画面）' }))); }))));
  if (!ids.length) return;
  b.appendChild(h('p', { class: 'note', style: 'margin-bottom:8px' }, '同じ物を売り続けると値下がりします（時間で回復）。設置物は値下がりしません。'));
  for (const id of ids) {
    const it = ITEMS[id], n = game.inv[id], m = game.market.m[id] != null ? game.market.m[id] : 1, ev = game.market.ev;
    const tags = [];
    if (ev && ev.up === id) tags.push(h('span', { class: 'tag trend-up' }, '特需'));
    if (ev && ev.dn === id) tags.push(h('span', { class: 'tag trend-dn' }, '値崩れ'));
    if (m < 0.95) tags.push(h('span', { class: 'trend-dn' }, ` ↓${Math.round((1 - m) * 100)}%`));
    b.appendChild(h('div', { class: 'row-item' }, icon(id), h('div', { class: 'grow' }, h('div', { class: 'name' }, `${it.n} ×${n}`, ...tags), h('div', { class: 'desc' }, '1個 ', h('span', { class: 'price' }, fmt$(price(id))), `（基本 ${fmt$(it.p)}）`)),
      h('div', { class: 'btns' }, btn(`1個 ${fmt$(price(id))}`, () => sellCheck(id, 1, L), { key: 'sell1-' + id, silent: true }),
        btn(`全部 ${fmt$(sellEstimate(id, n))}`, () => sellCheck(id, n, L), { key: 'sella-' + id, cls: 'gold', silent: true }))));
  }
}
function renderRepay(b, L) {
  if (game.debt <= 0) { b.appendChild(h('p', { class: 'note ok', style: 'font-size:16px' }, '借金は完済済みです！ いかだを作って島を脱出しよう。')); return; }
  const max = Math.min(game.money, game.debt);
  if (L.amt == null || L.amt > max) L.amt = max;
  const set = v => { L.amt = clamp(v, 0, max); UI.refresh(L); };
  b.appendChild(h('div', { class: 'set-row' }, h('div', { class: 'lbl' }, '返済額', h('small', null, `所持金 ${fmt$(game.money)}／借金 ${fmt$(game.debt)}`)), h('div', { class: 'val price', style: 'font-size:22px' }, fmt$(L.amt))));
  b.appendChild(h('div', { style: 'display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin-bottom:10px' },
    btn('-1000', () => set(L.amt - 1000), { key: 'm1000' }), btn('-100', () => set(L.amt - 100), { key: 'm100' }),
    btn('+100', () => set(L.amt + 100), { key: 'p100' }), btn('+1000', () => set(L.amt + 1000), { key: 'p1000' }), btn('最大', () => set(max), { key: 'pmax', cls: 'gold' })));
  b.appendChild(h('p', { class: 'note', style: 'text-align:center;margin-bottom:10px' }, `返済後の借金：${fmt$(game.debt - L.amt)}　／　明朝の利息（見込み）：${fmt$(Math.ceil((game.debt - L.amt) * game.contract.rate / 100))}`));
  b.appendChild(h('div', { style: 'display:flex;justify-content:center' }, btn('返済する', () => { repay(L.amt); L.amt = null; UI.refresh(L); }, { key: 'dorepay', cls: 'primary', disabled: L.amt <= 0, why: '返済額を選んでください', silent: true })));
  const r = repaidRatio();
  b.appendChild(h('p', { class: 'note', style: 'margin-top:12px' }, `返済率 ${Math.floor(r * 100)}%`));   // v7a：設計図は最初から買える（返済率での解禁を廃止）
}
function renderBuy(b, L) {
  const r = repaidRatio();
  for (const s of SHOP) {
    const locked = r < s.req, owned = s.bp && game.bp[s.bp], can = !locked && !owned && game.money >= s.p;
    const label = owned ? '購入済み' : locked ? `返済${Math.round(s.req * 100)}%で解禁` : `${fmt$(s.p)}`;
    b.appendChild(h('div', { class: 'row-item' + (locked ? ' locked' : '') }, icon(s.item || 'bp'), h('div', { class: 'grow' }, h('div', { class: 'name' }, s.n), h('div', { class: 'desc' }, s.d)),
      h('div', { class: 'btns' }, btn(label, () => { buy(s); UI.refresh(L); }, { key: 'buy-' + s.id, cls: can ? 'gold' : '', disabled: !can, why: owned ? 'すでに持っています' : locked ? 'まだ解禁されていません' : 'お金が足りません', silent: true }))));
  }
}

/* いかだ */
const voyageFood = () => VOYAGE_FOOD.reduce((s, k) => s + (game.inv[k] || 0), 0);
function openRaft() {
  if (!game.bp.raft) { queueTalk(TALK.raftNoBp.concat(game.flags.diary1 ? [] : TALK.paidHint)); return; }
  UI.open({ render: (el, L) => el.appendChild(windowEl(L, { title: 'いかだ置き場', cls: 'small', body: b => {
    if (!game.raftBuilt) {
      b.appendChild(h('p', { class: 'note', style: 'color:var(--text);margin-bottom:8px' }, 'ゲンの設計図どおりに、いかだを組み立てよう。'));
      b.appendChild(h('div', { class: 'row-item' }, icon('raft'), h('div', { class: 'grow' }, h('div', { class: 'name' }, 'いかだ'), costEls(RAFT_COST)),
        h('div', { class: 'btns' }, btn('組み立てる', () => { buildRaft(); UI.close(L); }, { key: 'build', cls: hasAll(RAFT_COST) ? 'primary' : '', disabled: !hasAll(RAFT_COST), why: '素材が足りません' }))));
    } else {
      const f = voyageFood();
      b.appendChild(h('p', { class: 'note', style: 'color:var(--text)' }, '出航の準備'));
      b.appendChild(h('p', { class: game.debt > 0 ? 'note ng' : 'note ok' }, game.debt > 0 ? `借金が ${fmt$(game.debt)} 残っている` : '借金は完済済み'));
      b.appendChild(h('p', { class: f >= 3 ? 'note ok' : 'note ng' }, `航海用の食料（ココナッツ・焼き魚・焼き肉・焼きガニ・缶詰）${f}/3`));
      b.appendChild(h('p', { class: game.weather === 'storm' ? 'note ng' : 'note' }, game.weather === 'storm' ? '今は大嵐。嵐がおさまるまで出航できません' : `今日の天気：${WEATHER[game.weather].n}`));
      b.appendChild(h('div', { style: 'display:flex;justify-content:center;margin-top:10px' }, btn('出航する', () => depart(), { key: 'depart', cls: f >= 3 ? 'primary' : '', disabled: f < 3, why: '食料が3個必要です' })));
    }
  } })) });
}

/* タイトル・はじめから・プロローグ・エンディング */
let titleMap = null;
function showTitle() {
  state.scene = 'title'; UI.closeAll(); Dialog.active = false; $('dialog').classList.add('hidden');
  $('hud').classList.add('hidden'); $('hint').classList.add('hidden'); updateTouchVisibility();
  if (!titleMap) { const s0 = MAP_SEED; MAP_SEED = CONFIG.islandSeed; const d = genIsland(2); MAP_SEED = s0; titleMap = buildMap('island', d, d.objs.filter(o => o.t !== 'box')); }   // v8f：回収ボックスはなし   // v8a：タイトルの背景はいつもの島
  UI.open({ cls: 'screen', onBack: () => {}, render: el => {
    const can = hasSave(), nEnd = settings.endings.length;
    el.appendChild(h('div', { class: 'title-wrap' },
      h('div', { class: 'logo' }, h('small', null, 'SURVIVAL × DEBT'), '売倍アイランド'),
      h('div', { class: 'title-sub' }, '島の物はすべて換金できる。売るか、投資するか。'),
      h('div', { class: 'title-menu' },
        btn('はじめから', () => openSlots('new'), { key: 'new', cls: can ? '' : 'primary' }),
        btn('つづきから', () => openSlots('load'), { key: 'cont', cls: can ? 'primary' : '', disabled: !can, why: 'セーブデータがありません' }),
        btn('マルチプレイ', () => {}, { key: 'multi', disabled: true, why: 'Coming Soon...' }),   // v8b：準備中（押すと「Coming Soon...」）
        btn('デモプレイ', () => confirmBox('デモプレイを開始しますか？', () => startDemo(), { title: 'デモプレイ', yes: '開始', no: '戻る', note: 'デモプレイでは、借金$1,000のみで期限・利息はなし。但し、セーブは不可能。' }), { key: 'demo', cls: 'gold' }),   // v8d：開始する前に確認する
        btn(`エンディング（${nEnd}/${ENDING_ORDER.length}）`, () => openEndings(), { key: 'end', disabled: !nEnd, why: 'まだエンディングを見ていません' }),
        btn('設定', () => openSettingsLayer(), { key: 'set' })),
      h('div', { class: 'title-foot' }, 'Ver 8.2')));   // v8d：デモプレイの説明は、押した時の確認に移した。v8.1：Ver 8.1
  } });
}
function fmtDate(t) { if (!t) return ''; const d = new Date(t), p = n => String(n).padStart(2, '0'); return `${d.getMonth() + 1}/${d.getDate()} ${p(d.getHours())}:${p(d.getMinutes())}`; }
// セーブスロット（kind: load=つづきから / new=はじめから）
function openSlots(kind) {
  UI.open({ onClose: () => { const t = UI.top(); if (t && state.scene === 'title') UI.refresh(t); }, render: (el, L) => el.appendChild(windowEl(L, {
    title: kind === 'load' ? 'つづきから' : 'はじめから：スロットを選ぶ', cls: 'small',
    body: b => {
      for (let n = 1; n <= CONFIG.slots; n++) {
        const inf = slotInfo(n);
        const info = inf
          ? h('div', { class: 'grow' }, h('div', { class: 'name' }, `${inf.name}　${inf.day}日目`),
            h('div', { class: 'desc' }, `${inf.mode === 'hard' ? 'ハード' : 'ノーマル'}／借金 ${fmt$(inf.debt)}${inf.debt <= 0 ? '（完済）' : ''}`), inf.savedAt ? h('div', { class: 'desc' }, '保存 ' + fmtDate(inf.savedAt)) : null)
          : h('div', { class: 'grow' }, h('div', { class: 'name', style: 'color:var(--muted)' }, 'データなし'));
        const act = kind === 'load'
          ? btn('ロード', () => continueGame(n), { key: 'sl' + n, cls: inf ? 'primary' : '', disabled: !inf, why: 'このスロットにはデータがありません' })
          : btn(inf ? '上書き' : 'ここで始める', () => { if (inf) confirmBox(`スロット${n}のデータは消えて、新しいゲームになります。\nよろしいですか？`, () => openNewGame(n), { yes: '上書きする', danger: true }); else openNewGame(n); }, { key: 'sl' + n, cls: inf ? 'danger' : 'primary' });
        const del = inf && kind === 'load' ? btn('削除', () => confirmBox(`スロット${n}のデータを削除します。\n元に戻せません。よろしいですか？`, () => { deleteSave(n); toast(`スロット${n}を削除しました`); UI.refresh(L); }, { yes: '削除する', danger: true }), { key: 'del' + n, cls: 'small danger' }) : null;
        b.appendChild(h('div', { class: 'row-item slot-row' }, h('div', { class: 'slot-no' }, String(n)), info, h('div', { class: 'btns' }, act, del)));
      }
    },
    foot: [btn('もどる', () => UI.close(L), { key: 'back' })],
  })) });
}
// 見たエンディングを読み返す
function openEndings() {
  UI.open({ render: (el, L) => el.appendChild(windowEl(L, {
    title: `エンディング ${settings.endings.length}/${ENDING_ORDER.length}`, cls: 'small',
    body: b => {
      for (const k of ENDING_ORDER) {
        const seen = settings.endings.includes(k), E = ENDINGS[k];
        b.appendChild(h('div', { class: 'row-item' + (seen ? '' : ' locked') }, h('div', { class: 'grow' }, h('div', { class: 'desc' }, `${k}　` + (seen ? E.type : '？？？')), h('div', { class: 'name' }, seen ? E.title : '？？？？')),
          h('div', { class: 'btns' }, btn('見る', () => replayEnding(k), { key: 'e' + k, cls: seen ? 'primary' : '', disabled: !seen, why: 'まだ見ていないエンディングです' }))));
      }
    },
    foot: [btn('もどる', () => UI.close(L), { key: 'back' })],
  })) });
}
// v8f：タイトルの「エンディング」から見る時も、ゲームの時と同じムービー（場面と字幕）で流す。最後は「もう一度ながめる」「もどる」
// （v8eまでは文だけの画面だった。文だけの画面 showEndingText も残してある）
function replayEnding(k) {
  const E = ENDINGS[k]; if (!E) return;
  const lines = E.lines.map(t => t.replace(/\{days1\}日目の朝/g, '返済期限の翌朝').replace(/\{name\}/g, 'あなた')), phases = (END_SCENES[k] || ['sail']).slice();
  while (phases.length < lines.length) phases.push(phases[phases.length - 1]);
  const ED = 3.4, total = lines.length * ED;
  let t0 = performance.now(), cur = -1, done = false, skip = null;
  const L = UI.open({ cls: 'dark end-movie', endReplay: true, onBack: () => { if (done) { if (state.endSkip === skip) state.endSkip = null; UI.close(L); } else if (skip) skip(); }, render: el => {
    const cv = h('canvas', { class: 'end-cv' }), sub = h('div', { class: 'end-sub' }), sk = h('button', { class: 'cine-skip', type: 'button', tabindex: '-1' }, 'スキップ ▶▶');
    const res = h('div', { class: 'end-result' },
      h('div', { class: 'end-res-l' }, h('div', { class: 'etype' }, E.type), h('div', { class: 'etitle' }, E.title)),
      h('div', { class: 'end-res-r' }, h('div', null, btn('もう一度ながめる', () => { t0 = performance.now(); cur = -1; done = false; res.classList.remove('on'); cv.classList.remove('dim'); sub.classList.remove('out'); el.appendChild(sk); state.endSkip = skip; }, { key: 'replay' }),
        btn('もどる', () => { state.endSkip = null; UI.close(L); }, { key: 'back', cls: 'primary' }))));
    el.appendChild(cv); el.appendChild(sub); el.appendChild(res); el.appendChild(sk);
    const g2 = cv.getContext('2d');
    skip = () => { t0 = performance.now() - total * 1000; };
    state.endSkip = skip;
    sk.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); skip(); });
    const loop = now => {
      if (!cv.isConnected) { if (state.endSkip === skip) state.endSkip = null; return; }
      const t = (now - t0) / 1000, li = clamp(Math.floor(t / ED), 0, lines.length - 1);
      try { CV.fit(cv); g2.imageSmoothingEnabled = false; drawEndPhase(g2, CV.W, CV.H, phases[li], t, t - li * ED); } catch (er) { console.error(er); }
      if (t < total && li !== cur) { cur = li; sub.innerHTML = ''; sub.appendChild(h('p', null, lines[li])); }
      if (t >= total && !done) { done = true; sub.classList.add('out'); cv.classList.add('dim'); res.classList.add('on'); sk.remove(); if (state.endSkip === skip) state.endSkip = null; L.focusKey = 'back'; UI.applyFocus(L); }
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  } });
}
function showEndingText(k) {
  const E = ENDINGS[k];
  UI.open({ cls: 'dark', render: (el, L) => {
    const e = h('div', { class: 'ending' }); let dl = 0;
    for (const t of E.lines) { e.appendChild(h('p', { style: `animation-delay:${dl}s` }, fmtText(t.replace(/\{days1\}日目の朝/g, '返済期限の翌朝')))); dl += 0.6; }
    e.appendChild(h('div', { style: `opacity:0;animation:fadeIn .8s ease-out ${dl}s forwards` }, h('div', { class: 'etype' }, E.type), h('div', { class: 'etitle' }, E.title),
      btn('もどる', () => UI.close(L), { key: 'back', cls: 'primary' })));
    el.appendChild(e);
  } });
}
function openNewGame(slot) {
  const o = { name: 'カイ', preset: 'normal', debt: 5000, days: 10, rate: 2, mode: 'normal', map: 'random', seed: Math.floor(Math.random() * 10000), seedNote: '' };   // v8d：マップ（旧マップ／ランダム生成）と種。v8f：シード値は4桁（0000〜9999。どの番号でも遊べる）
  const custom = settings.endings.length > 0;
  UI.open({ render: (el, L) => {
    // v8e：はじめからの画面を刷新。左列＝名前・難易度・モード、右列＝マップ・借金の契約。スマホの横画面でも1画面に全部収まる
    el.appendChild(windowEl(L, { title: 'はじめから', cls: 'ng-win', body: b => {
      const ngSec = (title, ...kids) => h('div', { class: 'ng-sec' }, h('div', { class: 'ng-h' }, title), ...kids);
      const ngFix = (label, value) => h('div', { class: 'ng-cell' }, h('div', { class: 'ng-lbl' }, label), h('div', { class: 'ng-val' }, value));
      const ngStep = (key, label, value, onDn, onUp) => {
        const wrap = h('div', { class: 'stepper f', 'data-k': key, 'data-stepper': '1' }, btn('◀', onDn, { key: key + '-dn', cls: 'small st-dn' }), h('span', { class: 'val' }, value), btn('▶', onUp, { key: key + '-up', cls: 'small st-up' }));
        wrap.querySelectorAll('.btn').forEach(x => x.classList.remove('f'));
        return h('div', { class: 'ng-cell' }, h('div', { class: 'ng-lbl' }, label), wrap);
      };
      // 名前
      const inp = h('input', { class: 'name-input', type: 'text', maxlength: '8', value: o.name, autocomplete: 'off', spellcheck: 'false' });
      inp.addEventListener('input', () => { o.name = inp.value; });
      const nameWrap = h('div', { class: 'f', 'data-k': 'name' }, inp);
      nameWrap.addEventListener('click', () => inp.focus());
      // v8d：マップ。ランダム生成は種（シード値）で決まる。同じ番号なら同じ島。v8f：シード値は4桁、洞窟もランダム
      const seedIn = h('input', { class: 'name-input seed-input', type: 'text', inputmode: 'numeric', maxlength: '4', value: seedText(o.seed), autocomplete: 'off', spellcheck: 'false' });
      const seedNoteEl = h('p', { class: 'note warn', style: o.seedNote ? '' : 'display:none' }, o.seedNote);
      const seedShow = t => { o.seedNote = t; seedNoteEl.textContent = t; seedNoteEl.style.display = t ? '' : 'none'; };
      // 入力しなおしても画面は作りなおさない（スタートを押す前に画面が入れ替わって押せなくなるのを防ぐ）
      const seedApply = () => {
        const v = seedIn.value.replace(/[^0-9]/g, '');
        if (!/^[0-9]{1,4}$/.test(v)) { seedShow('4桁までの数字（0000〜9999）を入れてください。'); seedIn.value = seedText(o.seed); return; }   // v8f：4桁
        o.seed = parseInt(v, 10); seedIn.value = seedText(o.seed); seedShow('');   // v8f：どの番号でも島と洞窟が作れる
      };
      seedIn.addEventListener('change', seedApply);
      seedIn.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); seedApply(); } });
      seedIn.addEventListener('keyup', e => { if (e.key === 'Enter') e.stopPropagation(); });
      const seedWrap = h('div', { class: 'f', 'data-k': 'seed' }, seedIn);
      seedWrap.addEventListener('click', () => seedIn.focus());
      // 借金の契約
      const adj = (k, d) => { const [lo, hi, s] = LIMITS[k]; o[k] = Math.round(clamp(o[k] + d * s, lo, hi) * 10) / 10; o.preset = 'custom'; UI.refresh(L); };
      const contract = custom
        ? h('div', { class: 'ng-contract' }, ngStep('debt', '借金額', fmt$(o.debt), () => adj('debt', -1), () => adj('debt', 1)), ngStep('days', '返済期限', `${o.days}日`, () => adj('days', -1), () => adj('days', 1)), ngStep('rate', '利息/日', `${o.rate}%`, () => adj('rate', -1), () => adj('rate', 1)))
        : h('div', { class: 'ng-contract' }, ngFix('借金額', fmt$(o.debt)), ngFix('返済期限', `${o.days}日`), ngFix('利息/日', `${o.rate}%`));
      const colL = h('div', { class: 'ng-col' },
        ngSec('主人公の名前', h('div', { class: 'ng-name' }, nameWrap, h('small', null, '8文字まで'))),
        ngSec('難易度', h('div', { class: 'preset-row' }, ...PRESETS.map(p => btn(p.label, () => { Object.assign(o, { preset: p.id, debt: p.debt, days: p.days, rate: p.rate }); UI.refresh(L); }, { key: 'pre-' + p.id, cls: o.preset === p.id ? 'on' : '' }))), h('p', { class: 'note' }, 'はじめての人は「ふつう」がおすすめです。')),
        ngSec('モード', h('div', { class: 'preset-row' },
          btn('ノーマル', () => { o.mode = 'normal'; UI.refresh(L); }, { key: 'mode-n', cls: o.mode === 'normal' ? 'on' : '' }),
          btn('ハード', () => { o.mode = 'hard'; UI.refresh(L); }, { key: 'mode-h', cls: o.mode === 'hard' ? 'on' : '' })),
          h('p', { class: 'note' + (o.mode === 'hard' ? ' warn' : '') }, o.mode === 'hard' ? 'ハード：体力が0になるとゲームオーバー。最後にセーブしたところからやり直せます。' : 'ノーマル：倒れても翌朝に浜辺で目覚めます。持ち物は倒れた場所に落とし、所持金を少し失います。')));
      const colR = h('div', { class: 'ng-col' },
        ngSec('マップ', h('div', { class: 'preset-row' },
          btn('旧マップ', () => { o.map = 'old'; UI.refresh(L); }, { key: 'map-old', cls: o.map === 'old' ? 'on' : '' }),
          btn('ランダム生成', () => { o.map = 'random'; UI.refresh(L); }, { key: 'map-rnd', cls: o.map === 'random' ? 'on' : '' })),
          o.map === 'random' ? h('div', { class: 'ng-seed' }, h('span', { class: 'ng-lbl' }, 'シード値'), seedWrap, btn('ふりなおす', () => { o.seed = Math.floor(Math.random() * 10000); o.seedNote = ''; UI.refresh(L); }, { key: 'seed-re', cls: 'small' })) : null,
          h('p', { class: 'note' }, o.map === 'old' ? '旧マップ：v7までと同じ島と洞窟で始まります。' : '同じシード値なら、いつでも同じ島と洞窟になります。'),
          o.map === 'random' ? seedNoteEl : null),
        ngSec(custom ? '借金の契約（自由に変更できます）' : '借金の契約', contract,
          h('p', { class: 'note' }, `想定プレイ時間：約${Math.round(o.days * CONFIG.dayLength / 60)}分（1日＝${fmtDur(CONFIG.dayLength)}）`),
          custom ? null : h('p', { class: 'note warn' }, 'どれかのエンディングを1回見ると、契約を自由に変更できるようになります。')));
      b.appendChild(h('div', { class: 'ng-grid' }, colL, colR));
    }, foot: [btn('もどる', () => UI.close(L), { key: 'back' }), btn('スタート', () => {
      let nm = (o.name || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 8); if (!nm) nm = 'カイ';
      game = newGameData({ name: nm, debt: o.debt, days: o.days, rate: o.rate, mode: o.mode, map: o.map, seed: o.seed }); curSlot = slot || 1; ensureSlots(); syncInv();
      game.tut = settings.tutorial ? -2 : -1;   // v8a：-2＝会話と時計の説明のあとに「開始しますか？」を出す
      setupMaps(); player.x = game.px; player.y = game.py; player.dir = 0;
      respawn(maps.island, true); rollMarketEvent();
      UI.closeAll(); playPrologue();
    }, { key: 'start', cls: 'primary' })] }));
  } });
}
/* デモプレイ（展示会向け）：借金$1,000・期限と利息なし（DEMOで変更）・ノーマル・名前カイ。すぐ物語から始まり、セーブはしない */
function startDemo() {
  game = newGameData({ name: 'カイ', debt: DEMO.debt, days: DEMO.days, rate: DEMO.rate, free: DEMO.free, mode: 'normal' });
  game.demo = true; game.tut = 0; curSlot = 0; ensureSlots(); syncInv();
  setupMaps(); player.x = game.px; player.y = game.py; player.dir = 0;
  respawn(maps.island, true); rollMarketEvent();
  UI.closeAll(); playPrologue();
}
/* チュートリアル：やることを順番に表示し、できたら次へ（できている手順は飛ばす） */
const TUT = [
  { t: '歩いてみよう', d: m => m === 'touch' ? '左下のスティックで歩けます。Bを押したまま歩くとダッシュ。' : m === 'pad' ? '左スティックで歩けます。Bを押したまま歩くとダッシュ。' : 'WASDキーか矢印キーで歩けます。Shiftを押したままでダッシュ。', done: () => state.tutMoved > 60 },
  { t: '拾ってみよう', d: () => `浜辺の小石や枝に近づいて、${keyLabel('A')} を押すと拾えます。まずは小石と枝を1つずつ拾ってみよう。`, done: g => !!(g.flags.tPeb && g.flags.tTwig) },   // v8a：すぐあとの石斧のため、小石と枝を1つずつ
  { t: 'アイテムバー', d: m => m === 'touch' ? '拾った物は画面下のアイテムバーに入ります。タップで持ち替え、もう一度タップで使えます。' : m === 'pad' ? '拾った物は画面下のアイテムバーに入ります。LB/RBで持ち替えます。' : '拾った物は画面下のアイテムバーに入ります。1〜8キーかマウスホイールで持ち替えます。', done: () => state.tutT > 7 },
  { t: '木材を集めよう', d: () => `木の前で ${keyLabel('A')} を押したままにすると、木を切って木材が取れます。`, done: g => (g.inv.wood || 0) >= 2 || g.tools.stoneAxe != null || g.tools.ironAxe != null },
  { t: '石斧を作ろう', d: m => `${m === 'key' ? 'Cキー' : m === 'pad' ? keyLabel('X') + 'ボタン（持ち物）→ RB' : 'アイテムバーの右のハンマー'}で「石斧」（石2・木材2）を作ろう。アイテムバーに入れておくと、木を切る時に自動で持ち替えます。`, done: g => g.tools.stoneAxe != null || g.tools.ironAxe != null },
  { t: '素材を売ろう', d: m => `後ろについてくるゼニ丸を${m === 'touch' ? '右下の$ボタン' : m === 'pad' ? '−ボタン（セレクト）' : 'Rキー'}で呼んで、集めた素材を売ってお金にしよう。どこにいても売れます。`, done: g => g.stats.sold >= 1 },   // v8b：ゼニ丸はついてくる。v8f：回収ボックスはなくした
  { t: '借金を返そう', d: () => game && game.contract.free ? 'ゼニ丸の「返済」でお金を返そう。全部返せば、いかだで島を脱出できます。' : 'ゼニ丸の「返済」でお金を返そう。左上の「締め日」までに、決まった額を返すのが目標です。', done: g => g.repaid > 0 },
  { t: '作業台を置こう', d: m => `クラフトで「作業台」（木材4・石2）を作り、アイテムバーで持って${m === 'key' ? '右クリック' : keyLabel('Y') + 'ボタン'}で置こう。作業台の近くでは、高度なクラフトと加工ができます。`, done: () => ['island', 'house'].some(k => maps[k] && maps[k].objs.some(o => o.t === 'workbench')) },   // v8a
  { t: '器を作ろう', d: () => '作業台の近くでクラフトを開き、「木の器」（木材1）を作ろう。泉で水を汲むのに使います。', done: g => (g.inv.bowl || 0) > 0 || (g.inv.rawwater || 0) > 0 || (g.inv.cleanwater || 0) > 0 || !!g.flags.water1 },   // v8a
  { t: '泉で水を汲もう', d: () => '作った木の器を持って、島の中ほどにある泉で水を汲もう。', done: g => !!g.flags.water1 },
  { t: '焚き火を置こう', d: m => `クラフトで「焚き火」を作り、アイテムバーで持って${m === 'key' ? '右クリック' : keyLabel('Y') + 'ボタン'}で置こう。`, done: () => maps.island.objs.some(o => o.t === 'campfire') },
  { t: '水をろ過しよう', d: () => '焚き火の「加工」で泉の水をろ過すると、安全な「きれいな水」になります。', done: g => (g.inv.cleanwater || 0) > 0 || !!g.flags.drankClean },
  { t: '食べて飲もう', d: m => `飲食物をアイテムバーで持って、${m === 'key' ? '右クリック' : keyLabel('Y') + 'ボタン'}で食べたり飲んだりできます${m === 'touch' ? '（画面の何もない所を1秒長押しでもOK）' : ''}。右上の空腹と渇きに気をつけよう。`, done: g => !!g.flags.ate },
  { t: '夜に気をつけよう', d: m => `夜は冷えて、野犬などの獣が出ます。焚き火や小屋のそばは安全。${m === 'key' ? '生き物の方へ左クリックで攻撃できます。' : '生き物の方を向いて調べるボタンで攻撃できます。'}`, done: () => state.tutT > 10 },
  { t: 'これで基本はおしまい！', d: m => `借金を返して、いかだで島を脱出しよう。困ったら ${m === 'touch' ? '右上の≡' : m === 'pad' ? 'START' : 'Esc'} →「操作説明・遊び方」を見てね。`, done: () => state.tutT > 9 },
];
// v6.1e：項目をクリアした時の演出（パネルが光って「クリア！」のハンコ。メニューを開いている間は止めて、閉じたら見られる）
function showTutOk(el, title, fin) {
  const g = game; el._k = 'ok'; el.innerHTML = '';
  const done = fin ? TUT.length : g.tut;
  el.appendChild(h('div', { class: 'tut-hd' }, h('span', null, fin ? 'チュートリアル' : `チュートリアル ${done}/${TUT.length}`)));
  el.appendChild(h('div', { class: 'tut-bar' }, h('i', { style: `width:${Math.round(done / TUT.length * 100)}%` })));
  el.appendChild(h('div', { class: 'tut-t done' }, title || ''));
  el.appendChild(h('div', { class: 'tut-d' }, fin ? 'あとは脱出を目指そう！' : 'つぎの目標を準備中……'));
  el.appendChild(h('div', { class: 'tut-stamp' + (fin ? ' fin' : '') }, fin ? 'ぜんぶクリア！' : 'クリア！'));
  el.classList.remove('hidden', 'pop', 'cleared'); void el.offsetWidth; el.classList.add('cleared'); layoutTut();
  sfx(fin ? 'unlock' : 'tut'); burst(player.x, player.y - 14, '#ffe066', fin ? 18 : 10); floatText(player.x, player.y - 28, fin ? 'ぜんぶクリア！' : 'クリア！', '#ffe066');
  if (state.tutGlowOn) applyTutGlow([]); state.tutGoalPos = null;
  state.tutOk = { t: fin ? 2.2 : 1.2, fin };
}
function updateTut(dt) {
  const el = $('tut'), g = game; if (!el) return;
  // v6.1e：クリアの演出中（終わったら、つぎの項目を表示）
  if (state.tutOk) {
    if (!g || state.scene !== 'play') { state.tutOk = null; }
    else {
      if (!Dialog.active && !UI.isOpen()) state.tutOk.t -= dt;
      if (state.tutOk.t > 0) return;
      const fin = state.tutOk.fin; state.tutOk = null; el._k = null; el.classList.remove('cleared');
      if (fin) { el.classList.add('hidden'); toast('チュートリアル完了！', 'good'); return; }
    }
  }
  if (!g || state.scene !== 'play' || !(g.tut >= 0)) { if (!el.classList.contains('hidden')) el.classList.add('hidden'); if (state.tutGlowOn) applyTutGlow([]); state.tutGoalPos = null; return; }
  if (state.tutPX != null) state.tutMoved = (state.tutMoved || 0) + Math.hypot(player.x - state.tutPX, player.y - state.tutPY);
  state.tutPX = player.x; state.tutPY = player.y;
  if (!Dialog.active && !UI.isOpen()) state.tutT = (state.tutT || 0) + dt;
  let moved = false, lastT = null;
  while (g.tut < TUT.length && TUT[g.tut].done(g)) { lastT = TUT[g.tut].t; g.tut++; state.tutT = 0; moved = true; }
  if (moved) { const fin = g.tut >= TUT.length; if (fin) g.tut = -1; showTutOk(el, lastT, fin); return; }   // v6.1e：クリアの演出
  state.tutGT = (state.tutGT || 0) - dt;
  if (state.tutGT <= 0 || moved) { state.tutGT = 0.25; const gl = tutGoal(); state.tutGoalPos = tutGoalPos(gl); applyTutGlow(tutUiEls(gl)); }
  const st = TUT[g.tut], key = g.tut + '|' + Input.mode;
  if (!st) { g.tut = -1; el.classList.add('hidden'); return; }   // v8e：壊れたデータなどで番号が範囲外の時は、チュートリアルを終わりにする
  if (el._k !== key) {
    el._k = key; el.innerHTML = '';
    el.appendChild(h('div', { class: 'tut-hd' }, h('span', null, `チュートリアル ${g.tut + 1}/${TUT.length}`), h('button', { class: 'tut-skip', type: 'button', tabindex: '-1', onclick: e => { e.preventDefault(); e.stopPropagation(); g.tut = -1; el.classList.add('hidden'); toast('チュートリアルを終了しました（設定からまた見られます）'); } }, 'とじる')));
    el.appendChild(h('div', { class: 'tut-bar' }, h('i', { style: `width:${Math.round(g.tut / TUT.length * 100)}%` })));   // v6.1e：進み具合
    el.appendChild(h('div', { class: 'tut-t' }, st.t)); el.appendChild(h('div', { class: 'tut-d' }, st.d(Input.mode)));
    el._pg = h('div', { class: 'tut-pg' }); el.appendChild(el._pg); layoutTut();   // v7a：進み具合
    el.classList.remove('hidden'); el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop');
  }
  if (el._pg) { const p = tutProgText(g); if (el._pg.textContent !== p) el._pg.textContent = p; el._pg.style.display = p ? '' : 'none'; }   // v7a
}
// v7a：チュートリアルの進み具合（何をいくつやればクリアか）。時間で進む項目は出さない
function tutProgText(g) {
  const n = (a, b) => Math.min(b, Math.floor(a || 0)), inv = g.inv;
  const st = TUT[g.tut]; if (!st) return '';
  switch (st.t) {   // v8a：番号ではなく項目の名前で決める。歩いた距離・焚き火は出さない
    case '拾ってみよう': return `集めた数　小石 ${g.flags.tPeb ? 1 : 0}/1　枝 ${g.flags.tTwig ? 1 : 0}/1`;
    case '木材を集めよう': return `木材 ${n(inv.wood, 2)}/2`;
    case '石斧を作ろう': return `石 ${n(inv.stone, 2)}/2・木材 ${n(inv.wood, 2)}/2`;
    case '作業台を置こう': return `木材 ${n(inv.wood, 4)}/4・石 ${n(inv.stone, 2)}/2`;
    case '器を作ろう': return `木の器 ${n(inv.bowl, 1)}/1`;
    case '水をろ過しよう': return `きれいな水 ${n(inv.cleanwater, 1)}/1`;
    case '素材を売ろう': case '借金を返そう': case '泉で水を汲もう': case '食べて飲もう': return '0/1';
    default: return '';
  }
}
// v5：チュートリアルの案内（行き先は点線の矢印、押すボタンは光らせる）
function tutGoal() {
  const g = game; if (!g || !(g.tut >= 0) || g.tut >= TUT.length || state.scene !== 'play') return null;
  const n = id => g.inv[id] || 0, hb = f => g.slots.findIndex((s, k) => k < CONFIG.hotSize && s && f(s));
  switch (TUT[g.tut].t) {
    case '拾ってみよう': return { world: !g.flags.tPeb && !g.flags.tTwig ? ['pebble', 'twig'] : !g.flags.tPeb ? ['pebble'] : ['twig'] };   // v8a
    case '木材を集めよう': return { world: ['tree'] };
    case '石斧を作ろう': return n('stone') < 2 ? { world: ['pebble', 'boulder'] } : n('wood') < 2 ? { world: ['tree', 'driftwood'] } : { craft: 'stoneAxe' };
    case '素材を売ろう': return { zeni: true, box: 'sell' };   // v8b：Rキー・$ボタンでゼニ丸を呼ぶ。v8f：コントローラーも−ボタンで（回収ボックスはなくした）
    case '借金を返そう': return { zeni: true, box: g.money > 0 ? 'repay' : 'sell' };
    case '作業台を置こう': { const i = g.slots.findIndex(s => s && s.id === 'workbench'); return i >= 0 && i < CONFIG.hotSize ? { slot: i, use: true } : i >= 0 ? null : n('wood') < 4 ? { world: ['tree', 'driftwood'] } : n('stone') < 2 ? { world: ['pebble', 'boulder'] } : { craft: 'workbench' }; }   // v8a
    case '器を作ろう': return n('wood') < 1 ? { world: ['tree', 'driftwood'] } : !nearStation('bench') ? { world: ['workbench'] } : { craft: 'bowl' };   // v8a
    case '泉で水を汲もう': return n('bowl') > 0 ? { spring: true } : n('wood') < 1 ? { world: ['tree', 'driftwood'] } : !nearStation('bench') ? { world: ['workbench'] } : { craft: 'bowl' };
    case '焚き火を置こう': { const i = g.slots.findIndex(s => s && s.id === 'campfire'); return i >= 0 && i < CONFIG.hotSize ? { slot: i, use: true } : i >= 0 ? null : { craft: 'campfire' }; }
    case '水をろ過しよう': return { world: ['campfire'] };
    case '食べて飲もう': { const i = hb(s => ITEMS[s.id] && ITEMS[s.id].food); return i >= 0 ? { slot: i, use: true } : null; }
  }
  return null;
}
function tutGoalPos(goal) {
  if (!goal || game.map !== 'island') return null;
  const m = maps.island, px = player.x, py = player.y - 6; let best = null, bd = 1e9;
  if (goal.spring) {
    if (!m._spring) { m._spring = []; for (let i = 0; i < m.tiles.length; i++) if (m.tiles[i] === T.SPRING) m._spring.push({ x: (i % m.W) * 16 + 8, y: Math.floor(i / m.W) * 16 + 8 }); }
    for (const s of m._spring) { const d = Math.hypot(s.x - px, s.y - py); if (d < bd) { bd = d; best = s; } }
    return best;
  }
  if (!goal.world) return null;
  const PL = m.plat, onPlat = !!(PL && PL[Math.floor((player.y - 4) / 16) * m.W + Math.floor(player.x / 16)]);   // v8a：崖の上（台地）の物は、台地にいない時は案内しない
  for (const o of m.objs) { if (!goal.world.includes(o.t)) continue; if (PL && !onPlat && PL[o.y * m.W + o.x]) continue; const x = o.x * 16 + 8, y = o.y * 16 + 6, d = Math.hypot(x - px, y - py); if (d < bd) { bd = d; best = { x, y }; } }
  return best;
}
function tutUiEls(goal) {
  if (!goal) return [];
  const L = UI.top(), q = s => document.querySelector('.modal:not(.under) ' + s);
  if (goal.craft) {
    if (!L) return Input.mode === 'touch' && hotCraft ? [hotCraft] : [hotBag];   // v7a：スマホはアイテムバーの右のハンマーを光らせる
    if (!L.mainMenu) return [];
    if (L.tab !== 'craft') return [q('[data-k=tab-craft]')];
    const r = RECIPES.find(x => x.id === goal.craft); if (r && L.ccat !== 'all' && L.ccat !== craftCat(r)) return [q('[data-k=cc-all]')];
    return [q(`[data-k="cr-${goal.craft}"]`)];
  }
  if (goal.zeni && !L) return Input.mode === 'touch' && hotZeni ? [hotZeni] : [];   // v8b
  if (goal.box) { if (L && L.tabs && L.tabs.some(t => t.id === 'sell')) return L.tab === goal.box ? [] : [q(`[data-k=tab-${goal.box}]`)]; return []; }
  if (goal.slot != null) { if (L || !hotEls || !hotEls[goal.slot]) return []; return [game.hotSel === goal.slot && Input.mode === 'touch' ? document.querySelector('.tb-y') : hotEls[goal.slot].sl]; }
  return [];
}
function applyTutGlow(els) {
  const set = new Set(els.filter(Boolean));
  for (const e of document.querySelectorAll('.tut-glow')) if (!set.has(e)) e.classList.remove('tut-glow');
  for (const e of set) e.classList.add('tut-glow');
  state.tutGlowOn = set.size > 0;
}
// 行き先までの点線の矢印（画面の外なら、画面の端に向きを出す）
function drawTutGuide() {
  const p = state.tutGoalPos; if (!p || Dialog.active || UI.isOpen() || state.place || !game || game.map !== 'island') return;
  const z = zoom, k = canvas.width / Math.max(1, window.innerWidth), cw = canvas.width, ch = canvas.height, t = performance.now() / 1000;
  const sx = (p.x - state.cam.x) * z, sy = (p.y - state.cam.y) * z, ox = (player.x - state.cam.x) * z, oy = (player.y - 10 - state.cam.y) * z;
  if (Math.hypot(sx - ox, sy - oy) < 20 * z) return;
  ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0);
  // v6.1e：矢印を太く・大きくして、黒いふちで地面の色に負けないように
  const mg = 56 * k, onScr = sx > mg && sx < cw - mg && sy > mg && sy < ch - mg, Y = 'rgba(255,224,102,0.97)', OL = 'rgba(40,24,0,0.75)';
  const tri = (x, y, a, hs, sp) => { ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * hs, y + Math.sin(a) * hs); ctx.lineTo(x + Math.cos(a + sp) * hs, y + Math.sin(a + sp) * hs); ctx.lineTo(x + Math.cos(a - sp) * hs, y + Math.sin(a - sp) * hs); ctx.closePath(); ctx.fillStyle = Y; ctx.strokeStyle = OL; ctx.lineWidth = 3 * k; ctx.setLineDash([]); ctx.stroke(); ctx.fill(); };
  const dash = (x0, y0, x1, y1, al) => { ctx.lineCap = 'round'; ctx.setLineDash([9 * k, 8 * k]); ctx.lineDashOffset = -t * 50 * k; ctx.globalAlpha = al;
    ctx.strokeStyle = OL; ctx.lineWidth = 7 * k; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
    ctx.strokeStyle = Y; ctx.lineWidth = 4 * k; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1; };
  if (onScr) {
    const a = Math.atan2(sy - oy, sx - ox), ex = sx - Math.cos(a) * 12 * z, ey = sy - Math.sin(a) * 12 * z;
    dash(ox, oy, ex, ey, 1);
    tri(ex, ey, a, 15 * k, 2.45);
    const by = sy - (14 + Math.abs(Math.sin(t * 4)) * 5) * z, bs = 11 * k;   // 行き先の上で弾む▼
    ctx.beginPath(); ctx.moveTo(sx - bs, by - bs * 1.3); ctx.lineTo(sx + bs, by - bs * 1.3); ctx.lineTo(sx, by); ctx.closePath(); ctx.fillStyle = Y; ctx.strokeStyle = OL; ctx.lineWidth = 3 * k; ctx.stroke(); ctx.fill();
  } else {
    const cx = cw / 2, cy = ch / 2, a = Math.atan2(sy - cy, sx - cx), dx = Math.cos(a), dy = Math.sin(a);
    const s = Math.min(Math.abs((cw / 2 - mg) / (dx || 1e-6)), Math.abs((ch / 2 - mg) / (dy || 1e-6))), ax = cx + dx * s, ay = cy + dy * s, hs = (20 + Math.sin(t * 6) * 3) * k;
    dash(ox, oy, ax - dx * hs, ay - dy * hs, 0.7);
    tri(ax, ay, a, hs, 2.35);   // 画面の端で、行き先の向きを指す
  }
  ctx.restore();
}
/* 操作説明・遊び方 */
function openHowTo() {
  const row = (k, v) => h('div', { class: 'howto-row' }, h('div', { class: 'hk' }, k), h('div', { class: 'hv' }, v));
  const tabs = { key: 'キーボード', pad: 'コントローラー', touch: 'スマホ', rule: '遊び方' };
  UI.open({ tab: Input.mode === 'touch' ? 'touch' : Input.mode === 'pad' ? 'pad' : 'key', render: (el, L) => el.appendChild(windowEl(L, {
    title: '操作説明・遊び方', tabs: Object.keys(tabs).map(id => ({ id, label: tabs[id] })),
    body: b => {
      if (L.tab === 'key') b.appendChild(h('div', null, row('移動', 'WASD／矢印キー（Shiftを押したままでダッシュ）'), row('調べる・拾う', 'Space（拾う・採取はSpaceだけ。木や岩は長押し。何もない所では、回復アイテムを使う）'), row('攻撃', '左クリックかSpace（向いている方へ。押したままで連続）'), row('採掘・伐採', '左クリックを押したままでもできる'), row('使う', '右クリック（食べる・飲む・置く。剣などを持っている時は、左手の回復アイテム）'), row('左手', 'F（手に持っている物と左手を入れ替え。たいまつ・回復アイテムだけ）'),
        row('画面', 'E 持ち物（アイテムバー右のバッグでも）／C クラフト／M 地図'), row('記録', 'Esc（ポーズ）→「記録」。見ている間は時間が止まる'), row('ステータス', '右上の体力などをクリックで、くわしい状態と残り時間'), row('アイテムバー', '1〜8キー／マウスホイール'), row('捨てる', 'Q（Ctrl+Qで全部）'), row('ポーズ', 'Esc'),
        row('持ち物の移動', 'ドラッグ＆ドロップで好きな枠へ（押すと説明。マウスを乗せると名前と耐久を表示）'), row('会話', 'Space長押しで早送り／Escでスキップ'), row('タブ', '設定でONにすると、タブのある画面（ゼニ丸など）でQ・Eで切り替え'), row('UIの表示', 'F2で、時間・ステータス・地図・アイテムバーなどの表示を消す／戻す（消している間も持ち替えや画面を開くのはそのまま）'),
        row('設置', '設置物を持って右クリック → 置きたいマスをクリック（右クリックでやめる）')));
      else if (L.tab === 'pad') b.appendChild(h('div', null, row('移動', '左スティック／十字キー（Bを押したままでダッシュ）'), row('A', '決定・調べる・拾う'), row('ZR', '攻撃・採掘・伐採（木や岩は長押し）。弓を持っている時は矢を撃つ'), row('B', '戻る'), row('X', '持ち物（LB／RBでクラフト・地図に切り替え）'), row('Y／ZL', '使う（食べる・飲む・置く・作業台や炉などを開く。剣などを持っている時は、左手の回復アイテム）'),
        row('LB／RB', 'アイテムバーの持ち替え（持ち物・クラフト・地図では画面の切り替え）'), row('START', 'ポーズ（会話中はスキップ）'), row('−（セレクト）', 'ゼニ丸を呼ぶ（売買・返済）'), row('会話', 'Aの長押しで早送り'), row('入れ替え', '設定でA/B・X/Yを入れ替えられます')));
      else if (L.tab === 'touch') b.appendChild(h('div', null, row('移動', '左下のスティック（Bを押したままでダッシュ）'), row('A', '調べる・拾う・攻撃（木や岩は長押し）'), row('B', '戻る（押したまま移動でダッシュ）'), row('X', '持ち物'), row('Y', '使う（食べる・飲む・置く。剣などを持っている時は、左手の回復アイテム）'),
        row('アイテムバー', 'タップで持ち替え、選んでいる枠をもう一度タップで使う'), row('バッグ', 'アイテムバーの右：持ち物を開く'), row('ハンマー（バッグの右）', 'クラフトを開く'), row('ステータス', '右上の体力などをタップで、くわしい状態と残り時間'), row('長押しで食べる', '食べ物・飲み物を持って、画面の何もない所を1秒長押し'), row('持ち物の移動', '枠を長押しして、好きな枠へドラッグ（押すだけだと説明が出る）'), row('会話', '長押しで早送り、右上の「スキップ」で飛ばす'), row('設置', '置きたいマスをタップ'), row('≡（右上）', 'ポーズ'), row('ミニマップ', 'タップで地図を開く'), row('左手', 'アイテムバーの左（縦画面は上）の枠をタップで、左手の回復アイテムを使う'), row('コントローラー', 'つなぐとタッチボタンを隠す（触ると元に戻る）')));
      else b.appendChild(h('div', null,
        row('目的', '借金を返して、いかだで島を脱出する。返済期限を過ぎると……'), row('お金', '島の素材を、ついてくるゼニ丸に売る。同じ物を売り続けると値下がりし、時間で戻る'),
        row('締め日', '左上に表示。決まった日までに返す額が届かないと、借金が上乗せされる'), row('生きのびる', '空腹・渇き・体力・スタミナに注意。0になると体力が減っていく'),
        row('水', '泉で木の器に汲む → 焚き火でろ過 → きれいな水で渇きを回復。雨の日は1日に2回まで、器に雨水がたまる'), row('夜', '寒くて獣が出る。焚き火や小屋のそばは安全。寝床や小屋で朝まで眠れる'),
        row('道具', 'アイテムバーで持っている時だけ効果がある。採掘・攻撃はバーの道具や剣へ自動で持ち替え（設定でOFFにできる）。たいまつは持っている間だけ燃える（1本1分。左手に持ってもOK）'),
        row('防具', '鉄の防具を持ち物画面で「装備」すると、受けるダメージが30%減る。攻撃を受けるたびに耐久が減る'), row('左手', 'たいまつか回復アイテムを1枠持てる。剣を持ったままでも回復できる'),
        row('崖', '台地は崖に囲まれていて、歩いては登れない。崖の壁に縄梯子（クラフト）を掛けると、上り下りできる'), row('持ち物', '1枠に5個まで。持ち物がいっぱいでも木や岩は採れて、入りきらない分は足元に置く（拾うだけの物は拾えない）。チェストや小屋の倉庫にしまえる'),
        row('天気', '晴れ・くもり・雨・嵐・雪。6時と18時の1日2回変わる。嵐の日は釣りができず、雷に注意。雪の日は昼も寒く、焚き火や小屋のそばか屋内で暖まる'), row('カジノ', '浜辺の豪華客船を直すと遊べる。続けるほど負ける仕組みなので、ほどほどに'),
        row('倒れたら', 'ノーマルは翌朝に浜辺で目覚め、持ち物は倒れた場所に落ちる。ハードはゲームオーバー'),
        row('めずらしい生き物', 'ごくまれに金のウサギが出る（1日1体まで）。とても速いが、どの武器でも5回当てれば倒せる。木を切ると、まれに蜂が飛び出して襲ってくる（毒あり）'), row('幸福', '黄金の焼き肉を食べると5分間。体力の自然回復が2倍になる'),
        row('自動採掘機', '炉と作業台で部品を作って組み立てる。島の岩場の2×2マスに置き、木炭（10回）か石炭（15回）を入れると20秒ごとに石と鉱石を掘ってためる（1台まで）'),
        row('自動伐採機', '作業台で作る（木材10・歯車2・鉄板3）。置いたまわり3×3マスの木を8秒ごとに1本切って、木材と木の枝をためる。燃料はいらない。範囲の中は歩ける'),
        row('炉の燃料', '炉の画面の左の持ち物から、木の枝（+2）・木炭（+8）・石炭（+10）を押して燃料を入れる（最大10）。1個加工するごとに1減る'),
        row('ゼニ丸', 'いつも後ろについてくる。Rキー（スマホは右下の$ボタン）で、どこでも売買・返済の画面を開ける。家の中では出口のそばにいて、話しかけられる'),
        row('ラージチェスト', 'チェストを横に2つ並べると、つながって16枠のラージチェストになる'),
        row('弓と矢', '作業台で作る。弓を持って攻撃すると、自分のまわり半径5マスの円の中の生き物を自動で狙って矢を撃つ（矢は1本ずつ使い切り。ボスには効かない）'),
        row('雪とシロクマ', '雪の日の6〜18時は、草地にシロクマが出る。ふだんはおとなしいが、攻撃すると怒る。一度止まったら、その時に立っていた場所へ突進してくるので横によけよう'),
        row('ヤドカリ', '6〜20時の砂浜にいる。逃げないので捕まえやすい。貝殻（まれに珍しい貝殻）を落とす'),
        row('洞窟の魔物', '4日目から、ときどき夜の地上にもサソリやコウモリが出る（18時にお知らせ）'), row('借金の推移', 'ポーズ画面の「記録」で、借金の変わり方をグラフで見られる'),
        row('木造の家', '作業台で「釘」を加工し、設計キット（板材15・繊維30・釘5）を作って建てる。草地や森の5×5マス（海・砂浜・道・崖・泉・岩場から2マス以上はなす）なら、木・岩・草・拾える物の上にも建てられる（建てるとどかす）。12時間で完成・1軒まで。中は縦7×横11マスで、天気や寒さの影響がなく、空腹と渇きの減りが半分。焚き火以外の設置物を置ける'),
        row('時間', `ゲーム内の1日＝現実の${fmtDur(CONFIG.dayLength)}。持ち物・クラフト・地図・カジノを開いている間も進む（ポーズ・記録・会話の間は止まる）`), row('落とし物', '捨てた物・敵が落とした物は、地面に出てから丸1日で消える（倒れた時に落とした物・ボスの報酬は消えない）'), row('セーブ', 'ポーズ画面から。朝・売買・クラフト時なども自動でセーブ（デモプレイはセーブなし）')));
    },
  })) });
}
/* セーブのバックアップ（タイトルの設定だけ）：3つのスロットと設定をファイルに書き出す／読み込む */
function exportBackup() {
  const data = { app: 'mujintou-saimu', saveVersion: CONFIG.saveVersion, date: new Date().toISOString(), slots: {}, settings: null };
  try { for (let n = 1; n <= CONFIG.slots; n++) data.slots[n] = localStorage.getItem(slotKey(n)); data.settings = localStorage.getItem(CONFIG.settingsKey); } catch (e) { toast('書き出しに失敗しました', 'bad'); return; }
  const d = new Date(), p = n => String(n).padStart(2, '0'), name = `mujintou-backup-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}.json`;
  const url = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
  const a = h('a', { href: url, download: name }); document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 2000);
  toast('バックアップを書き出しました：' + name, 'good');
}
function importBackup() {
  const inp = h('input', { type: 'file', accept: '.json,application/json' }); inp.style.display = 'none'; document.body.appendChild(inp);
  inp.addEventListener('change', () => {
    const f = inp.files && inp.files[0]; inp.remove(); if (!f) return;
    const rd = new FileReader();
    rd.onload = () => {
      let d; try { d = JSON.parse(rd.result); } catch (e) { d = null; }
      if (!d || d.app !== 'mujintou-saimu' || !d.slots) { sfx('error'); toast('このファイルはバックアップではありません', 'bad'); return; }
      confirmBox('バックアップを読み込みます。\n今のセーブデータと設定は上書きされます。よろしいですか？', () => {
        try {
          for (let n = 1; n <= CONFIG.slots; n++) { const v = d.slots[n]; if (v) localStorage.setItem(slotKey(n), v); else localStorage.removeItem(slotKey(n)); }
          if (d.settings) localStorage.setItem(CONFIG.settingsKey, d.settings);
        } catch (e) { toast('読み込みに失敗しました（容量不足の可能性）', 'bad'); return; }
        toast('バックアップを読み込みました。再読み込みします…', 'good'); setTimeout(() => location.reload(), 900);
      }, { yes: '読み込む', danger: true });
    };
    rd.readAsText(f);
  });
  inp.click();
}
function playPrologue() {
  state.scene = 'story';
  const finish = () => { UI.closeAll(); startPlay(true); };
  UI.open({ cls: 'dark', onBack: finish, render: (el, L) => {
    L.i = L.i || 0;
    const d = h('div', { class: 'story f', 'data-k': 'story' }, h('p', null, fmtText(PROLOGUE[L.i])), h('div', { class: 'next' }, '▼'));
    d.addEventListener('click', () => { sfx('ui'); L.i++; if (L.i >= PROLOGUE.length) finish(); else UI.refresh(L); });
    el.appendChild(h('div', { style: 'display:flex;flex-direction:column;align-items:center' }, d, btn('スキップ ▶▶', finish, { key: 'skip', cls: 'small' })));
  } });
}
function continueGame(n) {
  if (!loadGame(n)) { toast('セーブデータを読み込めませんでした', 'bad'); return; }
  UI.closeAll(); startPlay(false);
}
function startPlay(isNew) {
  toggleHudHide(false);   // v8f：始める時はUIを表示
  state.scene = 'play'; state.rocks = []; state.particles = []; state.floats = []; state.fishing = null; state.fishFx = null; state.reel = 0; state.pendingTalks = []; state.gather = { o: null, prog: 0, hits: 0 }; state.warn = {};
  $('hud').classList.remove('hidden'); updateTouchVisibility(); Input.clearAll();
  state.clockIntro = false; { const ci = $('clock-intro'); if (ci) ci.classList.add('hidden'); }   // v6.2
  state.place = null; document.body.classList.remove('placing'); state.konami = 0; state.mobs = []; state.mobT = 3; state.invuln = 0;
  state.tutT = 0; state.tutMoved = 0; state.tutPX = null; const te = $('tut'); if (te) { te._k = null; te.classList.add('hidden'); }
  if (game.demo) setTimeout(() => { if (state.scene === 'play' && game && game.demo) toast('デモプレイ中：セーブはされません', ''); }, 1200);
  if (isNew) {
    const st = stagesOf(game.contract);
    queueTalk(game.contract.free ? TALK.introFree : TALK.intro, st.length ? null : showClockIntro);   // v6.2：会話のあとに、時計の説明
    if (st.length) queueTalk([['same', 'それと、返済には「締め日」がある。' + st.map(x => `${x.day}日目までに累計${fmt$(x.need)}`).join('、') + 'だ。'], ['same', '届かなけりゃ、遅延損害金を上乗せさせてもらうぜ。ハッハッハ！'], ['sys', '締め日はポーズ画面の「記録」で確認できる。']], showClockIntro);
    saveGame(true);
  }
  else { toast(`スロット${curSlot}：${game.day}日目から再開`); if (game.tut === -2) setTimeout(askTutorial, 1200); }   // v8a：確認する前にやめたセーブは、再開した時に聞く
}
// v6.2：はじめての開始：画面を暗くして、左上の時計に注目させる。画面のどこかを押すと、時間が動き出す
function showClockIntro() {
  if (state.scene !== 'play' || !game) return;
  const ov = $('clock-intro'); if (!ov) return;
  state.clockIntro = true; state.ciT = performance.now(); Input.clearAll();
  $('ci-text').innerHTML = `<b>ここが時計と天気</b><br>今の時刻と、今日の天気がここに出ます。<br>天気は<span class="hl-r">6時と18時の1日2回</span>変わります（晴れ・くもり・雨・嵐・雪）。<br>時間は<span class="hl-n">ゲーム内の1日＝現実の${fmtDur(CONFIG.dayLength)}</span>（昼${fmtDur(CONFIG.dayPart)}・夜${fmtDur(CONFIG.dayLength - CONFIG.dayPart)}）で進みます。<br><small>会話中・ポーズ中・記録を見ている間は止まります。</small>`;
  ov.classList.remove('hidden'); placeClockIntro(); sfx('ui');
}
function placeClockIntro() {
  const el = document.querySelector('#hud-status .hud-day'), sp = $('ci-spot'), bx = $('ci-box'); if (!el || !sp || !bx) return;
  const r = el.getBoundingClientRect(), k = `${Math.round(r.left)},${Math.round(r.top)},${Math.round(r.width)},${Math.round(r.height)}`; if (sp._k === k) return; sp._k = k;
  const L = r.left - 6, T = r.top - 4, W = r.width + 12, H = r.height + 8, ov = $('clock-intro'), VW = ov.clientWidth || innerWidth, VH = ov.clientHeight || innerHeight;
  sp.style.left = L + 'px'; sp.style.top = T + 'px'; sp.style.width = W + 'px'; sp.style.height = H + 'px';
  const dim = (id, x, y, w, hh) => { const d = $(id); if (d) d.style.cssText = `left:${x}px;top:${y}px;width:${Math.max(0, w)}px;height:${Math.max(0, hh)}px`; };   // 時計のまわりを4枚の板で暗くする
  dim('ci-d0', 0, 0, VW, T); dim('ci-d1', 0, T + H, VW, VH - T - H); dim('ci-d2', 0, T, L, H); dim('ci-d3', L + W, T, VW - L - W, H);
  bx.style.left = Math.max(8, r.left - 6) + 'px'; bx.style.top = (r.bottom + 16) + 'px';
}
function closeClockIntro() {
  if (!state.clockIntro || performance.now() - (state.ciT || 0) < 450) return;
  state.clockIntro = false; const ov = $('clock-intro'); if (ov) ov.classList.add('hidden'); Input.clearAll(); sfx('ui'); toast('時間が動き出した！', 'good');
  setTimeout(askTutorial, 700);   // v8a
}
// v8a：チュートリアルをやるか選んでもらう（はじめての開始で、会話と時計の説明が終わって動けるようになったあと）
function askTutorial() {
  if (!game || game.tut !== -2) return;
  if (state.scene !== 'play' || UI.isOpen() || Dialog.active || state.fading || state.clockIntro) { setTimeout(askTutorial, 500); return; }
  UI.open({ onBack: () => { game.tut = -1; UI.close(); toast('チュートリアルはあとから設定で表示できます'); }, render: (el, L) => el.appendChild(windowEl(L, {
    title: 'チュートリアル', cls: 'small', noClose: true,
    body: b => b.appendChild(h('p', { class: 'note', style: 'font-size:15px;color:var(--text);line-height:1.7' }, 'チュートリアルを開始しますか？', h('br'), h('small', { style: 'color:var(--muted)' }, '拾う・作る・売る・返す・水と食べ物まで、基本の遊び方を順番に案内します。'))),
    foot: [btn('いいえ', () => { game.tut = -1; UI.close(); toast('チュートリアルはあとから設定で表示できます'); }, { key: 'no' }), btn('はい', () => { game.tut = 0; state.tutT = 0; state.tutMoved = 0; UI.close(); }, { key: 'yes', cls: 'primary' })],
  })) });
}
/* ---------- v8e：ムービー（オープニング・エンディング） ----------
   低い解像度のキャンバス（横長なら高さ135ドット）にドット絵を描き、画面いっぱいに拡大して見せる。文字はくっきり見えるようにHTMLで重ねる */
const CV = {
  W: 240, H: 135,
  fit(cv) {
    const vw = Math.max(1, innerWidth), vh = Math.max(1, innerHeight);
    if (vw >= vh) { this.H = 135; this.W = Math.round(clamp(135 * vw / vh, 180, 330)); } else { this.W = 180; this.H = Math.round(clamp(180 * vh / vw, 180, 400)); }
    if (cv.width !== this.W || cv.height !== this.H) { cv.width = this.W; cv.height = this.H; }
  },
};
const cvR = (g, x, y, w, h, c) => { g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); };
const cvHash = i => { const s = Math.sin(i * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
function cvMix(a, b, k) {
  const pa = hexRgb(a), pb = hexRgb(b), m = (x, y) => Math.round(x + (y - x) * clamp(k, 0, 1));
  return `rgb(${m(pa[0], pb[0])},${m(pa[1], pb[1])},${m(pa[2], pb[2])})`;
}
// 空：上から下へ色を変える（4ドットずつの帯にして、ドット絵らしく）
function cvSky(g, W, y0, y1, cTop, cBot) {
  const n = Math.max(1, Math.ceil((y1 - y0) / 4));
  for (let i = 0; i < n; i++) cvR(g, 0, y0 + i * 4, W, 4, cvMix(cTop, cBot, i / Math.max(1, n - 1)));
}
function cvStars(g, W, H, t, n, a) {
  for (let i = 0; i < n; i++) {
    const x = Math.floor(cvHash(i) * W), y = Math.floor(cvHash(i + 50) * H), tw = 0.5 + 0.5 * Math.sin(t * (1.5 + cvHash(i + 9) * 2) + i);
    g.globalAlpha = a * (0.35 + tw * 0.65); cvR(g, x, y, 1, 1, i % 7 ? '#ffffff' : '#ffe9a8');
  }
  g.globalAlpha = 1;
}
function cvDisk(g, cx, cy, r, c) { for (let y = -r; y <= r; y++) { const w = Math.round(Math.sqrt(Math.max(0, r * r - y * y))); cvR(g, cx - w, cy + y, w * 2 + 1, 1, c); } }
function cvSun(g, cx, cy, r, c, glow) {
  if (glow) { g.globalAlpha = 0.18; cvDisk(g, cx, cy, r + 6, glow); g.globalAlpha = 0.3; cvDisk(g, cx, cy, r + 3, glow); g.globalAlpha = 1; }
  cvDisk(g, cx, cy, r, c);
}
function cvMoon(g, cx, cy, r) { cvSun(g, cx, cy, r, '#f4f0d8', '#c8d4ff'); cvDisk(g, cx + 2, cy - 1, Math.max(1, r - 2), '#e2dcbc'); cvR(g, cx - 2, cy + 1, 2, 2, '#d0c8a4'); cvR(g, cx + 1, cy + 3, 1, 1, '#d0c8a4'); }
// 海：水平線から下。波の線と、光の反射
function cvSea(g, W, H, hy, cTop, cBot, t, spark, rough) {
  cvSky(g, W, hy, H, cTop, cBot);
  rough = rough || 1;
  for (let row = 0; row < 26; row++) {
    const y = hy + 2 + row * row * (H - hy) / 700, sp = 4 + row * 1.5, len = 2 + Math.floor(row / 3);
    for (let x = -20; x < W + 20; x += sp * 3) {
      const ox = (x + Math.sin(t * 1.3 + row * 1.7) * 6 * rough + row * 13) % (W + 40) - 20;
      g.globalAlpha = 0.35; cvR(g, ox, y + Math.sin(t * 2 + x * 0.1) * rough, len, 1, '#ffffff'); g.globalAlpha = 1;
    }
  }
  if (spark) for (let i = 0; i < 18; i++) { const x = cvHash(i + 3) * W, y = hy + 2 + cvHash(i + 7) * (H - hy) * 0.6; if (Math.sin(t * 3 + i * 2.1) > 0.55) cvR(g, x, y, 2, 1, spark); }
}
// ヤシの木（遠く）
function cvPalm(g, x, y, s, c, t) {
  const h = 10 * s, sw = Math.sin(t * 1.2 + x) * s * 0.6;
  for (let i = 0; i < h; i++) cvR(g, x + Math.sin(i / h * 1.6) * s * 1.5 + sw * i / h, y - i, Math.max(1, s * 0.8), 1, c.trunk);
  const tx = x + Math.sin(1.6) * s * 1.5 + sw, ty = y - h;
  for (const [dx, dy] of [[-5, 2], [-3, -2], [0, -3], [3, -2], [5, 2], [-6, 4], [6, 4]]) {
    const n = 6; for (let k = 1; k <= n; k++) cvR(g, tx + dx * s * k / n, ty + dy * s * k / n + (k * k) * 0.06 * s, Math.max(1, s * 0.9), Math.max(1, s * 0.7), k > n - 2 ? c.leafD : c.leaf);
  }
}
// 島（海の上に浮かぶ姿）。s＝大きさ
function cvIsland(g, cx, by, s, t, pal) {
  pal = pal || { sand: '#e8d29a', sandD: '#c8a868', hill: '#2f8a3e', hillD: '#1f5e2e', trunk: '#7a5530', leaf: '#3ea24a', leafD: '#1f6e2e', rock: '#8a8fa0' };
  const w = 46 * s;
  g.globalAlpha = 0.25; cvR(g, cx - w * 0.6, by + 1, w * 1.2, Math.max(1, s), '#ffffff'); g.globalAlpha = 1;
  for (let i = 0; i < 4 * s; i++) { const k = i / (4 * s), ww = w * (0.62 - k * 0.12); cvR(g, cx - ww, by - i, ww * 2, 1, i < s ? pal.sandD : pal.sand); }
  for (let i = 0; i < 16 * s; i++) { const k = i / (16 * s), ww = w * 0.48 * Math.sqrt(1 - k * k * 0.95) * (1 - k * 0.25), x0 = cx - ww - 4 * s + Math.sin(k * 3) * 3 * s; cvR(g, x0, by - 4 * s - i, ww * 2, 1, i < 2 * s ? pal.hillD : pal.hill); cvR(g, x0 + ww * 1.35, by - 4 * s - i, ww * 0.65, 1, pal.hillD); if (k > 0.35) cvR(g, x0 + ww * 0.25, by - 4 * s - i, ww * 0.35, 1, pal.hillL || '#4aa84e'); }
  cvR(g, cx + w * 0.22, by - 7 * s, 5 * s, 3 * s, pal.rock);
  for (const [dx, sc] of [[-0.5, 1], [-0.3, 1.2], [0.36, 1.1], [0.55, 0.9]]) cvPalm(g, cx + dx * w, by - 3 * s, sc * s, pal, t);
}
// いかだ（プレイヤーが乗っている）
function cvRaft(g, x, y, t, o) {
  o = o || {};
  const bob = Math.round(Math.sin(t * 2.2) * 1);
  y += bob;
  for (let i = 0; i < 5; i++) { cvR(g, x - 11 + i * 4.4, y - 2, 4, 4, i % 2 ? '#8b5a2b' : '#a06a34'); cvR(g, x - 11 + i * 4.4, y + 1, 4, 1, '#5a3a22'); }
  cvR(g, x - 1, y - 24, 2, 22, '#5a3a22');
  const sw = Math.sin(t * 1.6) * 1.5;
  for (let i = 0; i < 16; i++) cvR(g, x + 1, y - 23 + i, Math.round(4 + i * 0.7 + sw * i / 16), 1, i % 6 === 5 ? '#d8cfb8' : '#efe6d0');
  cvR(g, x + 5, y - 17, 3, 3, '#c9a36a');
  if (o.rope) { g.strokeStyle = '#c8b088'; g.lineWidth = 1; g.beginPath(); g.moveTo(x + 11, y - 1); g.quadraticCurveTo(x + 15 + (o.rope - x - 11) * 0.5, y + 4, o.rope, y - 6); g.stroke(); }   // v8f：桟橋につないだロープ
  const spr = PL[3] && PL[3][0]; if (spr && !o.empty) g.drawImage(spr, Math.round(x - 13), Math.round(y - 15));   // v8f：empty＝降りたあと（プレイヤーが2人に見えないように）
  g.globalAlpha = 0.3; cvR(g, x - 14, y + 3, 28, 1, '#ffffff'); g.globalAlpha = 1;
}
// 漁船（オープニングの嵐）
function cvBoat(g, x, y, ang, t, broken) {
  g.save(); g.translate(Math.round(x), Math.round(y)); g.rotate(ang);
  cvR(g, -18, -4, 36, 6, '#6a3a22'); cvR(g, -16, 2, 32, 2, '#4a2614'); cvR(g, -20, -5, 40, 2, '#8b5a2b');
  cvR(g, -6, -14, 14, 9, '#d8d4c8'); cvR(g, -4, -12, 3, 3, Math.sin(t * 9) > 0 ? '#ffd45a' : '#c89a3a'); cvR(g, 2, -12, 3, 3, '#5a7a9a');
  if (!broken) { cvR(g, -12, -30, 2, 26, '#4a3020'); cvR(g, -12, -30, 10, 1, '#4a3020'); }
  else { g.rotate(-0.6); cvR(g, -14, -20, 2, 16, '#4a3020'); }
  g.restore();
}
// 鮫島の黒い船
function cvBlackShip(g, x, y, s, t) {
  const w = 40 * s;
  cvR(g, x - w, y - 6 * s, w * 2, 7 * s, '#14141c'); cvR(g, x - w + 2 * s, y + s, w * 2 - 4 * s, 2 * s, '#0a0a10'); cvR(g, x - w, y - 3 * s, w * 2, Math.max(1, s), '#c03030');
  cvR(g, x - w * 0.3, y - 14 * s, w * 0.9, 8 * s, '#22222e'); for (let i = 0; i < 4; i++) cvR(g, x - w * 0.25 + i * 7 * s, y - 12 * s, 3 * s, 2 * s, '#ffd45a');
  cvR(g, x + w * 0.35, y - 22 * s, 5 * s, 9 * s, '#14141c'); cvR(g, x + w * 0.35, y - 20 * s, 5 * s, Math.max(1, s), '#c03030');
  for (let i = 0; i < 5; i++) { const k = ((t * 0.6 + i * 0.2) % 1); g.globalAlpha = 0.5 * (1 - k); cvDisk(g, x + w * 0.37 + 2 * s + k * 14 * s, y - 24 * s - k * 12 * s, Math.max(1, Math.round((2 + k * 4) * s)), '#555560'); }
  g.globalAlpha = 1;
}
// 人のドット絵（鮫島・手下・家族など）。16×16の枠に描く
function cvPerson(g, x, y, k, t, face) {
  const L = { same: { suit: '#2a2a38', tie: '#d94b4b', hair: '#1a1a22', skin: '#e8b890', glass: 1 }, thug: { suit: '#1a1a22', tie: '#1a1a22', hair: '#2a2a2a', skin: '#e0b088', glass: 1 },
    mom: { suit: '#c86a7a', tie: '#c86a7a', hair: '#5a3a2a', skin: '#f2c9a0' }, kid: { suit: '#5a9ad8', tie: '#5a9ad8', hair: '#3a2a1a', skin: '#f2c9a0', small: 1 },
    old: { suit: '#7a6a5a', tie: '#7a6a5a', hair: '#d8d8d8', skin: '#e8c0a0' }, cop: { suit: '#2a4a8a', tie: '#2a4a8a', hair: '#1a1a2a', skin: '#f0c098', cap: 1 } }[k];
  const sx = Math.round(x), sy = Math.round(y), sm = L.small ? 3 : 0;
  cvR(g, sx - 4, sy - 12 + sm, 8, 9 - sm, L.suit); cvR(g, sx - 1, sy - 12 + sm, 2, 5, L.tie);
  cvR(g, sx - 3, sy - 3, 2, 3, '#1a1a22'); cvR(g, sx + 1, sy - 3, 2, 3, '#1a1a22');
  cvR(g, sx - 3, sy - 18 + sm, 6, 6, L.skin); cvR(g, sx - 3, sy - 19 + sm, 6, 2, L.hair); if (L.cap) { cvR(g, sx - 4, sy - 20 + sm, 8, 2, '#1a2a5a'); cvR(g, sx - 1, sy - 20 + sm, 2, 1, '#f2c440'); }
  if (L.glass) { cvR(g, sx - 3, sy - 16 + sm, 6, 2, '#0a0a0a'); cvR(g, sx - 2, sy - 16 + sm, 1, 1, '#ffffff'); }
  else { cvR(g, sx - 2 + (face || 0), sy - 16 + sm, 1, 1, '#1a1626'); cvR(g, sx + 1 + (face || 0), sy - 16 + sm, 1, 1, '#1a1626'); }
  if (k === 'same') { cvR(g, sx + 3, sy - 14, 3, 1, '#c8a878'); if (Math.sin(t * 3) > 0) cvR(g, sx + 6, sy - 15, 1, 1, '#ff8a3a'); }
}
// プレイヤー（ゲームのドット絵を使う）
function cvPlayer(g, x, y, dir, t, walk) { const fr = walk ? [1, 0, 2, 0][Math.floor(t * 7) % 4] : 0, spr = PL[dir] && PL[dir][fr]; if (spr) g.drawImage(spr, Math.round(x - 8), Math.round(y - 16)); }
function cvDrone(g, x, y, t) { const spr = Math.floor(t * 12) % 2 ? SPR.drone1 : SPR.drone0; if (spr) g.drawImage(spr, Math.round(x - 8), Math.round(y - 6 + Math.sin(t * 2.4) * 2)); }
function cvIcon(g, id, x, y, s) { const ic = ICON[id]; if (ic) g.drawImage(ic, Math.round(x - 8 * s), Math.round(y - 8 * s), Math.round(16 * s), Math.round(16 * s)); }
// 港（桟橋と町並み）
function cvPort(g, W, H, hy, t, night) {
  for (let i = 0; i < 9; i++) {
    const bx = W * 0.42 + i * W * 0.075, bh = 14 + cvHash(i + 21) * 22, bw = W * 0.07;
    cvR(g, bx, hy - bh, bw, bh, night ? '#1a2238' : '#8a96a8'); cvR(g, bx, hy - bh, bw, 2, night ? '#24304a' : '#a8b4c4');
    for (let wy = hy - bh + 4; wy < hy - 3; wy += 5) for (let wx = bx + 2; wx < bx + bw - 2; wx += 4) if (cvHash(wx * 3 + wy) > (night ? 0.45 : 0.7)) cvR(g, wx, wy, 2, 2, night ? (Math.sin(t + wx) > -0.8 ? '#ffd86a' : '#8a7a3a') : '#d8e4f0');
  }
  cvR(g, W * 0.88, hy - 40, 2, 40, night ? '#2a3044' : '#c05030'); cvR(g, W * 0.72, hy - 40, W * 0.18, 2, night ? '#2a3044' : '#c05030'); cvR(g, W * 0.75, hy - 38, 1, 12, night ? '#2a3044' : '#5a5a5a');
  cvR(g, W * 0.3, hy + 8, W * 0.75, 4, night ? '#3a2a1e' : '#8b5a2b'); cvR(g, W * 0.3, hy + 12, W * 0.75, 1, '#2a1a10');
  for (let i = 0; i < 8; i++) cvR(g, W * 0.32 + i * W * 0.09, hy + 12, 2, 10, night ? '#2a1a10' : '#5a3a22');
  if (night) for (let i = 0; i < 3; i++) { const lx = W * 0.4 + i * W * 0.2; cvR(g, lx, hy - 8, 1, 16, '#3a3a44'); g.globalAlpha = 0.25; cvDisk(g, lx, hy - 9, 5, '#ffe08a'); g.globalAlpha = 1; cvR(g, lx - 1, hy - 10, 3, 2, '#ffe08a'); }
}
function cvRain(g, W, H, t, n, a) {
  g.globalAlpha = a; g.fillStyle = '#b8c8e8';
  for (let i = 0; i < n; i++) { const x = (cvHash(i) * W * 1.4 + t * 160 * (0.8 + cvHash(i + 3) * 0.4)) % (W * 1.4) - W * 0.2, y = (cvHash(i + 11) * H + t * 260) % (H + 10) - 10; g.fillRect(Math.round(x), Math.round(y), 1, 4); g.fillRect(Math.round(x) - 1, Math.round(y) + 4, 1, 2); }
  g.globalAlpha = 1;
}
function cvBolt(g, x, y0, y1, seed, c) {
  let px = x, py = y0; g.fillStyle = c;
  while (py < y1) { const nx = px + (cvHash(seed + py) - 0.5) * 10, ny = py + 4 + cvHash(seed + py * 3) * 5; const n = Math.ceil(Math.max(Math.abs(nx - px), ny - py)); for (let k = 0; k <= n; k++) g.fillRect(Math.round(px + (nx - px) * k / n), Math.round(py + (ny - py) * k / n), 2, 1); px = nx; py = ny; }
}
function cvCoins(g, W, H, t, n, up, x0, y0) {
  for (let i = 0; i < n; i++) {
    const life = (t * 0.7 + cvHash(i + 5)) % 1, x = (x0 != null ? x0 + (cvHash(i + 8) - 0.5) * 60 * life : cvHash(i + 8) * W), y = up ? y0 - life * 50 + life * life * 30 : -6 + life * (H + 12);
    const fl = Math.floor(t * 8 + i) % 4, w = fl === 1 || fl === 3 ? 1 : fl === 2 ? 2 : 3;
    g.globalAlpha = up ? 1 - life : 1; cvR(g, x - w / 2, y, w, 3, '#f2c440'); cvR(g, x - w / 2, y, Math.max(1, w - 1), 1, '#fff2a8'); g.globalAlpha = 1;
  }
}
// 花火のような光の粒
function cvSparkle(g, x, y, t, c, r) { for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2 + t, d = r * (0.6 + 0.4 * Math.sin(t * 3 + i)); cvR(g, x + Math.cos(a) * d, y + Math.sin(a) * d, 1, 1, c); } }
// 黒い宝玉
// 夜の部屋（Aのエンディングの最後）。v8f：窓は主人公に合う大きさにし、壁・床（板張り）・ベッド・机・カーテンを描き分けた。戻り値は窓と床の位置
function cvRoom(g, W, H, t, opt) {
  const fy = Math.round(H * 0.64);   // 壁と床の境目
  // 壁（壁紙のすじ）と、天井の影
  cvR(g, 0, 0, W, fy, '#2a2236'); for (let x = 3; x < W; x += 9) cvR(g, x, 0, 1, fy, '#30283e'); cvSky(g, W, 0, 10, '#16121e', '#2a2236');
  // 床（板張り。奥ほど板が細い）と幅木
  cvR(g, 0, fy, W, H - fy, '#4e3420'); let yy = fy, k = 0; while (yy < H) { const hgt = 3 + k; cvR(g, 0, yy, W, 1, '#3e2816'); for (let x = (k % 2) * 13; x < W; x += 26) cvR(g, x, yy, 1, hgt, '#3e2816'); yy += hgt; k++; }
  cvR(g, 0, fy - 3, W, 3, '#3a2a1e'); cvR(g, 0, fy - 3, W, 1, '#4a3828');
  // 窓（主人公の2倍くらいの大きさ）
  const ww = Math.round(Math.min(46, W * 0.24)), wh = Math.round(ww * 0.72), wx = Math.round(W * 0.5 - ww / 2), wy = fy - 10 - wh;
  g.save(); g.beginPath(); g.rect(wx, wy, ww, wh); g.clip();
  cvSky(g, W, wy, wy + wh, '#0a1430', '#24305a'); cvStars(g, W, wy + wh, t, 30, 0.9); cvMoon(g, wx + Math.round(ww * 0.72), wy + 9, 4);
  cvSea(g, W, wy + wh, wy + Math.round(wh * 0.7), '#16244a', '#0c1630', t, '#8aa0d0', 0.6);
  cvIsland(g, wx + Math.round(ww * 0.3), wy + Math.round(wh * 0.7), 0.22, t, { sand: '#3a3a4a', sandD: '#2a2a3a', hill: '#14202a', hillD: '#0e1820', trunk: '#14202a', leaf: '#14202a', leafD: '#0e1820', rock: '#2a2a3a' });
  if (opt && opt.drone) { const dx = wx + ((t * 7) % (ww + 16)) - 8; cvR(g, dx, wy + 12, 3, 1, '#0a0a10'); cvR(g, dx + 1, wy + 11, 1, 1, Math.sin(t * 8) > 0 ? '#ff4040' : '#0a0a10'); }   // 遠くを飛ぶドローンの赤い光
  g.restore();
  const fr = '#5a3a22'; cvR(g, wx - 2, wy - 2, ww + 4, 2, fr); cvR(g, wx - 2, wy + wh, ww + 4, 2, fr); cvR(g, wx - 2, wy, 2, wh, fr); cvR(g, wx + ww, wy, 2, wh, fr); cvR(g, wx + Math.round(ww / 2) - 1, wy, 2, wh, fr); cvR(g, wx, wy + Math.round(wh / 2) - 1, ww, 1, fr);
  cvR(g, wx - 4, wy + wh + 2, ww + 8, 2, '#6b4a2a');   // 窓台
  // カーテン
  for (const [cx, dir] of [[wx - 9, 1], [wx + ww + 3, -1]]) { cvR(g, cx, wy - 5, 6, wh + 9, '#3a4a78'); for (let i = 0; i < 3; i++) cvR(g, cx + 1 + i * 2, wy - 5, 1, wh + 9, '#2e3c66'); cvR(g, cx + (dir > 0 ? 4 : 0), wy - 5, 2, wh + 9, '#46588a'); }
  cvR(g, wx - 11, wy - 7, ww + 22, 2, '#2a2016');   // カーテンレール
  // 床に落ちる月明かり
  g.globalAlpha = 0.13; g.fillStyle = '#c8d4ff'; g.beginPath(); g.moveTo(wx + 2, fy); g.lineTo(wx + ww - 2, fy); g.lineTo(wx + ww + 10, H); g.lineTo(wx - 6, H); g.closePath(); g.fill(); g.globalAlpha = 1;
  // ベッド（左）
  const bx = Math.round(W * 0.06), bw = Math.round(Math.min(56, W * 0.26)), by = fy + 6;
  cvR(g, bx, by - 16, 4, 22, '#6a4a2a'); cvR(g, bx + bw - 3, by - 9, 3, 15, '#6a4a2a');
  cvR(g, bx + 3, by - 8, bw - 6, 6, '#e8e4f0'); cvR(g, bx + 5, by - 12, 10, 5, '#f4f2fa'); cvR(g, bx + 14, by - 9, bw - 17, 5, '#4a6aa8'); cvR(g, bx + 14, by - 9, bw - 17, 1, '#5a7ab8');
  cvR(g, bx + 3, by - 2, bw - 6, 3, '#5a3a22'); cvR(g, bx + 4, by + 1, 2, 5, '#4a2e1a'); cvR(g, bx + bw - 7, by + 1, 2, 5, '#4a2e1a');
  // 机とランプ（右）
  const dx0 = Math.round(W * 0.94) - 34, dyy = fy + 2;
  cvR(g, dx0, dyy - 12, 34, 3, '#7a5530'); cvR(g, dx0 + 1, dyy - 9, 2, 13, '#5a3a22'); cvR(g, dx0 + 31, dyy - 9, 2, 13, '#5a3a22'); cvR(g, dx0 + 20, dyy - 9, 11, 7, '#6a4628'); cvR(g, dx0 + 24, dyy - 6, 3, 1, '#c8a060');
  cvR(g, dx0 + 5, dyy - 15, 7, 3, '#e8dcc0'); cvR(g, dx0 + 5, dyy - 16, 7, 1, '#c8bca0');   // 本
  cvR(g, dx0 + 25, dyy - 22, 1, 10, '#3a3a40'); cvR(g, dx0 + 22, dyy - 25, 7, 4, '#d8b860');   // ランプ（消えている）
  // 壁の時計
  const kx = Math.round(W * 0.82), ky = Math.round(wy + 2); cvDisk(g, kx, ky, 5, '#5a4a3a'); cvDisk(g, kx, ky, 4, '#e8e0d0'); cvR(g, kx, ky - 3, 1, 3, '#2a2016'); cvR(g, kx, ky, 2, 1, '#2a2016');
  return { fy, wx, wy, ww, wh };
}
// 新聞（Bのエンディング）
function cvPaper(g, cx, cy, t, k) {
  g.save(); g.translate(Math.round(cx), Math.round(cy)); g.rotate((1 - k) * 6.28 * 2); const s = 0.2 + k * 0.8; g.scale(s, s);
  cvR(g, -36, -26, 72, 52, '#efe8d6'); cvR(g, -36, 24, 72, 2, '#c8bfa8'); cvR(g, -32, -22, 64, 6, '#1a1a22'); cvR(g, -32, -13, 40, 3, '#3a3a44'); cvR(g, -32, -8, 40, 2, '#8a8a90');
  for (let i = 0; i < 6; i++) cvR(g, -32, -3 + i * 4, 40, 1, '#a8a8a8'); cvR(g, 12, -13, 20, 22, '#9aa4b0'); cvR(g, 17, -9, 10, 10, '#2a2a38'); cvR(g, 19, -7, 6, 2, '#0a0a0a');
  g.restore();
}
// 浜辺（オープニングとDのエンディング）
function cvBeach(g, W, H, t, o) {
  o = o || {};
  const hy = Math.round(H * 0.46), by = Math.round(H * 0.66);
  cvSky(g, W, 0, hy, o.skyT || '#5a7ab8', o.skyB || '#ffc890');
  if (o.sun != null) cvSun(g, Math.round(W * 0.66), Math.round(o.sun), 7, o.sunC || '#fff0b0', '#ffd890');
  for (let i = 0; i < 5; i++) { const cx = ((cvHash(i) * W * 1.3 + t * (3 + i)) % (W * 1.3)) - W * 0.15, cy = 8 + cvHash(i + 4) * hy * 0.5; g.globalAlpha = o.cloudA == null ? 0.55 : o.cloudA; cvR(g, cx, cy, 18 + i * 3, 3, o.cloud || '#fff4e0'); cvR(g, cx + 4, cy - 2, 10, 2, o.cloud || '#fff4e0'); g.globalAlpha = 1; }
  cvSea(g, W, by + 2, hy, o.seaT || '#3a8ab8', o.seaB || '#2a6a98', t, o.spark || '#fff4c8', 0.6);
  if (o.drawSea) o.drawSea(hy, by);
  cvSky(g, W, by, H, o.sandT || '#f0dca8', o.sandB || '#d8bc80');
  const fo = Math.sin(t * 1.4) * 3;
  g.globalAlpha = 0.85; for (let x = 0; x < W; x += 2) cvR(g, x, by - 1 + fo + Math.sin(x * 0.15 + t * 2) * 1.2, 2, 2, '#ffffff'); g.globalAlpha = 0.25; cvR(g, 0, by + 1 + fo, W, 3, '#c8a868'); g.globalAlpha = 1;
  for (let i = 0; i < 14; i++) cvR(g, cvHash(i + 30) * W, by + 6 + cvHash(i + 40) * (H - by - 6), 1, 1, '#c8a868');
  const pal = { trunk: '#7a5530', leaf: '#3ea24a', leafD: '#1f6e2e' };
  cvPalm(g, W * 0.08, H - 4, 2.4, pal, t); cvPalm(g, W * 0.93, H - 2, 2.2, pal, t + 1); cvPalm(g, W * 0.82, by + 10, 1.4, pal, t + 2);
  return { hy, by };
}
const OPENING_T = [4.6, 4.4, 4.2, 2.8];   // 嵐・浜辺・ゼニ丸・タイトル（秒）
function drawOpening(g, W, H, t) {
  let s = 0, lt = t; while (s < OPENING_T.length - 1 && lt >= OPENING_T[s]) { lt -= OPENING_T[s]; s++; }
  if (s === 0) {   // 嵐の夜
    const hy = Math.round(H * 0.42);
    cvSky(g, W, 0, hy, '#06080f', '#1e2238');
    for (let i = 0; i < 7; i++) { const cx = ((cvHash(i) * W * 1.4 + t * 22) % (W * 1.4)) - W * 0.2, cy = cvHash(i + 2) * hy * 0.7; g.globalAlpha = 0.8; cvR(g, cx, cy, 40, 6, '#0c0e18'); cvR(g, cx + 6, cy - 3, 26, 4, '#10121e'); g.globalAlpha = 1; }
    const fl = [1.3, 2.9, 3.4].reduce((a, x) => Math.max(a, lt > x && lt < x + 0.35 ? 1 - (lt - x) / 0.35 : 0), 0);
    if (fl > 0.6) cvBolt(g, W * (lt < 2 ? 0.25 : 0.72), 0, hy + 4, Math.floor(lt * 3), '#f4f6ff');
    cvSea(g, W, H, hy, '#14243c', '#060c18', t, null, 3);
    const bx = W * 0.5 + Math.sin(t * 0.9) * 8, by = hy + 14 + Math.sin(t * 2.1) * 5, ang = Math.sin(t * 1.7) * 0.28 + (lt > 3.6 ? (lt - 3.6) * 0.9 : 0);
    cvBoat(g, bx, by, ang, t, lt > 3.6);
    for (let i = 0; i < 3; i++) { const wx = ((t * 40 + i * W / 3) % (W + 60)) - 30, wy = hy + 22 + Math.sin(t * 2 + i) * 4; g.globalAlpha = 0.9; cvR(g, wx - 18, wy, 36, 3, '#1e3452'); cvR(g, wx - 10, wy - 2, 20, 2, '#2a4668'); cvR(g, wx - 8, wy - 3, 16, 1, '#d8e4f0'); g.globalAlpha = 1; }
    if (lt > 3.3) {   // 大波が下からせり上がって、船をのみこむ
      const k = clamp((lt - 3.3) / 1.2, 0, 1), top = H + 6 - k * k * (H + 30);
      for (let x = 0; x < W; x += 2) { const y = top + Math.sin(x * 0.07 + t * 5) * 5 + Math.sin(x * 0.19 - t * 7) * 2; cvR(g, x, y, 2, H - y + 4, '#12284a'); cvR(g, x, y + 4, 2, 3, '#1c3a62'); cvR(g, x, y, 2, 2, '#dfe9f8'); if (cvHash(x + Math.floor(t * 12)) > 0.86) cvR(g, x, y - 3 - cvHash(x) * 5, 1, 1, '#ffffff'); }
    }
    cvRain(g, W, H, t, 70, 0.55);
    if (fl > 0) { g.globalAlpha = fl * 0.7; cvR(g, 0, 0, W, H, '#e8ecff'); g.globalAlpha = 1; }
  } else if (s === 1 || s === 2) {   // 浜辺の朝 → ゼニ丸が飛んでくる
    const tt = s === 1 ? lt : OPENING_T[1] + lt, sunY = H * 0.46 + 6 - Math.min(1, tt / 6) * 22;
    const { by } = cvBeach(g, W, H, t, { sun: sunY });
    const px = Math.round(W * 0.42), py = Math.round(by + (H - by) * 0.55);
    for (const [dx, dy, w, c] of [[-38, 6, 12, '#8b5a2b'], [30, 10, 9, '#a06a34'], [-22, 16, 7, '#6a4a2a']]) { cvR(g, px + dx, py + dy - 2, w, 3, c); cvR(g, px + dx, py + dy + 1, w, 1, '#4a2e1f'); }
    cvR(g, px + 46, py - 6, 10, 8, '#8b5a2b'); cvR(g, px + 46, py - 6, 10, 1, '#b07a3f'); cvR(g, px + 50, py - 6, 1, 8, '#5a3a22');
    g.fillStyle = 'rgba(0,0,0,0.22)'; g.fillRect(px - 6, py - 1, 12, 2);
    if (s === 1 && lt < 2.4) { const spr = PL[0][0]; if (spr) { g.save(); g.translate(px, py - 3); g.rotate(-Math.PI / 2); g.drawImage(spr, -8, -8); g.restore(); } if (lt > 1.6 && Math.sin(lt * 20) > 0) cvR(g, px + 9, py - 12, 1, 3, '#ffffff'); }
    else if (s === 1 && lt < 2.8) { const k = (lt - 2.4) / 0.4; cvPlayer(g, px, py - Math.sin(k * Math.PI) * 4, 0, t); }
    else if (s === 1) cvPlayer(g, px, py, lt < 3.4 ? 2 : lt < 4 ? 3 : 0, t);
    else {
      const k = clamp(lt / 1.6, 0, 1), e = 1 - (1 - k) * (1 - k), dx = W + 12 + (px + 22 - W - 12) * e, dy = 8 + (py - 26 - 8) * e;
      cvPlayer(g, px, py, lt < 0.6 ? 0 : 3, t);
      if (lt > 1.6 && lt < 2.1) { cvR(g, px - 1, py - 26, 2, 5, '#ff5a4a'); cvR(g, px - 1, py - 20, 2, 2, '#ff5a4a'); }
      cvDrone(g, dx, dy, t);
      if (lt > 2.2) cvCoins(g, W, H, lt - 2.2, 14, true, dx, dy);
      if (lt > 2.0) cvSparkle(g, dx, dy, t * 2, '#fff2a8', 10 + (lt - 2) * 4);
    }
    if (s === 1 && lt < 0.6) { g.globalAlpha = 1 - lt / 0.6; cvR(g, 0, 0, W, H, '#ffffff'); g.globalAlpha = 1; }
  } else {   // 夕方の海に浮かぶ島（タイトルへ）
    const hy = Math.round(H * 0.58);
    cvSky(g, W, 0, hy, '#2a2050', '#f08a50'); cvStars(g, W, hy * 0.6, t, 30, clamp(lt / 2, 0, 0.8));
    cvSun(g, Math.round(W * 0.7), hy - 4, 9, '#ffd070', '#ff9a50');
    cvSea(g, W, H, hy, '#d06a50', '#2a2a5a', t, '#ffe0a0', 0.8);
    cvIsland(g, Math.round(W * 0.38), hy + 2, 1.5, t);
    cvCoins(g, W, H, t, 16, false);
  }
}
// ムービーの再生（オープニング）。スキップボタンつき。終わると onEnd
function playOpening(onEnd) {
  const ov = h('div', { class: 'cine' }), cv = h('canvas', { class: 'cine-cv' }), caps = h('div', { class: 'cine-caps' }), card = h('div', { class: 'cine-card' }, h('small', null, 'SURVIVAL × DEBT'), h('div', null, '売倍アイランド'), h('p', null, '島の物は、すべて換金できる。売るか、投資するか。'));
  const sk = h('button', { class: 'cine-skip', type: 'button', tabindex: '-1' }, 'スキップ ▶▶');
  ov.appendChild(cv); ov.appendChild(caps); ov.appendChild(card); ov.appendChild(sk); document.body.appendChild(ov);
  const zt = t => settings.zeniTr ? `${t}\n（${zeniTr(t)}）` : t;
  const CAPS = [[0.5, 2.3, '出港から三日目の夜——'], [2.5, 4.3, '船は、突然の嵐に呑まれた。'], [5.4, 8.6, '目が覚めると、見知らぬ島の浜辺だった。'], [10.6, 12.6, zt('「ピピッ！ 回収ドローン「ゼニ丸」デス！」'), 'zeni']];
  const total = OPENING_T.reduce((a, b) => a + b, 0), cardAt = total - OPENING_T[3] + 0.3;
  const g = cv.getContext('2d'); let t0 = performance.now(), done = false, shown = -1;
  const end = () => { if (done) return; done = true; state.cine = null; ov.classList.add('out'); setTimeout(() => ov.remove(), 700); if (onEnd) onEnd(); };
  state.cine = { skip: end };
  sk.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); Sound.init(); end(); });
  ov.addEventListener('pointerdown', e => e.preventDefault());
  const loop = now => {
    if (done) return;
    const t = (now - t0) / 1000;
    try { CV.fit(cv); g.imageSmoothingEnabled = false; drawOpening(g, CV.W, CV.H, t); } catch (er) { console.error(er); end(); return; }
    const ci = CAPS.findIndex(c => t >= c[0] && t < c[1]);
    if (ci !== shown) { shown = ci; caps.innerHTML = ''; if (ci >= 0) caps.appendChild(h('div', { class: 'cine-cap' + (CAPS[ci][3] ? ' ' + CAPS[ci][3] : '') }, CAPS[ci][2])); }
    card.classList.toggle('on', t >= cardAt);
    if (t >= total) { end(); return; }
    requestAnimationFrame(loop);
  };
  requestAnimationFrame(loop);
}
// エンディングの場面。pt＝その場面が始まってからの秒数
const END_PH = {
  // 島をあとにする（昼・夕方・夜）
  sail(g, W, H, t, pt, o) {
    o = o || {};
    const hy = Math.round(H * 0.5), night = o.night;
    if (night) { cvSky(g, W, 0, hy, '#060a1c', '#1c2650'); cvStars(g, W, hy, t, 50, 0.9); cvMoon(g, Math.round(W * 0.78), Math.round(hy * 0.35), 7); }
    else if (o.gold) { cvSky(g, W, 0, hy, '#7aa8e0', '#ffe0a0'); cvSun(g, Math.round(W * 0.2), hy - 8 - Math.min(10, pt * 3), 9, '#fff4c0', '#ffd890'); }
    else { cvSky(g, W, 0, hy, '#3a3070', '#ff9a60'); cvSun(g, Math.round(W * 0.25), hy - 3, 10, '#ffd070', '#ff8a50'); }
    cvSea(g, W, H, hy, night ? '#14204a' : o.gold ? '#4a9ad0' : '#d07a5a', night ? '#060c20' : o.gold ? '#2a6aa8' : '#3a3a6a', t, night ? '#8aa0d8' : '#fff0c0', 1);
    const k = clamp(pt / 7, 0, 1), s = 1.3 - k * 0.8;
    cvIsland(g, Math.round(W * (0.3 + k * 0.05)), hy + 1, s, t, night ? { sand: '#4a4a5a', sandD: '#3a3a4a', hill: '#1a2a2a', hillD: '#142020', trunk: '#1a2020', leaf: '#1e2a2a', leafD: '#142020', rock: '#3a3a4a' } : null);
    for (let i = 0; i < 6; i++) { const wx = W * 0.62 - i * 6 - pt * 3, wy = hy + 34 + i * 0.5; g.globalAlpha = 0.5 - i * 0.07; cvR(g, wx, wy, 5, 1, '#ffffff'); g.globalAlpha = 1; }
    cvRaft(g, Math.round(W * 0.68), Math.round(hy + H * 0.25), t);
    if (!night) for (let i = 0; i < 2; i++) { const bx = (W * 0.5 + i * 30 + t * 12) % (W + 20) - 10, by = 18 + i * 9 + Math.sin(t * 3 + i) * 2, f = Math.sin(t * 8 + i) > 0; cvR(g, bx - 3, by + (f ? 0 : 1), 3, 1, '#2a2a3a'); cvR(g, bx, by, 1, 1, '#2a2a3a'); cvR(g, bx + 1, by + (f ? 0 : 1), 3, 1, '#2a2a3a'); }
  },
  // 本土の港（朝）。いかだを桟橋につないで、降りて歩く（v8f：いかだは空。プレイヤーは桟橋の上の1人だけ）
  portDay(g, W, H, t, pt, o) {
    o = o || {}; const hy = Math.round(H * 0.52);
    cvSky(g, W, 0, hy, '#8ac0f0', '#e8f4ff'); cvSun(g, Math.round(W * 0.15), 22, 8, '#fffbe0', '#fff0b0');
    cvSea(g, W, H, hy, '#4a8ac8', '#2a5a98', t, '#ffffff', 0.7);
    cvPort(g, W, H, hy, t, false);
    cvRaft(g, Math.round(W * 0.22), Math.round(hy + 24), t, { empty: 1, rope: Math.round(W * 0.31) });
    if (!o.noPlayer) cvPlayer(g, Math.round(W * 0.36 + Math.min(1, pt / 2) * W * 0.12), hy + 8, 3, t, pt < 2);
    for (let i = 0; i < 3; i++) { const bx = (W * 0.2 + i * 40 + t * 15) % (W + 20) - 10, by = 12 + i * 7 + Math.sin(t * 3 + i) * 2, f = Math.sin(t * 9 + i) > 0; cvR(g, bx - 3, by + (f ? 0 : 1), 3, 1, '#ffffff'); cvR(g, bx, by, 1, 1, '#ffffff'); cvR(g, bx + 1, by + (f ? 0 : 1), 3, 1, '#ffffff'); }
  },
  // 夜の港（v8f）。o.arrive＝いかだが近づいてくる、o.figA＝鮫島たちの見え方（0〜1）、o.beam＝車のライト（0〜1）、o.step＝鮫島たちが前に出る（0〜1）、o.excl＝プレイヤーの「！」
  portSame(g, W, H, t, pt, o) {
    o = o || {}; const night = o.night !== false, hy = Math.round(H * 0.52);
    if (night) { cvSky(g, W, 0, hy, '#060a1c', '#1a2240'); cvStars(g, W, hy, t, 30, 0.6); } else { cvSky(g, W, 0, hy, '#7ab0e8', '#d8ecff'); }
    cvSea(g, W, H, hy, night ? '#101a3a' : '#4a8ac8', night ? '#060c1e' : '#2a5a98', t, night ? '#6a80b8' : '#ffffff', 0.7);
    cvPort(g, W, H, hy, t, night);
    const beam = o.beam == null ? (night ? 1 : 0) : o.beam;
    if (night) {
      if (beam > 0) { g.globalAlpha = 0.18 * beam; g.fillStyle = '#fff4c0'; g.beginPath(); g.moveTo(W * 0.95, hy + 4); g.lineTo(W * 0.5, hy - 4); g.lineTo(W * 0.5, hy + 16); g.closePath(); g.fill(); g.globalAlpha = 1; }
      cvR(g, W * 0.9, hy, 14, 6, '#2a2a34'); cvR(g, W * 0.9, hy + 1, 3, 2, beam > 0.5 ? '#fff4c0' : '#4a4a40');
    }
    const fa = o.figA == null ? (o.people === false ? 0 : 1) : o.figA, sx = Math.round(W * 0.56 + (1 - (o.step == null ? 1 : o.step)) * 8);
    if (fa > 0) { g.globalAlpha = fa; cvPerson(g, sx, hy + 8, 'same', t); cvPerson(g, sx + 12, hy + 8, 'thug', t); cvPerson(g, sx + 22, hy + 8, 'thug', t); g.globalAlpha = 1; }
    if (!o.arrive && !o.raftAt) return;
    const rx = o.arrive ? Math.round(W * 0.06 + Math.min(1, pt / 3) * W * 0.22) : Math.round(W * 0.28), ry = Math.round(hy + 26);
    cvRaft(g, rx, ry, t);
    if (o.excl && Math.sin(t * 12) > -0.6) { const ex = rx - 5, ey = ry - 24 + Math.round(Math.sin(t * 2.2)); cvR(g, ex, ey, 2, 5, '#ff5a4a'); cvR(g, ex, ey + 6, 2, 2, '#ff5a4a'); }   // v8f：「！」はプレイヤーの頭の上
  },
  // E：夜の港に着く。終わりぎわに車のライトがつき、桟橋の奥に人影が見える
  portArriveNight(g, W, H, t, pt) { const on = pt > 2.0 && !(pt > 2.15 && pt < 2.3); END_PH.portSame(g, W, H, t, pt, { arrive: 1, beam: on ? 1 : 0, figA: clamp((pt - 2.0) / 0.8, 0, 0.5), step: 0 }); },
  // E：そのまま続けて（暗転しない）、ライトに照らされた鮫島たちが前に出てくる
  portWaitNight(g, W, H, t, pt) { END_PH.portSame(g, W, H, t, pt, { raftAt: 1, beam: 1, figA: clamp(0.5 + pt / 0.8, 0, 1), step: clamp(pt / 1.4, 0, 1), excl: pt > 0.4 && pt < 2.6 }); },
  // C：港に着くと、ライトの中で鮫島たちが待っている
  portMeetNight(g, W, H, t, pt) { END_PH.portSame(g, W, H, t, pt, { arrive: 1, beam: pt > 0.6 ? 1 : 0, figA: clamp((pt - 0.8) / 1.0, 0, 1), step: clamp((pt - 1.2) / 1.4, 0, 1), excl: pt > 2.2 }); },
  // ゼニ丸のGPS
  gps(g, W, H, t, pt) {
    cvR(g, 0, 0, W, H, '#0a0e1a'); for (let y = 0; y < H; y += 3) cvR(g, 0, y, W, 1, '#0e1424');
    const cx = Math.round(W / 2), cy = Math.round(H * 0.42);
    for (let i = 0; i < 3; i++) { const k = ((pt * 0.8 + i / 3) % 1), r = Math.round(10 + k * Math.min(W, H) * 0.45); g.globalAlpha = 0.5 * (1 - k); g.strokeStyle = '#ff4040'; g.lineWidth = 1; g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.stroke(); g.globalAlpha = 1; }
    g.save(); g.translate(cx, cy); g.scale(3, 3); cvDrone(g, 0, 0, t); g.restore();
    if (Math.sin(t * 8) > 0) { cvR(g, cx - 2, cy - 22, 4, 4, '#ff3030'); g.globalAlpha = 0.4; cvDisk(g, cx, cy - 20, 6, '#ff3030'); g.globalAlpha = 1; }
    cvR(g, cx - 14, cy + 24, 28, 7, '#1a0a0a'); cvR(g, cx - 13, cy + 25, 26, 5, '#3a0a0a');
    for (let i = 0; i < 3; i++) cvR(g, cx - 10 + i * 8, cy + 26, 5, 3, Math.sin(t * 6 + i) > 0 ? '#ff4040' : '#5a1a1a');
  },
  // 夜の部屋で、島の夢（v8f：窓を小さくし、壁と床・ベッド・机を描き分けた。主人公は床に立って窓を見上げる）
  dream(g, W, H, t, pt) { const r = cvRoom(g, W, H, t, { drone: 1 }); cvPlayer(g, Math.round(r.wx + r.ww / 2 - 2), Math.round(r.fy + 15), 1, t); },
  // 警察署へ裏帳簿を届ける
  police(g, W, H, t, pt) {
    const gy = Math.round(H * 0.72);
    cvSky(g, W, 0, gy, '#9ac8f0', '#e8f4ff');
    cvR(g, W * 0.3, gy - 56, W * 0.5, 56, '#c8ccd8'); cvR(g, W * 0.3, gy - 58, W * 0.5, 3, '#8a90a0');
    for (let i = 0; i < 5; i++) for (let j = 0; j < 3; j++) cvR(g, W * 0.33 + i * W * 0.09, gy - 50 + j * 14, W * 0.05, 8, '#5a7a9a');
    cvR(g, W * 0.5, gy - 20, 16, 20, '#4a4a5a'); cvR(g, W * 0.5 + 7, gy - 20, 1, 20, '#2a2a34');
    cvR(g, W * 0.46, gy - 30, 26, 7, '#2a4a8a'); g.fillStyle = '#ffffff'; for (let i = 0; i < 5; i++) cvR(g, W * 0.46 + 3 + i * 4.4, gy - 28, 3, 3, '#ffffff');
    if (Math.sin(t * 4) > 0) cvR(g, W * 0.46 + 11, gy - 34, 4, 3, '#ff3030'); else cvR(g, W * 0.46 + 11, gy - 34, 4, 3, '#3060ff');
    cvSky(g, W, gy, H, '#9aa0a8', '#7a8088'); for (let x = 0; x < W; x += 12) cvR(g, x, gy, 1, H - gy, '#8a9098');
    cvPerson(g, Math.round(W * 0.66), gy, 'cop', t);
    const k = Math.min(1, pt / 2.2), px = Math.round(W * 0.12 + k * W * 0.34); cvPlayer(g, px, gy, 3, t, k < 1);
    cvIcon(g, 'ledger', px + 6, gy - 9, 0.5);
  },
  news(g, W, H, t, pt) {
    cvR(g, 0, 0, W, H, '#3a2616'); for (let y = 0; y < H; y += 7) cvR(g, 0, y, W, 1, '#2e1e10');
    g.globalAlpha = 0.3; cvDisk(g, Math.round(W / 2), Math.round(H / 2), Math.round(Math.min(W, H) * 0.42), '#fff0c0'); g.globalAlpha = 1;
    cvPaper(g, W / 2, H * 0.46, t, clamp(pt / 1.2, 0, 1));
  },
  refund(g, W, H, t, pt) { END_PH.portDay(g, W, H, t, 3, { noPlayer: 1 }); cvCoins(g, W, H, t, 26, false); const hop = Math.abs(Math.sin(t * 5)) * 5; cvPlayer(g, Math.round(W * 0.48), Math.round(H * 0.52 + 8 - hop), 0, t); },   // v8f：プレイヤーは1人だけ（いかだと桟橋に分身していた）
  // ゲンの家族へ日誌を届ける（丘の家・夕方）
  family(g, W, H, t, pt) {
    const gy = Math.round(H * 0.7);
    cvSky(g, W, 0, gy, '#5a4a8a', '#ffb070'); cvSun(g, Math.round(W * 0.82), gy - 22, 10, '#ffd890', '#ffa860');
    cvSea(g, W, gy - 14, gy - 26, '#e08a6a', '#a06070', t, '#ffe0a0', 0.4);
    g.fillStyle = '#3a8a3e'; g.beginPath(); g.moveTo(0, gy - 10); g.quadraticCurveTo(W * 0.5, gy - 30, W, gy - 6); g.lineTo(W, H); g.lineTo(0, H); g.closePath(); g.fill();
    cvR(g, 0, gy, W, H - gy, '#2f7a34');
    const hx = Math.round(W * 0.2); cvR(g, hx, gy - 34, 34, 22, '#e8dcc0'); g.fillStyle = '#b04a3a'; g.beginPath(); g.moveTo(hx - 4, gy - 33); g.lineTo(hx + 17, gy - 48); g.lineTo(hx + 38, gy - 33); g.closePath(); g.fill();
    cvR(g, hx + 13, gy - 24, 8, 12, '#6a4a2a'); cvR(g, hx + 3, gy - 28, 7, 6, '#ffd86a'); cvR(g, hx + 24, gy - 28, 7, 6, '#ffd86a');
    for (let i = 0; i < 16; i++) { const fx = cvHash(i + 60) * W, fy = gy - 4 + cvHash(i + 70) * (H - gy); cvR(g, fx, fy, 2, 2, ['#ff8aa0', '#ffe060', '#ffffff', '#c890ff'][i % 4]); cvR(g, fx, fy + 2, 1, 2, '#1f5e2e'); }
    const mx = Math.round(W * 0.56); cvPerson(g, mx, gy - 2, 'mom', t, -1); cvPerson(g, mx - 9, gy - 2, 'kid', t, -1);
    const k = Math.min(1, pt / 1.8), px = Math.round(W * 0.9 - k * W * 0.2); cvPlayer(g, px, gy - 2, 2, t, k < 1);
    if (k >= 1) { cvR(g, px - 10, gy - 12, 5, 6, '#3a7a4a'); cvR(g, px - 10, gy - 12, 1, 6, '#2a5a3a'); cvR(g, px - 9, gy - 11, 3, 1, '#e8dcc0'); if (pt > 2.4) for (let i = 0; i < 2; i++) { const hy2 = gy - 26 - ((pt * 8 + i * 6) % 12); cvR(g, mx - 3 + i * 6, hy2, 2, 1, '#ff6a8a'); cvR(g, mx - 4 + i * 6, hy2 - 1, 1, 1, '#ff6a8a'); cvR(g, mx - 1 + i * 6, hy2 - 1, 1, 1, '#ff6a8a'); } }
  },
  museum(g, W, H, t, pt) {
    cvR(g, 0, 0, W, H, '#1a1626'); for (let x = 0; x < W; x += 16) cvR(g, x, 0, 1, H, '#221c30');
    const cx = Math.round(W / 2), gy = Math.round(H * 0.74);
    g.globalAlpha = 0.18; g.fillStyle = '#fff0c0'; g.beginPath(); g.moveTo(cx - 6, 0); g.lineTo(cx + 6, 0); g.lineTo(cx + 34, gy); g.lineTo(cx - 34, gy); g.closePath(); g.fill(); g.globalAlpha = 1;
    cvR(g, cx - 18, gy - 18, 36, 18, '#c8c0d0'); cvR(g, cx - 20, gy - 20, 40, 3, '#e8e0f0'); cvR(g, cx - 10, gy - 10, 20, 4, '#8a7a5a');
    cvIcon(g, 'turtle', cx, gy - 30, 1.6); cvSparkle(g, cx, gy - 30, t, '#fff2a8', 16);
    cvR(g, 0, gy, W, H - gy, '#2a2238'); for (let i = 0; i < 4; i++) cvR(g, cx - 40 + i * 24, gy + 1, 1, 6, '#c8a040');
    cvPerson(g, Math.round(W * 0.2), gy, 'old', t, 1); cvPerson(g, Math.round(W * 0.8), gy, 'kid', t, -1);
  },
  // 裏帳簿を突きつける
  ledgerShow(g, W, H, t, pt) {
    cvR(g, 0, 0, W, H, '#0e1428'); for (let i = 0; i < 14; i++) { const a = i / 14 * Math.PI * 2 + t * 0.3; g.globalAlpha = 0.12; g.fillStyle = '#ffe08a'; g.beginPath(); g.moveTo(W * 0.3, H * 0.5); g.lineTo(W * 0.3 + Math.cos(a) * W, H * 0.5 + Math.sin(a) * W); g.lineTo(W * 0.3 + Math.cos(a + 0.12) * W, H * 0.5 + Math.sin(a + 0.12) * W); g.closePath(); g.fill(); } g.globalAlpha = 1;
    const k = clamp(pt / 0.5, 0, 1); cvIcon(g, 'ledger', W * 0.3, H * 0.5, 1.5 + k * 2);
    const sh = pt > 0.8 ? Math.round(Math.sin(t * 40) * 1) : 0; const por = POR.same; if (por) g.drawImage(por, Math.round(W * 0.68 - 36 + sh), Math.round(H * 0.5 - 36), 72, 72);
    if (pt > 0.9) for (let i = 0; i < 3; i++) { const dy = ((pt * 30 + i * 8) % 24); cvR(g, W * 0.68 + 24 + i * 4, H * 0.5 - 30 + dy, 2, 3, '#8ad0ff'); }
    if (pt < 0.3) { g.globalAlpha = 1 - pt / 0.3; cvR(g, 0, 0, W, H, '#ffffff'); g.globalAlpha = 1; }
  },
  // 逮捕（パトカーの光）
  arrest(g, W, H, t, pt) {
    END_PH.portSame(g, W, H, t, 4, { night: true, people: false, raftAt: 1 });   // v8f：つないだいかだも映す
    const hy = Math.round(H * 0.52);
    cvPerson(g, Math.round(W * 0.56), hy + 8, 'same', t); cvPerson(g, Math.round(W * 0.56) + 10, hy + 8, 'cop', t); cvPerson(g, Math.round(W * 0.56) - 10, hy + 8, 'cop', t);
    cvR(g, W * 0.56 + 3, hy - 6, 4, 2, '#c8c8d0');
    const red = Math.sin(t * 9) > 0; g.globalAlpha = 0.1; cvR(g, 0, 0, W, H, red ? '#ff2020' : '#2040ff'); g.globalAlpha = 0.25; cvDisk(g, Math.round(W * 0.82 + 10), hy, 14, red ? '#ff3030' : '#3060ff'); g.globalAlpha = 1;
    cvR(g, W * 0.82, hy + 2, 24, 8, '#e8e8f0'); cvR(g, W * 0.82, hy + 6, 24, 3, '#1a1a22'); cvR(g, W * 0.82 + 8, hy - 1, 3, 3, red ? '#ff3030' : '#3060ff'); cvR(g, W * 0.82 + 12, hy - 1, 3, 3, red ? '#3060ff' : '#ff3030');
    if (pt > 1.5) { g.globalAlpha = clamp((pt - 1.5) / 3, 0, 0.5); cvSky(g, W, 0, hy, '#ff9a60', '#ffd8a0'); g.globalAlpha = 1; }
  },
  // D：黒い船が水平線に現れる（島の浜辺から見た海）
  shipCome(g, W, H, t, pt, o) {
    const near = o && o.near, k = near ? 1 : clamp(pt / 3, 0, 1);
    cvBeach(g, W, H, t, { sun: H * 0.3, skyT: '#6a7aa0', skyB: '#e8c8a8', seaT: '#4a7aa0', seaB: '#2a4a70', cloud: '#c8c8d8', drawSea: hy => cvBlackShip(g, Math.round(W * (0.62 - (near ? 0.06 : 0))), Math.round(hy + 3 + (near ? 10 : k * 2)), near ? 1 : 0.25 + k * 0.25, t) });
    const by = Math.round(H * 0.66), py = Math.round(by + (H - by) * 0.5); cvPlayer(g, Math.round(W * 0.42), py, 1, t);
    if (near) { const sx = Math.round(W * 0.56), sy = Math.round(H * 0.46 + 2); cvPerson(g, sx, sy, 'same', t); cvPerson(g, sx + 10, sy, 'thug', t); if (Math.sin(t * 2) > 0) { g.globalAlpha = 0.2; cvDisk(g, sx, sy - 10, 10, '#ffffff'); g.globalAlpha = 1; } }
  },
  shipNear(g, W, H, t, pt) { END_PH.shipCome(g, W, H, t, pt, { near: 1 }); },
  // D：マグロ船で遠くへ
  tuna(g, W, H, t, pt) {
    const hy = Math.round(H * 0.5); cvSky(g, W, 0, hy, '#3a3e4a', '#7a7e88'); cvRain(g, W, H, t, 30, 0.25);
    cvSea(g, W, H, hy, '#3a4a5a', '#1a2430', t, null, 1.6);
    cvIsland(g, Math.round(W * 0.14), hy + 1, 0.7, t, { sand: '#8a8a7a', sandD: '#6a6a5a', hill: '#3a4a3a', hillD: '#2a3a2a', trunk: '#3a3a30', leaf: '#3a4a3a', leafD: '#2a3a2a', rock: '#5a5a60' });
    const k = clamp(pt / 6, 0, 1), s = 1 - k * 0.6, bx = W * 0.6 + k * W * 0.2, by = hy + 10 - k * 8;
    g.save(); g.translate(Math.round(bx), Math.round(by)); g.scale(s, s); cvBoat(g, 0, 0, Math.sin(t * 1.5) * 0.06, t); cvR(g, -2, -20, 12, 4, '#14141c'); g.restore();
    const bx2 = (W * 0.3 + t * 10) % (W + 20) - 10, f = Math.sin(t * 8) > 0; cvR(g, bx2 - 3, 20 + (f ? 0 : 1), 3, 1, '#d8d8e0'); cvR(g, bx2, 20, 1, 1, '#d8d8e0'); cvR(g, bx2 + 1, 20 + (f ? 0 : 1), 3, 1, '#d8d8e0');
  },
};
// エンディングごとの場面（文の数と同じ並び）。endGame で追加の文が入る時は、その位置に場面も入れる
const END_SCENES = {   // v8f：A〜Eに振り直し（Gは削除）
  A: ['sail', 'portDay', 'dream'],
  B: ['sailGold', 'police', 'news', 'refund', 'family'],
  C: ['sailNight', 'portMeetNight', 'ledgerShow', 'arrest'],
  D: ['shipCome', 'shipNear', 'tuna'],
  E: ['sailNight', 'portArriveNight', 'portWaitNight', 'gps'],
};
const END_CONT = { portWaitNight: 1 };   // v8f：前の場面からそのまま続く場面（黒から始めない）
function drawEndPhase(g, W, H, name, t, pt) {
  const P2 = {
    sailGold: () => END_PH.sail(g, W, H, t, pt, { gold: 1 }), sailNight: () => END_PH.sail(g, W, H, t, pt, { night: 1 }),
  };
  if (P2[name]) P2[name](); else if (END_PH[name]) END_PH[name](g, W, H, t, pt); else END_PH.sail(g, W, H, t, pt);
  if (pt < 0.45 && !END_CONT[name]) { g.globalAlpha = 1 - pt / 0.45; cvR(g, 0, 0, W, H, '#000000'); g.globalAlpha = 1; }   // 場面の切り替わりは黒から（v8f：続きの場面はそのまま）
}

function endGame(id) {
  const E = ENDINGS[id], g = game;
  state.scene = 'ending'; Dialog.active = false; $('dialog').classList.add('hidden'); UI.closeAll();
  $('hud').classList.add('hidden'); $('hint').classList.add('hidden'); updateTouchVisibility(); stopFishing();
  // クリアしてもセーブは消さない（最後にセーブした所から遊び直せる）
  if (!g.demo && !settings.endings.includes(id)) { settings.endings.push(id); saveSettings(); }   // デモプレイは記録しない
  const lines = E.lines.slice();
  if (id === 'B' && has('turtle')) lines.push('黄金の亀像は博物館に寄贈され、\n「漂流者の守り神」として今も人々を見守っている。');   // v8f：TRUE END は B
  const good = id === 'A' || id === 'B' || id === 'C', ratio = g.contract.free ? 1 : g.day / g.contract.days;   // v8f：A〜Cがよいエンディング
  let score = id === 'B' ? 3 : good ? 2 : 0;   // v8f：TRUE END（B）は3点
  if (good) score += ratio <= 0.6 ? 2 : ratio <= 0.8 ? 1 : 0;   // v6.1c：コメントの中に入って動いていなかった「早さのボーナス」を戻した
  if (g.flags.bossDown) score += 1;   // v5：地下2階のボスを倒すとボーナス
  const rank = score >= 5 ? 'S' : score >= 4 ? 'A' : score >= 2 ? 'B' : 'C';
  sfx(good ? 'unlock' : 'hurt');
  // v8e：エンディングムービー。種類ごとの場面（島の背景つき）に字幕を重ね、最後に結果を出す
  const phases = (END_SCENES[id] || ['sail']).slice();
  if (id === 'B' && has('turtle')) phases.push('museum');   // v8f
  while (phases.length < lines.length) phases.push(phases[phases.length - 1]);
  const ED = 3.4;   // 1つの文（場面）の長さ（秒）
  UI.open({ cls: 'dark end-movie', onBack: () => {}, render: el => {
    const cv = h('canvas', { class: 'end-cv' }), sub = h('div', { class: 'end-sub' }), sk = h('button', { class: 'cine-skip', type: 'button', tabindex: '-1' }, 'スキップ ▶▶');
    const res = h('div', { class: 'end-result' },
      h('div', { class: 'end-res-l' }, h('div', { class: 'etype' }, E.type), h('div', { class: 'etitle' }, E.title), h('div', { class: 'erank-l' }, 'RANK'), h('div', { class: 'rank' }, rank)),
      h('div', { class: 'end-res-r' },
        h('div', { class: 'stats' }, `経過日数：${g.day}日` + (g.contract.free ? '（期限なし）' : ` / ${g.contract.days}日`), h('br'), `総売上：${fmt$(g.stats.earned || 0)}`, h('br'), `支払った利息：${fmt$(g.interestPaid)}`, h('br'),
          `採集した数：${g.stats.gathered || 0}　クラフト：${g.stats.crafted || 0}`, h('br'), `ギャンブル収支：${fmtNet(g.stats.gamble || 0)}`, h('br'), `残った借金：${fmt$(Math.max(0, g.debt))}`),
        h('div', null, btn('もう一度ながめる', () => { t0 = performance.now(); cur = -1; done = false; res.classList.remove('on'); cv.classList.remove('dim'); sub.classList.remove('out'); el.appendChild(sk); state.endSkip = skip; }, { key: 'replay' }), btn('タイトルへ', () => { state.endSkip = null; showTitle(); }, { key: 'title', cls: 'primary' }))));
    el.appendChild(cv); el.appendChild(sub); el.appendChild(res); el.appendChild(sk);
    const g2 = cv.getContext('2d'), total = lines.length * ED;
    let t0 = performance.now(), cur = -1, done = false;
    const skip = () => { t0 = performance.now() - total * 1000; };
    state.endSkip = skip;
    sk.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); skip(); });
    const loop = now => {
      if (!cv.isConnected) { if (state.endSkip === skip) state.endSkip = null; return; }
      const t = (now - t0) / 1000, li = clamp(Math.floor(t / ED), 0, lines.length - 1);
      try { CV.fit(cv); g2.imageSmoothingEnabled = false; drawEndPhase(g2, CV.W, CV.H, phases[li], t, t - li * ED); } catch (er) { console.error(er); }
      if (t < total && li !== cur) { cur = li; sub.innerHTML = ''; sub.appendChild(h('p', null, fmtText(lines[li]))); }
      if (t >= total && !done) { done = true; sub.classList.add('out'); cv.classList.add('dim'); res.classList.add('on'); sk.remove(); if (state.endSkip === skip) state.endSkip = null; L0.focusKey = 'title'; }
      requestAnimationFrame(loop);
    };
    const L0 = UI.top() || {};
    requestAnimationFrame(loop);
  } });
}

/* ---------- 19. ゲームの処理 ---------- */
function hourOf(t) { return t < CONFIG.dayPart ? 6 + t * (14 / CONFIG.dayPart) : 20 + (t - CONFIG.dayPart) * (10 / (CONFIG.dayLength - CONFIG.dayPart)); }
function clockText(t) { const h = hourOf(t) % 24, hh = Math.floor(h), mm = Math.floor((h - hh) * 6) * 10; return `${hh}:${String(mm).padStart(2, '0')}`; }
function darkness(h) {
  h = h % 24;
  if (h >= 7 && h < 17.5) return 0;
  if (h >= 17.5 && h < 20) return (h - 17.5) / 2.5 * 0.82;
  if (h >= 20 || h < 5) return 0.82;
  return 0.82 * (1 - (h - 5) / 2);
}
const duskAmt = h => clamp(1 - Math.abs((h % 24) - 18.2) / 1.6, 0, 1);
const isNight = () => darkness(hourOf(game.time)) > 0.5;

function rectBlocked(x, y) {
  const m = curMap(), l = x - 5, r = x + 5, t = y - 5, b = y;
  for (let ty = Math.floor(t / 16); ty <= Math.floor((b - 0.01) / 16); ty++) for (let tx = Math.floor(l / 16); tx <= Math.floor((r - 0.01) / 16); tx++) if (isBlocked(m, tx, ty)) return true;
  return false;
}
function tryMove(dx, dy) {
  if (state.noclip) { const m = curMap(); player.x = clamp(player.x + dx, 6, m.W * 16 - 6); player.y = clamp(player.y + dy, 6, m.H * 16 - 1); return; }   // v6a：デバッグの壁貫通（地図の外には出ない）
  if (dx) { const nx = player.x + dx; if (!rectBlocked(nx, player.y)) player.x = nx; else if (!dy) { for (const s of [3, -3, 6, -6]) if (!rectBlocked(player.x, player.y + s) && !rectBlocked(nx, player.y + s)) { player.y += Math.sign(s) * Math.min(Math.abs(dx), 1.5); break; } } }
  if (dy) { const ny = player.y + dy; if (!rectBlocked(player.x, ny)) player.y = ny; else if (!dx) { for (const s of [3, -3, 6, -6]) if (!rectBlocked(player.x + s, player.y) && !rectBlocked(player.x + s, ny)) { player.x += Math.sign(s) * Math.min(Math.abs(dy), 1.5); break; } } }
}

// v6a：壁貫通をOFFにした時、壁の中にいたら近くの歩ける所へ出す
function unstickPlayer() {
  if (!rectBlocked(player.x, player.y)) return;
  for (let r = 4; r <= 240; r += 4) for (let a = 0; a < 24; a++) { const x = player.x + Math.cos(a / 24 * Math.PI * 2) * r, y = player.y + Math.sin(a / 24 * Math.PI * 2) * r; if (!rectBlocked(x, y)) { player.x = x; player.y = y; return; } }
}
function findTarget() {
  const m = curMap(), [vx, vy] = DIRV[player.dir];
  const fx = player.x + vx * 11, fy = player.y - 4 + vy * 11, ftx = Math.floor(fx / 16), fty = Math.floor(fy / 16);
  const ptx = Math.floor(player.x / 16), pty = Math.floor((player.y - 3) / 16);
  const usable = o => o && (OBJ[o.t].g || OBJ[o.t].it || OBJ[o.t].regrowInfo);
  let o = objAt(m, ftx, fty); if (usable(o)) return { kind: 'obj', o };
  o = objAt(m, ptx, pty); if (usable(o) && !OBJ[o.t].block) return { kind: 'obj', o };
  const v = tileAt(m, ftx, fty);
  if (v === T.SPRING) return { kind: 'spring' };
  if (isWater(v) && game.map === 'island') return { kind: 'water', tx: ftx, ty: fty };
  // 近くの拾える物（タッチ操作の補助）
  let best = null, bd = 15;
  for (let ty = pty - 1; ty <= pty + 1; ty++) for (let tx = ptx - 1; tx <= ptx + 1; tx++) {
    const c = objAt(m, tx, ty); if (!usable(c) || OBJ[c.t].block) continue;
    const d = Math.hypot(c.x * 16 + 8 - fx, c.y * 16 + 10 - fy); if (d < bd) { bd = d; best = c; }
  }
  return best ? { kind: 'obj', o: best } : null;
}
function targetHint(tg) {
  if (!tg) return null;
  const hw = () => atkWillUse();   // v6.1a：自動で持ち替える武器・道具も表示（剣 ＞ 斧・つるはし ＞ 素手）
  if (tg.kind === 'mob') { const wk = hw(); return { act: `${MOBS[tg.m.type].n}を攻撃`, sub: wk ? TOOLS[wk].n : '素手', atk: 1 }; }
  if (tg.kind === 'boss') { const wk = hw(); return { act: `${BOSS.name}を攻撃`, sub: wk ? TOOLS[wk].n : '素手', atk: 1 }; }
  if (tg.kind === 'spring') return has('bowl') ? { act: '泉の水を汲む', sub: `木の器×${game.inv.bowl}` } : { act: null, info: '泉：木の器があれば水を汲める（作業台のクラフトで作れる）' };
  if (tg.kind === 'water') return !heldTool('rod') ? (game.tools.rod ? { act: null, info: '釣り竿を手に持つと釣りができる（アイテムバーで選ぶ）' } : null) : game.weather === 'storm' ? { act: null, info: '嵐で海が荒れていて、釣りができない' } : { act: '釣りをする' };
  const o = tg.o, d = OBJ[o.t];
  if (d.it === 'drop') { const nm = `${itemName(o.id)}×${o.n}`; return o.lock > 0 ? { act: null, info: `${nm}（あと${Math.ceil(o.lock)}秒で拾える）` } : { act: `${nm}を拾う`, sub: game.up.magnet ? '長押しで連続' : null }; }
  if (d.regrowInfo) { const n = Math.max(1, (o.r || game.day + 1) - game.day); return { act: null, info: `${d.n}（${n}日後に回復）` }; }
  if (d.g) {
    const g = d.g;
    if (g.special === 'palm' && !(o.n > 0)) return { act: null, info: 'ヤシの実はまだない（毎日実る）' };
    if (g.special === 'bush' && !(o.n > 0)) return { act: null, info: 'ベリーはまだない（明日また実る）' };
    const hi = g.cat && settings.autoTool ? hotbarTool(g.cat, g.need) : -1, hiT = hi >= 0 ? game.slots[hi].id : null;
    const lv = g.cat ? Math.max(toolLv(g.cat), hiT ? TOOLS[hiT].lv : 0) : 0;
    if (g.need && lv < g.need) return { act: g.act, ng: (g.need >= 2 ? '鉄のつるはしが必要' : 'つるはしが必要') + (toolInBag(g.cat) ? '（アイテムバーに入れると使える）' : '') };
    const tool = g.cat ? (heldTool(g.cat) && TOOLS[heldTool(g.cat)].lv >= (hiT ? TOOLS[hiT].lv : 0) ? heldTool(g.cat) : hiT) : null;
    return { act: g.act, sub: tool ? TOOLS[tool].n : g.instant && game.up.magnet ? '長押しで連続' : null, gather: !g.instant, lmb: !!g.cat && !g.instant };   // v6.2：lmb＝左クリックでもできる
  }
  if (d.it === 'station') { const q = o.q && o.q.length, out = o.out && Object.keys(o.out).length; return { act: out ? 'できあがりを受け取る' : d.act, sub: out ? null : q ? `加工中 残り${q}` : null }; }   // v6.2
  if (d.it === 'raft') return { act: game.raftBuilt ? 'いかだに乗る' : 'いかだを作る' };
  if (d.it === 'bed') return { act: '眠る', sub: isNight() || hourOf(game.time) >= 17 ? null : '夕方から眠れる' };
  return { act: d.act };
}

// frozen=true：持ち物・クラフト・地図などのメニューを開いている間（時間は進むが、操作は受け付けない）
function gameUpdate(dt, frozen) {
  const g = game, inCave = g.map === 'cave' || g.map === 'cave2', inHouse = g.map === 'house', TS = !!state.timeStop;   // v7c：inHouse＝木造の家の中
  // v6a：体力0の判定は、自然回復より先に行う（ボスなどの攻撃で体力がちょうど0になった後、回復で0.002に戻って倒れない不具合の修正）
  if (g.hp <= 0 && !state.god) { faint(); return; }
  // 時間（v6a：デバッグの時間停止中は、時計が止まる）
  if (!TS) g.time += dt;
  state.dirty = true;
  if (g.time >= CONFIG.dayLength) { if (UI.isOpen()) UI.closeAll(); g.time = 0; newDay('natural'); if (state.scene !== 'play') return; }
  const hr = hourOf(g.time), dk = darkness(hr);
  // v8c：天気は6時と18時の1日2回変わる（6時は日付が変わる時）
  if (hr >= 18 && g.wHalf !== g.day) {
    g.wHalf = g.day; const pw = g.weather; g.weather = rollWeather(pw);
    if (g.weather !== pw && !inCave && !inHouse) toast(`天気が変わった：${WEATHER[pw].n} → ${WEATHER[g.weather].n}`, g.weather === 'storm' || g.weather === 'snow' ? 'bad' : '');
    if (surfTonight(true) && !inHouse) setTimeout(() => { if (state.scene === 'play') { toast('今夜は、洞窟の魔物が地上に出てきそうな気配がする……', 'bad'); sfx('warn'); } }, 1500);
  }
  if (!g.flags.firstNight && dk > 0.4 && !inCave && !inHouse) { g.flags.firstNight = 1; queueTalk(TALK.firstNight); }
  // 生存（天気・健康状態）
  const SV = CONFIG.survival[g.mode === 'hard' ? 'hard' : 'normal'];
  const out = !inCave && !inHouse;   // v7c：家の中は天気・寒さの影響なし（常に快適）
  const mul = inCave ? SV.cave : inHouse ? CONFIG.house.drain : 1, nf = out && nearFire();
  const raining = out && (g.weather === 'rain' || g.weather === 'storm');
  const hot = out && g.weather === 'sun' && hr >= 11 && hr < 15;
  const shel = out && nearHut();
  const wet = raining && !nf && !shel;
  g.sick = Math.max(0, (g.sick || 0) - dt);
  if (!TS) { g.hunger = Math.max(0, g.hunger - SV.h * dt * mul * (g.sick > 0 ? 1.5 : 1)); g.thirst = Math.max(0, g.thirst - SV.t * dt * mul * (hot ? SV.hot : 1)); }
  let hpd = 0; if (!TS && g.hunger <= 0) hpd -= 0.6; if (!TS && g.thirst <= 0) hpd -= 0.6;
  const cold = out && (dk > 0.5 || g.weather === 'snow') && !nf && !shel;   // v8c：雪の日は昼も寒い
  if (cold && !TS) hpd -= wet ? 0.3 : 0.15;
  // v6a：自然回復は毎秒+0.5（空腹と渇きがどちらも50より上で、寒さのダメージを受けていない時）
  // v7a：空腹・渇きが両方90以上なら毎秒+1。「幸福」の間は2倍
  if (hpd === 0 && g.hp > 0 && g.hunger > 50 && g.thirst > 50) hpd = (g.hunger >= 90 && g.thirst >= 90 ? 1 : 0.5) * (g.happy > 0 ? 2 : 1);
  g.hp = clamp(g.hp + hpd * dt, 0, 100);
  updatePoison(dt);   // v6.1c：毒
  if (state.god) { g.hp = 100; g.hunger = Math.max(g.hunger, 80); g.thirst = Math.max(g.thirst, 80); }
  survivalWarnings(cold);
  if (!TS) updateWeather(dt, inCave || inHouse);   // v7c：家の中は雨水も雷もなし
  state.conds = conditions(cold, wet, hot); state.condFlags = { cold, wet, hot };   // v6.2：ステータス画面の説明用
  if (g.hp <= 0) { faint(); return; }
  // 移動
  const weak = g.hunger < 20 || g.thirst < 20;
  const stunned = state.pstun > 0;   // v6.1b：スタン中は動けない
  let [mx, my] = frozen || stunned ? [0, 0] : Input.moveVec(); const ml = Math.hypot(mx, my);
  player.moving = false;
  if (ml > 0.12) {
    if (state.fishing) stopFishing('moved');
    player.dir = Math.abs(mx) > Math.abs(my) ? (mx > 0 ? 3 : 2) : (my > 0 ? 0 : 1);
    setFace8(mx, my);   // v8d：8方向の向き
    if (g.stamina <= 0) g.exhaust = true;
    const dashing = !frozen && (Input.down('DASH') || Input.down('B')) && !g.exhaust;
    const sp = 72 * (weak ? 0.8 : 1) * (g.hp < 25 ? 0.85 : 1) * (dashing ? 1.55 : 1) * (g.awake > 0 ? 1.3 : 1) * (onLadder() ? 0.65 : 1);   // v6a：覚醒中は移動+30%。v6c：縄梯子の上はゆっくり
    tryMove(mx * sp * dt * (state.dbgSpd || 1), my * sp * dt * (state.dbgSpd || 1));   // v8a：デバッグの移動速度
    player.moving = true; player.anim += dt * 7 * Math.min(1, ml) * (dashing ? 1.4 : 1);   // v8d：歩きのアニメ。v8aの行にコメントが巻き込まれて消えていたのを戻した
    if (dashing) { g.stamina = Math.max(0, g.stamina - stCost(20 * dt)); state.stIdle = 0; }
  }
  // スタミナの回復（少し休むと戻る）
  if (g.exhaust && g.stamina >= 25) g.exhaust = false;
  state.stIdle += dt;
  if (state.stIdle > 0.6) g.stamina = Math.min(100, g.stamina + 16 * dt * (wet ? 0.6 : 1) * (g.sick > 0 ? 0.5 : 1) * (weak ? 0.5 : 1) * (g.awake > 0 ? 1.25 : 1));   // v6a：覚醒中は回復+25%
  if (state.infSt) { g.stamina = 100; g.exhaust = false; }   // v6a：デバッグのスタミナ無限
  // v6a：覚醒（プロテイン）の残り時間。ポーズ中は止まる
  if (g.awake > 0) { g.awake = Math.max(0, g.awake - dt); if (g.awake <= 0) { sfx('ui'); toast('覚醒の効果が切れた'); } }
  if (g.happy > 0) { g.happy = Math.max(0, g.happy - dt); if (g.happy <= 0) { sfx('ui'); toast('幸福の効果が切れた'); } }   // v7a
  revealCave();   // v6a：洞窟の地図は、歩いた周りだけ広がる
  if (!g.flags.cliffHint && g.map === 'island' && player.moving) { const [vx, vy] = DIRV[player.dir]; if (tileAt(maps.island, Math.floor((player.x + vx * 10) / 16), Math.floor((player.y - 4 + vy * 10) / 16)) === T.CLIFF) { g.flags.cliffHint = 1; toast('切り立った崖だ。縄梯子（クラフト）を掛ければ登れそうだ'); } }   // v6c
  // 操作（メニューを開いている間は受け付けない）
  if (!frozen) {
  if (Input.press('START')) { openPause(); return; }
  if (Input.press('X')) { openMainMenu('inv'); return; }   // v6.2：X＝持ち物
  if (Input.press('INV')) { openMainMenu('inv'); return; }
  if (Input.press('CRAFT')) { openMainMenu('craft'); return; }
  if (Input.press('MAP')) { openMainMenu('map'); return; }
  if (Input.press('ZENI')) { callZeni(); return; }   // v8b。v8c：コントローラーは−（セレクト）ボタン
  for (let i = 1; i <= CONFIG.hotSize; i++) if (Input.press('H' + i)) hotSelect(i - 1);
  if (Input.press('LB')) hotSelect(g.hotSel - 1);
  if (Input.press('RB')) hotSelect(g.hotSel + 1);
  if (Input.press('DROPALL') || Input.press('DROP')) {
    const sl = heldSlot();
    if (!sl) { sfx('error'); toast(`アイテムバー${g.hotSel + 1}番は空です`); }
    else dropFromSlot(g.hotSel, Input.press('DROPALL') ? sl.n : 1);
  }
  if (Input.press('Y') && !stunned) useSelected(true);
  if (Input.press('OFF')) swapOffhand();   // v6b：Fキー
  if (state.fishing) updateFishing(dt);
  else if (!stunned) updateInteraction(dt);   // v6.1b：スタン中は攻撃・調べるもできない
  }
  updateMiners(dt);   // v7b：自動採掘機（どのマップにいても動く）
  updateLumbers(dt);   // v8b：自動伐採機（どのマップにいても動く）
  updateZeni(dt);   // v8b：ついてくるゼニ丸
  updateHouse();   // v7c：木造の家（建設・出入り）
  // 設備の加工
  for (const o of stations) if (o.q && o.q.length) {
    o.q[0].left -= dt;
    if (o.q[0].left <= 0) { const job = o.q.shift(), rec = findProc(OBJ[o.t].st, job.id); o.out = o.out || {}; o.out[rec.out] = (o.out[rec.out] || 0) + (rec.n || 1); if (rec.ret) for (const k in rec.ret) o.out[k] = (o.out[k] || 0) + rec.ret[k]; }
  }
  // 生き物・敵
  state.rawCd = Math.max(0, (state.rawCd || 0) - dt);   // v6.2：生水を飲む間
  state.invuln = Math.max(0, state.invuln - dt); state.swing = Math.max(0, state.swing - dt); state.pstun = Math.max(0, (state.pstun || 0) - dt);
  updateMobs(dt);
  updateArrows(dt);   // v8c：飛んでいる矢
  // 落とし物：拾えるまでの待ち時間
  for (const k in maps) for (const o of maps[k].objs) if (o.t === 'drop' && o.lock > 0) o.lock = Math.max(0, o.lock - dt);
  state.dropT = (state.dropT || 0) + dt; if (state.dropT >= 0.5) { state.dropT = 0; expireDrops(); }   // v6.2：丸1日たった落とし物は消える
  if (state.hotName > 0) state.hotName -= dt;
  // たいまつ：手に持っている間だけ燃える（ポーズ中・会話中は止まる。メニューを開いている間は時間と一緒に進む）
  updateBoss(dt);
  updateHoldUse();
  const tsl = heldSlot(); if (tsl && tsl.id === 'torch') { tsl.dur -= dt; if (tsl.dur <= 0) { breakHeld(tsl); syncInv(); } }
  else if (g.off && g.off.id === 'torch') {   // v6b：左手のたいまつも、手に持っている時と同じように燃える
    const o = g.off; o.dur -= dt;
    if (o.dur <= 0) { if (o.n > 1) { o.n--; o.dur = Math.max(0.01, o.dur + TOOLS.torch.dur); toast(`左手のたいまつが燃え尽きた（残り${o.n}本）`); } else { g.off = null; toast('左手のたいまつが燃え尽きた！', 'bad'); sfx('error'); } }
  }
  // 相場の回復
  const rec = 1 - Math.exp(-dt * (TS ? 0 : 0.0115));
  for (const k in g.market.m) { g.market.m[k] += (1 - g.market.m[k]) * rec; if (g.market.m[k] > 0.995) delete g.market.m[k]; }
  // 洞窟の落石
  if (inCave && g.map === 'cave') {
    state.rockTimer -= dt;
    if (state.rockTimer <= 0) { state.rockTimer = rnd(12, 26); state.rocks.push({ x: player.x, y: player.y - 3, t: 1.2 }); sfx('warn'); }
  }
  for (let i = state.rocks.length - 1; i >= 0; i--) {
    const r = state.rocks[i]; r.t -= dt;
    if (r.t <= 0) {
      state.rocks.splice(i, 1); burst(r.x, r.y, P.stone, 8); sfx('thud');
      if (Math.hypot(player.x - r.x, player.y - 3 - r.y) < 11) { g.hp = Math.max(0, g.hp - 10); state.shake = 0.3; sfx('hurt'); toast('落石が当たった！ 体力-10', 'bad'); }
      const m = curMap(), tx = Math.floor(r.x / 16), ty = Math.floor(r.y / 16);
      if (g.map === 'cave' && !objAt(m, tx, ty) && tileAt(m, tx, ty) === T.CFLOOR && chance(0.5)) addObj(m, { t: 'pebble', x: tx, y: ty });
    }
  }
  if (g.flags.diary2 && !g.flags.objShown) g.flags.objShown = 1;
  // 返済状況のイベント
  checkMilestones();
  // オートセーブ
  state.autosave += dt; if (state.autosave > CONFIG.autosaveSec) { state.autosave = 0; saveGame(true); }
}
// v6.2：カジノを開いているか
const casinoOpen = () => UI.stack.some(l => l.casino);
function nearFire() { const m = curMap(); for (const o of stations) if (o.t === 'campfire' && m.objs.includes(o) && Math.hypot(o.x * 16 + 8 - player.x, o.y * 16 + 10 - player.y) < 60) return true; return false; }
// 健康状態（HUDに表示）
function conditions(cold, wet, hot) {
  const g = game, c = [];
  if (g.hp < 25) c.push(['重傷', 'bad']);
  if (cold) c.push(['寒い', 'bad']);
  if (wet) c.push(['濡れ', 'bad']);
  if (hot) c.push(['暑い', 'warn']);
  if (g.sick > 0) c.push(['腹痛', 'bad']);
  if (g.hunger < 20) c.push(['空腹', 'bad']);
  if (g.thirst < 20) c.push(['脱水', 'bad']);
  if (g.exhaust) c.push(['息切れ', 'warn']);
  if (g.poison > 0) c.unshift([`毒 ${Math.ceil(g.poison)}秒`, 'poison']);   // v6.1c
  if (!c.length) c.push(['快適', 'ok']);
  if (g.happy > 0) { const sec = Math.ceil(g.happy); c.unshift([`幸福 ${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`, 'buff']); }   // v7a
  if (g.awake > 0) { const sec = Math.ceil(g.awake); c.unshift([`覚醒 ${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`, 'buff']); }   // v6a：覚醒だけ残り時間を出す
  return c;
}
// v6a：スタミナの消費（覚醒中は半分）
const stCost = n => n * (game && game.awake > 0 ? 0.5 : 1);
// 天気：雨水・雷
function updateWeather(dt, inCave) {
  const g = game, w = g.weather;
  if (w !== 'rain' && w !== 'storm') return;
  // v6.2：雨水がたまるのは1日に最大2回（時刻はランダム）。以前は20秒（嵐は12秒）ごとで、多すぎた
  let rp = g.rainPlan;
  if (!rp || rp.day !== g.day || !Array.isArray(rp.at)) {
    const t0 = Math.min(g.time + 3, CONFIG.dayLength - 2), at = [];
    for (let i = 0; i < CONFIG.rainCatchMax; i++) at.push(rnd(t0, CONFIG.dayLength - 1));
    rp = g.rainPlan = { day: g.day, at: at.sort((a, b) => a - b), n: 0 };
  }
  while (rp.n < rp.at.length && g.time >= rp.at[rp.n]) {
    rp.n++;
    if (inCave || casinoOpen()) continue;   // 洞窟やカジノ船の中では、たまらない（その回は終わり）
    if (has('bowl')) { takeItem('bowl', 1); addItem('cleanwater', 1, true); sfx('drink'); toast('木の器に雨水がたまった（きれいな水）', 'good'); }
  }
  if (inCave) return;
  if (w === 'storm') {
    state.boltT -= dt;
    if (state.boltT <= 0) {
      state.boltT = rnd(10, 22); state.flash = 0.35; sfx('thud');
      const hit = chance(0.1) && !casinoOpen();
      state.bolt = { x: hit ? player.x : player.x + rnd(-150, 150), y: hit ? player.y - 4 : player.y + rnd(-90, 90), t: 0.45, seed: Math.random() * 1000 };   // v8c：稲妻を描く
      if (hit) { g.hp = Math.max(0, g.hp - 12); state.shake = 0.5; state.zap = 3; sfx('hurt'); floatText(player.x, player.y - 24, '-12', '#ffe14a'); toast('雷に打たれた！ 体力-12（しびれている……）', 'bad'); }
    }
  }
}
// v6.1c：毒を受ける（重ねて受けても残り時間は最大まで）
function poisonPlayer() {
  const g = game, first = !(g.poison > 0); g.poison = CONFIG.poison.sec;
  floatText(player.x, player.y - 30, '毒！', '#b6f07a'); burst(player.x, player.y - 10, '#9be36a', 6);
  if (!g.flags.firstPoison) { g.flags.firstPoison = 1; toast(`毒を受けた！ ${CONFIG.poison.every}秒ごとに体力が${CONFIG.poison.dmg}減る（${CONFIG.poison.sec}秒で治る・救急キットでも治る）`, 'bad'); }
  else if (first) toast('毒を受けた！', 'bad');
}
// 残り時間が「every秒の区切り」を越えるたびにダメージ（10秒なら5回＝15）。毒では体力1より下がらない（体力1なら減らない）
function updatePoison(dt) {
  const g = game, P = CONFIG.poison; if (!(g.poison > 0)) { g.poison = 0; return; }
  const prev = g.poison; g.poison = Math.max(0, prev - dt);
  const ticks = Math.ceil(prev / P.every - 1e-9) - Math.ceil(g.poison / P.every - 1e-9);
  for (let i = 0; i < ticks; i++) {
    if (state.god || g.hp <= 1) continue;
    const before = g.hp; g.hp = Math.max(1, g.hp - P.dmg); const lost = Math.round(before - g.hp);
    if (lost > 0) { floatText(player.x + rnd(-4, 4), player.y - 22, `-${lost}`, '#b6f07a'); sfx('poison'); }
  }
  if (Math.random() < dt * 5) burst(player.x + rnd(-4, 4), player.y - 12, '#9be36a', 1);
  if (g.poison <= 0) { toast('毒が治った', 'good'); sfx('ui'); }
}
function survivalWarnings(cold) {
  const g = game, w = state.warn;
  const chk = (key, cond, reset, msg) => { if (cond && !w[key]) { w[key] = 1; toast(msg, 'bad'); sfx('warn'); } else if (reset) w[key] = 0; };
  chk('hunger', g.hunger < 25, g.hunger > 40, `お腹が空いてきた……（食べ物を持って${Input.mode === 'key' ? '右クリック' : keyLabel('Y') + 'ボタン'}で食事）`);
  chk('thirst', g.thirst < 25, g.thirst > 40, '喉が渇いた……泉の水を汲んで、焚き火でろ過しよう');
  chk('stamina', g.exhaust, !g.exhaust, '息が切れた……少し休もう');
  chk('hp', g.hp < 30, g.hp > 45, '体力が危ない！ 休むか、食事をとろう');
  chk('cold', cold && g.hp < 90, !cold, '体が冷える……焚き火のそばへ行こう');
}
function updateInteraction(dt) {
  const tg = findTarget(); state.target = tg;
  state.holdCd = Math.max(0, state.holdCd - dt); state.drinkCd = Math.max(0, state.drinkCd - dt); state.capToast = Math.max(0, state.capToast - dt);
  const aDown = Input.down('A'), aPress = Input.press('A');
  state.atkCd = Math.max(0, state.atkCd - dt);
  // v6b：PCは左クリックで攻撃。コントローラーとスマホは今まで通りAで攻撃
  // v6.2：攻撃の向きはマウスではなく、WASDで向いている方向。Spaceでも攻撃できる。左クリックで採掘・伐採もできる（拾う・採取はSpaceだけ）
  const keyM = Input.mode === 'key', padM = Input.mode === 'pad', atkP = Input.press('ATK') || (padM && Input.press('ZR')), atkD = (!!state.lmb && keyM) || (padM && !!Input.pad.ZR);   // v8c：コントローラーはZRで攻撃・採掘
  const wantAtk = keyM ? (atkP || atkD || aPress || aDown) : padM ? (atkP || atkD) : (aPress || aDown);
  if (heldTool('bow') && wantAtk && state.atkCd <= 0 && (atkP || aPress || (keyM && atkD))) { if (shootArrow()) return; }   // v8c：弓
  if (state.boss && game.map === 'cave2' && bossInFront()) { state.target = { kind: 'boss' }; state.gather.o = null; if (wantAtk && state.atkCd <= 0) { autoWeapon(); attackBoss(); } return; }
  const mob = mobInFront();
  if (mob) { state.target = { kind: 'mob', m: mob }; state.gather.o = null; if (wantAtk && state.atkCd <= 0) { autoWeapon(); attackMob(mob); } return; }
  const chopT = (keyM || padM) && tg && tg.kind === 'obj' && OBJ[tg.o.t] && OBJ[tg.o.t].g && OBJ[tg.o.t].g.cat && !OBJ[tg.o.t].g.instant;   // 左クリックで掘れる・切れる物
  if (keyM && atkP && state.atkCd <= 0 && !chopT) { state.swing = 0.15; state.atkCd = 0.3; }   // v6b：何もない所を左クリック＝空振り（スタミナは減らない）
  // 足元の落とし物も拾える（目の前に拾える物がない時）
  if (aPress && (!tg || (tg.kind === 'obj' && OBJ[tg.o.t] && (OBJ[tg.o.t].regrowInfo || (!OBJ[tg.o.t].g && !OBJ[tg.o.t].it))))) {
    const [px, py] = playerTile(), fd = objAt(curMap(), px, py);
    if (fd && fd.t === 'drop') { pickDrop(fd, true); return; }
  }
  if (!tg) { state.gather.o = null; if (keyM && aPress) useHeal(); return; }   // v6b：何もない所でSpace＝手に持った回復アイテムを使う
  if (tg.kind === 'spring') { if (aPress && !(state.drinkCd > 0)) drink(); return; }   // v6.2：汲むのにも少し間をあける
  if (tg.kind === 'water') { if (aPress && heldTool('rod')) startFishing(tg); return; }
  const o = tg.o, d = OBJ[o.t];
  if (d.g) {
    const g = d.g;
    // 拾い物は1回押すごとに1つ。アイテム回収機があれば長押しで連続回収
    if (g.instant) { if (aPress || (game.up.magnet && aDown && state.holdCd <= 0)) { state.holdCd = 0.22; if (aPress || state.lastInstant !== o) gatherDone(o, g, 0); } return; }
    const lmbG = (keyM || padM) && !!g.cat, gPress = (padM && g.cat ? false : aPress) || (lmbG && atkP), gDown = (padM && g.cat ? false : aDown) || (lmbG && atkD);   // v6.2：左クリックでも採掘・伐採。v8c：コントローラーの採掘・伐採はZR（Aは調べる・拾う）
    if (g.cat && (gPress || gDown) && settings.autoTool) autoTool(g.cat, g.need || 0);   // アイテムバーの適した道具へ自動で持ち替え（v6b：設定でOFFにできる）
    const lv = g.cat ? toolLv(g.cat) : 0;
    if (g.need && lv < g.need) { state.gather.o = null; if (gPress) { sfx('error'); toast(!settings.autoTool && hotbarTool(g.cat, g.need) >= 0 ? 'つるはしを手に持とう（自動切り替えはOFF）' : toolInBag(g.cat) ? 'つるはしをアイテムバーに入れると使える（持ち物画面で移動）' : g.need >= 2 ? '鉄のつるはしが必要だ' : 'つるはしが必要だ（クラフトで作れる）', 'bad'); } return; }
    if (g.special === 'palm' && !(o.n > 0)) { if (aPress) { sfx('error'); toast('ヤシの実はまだなっていない'); } return; }
    if (!gDown) { state.gather.o = null; return; }
    // v7a：持ち物がいっぱいでも採集できる（入りきらない分は gatherDone で足元に置く）。拾うだけの物は今までどおり
    const interval = (lv >= 2 ? 0.25 : lv === 1 ? 0.3 : 0.42) * ((game.hunger < 20 || game.thirst < 20) ? 1.4 : 1) * (game.stamina <= 0 ? 1.6 : 1);
    const gs = state.gather;
    if (gs.o !== o) { gs.o = o; gs.prog = interval * 0.6; gs.hits = 0; if (o.t === 'tree') tryBee(o); }   // v7a：木を切り始めた時に、まれに蜂
    gs.prog += dt;
    if (gs.prog >= interval) {
      gs.prog -= interval; gs.hits++;
      game.stamina = Math.max(0, game.stamina - stCost(lv > 0 ? 2 : 3)); state.stIdle = 0;
      o._shake = 0.15; player.lunge = 0.12; sfx(g.sfx || 'chop'); burst(o.x * 16 + 8, o.y * 16 + 8, fxColor(g.fx), 4);
      if (gs.hits >= g.hits[lv]) { gs.o = null; gatherDone(o, g, lv); }
    }
    return;
  }
  if (d.it === 'drop') { if (aPress || (game.up.magnet && aDown && state.holdCd <= 0)) { state.holdCd = 0.22; pickDrop(o, aPress); } return; }
  if (aPress && d.it) interact(o);
}
function fxColor(fx) { return { wood: P.woodL, leaf: P.leafL, stone: P.stoneL, metal: '#c8d0d8', iron: '#d97a3a', crystal: '#9fe8f6', gold: P.gold }[fx] || '#ffffff'; }
function gatherDone(o, g, lv) {
  const m = curMap();
  if (g.instant && !gatherRoomOk(o, g, lv)) { if (state.capToast <= 0) { state.capToast = 2.5; sfx('error'); toast('持ち物がいっぱいで拾えない！', 'bad'); } return; }
  // 入りきらない物（確率で出るおまけ）は足元に置く（消えない）
  let ys;
  if (g.special === 'palm') { ys = [['coconut', o.n]]; o.n = 0; }
  else if (g.special === 'bush') { if (!(o.n > 0)) { state.lastInstant = o; return; } ys = [['berry', 2], ['fiber', 1, 0.3]]; o.n = 0; }
  else if (g.special === 'shell') ys = [[chance(0.12) ? 'rareshell' : 'shell', 1]];
  else if (g.special === 'crate') { ys = [['wood', 2]]; const r = Math.random(); ys.push(r < 0.3 ? ['rope', 2] : r < 0.55 ? ['metal', 1] : r < 0.75 ? ['canned', 1] : r < 0.87 ? ['coin', 1] : ['cloth', 1]); }
  else ys = g.y(lv);
  const got = []; let lost = false, total = 0;
  for (const [id, n, p] of ys) { if (p != null && !chance(p)) continue; const a = addItem(id, n, true); if (a < n) lost = true; if (a > 0) { got.push(`+${a} ${ITEMS[id].n}`); total += a; } }
  if (g.cat && lv > 0) useTool(g.cat);
  if (g.remove) removeObj(m, o); else if (g.to) { o.t = g.to; o.r = game.day + g.regrow; }
  if (o.t === 'pebble') game.flags.tPeb = 1; else if (o.t === 'twig') game.flags.tTwig = 1;   // v8a：チュートリアル「拾ってみよう」
  state.lastInstant = o;
  game.stats.gathered += total;
  if (g.instant) sfx(g.sfx || 'pick'); else sfx('pick');
  got.forEach((s, i) => floatText(o.x * 16 + 8, o.y * 16 - 2 - i * 9, s, '#ffffff'));
  if (lost) toast('持ち物がいっぱいで、入りきらなかった分は捨てた', 'bad');
  if (!game.flags.g5 && game.stats.gathered >= 5) game.flags.g5 = 1;
}
function interact(o) {
  const d = OBJ[o.t];
  switch (d.it) {
    case 'shop': openShop(); break;
    case 'zeniTalk': zeniTalk(); break;   // v8b
    case 'station': if (o.out && Object.keys(o.out).some(k => o.out[k] > 0) && collectOutput(o)) break; openStation(o); break;   // v6.2：できあがりがある時は、1回目で受け取るだけ（2回目で画面を開く）
    case 'bed': openBed(o); break;
    case 'chest': openChest(o); break;
    case 'miner': openMiner(o); break;   // v7b
    case 'lumber': openLumber(o); break;   // v8b
    case 'house': { if (o.done) toast('下の真ん中のドアに向かって歩くと入れる'); else { const left = Math.max(0, CONFIG.house.buildH * (1 - houseProg(o))); toast(`建設中……あと約${Math.ceil(left)}時間で完成（${Math.floor(houseProg(o) * 100)}%）`); } break; }   // v7c
    case 'diary': readDiary(o); break;
    case 'shrine': takeShrine(o); break;
    case 'shrineEmpty': examineEmptyShrine(o); break;
    case 'cave': enterCave(); break;
    case 'exit': exitCave(); break;
    case 'stairsDown': goCave2(); break;
    case 'stairsUp': leaveCave2(); break;
    case 'brazier': toast('かがり火が、ゆらゆらと燃えている'); break;
    case 'liner': openLiner(); break;
    case 'hut':
      if (!game.flags.hutSeen) { game.flags.hutSeen = 1; queueTalk(TALK.hut.concat([['sys', '小屋の中には、物をしまっておける棚がある。ここで眠ることもできそうだ。']]), openHut); }
      else openHut();
      break;
    case 'wreck': queueTalk(TALK.wreck); break;
    case 'raft': openRaft(); break;
  }
}
// 泉：木の器で水を汲む（そのままでは飲まず、焚き火でろ過する）
function drink() {
  if (!has('bowl')) { sfx('error'); toast('木の器がない（作業台のクラフトで木材1つから作れる）', 'bad'); return; }
  takeItem('bowl', 1); addItem('rawwater', 1, true); state.drinkCd = 0.4; sfx('drink');
  floatText(player.x, player.y - 20, '+1 泉の水', '#9fd3ff');
  if (!game.flags.water1) { game.flags.water1 = 1; toast('焚き火の「加工」でろ過すると、きれいな水になる', 'good'); }
}
function consume(id, slotI) {
  const it = ITEMS[id]; if (!it || (slotI === 'off' ? !(game.off && game.off.id === id) : !has(id))) return;
  const take = () => { if (slotI === 'off') { game.off.n--; if (game.off.n <= 0) game.off = null; syncInv(); } else if (slotI != null && game.slots[slotI] && game.slots[slotI].id === id) takeFromSlot(slotI, 1); else takeItem(id, 1); };   // v6b：'off'＝左手から
  if (it.heal) { const pz = game.poison > 0 && !!it.cure; if (game.hp >= 100 && !pz) { toast('体力は満タンだ'); return; } take(); game.hp = Math.min(100, game.hp + it.heal); if (it.cure) game.poison = 0; sfx('eat'); toast(`${it.n}を使った（体力+${it.heal}${pz ? '・毒が治った' : ''}）`, 'good'); return; }   // v6.1c：毒も治る
  if (it.buff) { const was = game.awake > 0; take(); game.awake = CONFIG.awakeSec; sfx('drink'); toast(was ? `${it.n}を飲んだ（覚醒の残りが2:00に戻った）` : `${it.n}を飲んだ！ 2分間「覚醒」した`, 'good'); return; }
  const f = it.food; if (!f) return;
  const drinkOnly = !f.h;
  if (drinkOnly && game.thirst >= 99) { toast('喉は渇いていない'); return; }
  if (id === 'rawwater' && state.rawCd > 0) return;   // v6.2：生水は飲むのに0.8秒かかる（連打しても速くならない）
  if (!drinkOnly && !f.happy && game.hunger >= 99 && (game.thirst >= 99 || !f.t)) { toast('もうお腹いっぱいだ'); return; }   // v7a：黄金の焼き肉は満腹でも食べられる
  take(); game.flags.ate = 1; if (id === 'cleanwater') game.flags.drankClean = 1; game.hunger = Math.min(100, game.hunger + f.h); game.thirst = Math.min(100, game.thirst + (f.t || 0));
  if (it.ret) addItem(it.ret, 1, true);
  if (id === 'rawwater') state.rawCd = 0.8;
  sfx(drinkOnly ? 'drink' : 'eat');
  let msg = `${it.n}を${drinkOnly ? '飲んだ' : '食べた'}（` + [f.h ? (f.full ? '空腹が全回復' : '空腹+' + f.h) : '', f.t ? '渇き+' + f.t : ''].filter(Boolean).join(' ') + '）';
  if (f.poison) { game.hp = Math.max(1, game.hp - 25); game.sick = Math.max(game.sick || 0, 60); msg += '……猛毒だ！ 体力-25'; toast(msg, 'bad'); sfx('hurt'); }
  else if (f.raw && chance(f.sickP || 0.25)) { game.hp = Math.max(1, game.hp - 8); game.sick = Math.max(game.sick || 0, 40); msg += '……お腹を壊した！ 体力-8'; toast(msg, 'bad'); } else toast(msg, 'good');
  if (f.happy) { const was = game.happy > 0; game.happy = CONFIG.happySec; sfx('unlock'); toast(was ? '幸福の残りが5:00に戻った' : '5分間「幸福」になった！ 体力の自然回復が2倍', 'good'); }   // v7a
}
// 使う（右クリック・Yボタン・選択中の枠をタップ）：手に持っている物だけを使う（飲食物は食べる、設置物は置き場所を選ぶ）
// v4：持っていない食べ物を自動で選んで食べることはしない（feedback：Yボタンの時は、使えない理由を出す）
function useSelected(feedback) {
  const sl = heldSlot(), id = sl && sl.id;
  if (id && ITEMS[id] && (ITEMS[id].food || ITEMS[id].heal || ITEMS[id].buff)) { consume(id, game.hotSel); return; }
  if (id && isPlace(id)) { startPlace(game.hotSel); return; }
  if (offUsable()) { consume(game.off.id, 'off'); return; }   // v6b：手に剣などを持っている時は、左手の回復アイテムを使う
  const now = performance.now(); if (!feedback || now < (state.useToastT || 0)) return;
  state.useToastT = now + 1200; sfx('error');
  toast(id ? `${itemName(id)}は「使う」ことはできない（食べ物などを持って使おう）` : `アイテムバー${game.hotSel + 1}番は空です`);
}
function craft(r) {
  const s = recipeState(r, true); if (!s.ok) return;
  if (r.build === 'houseKit' && houseTotal() > 0) { sfx('error'); toast('木造の家は1軒までです', 'bad'); return; }   // v7c
  payCost(r.cost);
  if (r.tool) addItem(r.tool, 1, true, TOOLS[r.tool].dur || 0);
  if (r.build) addItem(r.build, 1, true);   // 設置物は持ち物に入る（アイテムバーで持って右クリックで置く）
  if (r.up) { game.up[r.up] = true; ensureSlots(); syncInv(); }
  if (r.out) addItem(r.out, r.n, true);
  game.stats.crafted++; sfx('craft');
  saveGame(true);
  // v6.2：設置物を作った時は「今すぐ設置しますか？」を出す（島の上で、持ち物に入った時だけ）
  const bi = r.build ? game.slots.findIndex(x => x && x.id === r.build) : -1;
  if (bi >= 0 && game.map === 'island' && state.scene === 'play') {
    confirmBox(`${recipeName(r)}を作成しました。\n今すぐ設置しますか？`, () => { const j = game.slots.findIndex(x => x && x.id === r.build); if (j >= 0) startPlace(j); }, { title: 'クラフト', yes: '設置', no: '設置しない' });
    return;
  }
  toast(r.build ? `${recipeName(r)}を作った！ アイテムバーで持って${Input.mode === 'key' ? '右クリック' : 'Yボタン'}で置ける` : `${recipeName(r)}を作った！`, 'good');
}
function findBuildSpot() {
  const m = curMap(), ptx = Math.floor(player.x / 16), pty = Math.floor((player.y - 3) / 16), [vx, vy] = DIRV[player.dir];
  const ok = (x, y) => { const v = tileAt(m, x, y); if (!WALK[v] || v === T.PIER || objAt(m, x, y)) return false;
    const l = player.x - 5, r = player.x + 5, t = player.y - 5, b = player.y; return !(l < x * 16 + 16 && r > x * 16 && t < y * 16 + 16 && b > y * 16); };
  const cands = [[ptx + vx, pty + vy]];
  for (let rr = 1; rr <= 2; rr++) for (let dy = -rr; dy <= rr; dy++) for (let dx = -rr; dx <= rr; dx++) cands.push([ptx + dx, pty + dy]);
  return cands.find(([x, y]) => ok(x, y)) || null;
}
/* 設置モード（半径CONFIG.placeRangeマス以内をクリック／タップ） */
const playerTile = () => [Math.floor(player.x / 16), Math.floor((player.y - 3) / 16)];
// v6c：縄梯子を掛けられる列（崖の壁の上と下が地面で、まだ何も掛かっていない）
function ladderSpan(m, x, y) {
  if (tileAt(m, x, y) !== T.CLIFF) return null;
  let a = y, b = y; while (tileAt(m, x, a - 1) === T.CLIFF) a--; while (tileAt(m, x, b + 1) === T.CLIFF) b++;
  if (!WALK[tileAt(m, x, a - 1)] || !WALK[tileAt(m, x, b + 1)]) return null;
  for (let k = a; k <= b; k++) if (objAt(m, x, k)) return null;
  return { x, y: a, h: b - a + 1 };
}
const onLadder = () => { if (!game || game.map !== 'island' || !maps.island) return false; const o = objAt(maps.island, Math.floor(player.x / 16), Math.floor((player.y - 3) / 16)); return !!(o && o.t === 'ladder'); };
// v8b：家・伐採機を置く時に、どかしてよい自然の物（拾える物・木・岩・草・しげみなど）
const NATURAL = ['tree', 'stump', 'palm', 'bush', 'grass', 'grassCut', 'pebble', 'twig', 'shell', 'driftwood', 'boulder', 'rubble'];
const isNatural = o => !!o && NATURAL.includes(o.t);
// v8b：自動伐採機（まん中の1マス）。島の歩ける地面で、まん中の物は自然の物ならOK（置くとどかす）。ほかの伐採機の範囲とは重ねない
function lumberSpotOk(x, y) {
  if (game.map !== 'island') return false;
  const m = maps.island, [ptx, pty] = playerTile(), v = tileAt(m, x, y);
  if (Math.hypot(x - ptx, y - pty) > CONFIG.placeRange + 2 || !WALK[v] || v === T.PIER) return false;
  const o = objAt(m, x, y); if (o && !isNatural(o)) return false;
  if (m.objs.some(q => q.t === 'lumber' && Math.max(Math.abs(q.x - x), Math.abs(q.y - y)) < 3)) return false;
  return !(ptx === x && pty === y);
}
function placeOk(x, y) {
  const m = curMap(), [ptx, pty] = playerTile();
  if (state.place && state.place.id === 'houseKit') return houseSpotOk(x, y);   // v7c：(x, y)は家の真ん中
  if (state.place && state.place.id === 'ladder') return game.map === 'island' && Math.hypot(x - ptx, y - pty) <= CONFIG.placeRange && !!ladderSpan(m, x, y);   // v6c
  if ((game.map !== 'island' && game.map !== 'house') || Math.hypot(x - ptx, y - pty) > CONFIG.placeRange) return false;   // v7c：家の中にも置ける
  if (game.map === 'house') { const e = maps.house.lm.exit; if (Math.max(Math.abs(x - e.x), Math.abs(y - e.y)) <= 2) return false; }   // 出入り口のまわり2マスは置けない
  if (state.place && state.place.id === 'lumber') return lumberSpotOk(x, y);   // v8b
  const v = tileAt(m, x, y); if (!WALK[v] || v === T.PIER || objAt(m, x, y)) return false;
  if (state.place && state.place.id === 'miner') {   // v7b：自動採掘機は岩場だけ。v8b：2×2マス（左下が(x, y)）
    for (const [dx, dy] of OBJ.miner.fp) { const xx = x + dx, yy = y + dy; if (tileAt(m, xx, yy) !== T.ROCK || objAt(m, xx, yy)) return false; }
    const l = player.x - 5, r = player.x + 5, t = player.y - 5, b = player.y;
    return !(l < x * 16 + 32 && r > x * 16 && t < (y - 1) * 16 + 32 && b > (y - 1) * 16);
  }
  const l = player.x - 5, r = player.x + 5, t = player.y - 5, b = player.y;
  return !(l < x * 16 + 16 && r > x * 16 && t < y * 16 + 16 && b > y * 16);
}
function startPlace(slotI) {
  const sl = game.slots[slotI]; if (!sl || !isPlace(sl.id)) return;
  // v7c：家の設計キットは島の上だけ（1軒まで）。家の中には焚き火・縄梯子・採掘機以外を置ける
  if (sl.id === 'houseKit') { if (game.map !== 'island') { sfx('error'); toast('木造の家は島の上にだけ建てられる', 'bad'); return; } if (houseObj()) { sfx('error'); toast('木造の家は1軒までです', 'bad'); return; } }
  else if (game.map === 'house') { if (sl.id === 'campfire' || sl.id === 'ladder' || sl.id === 'miner' || sl.id === 'lumber') { sfx('error'); toast(sl.id === 'campfire' ? '家の中では焚き火は置けない' : `${itemName(sl.id)}は家の中には置けない`, 'bad'); return; } }
  else if (game.map !== 'island') { sfx('error'); toast('洞窟の中には置けない', 'bad'); return; }
  if (sl.id === 'miner' && maps.island.objs.some(o => o.t === 'miner')) { sfx('error'); toast('自動採掘機は1台までです', 'bad'); return; }   // v7b
  const sp = findBuildSpot(), [ptx, pty] = playerTile(), [vx, vy] = DIRV[player.dir];
  UI.closeAll(); stopFishing(); state.gather.o = null;
  const lad = sl.id === 'ladder';   // v6c：縄梯子は目の前のマスから
  state.place = { id: sl.id, slot: slotI, tx: !lad && sp ? sp[0] : ptx + vx, ty: !lad && sp ? sp[1] : pty + vy };
  if (sl.id === 'houseKit') { state.place.tx = ptx + vx * 3; state.place.ty = pty + vy * 3; }   // v7c：家は向いている方向の3マス先を真ん中に
  if (sl.id === 'houseKit' || sl.id === 'lumber') setTimeout(() => { if (state.place) toast(Input.mode === 'touch' ? '指で押したまま動かして場所を決め、離すと決定' : Input.mode === 'pad' ? '十字キーで場所を動かし、Aで決定' : '左クリックを押したまま動かして場所を決め、離すと決定（方向キー＋Spaceでもできる）'); }, 300);   // v8b
  document.body.classList.add('placing'); state.hintHtml = undefined; sfx('ui');
}
function cancelPlace(silent) {
  if (!state.place) return; state.place = null; state.placeDrag = null; document.body.classList.remove('placing'); state.hintHtml = undefined;
  if (!silent) { sfx('ui'); toast('設置をやめた'); }
}
// v6b：マウスのある方向（下・上・左・右）
function aimDir() {
  const rc = canvas.getBoundingClientRect(); if (!rc.width || !state.aim) return player.dir;
  const wx = (state.aim[0] - rc.left) * (canvas.width / rc.width) / zoom + state.cam.x, wy = (state.aim[1] - rc.top) * (canvas.height / rc.height) / zoom + state.cam.y;
  const dx = wx - player.x, dy = wy - (player.y - 6); if (Math.hypot(dx, dy) < 4) return player.dir;
  return Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 3 : 2) : (dy > 0 ? 0 : 1);
}
function placeCursorFromScreen(cx, cy) {
  const rc = canvas.getBoundingClientRect(); if (!rc.width) return;
  const wx = (cx - rc.left) * (canvas.width / rc.width) / zoom + state.cam.x, wy = (cy - rc.top) * (canvas.height / rc.height) / zoom + state.cam.y;
  state.place.tx = Math.floor(wx / 16); state.place.ty = Math.floor(wy / 16);
}
function confirmPlace() {
  const pl = state.place; if (!pl) return;
  if (pl.id === 'houseKit') {   // v7c：取り消せないので確認する
    { const why = houseSpotWhy(pl.tx, pl.ty); if (why) { sfx('error'); toast(`木造の家は5×5マスが必要：${why}`, 'bad'); return; } }
    confirmBox('ここに木造の家を建てますか？\n一度建てると、データが消えるまで残ります（動かしたり回収したりはできません）。', () => buildHouse(pl), { title: '木造の家', yes: 'ここに建てる', no: 'やめる' });
    return;
  }
  if (!placeOk(pl.tx, pl.ty)) { sfx('error'); toast(pl.id === 'ladder' ? '縄梯子は、崖の壁（上と下が地面の所）にだけ掛けられる' : pl.id === 'miner' ? `自動採掘機は、島の岩場（灰色の地面）の空いた2×2マスに置ける（自分から${CONFIG.placeRange}マス以内）` : pl.id === 'lumber' ? '自動伐採機は、島の地面に置ける（ほかの伐採機の範囲と重ならない所・設備の上は不可）' : game.map === 'house' ? '家の中の空いた床に置ける（出入り口のまわり2マスは置けない）' : `そこには置けない（自分から${CONFIG.placeRange}マス以内の空いた地面）`, 'bad'); return; }
  let si = game.slots[pl.slot] && game.slots[pl.slot].id === pl.id ? pl.slot : game.slots.findIndex(x => x && x.id === pl.id);
  if (si < 0) { sfx('error'); toast(`${itemName(pl.id)}を持っていません`, 'bad'); cancelPlace(true); return; }
  takeFromSlot(si, 1);
  const obj = { t: pl.id, x: pl.tx, y: pl.ty }; if (pl.id === 'chest') obj.slots = new Array(8).fill(null);   // v6.2：8枠
  if (pl.id === 'ladder') { const sp = ladderSpan(curMap(), pl.tx, pl.ty); obj.y = sp.y; obj.h = sp.h; }   // v6c：崖の1列ぶん
  if (pl.id === 'miner') { obj.w2 = 1; obj.fuel = 0; obj.store = {}; obj.tm = CONFIG.miner.every; }   // v7b
  if (pl.id === 'lumber') { const c = objAt(curMap(), pl.tx, pl.ty); if (isNatural(c)) removeObj(curMap(), c); obj.store = {}; obj.tm = CONFIG.lumber.every; }   // v8b：まん中の自然の物はどかす
  if (pl.id === 'furnace') obj.fuel = 0;   // v8b：炉は燃料なしで置かれる
  const o = addObj(curMap(), obj);
  if (OBJ[pl.id].it === 'station') stations.push(o);
  burst(pl.tx * 16 + 8, pl.ty * 16 + 8, P.woodL, 10);
  cancelPlace(true);
  sfx('craft'); toast(pl.id === 'ladder' ? '縄梯子を掛けた！ 崖を上り下りできる' : `${itemName(pl.id)}を置いた！`, 'good');
  saveGame(true);
}
function updatePlace() {
  const pl = state.place, [ptx, pty] = playerTile(), R = pl.id === 'houseKit' ? houseRange() : pl.id === 'lumber' ? CONFIG.placeRange + 2 : CONFIG.placeRange;   // v8b
  if (Input.press('B') || Input.press('START') || Input.press('X')) { cancelPlace(); return; }
  const mv = { UP: [0, -1], DOWN: [0, 1], LEFT: [-1, 0], RIGHT: [1, 0] };
  for (const d in mv) if (Input.press(d)) { pl.tx = clamp(pl.tx + mv[d][0], ptx - R, ptx + R); pl.ty = clamp(pl.ty + mv[d][1], pty - R, pty + R); sfx('ui'); }
  if (Input.press('A')) confirmPlace();
}

function repay(amt) {
  amt = Math.min(Math.floor(amt), game.money, game.debt); if (amt <= 0) return;
  game.money -= amt; game.debt -= amt; game.repaid += amt; logDebt('p'); sfx('coin'); toast(`${fmt$(amt)} を返済した（残り ${fmt$(game.debt)}）`, 'money');
  if (!game.flags.firstRepay) { game.flags.firstRepay = 1; queueTalk(TALK.firstRepay); }
  checkMilestones(); saveGame(true);
}
// v7b：借金の記録（グラフ用）。[日（0＝1日目の6:00）, 借金, 種類]。種類：s＝はじめ、l＝読み込み、p＝返済、i＝利息、x＝遅延損害金
function logDebt(kind) {
  const g = game; if (!g) return; if (!Array.isArray(g.debtLog)) g.debtLog = [];
  g.debtLog.push([Math.round(dayNow() * 1000) / 1000, Math.max(0, Math.round(g.debt)), kind]);
  if (g.debtLog.length > CONFIG.debtLogMax) g.debtLog.splice(1, g.debtLog.length - CONFIG.debtLogMax);
}
function ensureDebtLog() {
  const g = game; if (!g) return;
  g.debtLog = Array.isArray(g.debtLog) ? g.debtLog.filter(e => Array.isArray(e) && Number.isFinite(e[0]) && Number.isFinite(e[1])).slice(-CONFIG.debtLogMax) : [];
  if (!g.debtLog.length) logDebt(g.day > 1 || g.repaid > 0 ? 'l' : 's');
}
function debtChartEl() {
  const g = game, log = (g.debtLog || []).slice(), now = dayNow(), dpr = Math.min(3, window.devicePixelRatio || 1);
  const W = 560, H = 210, padL = 52, padR = 12, padT = 14, padB = 26;
  const cv = h('canvas', { class: 'debt-chart', width: String(W * dpr), height: String(H * dpr), 'aria-label': '借金の推移のグラフ' }), x = cv.getContext('2d');
  x.scale(dpr, dpr);
  const stl = g.contract.free ? [] : stagesOf(g.contract);
  const xMax = Math.max(g.contract.free ? Math.ceil(now) + 1 : g.contract.days, Math.ceil(now + 0.05), 2), yTop = Math.max(g.contract.debt, ...log.map(e => e[1]), 1);
  const step = [100, 200, 500, 1000, 2000, 5000, 10000].find(v => yTop / v <= 5) || 20000, yMax = Math.ceil(yTop * 1.05 / step) * step;
  const X = d => padL + (W - padL - padR) * clamp(d / xMax, 0, 1), Y = v => padT + (H - padT - padB) * (1 - v / yMax);
  const font = n => `${n}px DotGothic16, 'Hiragino Sans', sans-serif`;
  x.fillStyle = '#0f1d33'; x.fillRect(0, 0, W, H);
  x.font = font(11); x.textBaseline = 'middle';
  for (let v = 0; v <= yMax; v += step) { x.strokeStyle = 'rgba(159,211,255,0.14)'; x.lineWidth = 1; x.beginPath(); x.moveTo(padL, Math.round(Y(v)) + 0.5); x.lineTo(W - padR, Math.round(Y(v)) + 0.5); x.stroke(); x.fillStyle = '#9fb0c8'; x.textAlign = 'right'; x.fillText(fmt$(v), padL - 5, Y(v)); }
  const every = Math.max(1, Math.ceil(xMax / 10)); x.textAlign = 'center'; x.textBaseline = 'top';
  for (let d = 0; d <= xMax; d++) { const px = Math.round(X(d)) + 0.5; x.strokeStyle = 'rgba(159,211,255,0.08)'; x.beginPath(); x.moveTo(px, padT); x.lineTo(px, H - padB); x.stroke(); if (d < xMax && d % every === 0) { x.fillStyle = '#9fb0c8'; x.fillText(`${d + 1}日`, X(d + 0.5), H - padB + 6); } }
  // 締め日（その日の終わり）と返済期限
  x.setLineDash([3, 3]);
  stl.forEach((sg, i) => { const px = Math.round(X(sg.day)) + 0.5; x.strokeStyle = 'rgba(242,196,64,0.8)'; x.beginPath(); x.moveTo(px, padT); x.lineTo(px, H - padB); x.stroke(); x.fillStyle = '#f2c440'; x.textAlign = 'center'; x.textBaseline = 'top'; x.font = font(10); x.fillText(`締め${i + 1}`, px, 1); });
  x.setLineDash([]);
  if (!g.contract.free) { const px = Math.round(X(g.contract.days)) - 0.5; x.strokeStyle = '#ff6a5a'; x.lineWidth = 2; x.beginPath(); x.moveTo(px, padT); x.lineTo(px, H - padB); x.stroke(); x.fillStyle = '#ff8a7a'; x.textAlign = 'right'; x.fillText('期限', px - 3, 1); }
  // 借金の線（変わるまでは横に、変わった所で縦に）
  if (log.length) {
    x.strokeStyle = '#ff8a7a'; x.lineWidth = 2; x.beginPath(); x.moveTo(X(log[0][0]), Y(log[0][1]));
    for (let i = 1; i < log.length; i++) { x.lineTo(X(log[i][0]), Y(log[i - 1][1])); x.lineTo(X(log[i][0]), Y(log[i][1])); }
    x.lineTo(X(Math.max(now, log[log.length - 1][0])), Y(g.debt)); x.stroke();
    for (const [d, v, k] of log) if (k === 'p' || k === 'x') { x.fillStyle = k === 'p' ? '#7fe08a' : '#ff5a4a'; x.beginPath(); x.arc(X(d), Y(v), 3, 0, Math.PI * 2); x.fill(); }
  }
  const nx = X(now), ny = Y(g.debt); x.fillStyle = '#ffffff'; x.beginPath(); x.arc(nx, ny, 3.5, 0, Math.PI * 2); x.fill();
  x.font = font(12); x.textBaseline = 'bottom'; x.textAlign = nx > W - 120 ? 'right' : 'left'; x.fillStyle = '#ffffff'; x.fillText(`いま ${fmt$(Math.max(0, g.debt))}`, nx + (nx > W - 120 ? -6 : 6), ny - 4);
  return h('div', null, cv, h('p', { class: 'note', style: 'margin-top:4px' }, '赤い線＝借金　緑の点＝返済　赤い点＝遅延損害金　黄色の点線＝締め日（その日の終わり）　赤い縦線＝返済期限'));
}
function checkMilestones() {
  const g = game, r = repaidRatio(), f = g.flags;
  if (!f.m25 && r >= 0.25) { f.m25 = 1; sfx('unlock'); queueTalk(TALK.m25); if (!f.linerSeen) { ensureLiner(); state.shake = 0.7; sfx('thud'); queueTalk([['sys', `ドォォン……！ 島の${linerDir()}の浜辺のほうで、大きな音が聞こえた。`], ['me', '……なんだ、今の音は？ 行ってみよう。']]); } }
  if (!f.m50 && r >= 0.5) { f.m50 = 1; sfx('unlock'); queueTalk(TALK.m50); }
  if (!f.m75 && r >= 0.75 && g.debt > 0) { f.m75 = 1; queueTalk(TALK.m75); }
  if (!f.paid && g.debt <= 0) { f.paid = 1; f.m25 = f.m50 = f.m75 = 1; sfx('unlock'); queueTalk(TALK.paid.concat(g.bp.raft ? [] : TALK.paidHint)); }
}
function buy(s) {
  if (repaidRatio() < s.req || (s.bp && game.bp[s.bp]) || game.money < s.p) return;
  if (s.item && roomFor(s.item) < 1) { sfx('error'); toast('持ち物がいっぱいです', 'bad'); return; }
  game.money -= s.p; game.stats.spent = (game.stats.spent || 0) + s.p;
  if (s.bp) { game.bp[s.bp] = true; sfx('unlock'); toast(`${s.n}を手に入れた！`, 'good'); } else { addItem(s.item, 1); sfx('coin'); toast(`${s.n}を買った`, 'good'); }
  saveGame(true);
}
function readDiary(o) {
  const n = o.page, m = curMap(); removeObj(m, o);
  if (!game.diaries.includes(n)) game.diaries.push(n);
  game.flags['diary' + n] = 1; sfx('unlock');
  if (n === 1) game.bp.raft = true;
  queueTalk(TALK['diary' + n]); saveGame(true);
}
function takeShrine(o) {
  o.t = 'shrineEmpty'; addItem('turtle', 1, true); addItem('ledger', 1, true); game.flags.turtle = 1; sfx('unlock');
  burst(o.x * 16 + 8, o.y * 16, P.gold, 20); queueTalk(TALK.shrine); saveGame(true);
}
function enterCave() {
  sfx('door'); stopFishing();
  fade(() => { state.mobs = []; game.map = 'cave'; const e = maps.cave.lm.exit; player.x = e.x * 16 + 8; player.y = (e.y - 1) * 16 + 12; player.dir = 1; state.rockTimer = 18; state.rocks = []; },
    () => { if (!game.flags.cave) { game.flags.cave = 1; queueTalk(TALK.cave); } saveGame(true); });
}
function exitCave() {
  sfx('door');
  fade(() => { state.mobs = []; game.map = 'island'; const c = maps.island.lm.cave; player.x = c.x * 16 + 8; player.y = (c.y + 1) * 16 + 12; player.dir = 0; state.rocks = []; }, () => saveGame(true));
}
/* ---------- 地下2階・ボス（仮実装） ----------
   画像・名前・セリフ・強さは BOSS だけを変えれば差し替えられる。画像は versions.json と同じフォルダに置く */
const BOSS = {
  name: '金木シンジ', img: 'Boss.png', imgDead: 'Boss_Dead.png', size: 48, facesLeft: true,   // 表示は約3×3マス。v8.1：体力が0になった時の絵（Boss_Dead.png）
  hp: 1650, contact: 10,   // v6.1a：240→1250（攻撃の新ルールに合わせた）。v8f：1250→1650
  lines: { intro: 'やあ。こんな所まで、何しに来たの？', p2: 'ちょっと、本気出しちゃおうかな。', p3: 'もう……怒ったからね！', win: 'ま、参った……今日はこのくらいにしといてあげる……', retry: 'また来たの？ 何度でも相手してあげるよ。', zero: 'これで全部……ゼロにしてあげる！', zeroFire: 'ゼロ・バースト！！', stun: 'う……動けない……', last: 'まだ……終わらないよ！' },
  atk: { claw: '爪とぎ連撃', charge: '取り立てダッシュ', leap: 'ジャンピング督促', ring: '衝撃のハイタッチ', shards: '請求書シャワー', blink: '残像ステップ', stamp: '判子レイン', zero: 'ゼロ・バースト' },   // v6b：ハイタッチは使わない（判子レインに変更）
  reward: [['bossGem', 1]],   // v6b：黒い宝玉1個（$5,000）
};
// v8.1：第2形態「ゲーミング金木シンジ」。1回目を倒すと虹色になって復活する（ぎりぎり勝てないかもしれない強さ）。
// 攻撃のダメージは mul 倍。開始から ultAt 秒たつと、逃げ場がわずかな「ゼロ・バースト∞」を撃つ（すき間の幅 zinfW、予告 zinfWarn 秒前）
// 無限リボ払い：体力が healAt 未満になると、healMax 回まで、最大体力の healAmt ぶん回復する
const BOSS_G = {
  name: 'ゲーミング金木シンジ', hp: 5555, mul: 1.75, ultAt: 40, ultCd: 16, healCd: 22,   // v8.1再：99999→9999、×3→×1.75。v8.2：9999→5555
  healAt: 0.5, healAmt: 0.3, healMax: 1, zinfW: 16, zinfWarn: 1.8,   // v8.1再：全回復（何度でも）→ 1回だけ30%回復。∞にすき間
  lines: {
    revive: 'なーんてね。まだ……終わってないよ？', awake: 'ゲーミングモード、起動♪ ここからが本番だよ。',
    intro: 'ゲーミングの光からは、誰も逃げられないよ♪', retry: 'また来たの？ 何回来ても、ゼロにしてあげる♪',
    heal: '支払いは、永遠に続くんだよ♪', zero: '逃げ道？ そんなもの、最初から無いよ♪', zeroFire: 'ゼロ・バースト∞！！', after: 'あれ、もう終わり？ つまんないなぁ♪',
    win: 'う、うそでしょ……？ ゲーミングが……負けるなんて……',
    hole: 'ぜーんぶ、吸い込んであげる♪', crash: 'あーあ、大暴落だね♪', snow: '借金ってね、転がすほど大きくなるんだよ♪', boom: '返したものは、ちゃんと戻ってくるからね♪',   // v8.2：新しい技のセリフ
  },
  atk: { claw: '七色の爪とぎ乱舞', charge: 'ゲーミング取り立てダッシュ', leap: 'ジャンピング督促・三連', stamp: 'ゲーミング判子レイン', shards: '請求書ストーム', blink: '残像ステップ・無限', spiral: '複利スパイラル', press: '差し押さえプレス', laser: 'ブラックリスト・レーザー', mirror: '多重債務ミラー', wave: '遅延損害金ウェーブ', heal: '無限リボ払い', zinf: 'ゼロ・バースト∞',
    dun: '督促状ラッシュ', gavel: '競売ハンマー', hole: '自己破産ブラックホール', crash: '大暴落チャート', snow: '借金雪だるま式', bomb: '延滞利息ボム', boom: '返済ブーメラン' },   // v8.2：新しい技7個（全部で20個）
  // v8.2：技の出やすさ（爪とぎは近い時、取り立てダッシュは遠い時に出やすい。同じ技は2回続けて出ない）
  w: { claw: 2, charge: 2, leap: 1.8, stamp: 1.8, shards: 1.8, blink: 1.8, spiral: 1.8, press: 2, laser: 1.8, mirror: 2, wave: 1.8, dun: 2.2, gavel: 2.2, hole: 1.6, crash: 1.8, snow: 1.6, bomb: 2, boom: 2.2 },
};
const ARENA = { x0: 58, x1: 326, y0: 84, y1: 246 };   // ボスの足元が動ける範囲
const BP = [null, { mv: 64, tele: 0.72, rec: 0.75, cd: 0.6 }, { mv: 80, tele: 0.6, rec: 0.6, cd: 0.42 }, { mv: 98, tele: 0.5, rec: 0.46, cd: 0.28 },
  { mv: 150, tele: 0.36, rec: 0.24, cd: 0.1 }];   // 段階ごとの速さ・予兆・すき。v8.1：4＝第2形態（ゲーミング）
// v8.1：色相（0〜359）から「r,g,b」の文字列（虹色の光に使う）
function hueRGB(h) { h = ((h % 360) + 360) % 360 / 60; const c = 255, x = Math.round(c * (1 - Math.abs(h % 2 - 1))), i = Math.floor(h); const r = [[c, x, 0], [x, c, 0], [0, c, x], [0, x, c], [x, 0, c], [c, 0, x]][i % 6]; return r.join(','); }
function genCave2() {
  const W = 24, H = 18, t = new Uint8Array(W * H).fill(T.CWALL);
  for (let y = 2; y <= 15; y++) for (let x = 2; x <= 21; x++) if (Math.min(x - 2, 21 - x) + Math.min(y - 2, 15 - y) >= 1) t[y * W + x] = T.CFLOOR;
  const objs = [{ t: 'stairsUp', x: 12, y: 15 }, { t: 'brazier', x: 3, y: 3 }, { t: 'brazier', x: 20, y: 3 }, { t: 'brazier', x: 3, y: 14 }, { t: 'brazier', x: 20, y: 14 }];
  return { W, H, tiles: t, lm: { up: { x: 12, y: 15 } }, objs };
}
// v7c：木造の家 ----------------------------------------------------------------
// 家の中：床は縦7×横11マス（x 1〜11、y 1〜7）。下の真ん中の下に出入り口（6, 8）。v8b：縦11→7マス（赤いマットがアイテムバーにかぶらないように）
const HOUSE_EXIT = { x: 6, y: 8 }, HOUSE_ZENI = { x: 8, y: 7 };   // v8b：ゼニ丸は出口の右上にいる
function genHouse() {
  const W = 13, H = 9, t = new Uint8Array(W * H).fill(T.WWALL);
  for (let y = 1; y <= 7; y++) for (let x = 1; x <= 11; x++) t[y * W + x] = T.WFLOOR;
  t[HOUSE_EXIT.y * W + HOUSE_EXIT.x] = T.WFLOOR;
  return { W, H, tiles: t, lm: { exit: { x: HOUSE_EXIT.x, y: HOUSE_EXIT.y } }, objs: [{ t: 'hexit', x: HOUSE_EXIT.x, y: HOUSE_EXIT.y }, { t: 'zeniH', x: HOUSE_ZENI.x, y: HOUSE_ZENI.y }] };
}
// v8b：家の中の物を、新しい広さに合わせて並べ直す（床の外・出入り口のまわり2マスにある物は、空いた床へ移す）
function fixHouseObjs(objs) {
  const ex = HOUSE_EXIT, ok = (x, y) => x >= 1 && x <= 11 && y >= 1 && y <= 7 && Math.max(Math.abs(x - ex.x), Math.abs(y - ex.y)) > 2;
  const keep = objs.filter(o => o.t !== 'hexit' && o.t !== 'zeniH'), used = new Set(), out = [];
  for (const o of keep) if (ok(o.x, o.y) && !used.has(o.x + ',' + o.y)) { used.add(o.x + ',' + o.y); out.push(o); }
  for (const o of keep) { if (out.includes(o)) continue; let done = false; for (let y = 1; y <= 7 && !done; y++) for (let x = 1; x <= 11 && !done; x++) if (ok(x, y) && !used.has(x + ',' + y)) { o.x = x; o.y = y; used.add(x + ',' + y); out.push(o); done = true; } }
  out.push({ t: 'hexit', x: ex.x, y: ex.y }, { t: 'zeniH', x: HOUSE_ZENI.x, y: HOUSE_ZENI.y });
  objs.length = 0; objs.push(...out); return objs;
}
const houseObj = () => (maps.island ? maps.island.objs.find(o => o.t === 'house') : null);
const houseTotal = () => (houseObj() ? 1 : 0) + (game.inv.houseKit || 0);
// ゲーム内の時計の通算（1日目6:00＝0時間）。眠って時間が飛んでも、そのぶん進む
const absHours = () => (game.day - 1) * 24 + ((hourOf(game.time) - 6) % 24 + 24) % 24;
const houseProg = o => o.done ? 1 : clamp((absHours() - (o.b0 || 0)) / CONFIG.house.buildH, 0, 1);
// 島の上で、真ん中(cx, cy)の3×3に家、まわり1マスは通り道（5×5すべてが空いた地面）
// v8b：設置条件をゆるくした。5×5は草地か森の地面（海・砂浜・道・崖・泉・岩場からは2マス以上はなす）。木・岩・草・拾える物の上でもよく、建てるとどかす
const HOUSE_NG = t => isWater(t) || t === T.SAND || t === T.PATH || t === T.CLIFF || t === T.LEDGE || t === T.SPRING || t === T.ROCK || t === T.PIER || !WALK[t];
const houseRange = () => CONFIG.placeRange + 3;
function houseSpotWhy(cx, cy) {
  if (game.map !== 'island') return '島の上にだけ建てられる';
  const m = maps.island, [ptx, pty] = playerTile();
  if (Math.hypot(cx - ptx, cy - pty) > houseRange()) return `自分から${houseRange()}マス以内に建てられる`;
  for (let y = cy - 4; y <= cy + 4; y++) for (let x = cx - 4; x <= cx + 4; x++) if (HOUSE_NG(tileAt(m, x, y))) return '海・砂浜・道・崖・泉・岩場から2マス以上はなれた、草地や森に建てられる';
  for (let y = cy - 2; y <= cy + 2; y++) for (let x = cx - 2; x <= cx + 2; x++) { const o = objAt(m, x, y); if (o && !isNatural(o)) return `${itemName(o.t) === o.t ? (OBJ[o.t] && OBJ[o.t].n) || '物' : itemName(o.t)}がある所には建てられない（木・岩・草・拾える物はどかせる）`; }
  if (ptx >= cx - 1 && ptx <= cx + 1 && pty >= cy - 1 && pty <= cy + 1) return '自分が立っている所には建てられない';
  return '';
}
const houseSpotOk = (cx, cy) => !houseSpotWhy(cx, cy);
function buildHouse(pl) {
  if (!houseSpotOk(pl.tx, pl.ty) || houseObj()) { sfx('error'); toast('ここには建てられない', 'bad'); return; }
  const si = game.slots.findIndex(x => x && x.id === 'houseKit'); if (si < 0) { sfx('error'); toast('木造の家（設計キット）を持っていません', 'bad'); cancelPlace(true); return; }
  takeFromSlot(si, 1);
  const m = maps.island; for (let y = pl.ty - 2; y <= pl.ty + 2; y++) for (let x = pl.tx - 2; x <= pl.tx + 2; x++) { const o = objAt(m, x, y); if (isNatural(o)) removeObj(m, o); }   // v8b：木・岩・草・拾える物はどかす
  addObj(maps.island, { t: 'house', x: pl.tx - 1, y: pl.ty + 1, b0: absHours(), done: false });
  cancelPlace(true); state.shake = 0.3; sfx('craft'); burst(pl.tx * 16 + 8, pl.ty * 16 + 8, P.woodL, 16);
  toast(`木造の家の建設が始まった！ ゲーム内の時計で${CONFIG.house.buildH}時間後に完成する`, 'good'); saveGame(true);
}
function completeHouse(o) {
  const m = maps.island; occDel(m, o); o.done = true; occAdd(m, o);
  sfx('unlock'); burst((o.x + 1) * 16 + 8, (o.y - 1) * 16, '#f2c440', 18); toast('木造の家が完成した！ 下の真ん中のドアから入れる', 'good'); saveGame(true);
}
function enterHouse() {
  sfx('door'); stopFishing(); state.gather.o = null;
  fade(() => { state.mobs = []; state.rocks = []; game.map = 'house'; const e = maps.house.lm.exit; player.x = e.x * 16 + 8; player.y = e.y * 16 + 12; player.dir = 1; state.houseArm = false; },
    () => { if (!game.flags.house1) { game.flags.house1 = 1; queueTalk([['me', '……ここが、俺の家か。'], ['sys', '家の中では雨や嵐、夜の寒さの影響を受けず、獣も入ってこない。空腹と渇きの減りも半分になる。'], ['sys', '焚き火以外の設置物を自由に置ける（出入り口のまわり2マスは置けない）。下の赤いマットに乗ると外に出る。']]); } saveGame(true); });
}
function leaveHouse() {
  sfx('door'); stopFishing();
  fade(() => { state.mobs = []; game.map = 'island'; const h = houseObj(); if (h) { player.x = (h.x + 1) * 16 + 8; player.y = (h.y + 1) * 16 + 12; } player.dir = 0; }, () => saveGame(true));
}
// 毎フレーム：建設の完成・ドアと出入り口
function updateHouse() {
  const g = game, ho = houseObj(); if (!ho) return;
  if (!ho.done && absHours() - (ho.b0 || 0) >= CONFIG.house.buildH) completeHouse(ho);
  if (state.fading || UI.isOpen() || Dialog.active || state.place) return;
  const [tx, ty] = playerTile();
  if (g.map === 'island') { if (ho.done && tx === ho.x + 1 && ty === ho.y) enterHouse(); }
  else if (g.map === 'house') { const e = maps.house.lm.exit; if (tx === e.x && ty === e.y) { if (state.houseArm) leaveHouse(); } else state.houseArm = true; }
}
// 空の祠をもう一度調べると、地下への階段が現れる
function examineEmptyShrine(o) {
  const g = game, m = curMap();
  if (g.flags.stairs) { toast(g.flags.gaming ? '祠は空っぽだ。階段の下から、七色の光がもれている……' : g.flags.bossDown ? '祠は空っぽだ。階段の下から、もう気配はしない' : '祠は空っぽだ。横に、地下へ続く階段がある'); return; }   // v8.1：第2形態がいる時
  const [ptx, pty] = playerTile();
  const spot = [[o.x - 2, o.y + 1], [o.x + 2, o.y + 1], [o.x - 1, o.y + 2], [o.x + 1, o.y + 2], [o.x - 3, o.y + 2], [o.x + 3, o.y + 2], [o.x, o.y + 3]].find(([x, y]) => tileAt(m, x, y) === T.CFLOOR && !objAt(m, x, y) && !(x === ptx && y === pty));
  if (!spot) { toast('祠は空っぽだ'); return; }
  g.flags.stairs = 1; addObj(m, { t: 'stairsDown', x: spot[0], y: spot[1] });
  state.shake = 0.8; sfx('thud'); burst(spot[0] * 16 + 8, spot[1] * 16 + 8, '#a090b0', 18);
  queueTalk([['sys', '空の祠をもう一度調べると、ゴゴゴ……と地面が揺れた。'], ['sys', '祠の横に、地下へ続く階段が現れた！']]); saveGame(true);
}
function goCave2() {
  const go = () => {
    sfx('door'); stopFishing();
    const bossNext = !game.flags.bossDown || !!game.flags.bossRematch || !!game.flags.gaming;   // v6.1b：ボスが出る時だけ、画像を待ってゆっくり明るくする。v8.1：第2形態がいる時も
    fade(() => {
      state.mobs = []; state.rocks = []; endBossFight(); game.map = 'cave2'; const u = maps.cave2.lm.up; player.x = u.x * 16 + 8; player.y = (u.y - 1) * 16 + 12; player.dir = 1;
      state.bossArm = !!(game.flags.bossDown && game.flags.bossRematch);   // v6.1b：ボス再戦は、入り直した時だけ
      if (bossCanSpawn()) spawnBoss();
    }, () => saveGame(true), bossNext ? { hold: 450, until: () => BOSS_ART.ready, max: 2500, slow: true } : null);
  };
  if (!game.flags.bossDown && !game.flags.b2warn) { confirmBox('階段の下から、ただならぬ気配がする……。\nとても強い相手がいるようです。下りますか？', () => { game.flags.b2warn = 1; go(); }, { yes: '下りる', danger: true }); return; }
  if (game.flags.gaming && !game.flags.gwarn && !game.flags.bossRematch) { confirmBox('階段の下から、七色の光と笑い声がもれている……。\nとんでもなく強い相手がいるようです。下りますか？', () => { game.flags.gwarn = 1; go(); }, { yes: '下りる', danger: true }); return; }   // v8.1：第2形態（1回だけ確認）
  go();
}
// v8.2：デバッグ「ボス(第2形態)出現」。1回目を倒していなくても、地下2階でゲーミング金木シンジと戦える（地下2階を出るまで有効）
function debugGaming() {
  UI.closeAll(); state.forceGaming = 1; loadBossArt(); sfx('door'); stopFishing();
  fade(() => { state.mobs = []; state.rocks = []; endBossFight(); game.map = 'cave2'; const u = maps.cave2.lm.up; player.x = u.x * 16 + 8; player.y = (u.y - 1) * 16 + 12; player.dir = 1; state.bossArm = false; spawnBoss(); },
    () => toast('デバッグ：ゲーミング金木シンジが出現', 'good'), { hold: 450, until: () => BOSS_ART.ready, max: 2500, slow: true });
}
function leaveCave2() {
  sfx('door');
  fade(() => { endBossFight(); state.bossArm = false; state.forceGaming = 0; state.rocks = []; game.map = 'cave'; const sd = maps.cave.objs.find(o => o.t === 'stairsDown'); if (sd) { player.x = sd.x * 16 + 8; player.y = (sd.y + 1) * 16 + 12; } player.dir = 0; }, () => saveGame(true));
}
// 画像（読めない時は仮の絵）。縮小してから、半透明をなくして縁取りし、ドットをはっきりさせる
const BOSS_ART = { cv: null, fl: null, dead: null, tried: false, ready: false };   // v6.1b：ready＝本物の画像を読めた（または読めないと分かった）。v8.1：dead＝体力0の絵
// v8.1：体力が0になった時の絵（Boss_Dead.png）。読めない時は、ふだんの絵のまま
function loadBossDeadArt() {
  const urls = assetUrls(BOSS.imgDead); let i = 0;
  const next = () => {
    if (i >= urls.length) { BOSS_ART.dead = null; console.warn('ボスの画像（' + BOSS.imgDead + '）を読み込めませんでした'); return; }
    const u = urls[i++], im = new Image();
    try { if (new URL(u).origin !== location.origin) im.crossOrigin = 'anonymous'; } catch (e) { /* noop */ }
    im.onload = () => { BOSS_ART.dead = prepBossArt(im); };
    im.onerror = next; im.src = u;
  };
  next();
}
function loadBossArt() {
  if (BOSS_ART.tried) return; BOSS_ART.tried = true;
  loadBossDeadArt();   // v8.1
  const urls = assetUrls(BOSS.img); let i = 0;
  const next = () => {
    if (i >= urls.length) { BOSS_ART.cv = bossFallbackArt(); BOSS_ART.fl = flashOf(BOSS_ART.cv); BOSS_ART.ready = true; console.warn('ボスの画像（' + BOSS.img + '）を読み込めませんでした'); return; }
    const u = urls[i++], im = new Image();
    try { if (new URL(u).origin !== location.origin) im.crossOrigin = 'anonymous'; } catch (e) { /* noop */ }
    im.onload = () => { BOSS_ART.cv = prepBossArt(im); BOSS_ART.fl = flashOf(BOSS_ART.cv); BOSS_ART.ready = true; };   // v6.1b：読み込めた印
    im.onerror = next; im.src = u;
  };
  BOSS_ART.cv = bossFallbackArt(); BOSS_ART.fl = flashOf(BOSS_ART.cv);   // 読み込むまでは仮の絵
  next();
}
function prepBossArt(im) {
  const W = im.naturalWidth || im.width, H = im.naturalHeight || im.height, src = mkCanvas(W, H), sx = src.getContext('2d'); sx.drawImage(im, 0, 0);
  // v8.1：背景が透明でない画像（四すみが不透明）は、ふちから背景の色をたどって透明にする（白い背景の Boss_Dead.png など）。透明な画像はそのまま
  try {
    const id = sx.getImageData(0, 0, W, H), d = id.data, A = (x, y) => d[(y * W + x) * 4 + 3];
    if (A(0, 0) > 200 && A(W - 1, 0) > 200 && A(0, H - 1) > 200 && A(W - 1, H - 1) > 200) {
      const br = d[0], bgc = d[1], bb = d[2], near = i => Math.abs(d[i] - br) + Math.abs(d[i + 1] - bgc) + Math.abs(d[i + 2] - bb) < 90;
      const seen = new Uint8Array(W * H), q = [];
      for (let x = 0; x < W; x++) q.push(x, (H - 1) * W + x); for (let y = 0; y < H; y++) q.push(y * W, y * W + W - 1);
      while (q.length) { const p = q.pop(); if (seen[p]) continue; seen[p] = 1; if (!near(p * 4)) continue; d[p * 4 + 3] = 0; const x = p % W, y = (p / W) | 0; if (x > 0) q.push(p - 1); if (x < W - 1) q.push(p + 1); if (y > 0) q.push(p - W); if (y < H - 1) q.push(p + W); }
      sx.putImageData(id, 0, 0);
    }
  } catch (er) { /* 読めない画像はそのまま */ }
  let x0 = 0, y0 = 0, x1 = W - 1, y1 = H - 1;
  try { const d = sx.getImageData(0, 0, W, H).data; let a = W, b = H, c = -1, e = -1; for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (d[(y * W + x) * 4 + 3] > 40) { if (x < a) a = x; if (y < b) b = y; if (x > c) c = x; if (y > e) e = y; } if (c >= 0) { x0 = a; y0 = b; x1 = c; y1 = e; } } catch (er) { /* 読めない画像は全体を使う */ }
  const S = BOSS.size, cw = x1 - x0 + 1, ch = y1 - y0 + 1, k = S / Math.max(cw, ch), dw = Math.max(1, Math.round(cw * k)), dh = Math.max(1, Math.round(ch * k)), N = S + 2;
  const out = mkCanvas(N, N), ox = out.getContext('2d'); ox.imageSmoothingEnabled = true; ox.imageSmoothingQuality = 'high';
  ox.drawImage(src, x0, y0, cw, ch, 1 + Math.floor((S - dw) / 2), 1 + (S - dh), dw, dh);   // 下ぞろえ（足元が地面）
  try {
    const id = ox.getImageData(0, 0, N, N), p = id.data, solid = new Uint8Array(N * N);
    for (let i = 0; i < N * N; i++) { if (p[i * 4 + 3] >= 110) { p[i * 4 + 3] = 255; solid[i] = 1; } else p[i * 4 + 3] = 0; }
    for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) { const i = y * N + x; if (solid[i]) continue; if ((x > 0 && solid[i - 1]) || (x < N - 1 && solid[i + 1]) || (y > 0 && solid[i - N]) || (y < N - 1 && solid[i + N])) { p[i * 4] = 20; p[i * 4 + 1] = 10; p[i * 4 + 2] = 18; p[i * 4 + 3] = 255; } }
    ox.putImageData(id, 0, 0);
  } catch (er) { /* 別サイトの画像で読めない時は、そのまま */ }
  return out;
}
function bossFallbackArt() {
  const S = BOSS.size, c = mkCanvas(S + 2, S + 2), x = c.getContext('2d'), m = S / 2 + 1;
  x.fillStyle = '#140a12'; x.beginPath(); x.ellipse(m, m + 4, S / 2 - 2, S / 2 - 4, 0, 0, Math.PI * 2); x.fill();
  x.fillStyle = '#2e1e36'; x.beginPath(); x.ellipse(m, m + 4, S / 2 - 5, S / 2 - 7, 0, 0, Math.PI * 2); x.fill();
  x.fillStyle = '#ff3040'; x.fillRect(m - 9, m - 1, 5, 3); x.fillRect(m + 4, m - 1, 5, 3);
  return c;
}
function tintOf(c, col) { const f = mkCanvas(c.width, c.height), x = f.getContext('2d'); x.drawImage(c, 0, 0); x.globalCompositeOperation = 'source-atop'; x.fillStyle = col; x.fillRect(0, 0, f.width, f.height); return f; }   // v6b：残像用の色の付いた絵
function flashOf(c) { const f = mkCanvas(c.width, c.height), x = f.getContext('2d'); x.drawImage(c, 0, 0); x.globalCompositeOperation = 'source-atop'; x.fillStyle = '#ffffff'; x.fillRect(0, 0, f.width, f.height); return f; }
// ---- 戦い ----
// v6.1b：ボスが出てくる条件（倒していない、またはデバッグの再戦で入り直した）
// v8.1：第2形態（ゲーミング）は、1回目を倒したあと地下2階に居座る（デバッグの再戦の時は、1回目から）
const bossCanSpawn = () => !game.flags.bossDown || !!state.bossArm || !!game.flags.gaming || !!state.forceGaming;   // v8.2
function spawnBoss() {
  loadBossArt();
  const gm = !!state.forceGaming || (!!game.flags.gaming && !state.bossArm && !!game.flags.bossDown), hp = gm ? BOSS_G.hp : BOSS.hp;   // v8.2：デバッグの「ボス(第2形態)出現」   // v8.1：第2形態から始まるか
  const b = { x: (ARENA.x0 + ARENA.x1) / 2, y: ARENA.y0 + 24, hp, max: hp, lag: hp, phase: gm ? 4 : 1, st: 'pre', t: 0, atk: null, hurt: 0, z: 0, face: 1, tilt: 0, sq: 0, orb: 1, tg: [], rings: [], shots: [], fx: null, say: null, sayT: 0, blinkA: null, last: null, last2: null,   // v6.1b：pre＝画面が明るくなるのを待つ
    stamps: [], vfx: [], trail: [], trT: 0, sparks: [], beam: null, charge: 0, zbUsed: gm, zbIn: -1, zbCd: 0, walk: 0, px: 0, py: 0, kx: 0, hop: 0,   // v6b
    gaming: gm ? 1 : 0, gT: 0, healCd: BOSS_G.healCd * 0.5, healN: 0, zinfCd: 0, laser: null, clones: [], rk: 0,
    zones: [], balls: [], hole: null, chart: [], cut: null, impact: 0 };   // v8.2：zones＝ハンマー・爆弾の範囲、balls＝雪玉、hole＝ブラックホール、chart＝株価の線、cut＝カットイン   // v8.1：gaming＝第2形態、gT＝第2形態と戦っている秒数
  b.px = b.x; b.py = b.y;
  state.boss = b; state.camBias = 0.6;   // v6.1b：明るくなった時に、ボスも画面に入るように
}
const bossNameOf = b => (b && b.gaming ? BOSS_G.name : BOSS.name);   // v8.1
// v6.1b：画面が明るくなってから登場（セリフ・体力バー）。セリフの間は動かない
function bossIntro(b) {
  b.st = 'intro'; b.t = 3.0;
  if (b.gaming) { bossSay(game.flags.gTry ? BOSS_G.lines.retry : BOSS_G.lines.intro, 2.6); game.flags.gTry = (game.flags.gTry || 0) + 1; }   // v8.1：第2形態のセリフ
  else { bossSay(game.flags.bossTry ? BOSS.lines.retry : BOSS.lines.intro, 2.6); game.flags.bossTry = (game.flags.bossTry || 0) + 1; }
  document.body.classList.add('boss-on'); updateBossBar(true); sfx('warn'); state.shake = 0.4;
}
function endBossFight() { state.boss = null; state.pstun = 0; document.body.classList.remove('boss-on'); const el = $('boss-bar'); if (el) { el.classList.add('hidden'); el.classList.remove('gaming'); el.classList.remove('healing'); } }
function bossSay(t, s) { const b = state.boss; if (b) { b.say = t; b.sayT = s; } }
// v8.1：第2形態の攻撃は、ダメージが BOSS_G.mul 倍
function bossHit(dmg, x, y) { const b = state.boss, g = b && b.gaming; hurtPlayer(g ? Math.round(dmg * BOSS_G.mul) : dmg, { x, y, name: bossNameOf(b) }); }
// v6.1b：プレイヤーのスタン（その間は動けない・攻撃や調べるもできない）
function stunPlayer(sec) { state.pstun = Math.max(state.pstun || 0, sec); stopFishing(); state.gather.o = null; floatText(player.x, player.y - 30, 'スタン！', '#ffe060'); }
function bossMove(b, mx, my) { const nx = clamp(b.x + mx, ARENA.x0, ARENA.x1), ny = clamp(b.y + my, ARENA.y0, ARENA.y1), hit = nx !== b.x + mx || ny !== b.y + my; b.x = nx; b.y = ny; return hit; }
const angDiff = (a, b) => { let d = a - b; while (d > Math.PI) d -= Math.PI * 2; while (d < -Math.PI) d += Math.PI * 2; return d; };
function inCone(cx, cy, dir, r, half) { const dx = player.x - cx, dy = player.y - 6 - cy, d = Math.hypot(dx, dy); if (d > r + 5) return false; if (d < 14) return true; return Math.abs(angDiff(Math.atan2(dy, dx), dir)) <= half; }
function bossInFront() {
  const b = state.boss; if (!b || b.st === 'die' || b.st === 'fake' || b.st === 'revive' || b.z > 4) return false;   // v8.1：倒れている間・変身中はねらえない
  const [vx, vy] = D8[dir8()], dx = b.x - player.x, dy = (b.y - 20) - (player.y - 4), d = Math.hypot(dx, dy);   // v8d：8方向
  if (d > 17 + 29) return false; if (d > 20 && (dx * vx + dy * vy) / d < 0.2) return false; return true;   // v6.1a：リーチ 41→46px
}
function attackBoss() {
  const g = game, b = state.boss, wk = heldAtk(), hit = rollAtk(wk), dmg = hit.dmg;   // v6.1a：新しいダメージ計算
  state.atkCd = (wk === 'ironSword' ? 0.32 : 0.42) * (g.stamina <= 0 ? 1.6 : 1); state.swing = 0.15; player.lunge = 0.12;
  g.stamina = Math.max(0, g.stamina - stCost(5)); state.stIdle = 0;
  if (wk) useTool(TOOLS[wk].cat);   // v6.1a：斧・つるはしで殴っても耐久が減る
  if (b.st === 'pre' || b.st === 'roar' || b.st === 'intro' || b.st === 'die' || b.st === 'fake' || b.st === 'revive' || b.z > 4 || (b.blinkA != null && b.blinkA < 0.6) || (b.atk && (b.atk.k === 'zero' || b.atk.k === 'heal'))) { floatText(b.x, b.y - 40, 'ミス', '#a0a0b0'); sfx('ui'); return; }   // v8.1：無限リボ払いの間も効かない
  b.hp -= dmg; b.hurt = 0.1; b.kx = 1;
  // v6b：3段階目は、ゼロ・バーストを撃つまでは倒れない（必ず1回は撃つ）
  if (b.hp <= 0 && b.phase >= 3 && !b.zbUsed && !b.gaming) { b.hp = 1; b.zbIn = 0; if (b.sayT <= 0) bossSay(BOSS.lines.last, 1.6); } sfx('chop'); hitText(b.x + rnd(-8, 8), b.y - 44, dmg, hit.crit); burst(b.x, b.y - 22, '#ffffff', 4);
  if (b.hp <= 0) { b.hp = 0; b.st = 'die'; b.t = 2; b.atk = null; b.tg = []; b.rings = []; b.shots = []; b.stamps = []; b.beam = null; b.charge = 0; b.blinkA = null; b.z = 0; b.laser = null; b.clones = []; b.tilt = 0; b.zones = []; b.balls = []; b.hole = null; b.chart = []; b.cut = null; sfx('unlock'); state.shake = 0.6; return; }   // v8.1：ここから Boss_Dead.png の絵
  if (b.gaming) return;   // v8.1：第2形態は段階が変わらない
  const ph = b.hp / b.max > 0.66 ? 1 : b.hp / b.max > 0.33 ? 2 : 3;
  if (ph > b.phase) {   // 段階が上がる：吠えて押し返す（この間は無敵）
    b.phase = ph; b.st = 'roar'; b.t = 1.1; b.atk = null; b.tg = []; b.blinkA = null; b.z = 0;
    bossSay(ph === 2 ? BOSS.lines.p2 : BOSS.lines.p3, 2.2); sfx('warn'); state.shake = 0.6;
    if (ph >= 3) b.zbIn = rndi(0, 2);   // v6b：何回目の攻撃でゼロ・バーストを出すか（0〜2回あと）
    state.flash = Math.max(state.flash, 0.25); for (let k = 0; k < 3; k++) b.vfx.push({ k: 'ring', x: b.x, y: b.y - 10, r: 8 + k * 10, v: 190, t: 0.55, T: 0.55, col: ph >= 3 ? '255,60,90' : '255,170,90' });   // v6b：吠える衝撃（見た目だけ）
    const dx = player.x - b.x, dy = player.y - b.y, l = Math.hypot(dx, dy) || 1; if (l < 80) { tryMove(dx / l * 24, 0); tryMove(0, dy / l * 24); }
  }
}
function bossDefeated() {
  const b = state.boss;
  if (b.gaming) { gamingDefeated(); return; }   // v8.1：第2形態を倒した時（ふつうは無理）
  // v8.1：1回目を倒した。ここで「倒した」記録と報酬（黒い宝玉は持ち物へ。入らない時は足元）。
  // そのあと Boss_Dead.png の絵のまま倒れていて（fake）、虹色になって立ち上がる（revive）→ 第2形態
  const g = game;
  g.flags.bossDown = 1; g.flags.bossRematch = 0; state.bossArm = false; g.stats.boss = (g.stats.boss || 0) + 1;   // v6.1b：再戦の準備も消す
  g.flags.gaming = 1;   // v8.1：ここから地下2階には第2形態がいる
  for (const [id, n] of BOSS.reward) addItem(id, n, true);   // v6.2：ボスの報酬は消えない（足元に置く時も消えない）
  burst(b.x, b.y - 20, '#c080ff', 30); sfx('unlock');
  toast(`${BOSS.name}をたおした！ ${itemName('bossGem')}を手に入れた`, 'good');
  bossSay(BOSS.lines.win, 2.6); b.st = 'fake'; b.t = 3.0; b.tilt = 0; b.sq = 0;
  updateBossBar(); saveGame(true);
}
// v8.1：倒れたまま（fake）→ 虹色に光って立ち上がる（revive）→ 第2形態「ゲーミング金木シンジ」
function bossRevive(b, dt) {
  b.t -= dt;
  if (b.st === 'fake') { if (b.t <= 0) { b.st = 'revive'; b.t = 3.4; b.T = 3.4; b.rk = 0; bossSay(BOSS_G.lines.revive, 2.2); sfx('warn'); state.shake = 0.4; } return; }
  const k = clamp(1 - b.t / b.T, 0, 1); b.rk = k;
  b.tilt = Math.sin(b.t * (20 + k * 60)) * 0.04 * (1 + k * 2); state.shake = Math.max(state.shake, 0.05 + k * 0.22);
  if (Math.random() < dt * (10 + k * 70)) burst(b.x + rnd(-24, 24), b.y - rnd(4, 50), `hsl(${rndi(0, 359)},100%,62%)`, 2);
  if (Math.random() < dt * (2 + k * 6)) b.vfx.push({ k: 'ring', x: b.x, y: b.y - 4, r: 6, v: 120 + k * 120, t: 0.5, T: 0.5, col: hueRGB(rndi(0, 359)) });
  if (!b.gaming && b.t <= 1.1) {   // 変身！
    b.gaming = 1; b.phase = 4; b.max = BOSS_G.hp; b.hp = 0; b.lag = 0; b.gT = 0; b.healCd = BOSS_G.healCd * 0.5; b.healN = 0; b.zinfCd = 0; b.zbUsed = true; b.trail = [];
    state.flash = Math.max(state.flash, 0.9); state.shake = 1.0; sfx('unlock'); sfx('thud');
    for (let i = 0; i < 6; i++) b.vfx.push({ k: 'ring', x: b.x, y: b.y - 20, r: 6 + i * 6, v: 200 + i * 60, t: 0.8, T: 0.8, col: hueRGB(i * 60) });
    for (let i = 0; i < 30; i++) burst(b.x + rnd(-30, 30), b.y - rnd(0, 60), `hsl(${i * 12},100%,62%)`, 1);
    bossSay(BOSS_G.lines.awake, 2.4); updateBossBar(true); toast(`${BOSS.name}が、${BOSS_G.name}になった！`, 'bad');
    const dx = player.x - b.x, dy = player.y - b.y, l = Math.hypot(dx, dy) || 1; if (l < 90) { tryMove(dx / l * 28, 0); tryMove(0, dy / l * 28); }   // 変身の勢いで押し返す
  }
  if (b.gaming) { b.hp = Math.min(b.max, b.hp + b.max * dt / 0.9); b.lag = b.hp; }   // 体力が一気に満タンに
  if (b.t <= 0) { b.hp = b.max; b.lag = b.max; b.st = 'move'; b.t = 0.7; b.rk = 0; b.tilt = 0; }
}
// v8.1：第2形態を倒した（ふつうは無理）。地下2階は静かになる
function gamingDefeated() {
  const b = state.boss, g = game; g.flags.gaming = 0; g.stats.gamingDown = (g.stats.gamingDown || 0) + 1; if (state.forceGaming) { state.forceGaming = 0; g.flags.bossDown = 1; }   // v8.2：デバッグで出した時も、倒したら地下2階は静かになる
  burst(b.x, b.y - 20, '#ffffff', 40); endBossFight(); sfx('unlock');
  toast(`${BOSS_G.name}をたおした……！？`, 'good');
  queueTalk([['sys', `${BOSS_G.name}「${BOSS_G.lines.win}」`], ['sys', 'ありえないことが起きた……。地下2階は、静かになった。']]); saveGame(true);
}
function bossRetry() {
  // v8.1：第2形態に負けた時は、耐えた秒数と最高記録を出す
  const gb = state.boss && state.boss.gaming ? state.boss.gT || 0 : null;
  if (gb != null) game.stats.gamingBest = Math.max(game.stats.gamingBest || 0, Math.round(gb * 10) / 10);
  fade(() => {
    const g = game; endBossFight(); const u = maps.cave2.lm.up; player.x = u.x * 16 + 8; player.y = (u.y - 1) * 16 + 12; player.dir = 1;
    if (bossCanSpawn()) spawnBoss();   // v6.1b：明るくなる前に置いておく
    g.hp = 70; g.stamina = 100; g.exhaust = false; g.sick = 0; g.poison = 0; g.hunger = Math.max(g.hunger, 25); g.thirst = Math.max(g.thirst, 25); state.invuln = 1.5;
  }, () => { state.faintLock = false; if (state.scene === 'play') toast(gb != null ? `階段の前で目を覚ました……（${BOSS_G.name}に${gb.toFixed(1)}秒耐えた／最高${(game.stats.gamingBest || 0).toFixed(1)}秒）` : '階段の前で目を覚ました……（日付も持ち物もそのまま）'); });
}
function bossPick(b, dist) {
  // v6b：3段階目は、必殺技「ゼロ・バースト」を必ず1回以上（何回目の攻撃で出すかは乱数）
  if (!b.gaming && b.phase >= 3 && !b.zbUsed && b.zbIn-- <= 0) { startZero(b); return; }
  // v8.1：第2形態は、戦い始めて BOSS_G.ultAt 秒たつと「ゼロ・バースト∞」（逃げ場がわずか）を必ず撃つ
  if (b.gaming && b.gT >= BOSS_G.ultAt && b.zinfCd <= 0) { startZero(b, true); return; }
  const opts = [], add = (k, w) => { if (k === b.last && k === b.last2) return; opts.push([k, w]); };
  if (b.gaming) {   // v8.1：第2形態の技（体力が減ると「無限リボ払い」で回復。v8.1再：1回だけ・30%）
    if (b.hp < b.max * BOSS_G.healAt && b.healCd <= 0 && (b.healN || 0) < BOSS_G.healMax) add('heal', 100);   // v8.1再：回数に上限
    else {   // v8.2：技が18種類（＋無限リボ払い・ゼロ・バースト∞）になったので出やすさを見直し。同じ技は2回続けて出ない
      for (const kk in BOSS_G.w) {
        if (kk === b.last) continue; if (kk === 'snow' && b.balls && b.balls.length) continue; if (kk === 'hole' && b.hole) continue;   // 雪玉・ブラックホールは1つずつ
        let w = BOSS_G.w[kk]; if (kk === 'claw') w *= dist < 90 ? 1.5 : 0.4; if (kk === 'charge') w *= dist > 70 ? 1.3 : 0.6; opts.push([kk, w]);
      }
    }
  } else {
    add('claw', dist < 90 ? 5 : 1); add('charge', dist > 70 ? 4 : 1.5); add('leap', 2.5); add('stamp', b.phase >= 2 ? 2.5 : 2);   // v6b：衝撃のハイタッチ → 判子レイン
    if (b.phase >= 2) add('shards', 2.5); if (b.phase >= 3) add('blink', 3);
    if (b.phase >= 3 && b.zbUsed && b.zbCd <= 0) add('zero', 0.8);   // 2回目以降はたまに
  }
  if (!opts.length) add('claw', 1);
  let s = opts.reduce((a, o) => a + o[1], 0) * Math.random(), k = opts[0][0];
  for (const [kk, w] of opts) { s -= w; if (s <= 0) { k = kk; break; } }
  if (k === 'zero') { startZero(b); return; }
  b.last2 = b.last; b.last = k; b.st = 'atk'; b.tg = []; b.laser = null;   // v8.1
  b.atk = { k, step: 0, t: k === 'claw' ? (b.gaming ? 0.45 : 0.6) : k === 'leap' ? 0.32 : k === 'blink' || k === 'laser' || k === 'hole' ? 0.3 : k === 'heal' ? 0 : k === 'crash' ? 0.7 : BP[b.phase].tele + (k === 'charge' ? 0.15 : 0), n: 0, w: 0, nb: 0, off: Math.random() * Math.PI };
  if (k === 'ring' || k === 'wave') { b.atk.gap = Math.random() * Math.PI * 2; b.atk.gh = k === 'wave' ? 0.5 : 0.62; b.tg = [{ k: 'ring', gap: b.atk.gap, gh: b.atk.gh }]; }   // v8.1：遅延損害金ウェーブも、すき間を先に決める
  floatText(b.x, b.y - 58, (b.gaming && BOSS_G.atk[k] || BOSS.atk[k]) + '！', b.gaming ? `hsl(${rndi(0, 359)},100%,68%)` : '#ffd84a');   // v8.1：第2形態は技の名前も虹色
}
// v6b：ゼロ・バーストの開始（攻撃名は撃つ時に出す）。v8.1：inf＝第2形態の「ゼロ・バースト∞」（すき間なし）
function startZero(b, inf) { b.last2 = b.last; b.last = 'zero'; b.st = 'atk'; b.tg = []; b.laser = null; if (inf) { b.shots = []; b.zones = []; b.balls = []; b.hole = null; b.chart = []; b.clones = []; b.stamps = []; b.rings = []; }   /* v8.2：∞の前は、ほかの攻撃を全部消す */ b.atk = { k: 'zero', inf: !!inf, step: 0, t: 0.35, n: 0, w: 0, nb: 0 }; sfx('door'); }
// ビームの「すき間」：今いる所から歩いて間に合う距離（30〜80px）に、横か斜めの細い道を作る
function zeroGap() {
  const px = player.x, py = player.y - 6, th = Math.random() < 0.5 ? 0 : (Math.random() < 0.5 ? -1 : 1) * rnd(0.12, 0.3);
  const off = (Math.random() < 0.5 ? -1 : 1) * rnd(30, 80); let yp = py + off; if (yp < 46 || yp > 244) yp = py - off; yp = clamp(yp, 46, 244);
  const gx = (ARENA.x0 + ARENA.x1) / 2; return { gx, gy: yp - Math.tan(th) * (px - gx), th, w: 24 };
}
const zeroLineY = (g, x) => g.gy + Math.tan(g.th) * (x - g.gx);
const zeroSafe = g => Math.abs((player.y - 6 - g.gy) * Math.cos(g.th) - (player.x - g.gx) * Math.sin(g.th)) <= g.w / 2 - 2;
// 残像（素早い動き・瞬間移動）
function bossTrail(b, dt, gap) { b.trT -= dt; if (b.trT <= 0) { b.trT = gap || 0.04; b.trail.push({ x: b.x, y: b.y, z: b.z, face: b.face, a: 0.55 }); if (b.trail.length > 10) b.trail.shift(); } }
function bossAtk(b, dt, P, dx, dy, dist) {
  const a = b.atk, ang = Math.atan2(dy, dx), ph = b.phase; a.t -= dt;
  const done = rec => { b.atk = null; b.tg = []; b.blinkA = null; b.laser = null; b.st = 'rec'; b.t = rec != null ? rec : P.rec; };   // v8.1：レーザーも消す
  const strike = (dmg, dir) => { if (inCone(b.x, b.y - 12, dir, 60, 0.95)) bossHit(dmg, b.x, b.y - 12); b.fx = { k: 'slash', a: dir, t: 0.18 }; sfx('chop'); b.sq = -0.6; bossMove(b, Math.cos(dir) * 10, Math.sin(dir) * 10); };
  switch (a.k) {
    case 'claw':   // 間合いを詰めて、扇形に何度も引っかく（段階で2→3→4回）
      if (a.step === 0) {
        bossMove(b, dx / dist * P.mv * 1.9 * dt, dy / dist * P.mv * 1.9 * dt);
        if (dist < 44 || a.t <= 0) { a.step = 1; a.dir = ang; a.t = P.tele * 0.8; b.tg = [{ k: 'cone', a: a.dir, r: 60, half: 0.95 }]; }
      } else if (a.t <= 0) {
        strike(18, a.dir); a.n++;
        if (a.n >= ph + 1) { done(); break; }
        a.dir = ang; a.t = P.tele * 0.65; b.tg = [{ k: 'cone', a: a.dir, r: 60, half: 0.95 }];
      }
      break;
    case 'charge':   // 狙いを定めて一直線に突進（段階2以降は壁で跳ね返ってもう一度）
      if (a.step === 0) {
        if (a.t > 0.25) a.dir = ang;
        b.tg = [{ k: 'line', a: a.dir, w: 34 }]; b.tilt = Math.sin(a.t * 40) * 0.05;
        if (a.t <= 0) { a.step = 1; a.t = 1.4; b.tg = []; sfx('warn'); }
      } else {
        const sp = (300 + 40 * (ph - 1)) * 0.9 * (b.gaming ? 1.3 : 1), hitWall = bossMove(b, Math.cos(a.dir) * sp * dt, Math.sin(a.dir) * sp * dt); bossTrail(b, dt, 0.03);   // v8.1：第2形態は速い
        b.tilt = Math.cos(a.dir) * 0.22; if (Math.random() < 0.5) burst(b.x, b.y - 2, '#6a6070', 1);
        if (Math.hypot(player.x - b.x, player.y - 6 - (b.y - 12)) < 26) bossHit(24, b.x, b.y - 12);
        if (hitWall || a.t <= 0) {
          if (hitWall) { state.shake = 0.35; sfx('thud'); burst(b.x, b.y - 10, '#a09080', 10); }
          if (a.nb < ph - 1) { a.nb++; a.step = 0; a.t = P.tele * 0.55; } else done(P.rec + 0.35);   // 壁にぶつかったあとは大きなすき
        }
      }
      break;
    case 'leap':   // 跳び上がって相手の上へ。影が止まったら、そこへ落ちてくる
      if (a.step === 0) { b.sq = 0.7; if (a.t <= 0) { a.step = 1; a.t = [0, 1.05, 0.9, 0.78, 0.62][ph]; a.lock = [0, 0.6, 0.5, 0.42, 0.3][ph]; sfx('door'); } }   // v8.1：4＝第2形態
      else if (a.step === 1) {
        b.z = Math.min(110, b.z + 320 * dt); if (b.z < 100) bossTrail(b, dt, 0.05);
        if (a.t > a.lock) { a.tx = clamp(player.x, ARENA.x0, ARENA.x1); a.ty = clamp(player.y, ARENA.y0, ARENA.y1); b.x += (a.tx - b.x) * Math.min(1, dt * 9); b.y += (a.ty - b.y) * Math.min(1, dt * 9); }
        else { b.x = a.tx; b.y = a.ty; b.tg = [{ k: 'circle', x: a.tx, y: a.ty - 6, r: 34 }]; }
        if (a.t <= 0) { a.step = 2; a.t = 0.16; a.z0 = b.z; }
      } else {
        b.z = Math.max(0, a.z0 * a.t / 0.16);
        if (a.t <= 0) {
          b.z = 0; b.sq = 1; state.shake = 0.5; sfx('thud'); burst(b.x, b.y - 2, '#8a8070', 14);
          if (Math.hypot(player.x - b.x, player.y - 6 - (b.y - 6)) < 36) { const can = state.invuln <= 0 && !state.god; bossHit(26, b.x, b.y - 6); if (can) stunPlayer(1.5); }   // v6.1b：当たると1.5秒動けない
          // v6b：着地の衝撃波（よけにくい輪）は廃止。見た目だけの砂ぼこりの輪にする
          b.vfx.push({ k: 'ring', x: b.x, y: b.y - 2, r: 10, v: 150, t: 0.4, T: 0.4, col: b.gaming ? hueRGB(rndi(0, 359)) : '200,180,150' }); burst(b.x - 14, b.y - 2, '#a09080', 6); burst(b.x + 14, b.y - 2, '#a09080', 6);
          a.n++;
          if (b.gaming && a.n < 3) { a.step = 1; a.t = [0, 1.05, 0.9, 0.78, 0.62][ph]; a.lock = [0, 0.6, 0.5, 0.42, 0.3][ph]; sfx('door'); break; }   // v8.1：ジャンピング督促・三連（3回続けて跳ぶ）
          done();
        }
      }
      break;
    case 'ring':   // 足をドンと鳴らして、広がる衝撃波（光らない「すき間」に入ればよけられる）
      if (a.step === 0) { b.sq = 0.35 + Math.sin(a.t * 30) * 0.1; if (a.t <= 0) { b.sq = 1; sfx('thud'); state.shake = 0.3; b.rings.push({ x: b.x, y: b.y - 6, r: 16, v: 90 + 15 * ph, max: 230, w: 7, dmg: 16, gap: a.gap, gh: 0.62 }); if (ph >= 3) { a.step = 1; a.t = 0.5; a.gap += Math.PI * (0.6 + Math.random() * 0.8); b.tg = [{ k: 'ring', gap: a.gap, gh: 0.62 }]; } else done(); } }
      else if (a.t <= 0) { b.sq = 1; sfx('thud'); b.rings.push({ x: b.x, y: b.y - 6, r: 16, v: 110, max: 230, w: 7, dmg: 16, gap: a.gap, gh: 0.62 }); done(); }
      break;
    case 'shards':   // 紙吹雪のように、全方向へ弾をばらまく（v7a：段階2は14発×3回・速さ98、段階3は18発×4回・速さ112、ダメージ12→14）
      b.tilt = Math.sin(a.t * 50) * 0.06;
      if (a.t <= 0) {
        const n = ph >= 4 ? 22 : ph >= 3 ? 18 : 14, sp = ph >= 4 ? 105 : ph >= 3 ? 112 : 98;   // v8.1：請求書ストーム（第2形態）は28発×6回・速さ150。v8.2：22発×4回・速さ105
        for (let i = 0; i < n; i++) { const an = a.off + i / n * Math.PI * 2; b.shots.push({ x: b.x, y: b.y - 18, vx: Math.cos(an) * sp, vy: Math.sin(an) * sp, life: 4, r: 4, dmg: 14 }); }
        sfx('ui'); a.w++; a.off += Math.PI / n * (ph >= 4 && a.w % 2 ? -0.6 : 1);
        if (a.w >= (ph >= 4 ? 4 : ph >= 3 ? 4 : 3)) done(); else a.t = ph >= 4 ? 0.26 : 0.34;
      }
      break;
    case 'stamp': {   // v6b：判子レイン。ステージ全体のランダムな場所に、円い判子が降る（予告の1秒後）。v6.1b：約3秒・1秒あたり1.5倍・大きさ2倍・場所は完全ランダム
      if (a.step === 0) { b.sq = 0.5 + Math.sin(a.t * 30) * 0.12; if (a.t <= 0) { a.step = 1; a.t = b.gaming ? 3.6 : 3; a.sp = 0; sfx('warn'); } }
      else {
        a.sp -= dt;
        if (a.sp <= 0 && a.t > (b.gaming ? 0.7 : 0.9)) {   // 最後の約1秒は新しく降らせない（予告が全部消えてから終わる）
          a.sp += [0, 0.32, 0.24, 0.17, 0.1323][ph] / 2.25;   /* v8.2：第2形態は1秒に約26個→約17個 */   // v6.2：1秒あたりの数をさらに1.5倍（v6.1の1.5倍×1.5）。v8.1：第2形態はさらに2倍
          let x = rnd(40, 344), y = rnd(44, 250), bd = -1;   // v7a：8か所の候補から、いま出ている判子から一番遠い所を選ぶ（散らばらせる）
          for (let k = 0; k < 8; k++) { const cx = rnd(40, 344), cy = rnd(44, 250); let md = 1e9; for (const o of b.stamps) md = Math.min(md, Math.hypot(o.x - cx, o.y - cy)); if (md > bd) { bd = md; x = cx; y = cy; } }
          const tt = b.gaming ? 0.7 : 1;   // v8.1：第2形態は予告が短い
          b.stamps.push({ x, y, t: tt, T: tt, r: 28, dmg: [0, 14, 15, 16, 16][ph], rb: b.gaming ? 1 : 0 }); b.sq = -0.35; b.hop = 0.16;
        }
        if (a.t <= 0) done(P.rec + 0.2);
      }
      break;
    }
    case 'zero': {   // v6b：必殺技。端へ瞬間移動 → セリフ → 5秒ため（v6.2：残り1.5秒で予告。v8e：1.25秒に短縮）→ 発射 → 中央へ戻って3秒スタン（v6.1b：5→3秒）
      if (a.step === 0) {   // 消える
        b.blinkA = Math.max(0, a.t / 0.35); bossTrail(b, dt, 0.04);
        if (a.t <= 0) {
          a.side = Math.random() < 0.5 ? -1 : 1; b.x = a.side < 0 ? 14 : 370; b.y = clamp(player.y + rnd(-30, 30), ARENA.y0 + 24, ARENA.y1 - 14);   // 画面に入るよう、高さはプレイヤーの近く
          b.z = 12; b.face = -a.side; b.trail = [];   // v6.1b：コメントの中に入って動いていなかった処理を戻した（中央を向いて少し浮く）
          a.step = 1; a.t = 1.6; bossSay(a.inf ? BOSS_G.lines.zero : BOSS.lines.zero, 1.9); sfx('warn'); burst(b.x, b.y - 30, '#c080ff', 18);   // v8.1：∞のセリフ
          if (a.inf) { b.cut = { k: 'zinf', t: 1.5, T: 1.5 }; state.shake = Math.max(state.shake, 0.5); sfx('unlock'); }   // v8.2：∞はアニメのようなカットイン
        }
      } else if (a.step === 1) {   // 現れて、セリフ。少し間を空ける
        b.blinkA = Math.min(1, (1.6 - a.t) / 0.3); if (b.blinkA >= 1) b.blinkA = null;
        if (a.t <= 0) { b.blinkA = null; a.step = 2; a.t = a.inf ? 3 : 5; a.T = a.t; sfx('warn'); }   // v8.1：∞は3秒ため
      } else if (a.step === 2) {   // 5秒間のチャージ
        const k = 1 - a.t / a.T; b.charge = k; b.tilt = Math.sin(a.t * 60) * 0.02 * (1 + k * 3);
        state.shake = Math.max(state.shake, 0.06 + k * 0.2);
        if (Math.random() < dt * (18 + k * 70)) { const an = rnd(0, Math.PI * 2), r = rnd(40, 90); b.sparks.push({ x: b.x - a.side * 26 + Math.cos(an) * r, y: b.y - 26 + Math.sin(an) * r, t: 0.45 }); }
        if (a.t <= (a.inf ? BOSS_G.zinfWarn : 1.25) && !a.gap) { a.gap = zeroGap(); if (a.inf) a.gap.w = BOSS_G.zinfW;   // v8.1再：∞にも、ふつうより細いすき間を作る   // v8e：予告は残り1.25秒（1.5秒から短縮）。v8.1：∞はすき間なし（ステージ全部）
          b.tg = [{ k: 'beam', side: a.side, gap: a.gap }]; sfx('warn'); floatText(b.x - a.side * 30, b.y - 70, a.inf ? '逃げ場はわずか！！' : '！！', '#ff5a4a'); }
        if (a.t <= 0) {   // 発射（ダメージ80。すき間にいれば当たらない。防具・無敵時間は関係ない）。v8.1：∞はどこにいても9999
          a.step = 3; a.t = 1.0; b.charge = 0; b.zbUsed = true; b.zbCd = 22; b.tg = []; if (a.inf) b.zinfCd = BOSS_G.ultCd;
          b.beam = { side: a.side, gap: a.gap, t: 1.0, T: 1.0, y0: b.y - 26, ox: b.x - a.side * 26, oy: b.y - b.z - 26, inf: a.inf ? 1 : 0 };
          for (let i = 0; i < 4; i++) b.vfx.push({ k: 'ring', x: b.beam.ox, y: b.beam.oy + 12, r: 6 + i * 4, v: 220 + i * 70, t: 0.5 + i * 0.12, T: 0.5 + i * 0.12, col: a.inf ? hueRGB(i * 90) : ['255,255,255', '255,120,220', '255,220,120', '160,90,255'][i] });   // v6.2：発射の衝撃波
          bossSay(a.inf ? BOSS_G.lines.zeroFire : BOSS.lines.zeroFire, 1.2); floatText(b.x - a.side * 40, b.y - 62, (a.inf ? BOSS_G.atk.zinf : BOSS.atk.zero) + '！', '#ffd84a');
          sfx('thud'); sfx('unlock'); state.flash = Math.max(state.flash, 0.75); state.shake = 1.1;
          if (!zeroSafe(a.gap)) hurtPlayer(a.inf ? 9999 : 80, { x: b.x, y: player.y, name: bossNameOf(b), pierce: true });
          if (a.inf) for (let i = 0; i < 40; i++) burst(rnd(40, 344), rnd(40, 250), `hsl(${rndi(0, 359)},100%,65%)`, 1);
          if (a.inf && b.beam) { b.cut = { k: 'zfire', t: 1.1, T: 1.1 }; b.impact = 0.12; for (let i = 0; i < 80; i++) b.vfx.push({ k: 'conf', x: rnd(30, 354), y: rnd(10, 150), vx: rnd(-40, 40), vy: rnd(-60, 10), t: rnd(1.4, 2.2), T: 2.2, h: rndi(0, 359) }); for (let i = 0; i < 6; i++) b.vfx.push({ k: 'ring', x: b.beam.ox, y: b.beam.oy + 12, r: 10 + i * 12, v: 300 + i * 90, t: 0.8, T: 0.8, col: hueRGB(i * 60) }); }   // v8.2：発射の瞬間（一瞬の暗転・画面いっぱいの技名・虹色の紙吹雪・大きな衝撃波）
          else for (let i = 0; i < 24; i++) burst(rnd(40, 344), zeroLineY(a.gap, rnd(40, 344)) + (Math.random() < 0.5 ? -1 : 1) * rnd(14, 90), i % 2 ? '#ff6ab0' : '#ffe080', 1);
        }
      } else if (a.step === 3) { if (a.t <= 0) { a.step = 4; a.t = 0.35; } }   // 撃ち終わり
      else {   // 消えて、ステージの中央へ戻る → スタン
        b.blinkA = Math.max(0, a.t / 0.35);
        if (a.t <= 0) {
          b.x = (ARENA.x0 + ARENA.x1) / 2; b.y = (ARENA.y0 + ARENA.y1) / 2; b.z = 0; b.blinkA = null; b.atk = null; b.tg = []; b.trail = [];
          if (b.gaming) { b.st = 'rec'; b.t = 0.8; bossSay(BOSS_G.lines.after, 2); for (let i = 0; i < 4; i++) b.vfx.push({ k: 'ring', x: b.x, y: b.y - 2, r: 8 + i * 6, v: 160, t: 0.45, T: 0.45, col: hueRGB(i * 90) }); break; }   // v8.1：第2形態は撃ったあとも動ける
          b.st = 'stun'; b.t = 3; bossSay(BOSS.lines.stun, 2.2); sfx('thud'); burst(b.x, b.y - 4, '#a090b0', 14); b.vfx.push({ k: 'ring', x: b.x, y: b.y - 2, r: 8, v: 160, t: 0.45, T: 0.45, col: '200,160,255' });
        }
      }
      break;
    }
    case 'blink':   // 消えて、相手の後ろに現れて引っかく（段階3だけ）
      if (a.step === 0) {
        b.blinkA = Math.max(0, a.t / 0.3); bossTrail(b, dt, 0.05);
        if (a.t <= 0) {
          const l = Math.max(1, dist), nx = clamp(player.x + dx / l * 40, ARENA.x0, ARENA.x1), ny = clamp(player.y + dy / l * 40, ARENA.y0, ARENA.y1);
          b.x = nx; b.y = ny; a.step = 1; a.t = P.tele * (b.gaming ? 1.25 : 0.95); a.T = a.t;   // v8.2：第2形態は、現れてから引っかくまでを少し長く
        }
      } else {
        b.blinkA = Math.min(1, 1 - a.t / a.T); if (a.t > 0.2) a.dir = ang;
        b.tg = [{ k: 'cone', a: a.dir, r: 60, half: 0.95 }];
        if (a.t <= 0) { b.blinkA = null; strike(20, a.dir); a.n++; if (b.gaming && a.n < 2) { a.step = 0; a.t = 0.36; b.tg = []; break; } done(P.rec + 0.1); }   // v8.1：残像ステップ・無限（3回続けて背後へ）。v8.2：2回、次に消えるまで0.2→0.36秒
      }
      break;
    // ---- v8.1：第2形態の新しい技 ----
    case 'spiral': {   // 複利スパイラル：回る5本の腕から弾をばらまく。弾は時間とともにどんどん速くなる（利息が利息を生む）
      if (a.step === 0) { b.sq = 0.4 + Math.sin(a.t * 30) * 0.1; if (a.t <= 0) { a.step = 1; a.t = 3.6; a.T = 3.6; a.sp = 0; a.rot = Math.random() * Math.PI * 2; a.cw = Math.random() < 0.5 ? -1 : 1; sfx('warn'); } }
      else {
        a.sp -= dt; a.rot += dt * (1.4 + (1 - a.t / a.T) * 1.8) * a.cw; b.tilt = Math.sin(a.t * 40) * 0.05;
        let guard = 0;
        while (a.sp <= 0 && guard++ < 4) { a.sp += 0.11;   // v8.2：0.085→0.11秒ごと（弾が約2割少ない）
          for (let i = 0; i < 5; i++) { const an = a.rot + i / 5 * Math.PI * 2; b.shots.push({ x: b.x, y: b.y - 18, vx: Math.cos(an) * 46, vy: Math.sin(an) * 46, life: 5, r: 3, dmg: 9, acc: 0.95, col: i }); } }
        if (Math.random() < dt * 6) sfx('ui');
        if (a.t <= 0) done(P.rec + 0.3);
      }
      break;
    }
    case 'press': {   // 差し押さえプレス：巨大な判子が追いかけてきて、止まった所へ落ちる（3回。当たると動けなくなる）
      if (a.step === 0) { b.sq = 0.5 + Math.sin(a.t * 30) * 0.12; if (a.t <= 0) { a.step = 1; a.t = 0.95; a.px = player.x; a.py = player.y - 4; } }
      else if (a.step === 1) {
        a.px += (player.x - a.px) * Math.min(1, dt * 5); a.py += (player.y - 4 - a.py) * Math.min(1, dt * 5);
        b.tg = [{ k: 'circle', x: a.px, y: a.py, r: 46 }];
        if (a.t <= 0) { b.tg = []; b.stamps.push({ x: a.px, y: a.py, t: 0.42, T: 0.42, r: 46, dmg: 25, stun: 1.6, rb: 1 }); a.n++; a.step = 2; a.t = 0.5; sfx('warn'); b.sq = -0.5; b.hop = 0.16; }
      } else if (a.t <= 0) { if (a.n >= 3) done(P.rec + 0.2); else { a.step = 1; a.t = 0.7; } }
      break;
    }
    case 'laser': {   // ブラックリスト・レーザー：ステージの真ん中へ移って、十字の虹色レーザーを回す（だんだん速く回る）
      if (a.step === 0) {
        b.blinkA = Math.max(0, a.t / 0.3); bossTrail(b, dt, 0.05);
        if (a.t <= 0) { b.x = (ARENA.x0 + ARENA.x1) / 2; b.y = (ARENA.y0 + ARENA.y1) / 2 + 6; b.z = 0; b.trail = []; a.step = 1; a.t = 0.9; a.T = 0.9; a.rot = Math.atan2(player.y - 6 - (b.y - 22), player.x - b.x) + Math.PI / 4; a.cw = Math.random() < 0.5 ? -1 : 1; sfx('warn'); }
      } else if (a.step === 1) {   // 予告（細い点線）
        b.blinkA = Math.min(1, 1 - a.t / a.T); if (b.blinkA >= 1) b.blinkA = null;
        b.laser = { rot: a.rot, n: 4, warn: 1, w: 8 };
        if (a.t <= 0) { b.blinkA = null; a.step = 2; a.t = 3.6; a.T = 3.6; sfx('unlock'); state.shake = 0.5; }
      } else {
        a.rot += dt * (0.7 + (1 - a.t / a.T) * 1.5) * a.cw * 0.85; b.laser =   /* v8.2：回転-15% */ { rot: a.rot, n: 4, warn: 0, w: 8 };
        state.shake = Math.max(state.shake, 0.06);
        const ox = b.x, oy = b.y - 22, px = player.x - ox, py = player.y - 6 - oy;
        for (let i = 0; i < 4; i++) { const an = a.rot + i * Math.PI / 2, c = Math.cos(an), s = Math.sin(an); if (px * c + py * s > 0 && Math.abs(-px * s + py * c) < 8) { bossHit(16, ox, oy); break; } }
        if (a.t <= 0) done(P.rec + 0.25);
      }
      break;
    }
    case 'mirror': {   // 多重債務ミラー：虹色の分身4体が、まわりから一斉に突っ込んでくる
      if (a.step === 0) {
        b.sq = 0.5 + Math.sin(a.t * 30) * 0.12;
        if (a.t <= 0) {
          b.clones = []; const base = Math.random() * Math.PI * 2;
          for (let i = 0; i < 4; i++) { const an = base + i * Math.PI / 2; b.clones.push({ x: clamp(player.x + Math.cos(an) * 105, ARENA.x0, ARENA.x1), y: clamp(player.y + Math.sin(an) * 85, ARENA.y0, ARENA.y1), face: 1, hue: i * 90, dir: 0, st: 'aim', t: 0.75 + i * 0.12, a: 0 }); }
          a.step = 1; a.t = 2.6; sfx('warn'); burst(b.x, b.y - 22, '#ffffff', 12);
        }
      } else if (a.t <= 0 || !b.clones.length) { b.clones = []; done(P.rec); }
      break;
    }
    case 'wave': {   // 遅延損害金ウェーブ：すき間のある衝撃波を、すき間の向きを変えながら3連発（v8.2：5→3）
      if (a.step === 0) { b.sq = 0.35 + Math.sin(a.t * 30) * 0.1; if (a.t <= 0) { a.step = 1; a.t = 0; } }
      else if (a.t <= 0) {
        b.sq = 1; sfx('thud'); state.shake = Math.max(state.shake, 0.25);
        b.rings.push({ x: b.x, y: b.y - 6, r: 16, v: 94.5, max: 182, w: 7, dmg: 13, gap: a.gap, gh: a.gh, rb: 1 });   // v8.2：速さ135→94.5、広がる範囲260→182（どちらも-30%）
        a.n++; if (a.n >= 3) { done(P.rec + 0.2); break; }   // v8.2：5→3連発
        a.gap += (Math.random() < 0.5 ? -1 : 1) * rnd(1.0, 2.2); b.tg = [{ k: 'ring', gap: a.gap, gh: a.gh }]; a.t = 0.546;   // v8.2：間隔0.42→0.546秒（+30%）
      }
      break;
    }
    // ---- v8.2：第2形態の新しい技（7個） ----
    case 'dun': {   // 督促状ラッシュ：追いかけてくる督促状（封筒）を、扇形に5通×3回
      b.sq = 0.3 + Math.sin(a.t * 30) * 0.1;
      if (a.t <= 0) {
        for (let i = 0; i < 5; i++) { const an = ang + (i - 2) * 0.34; b.shots.push({ x: b.x, y: b.y - 18, vx: Math.cos(an) * 105, vy: Math.sin(an) * 105, life: 4.5, r: 4, dmg: 12, home: 1.1, env: 1 }); }
        sfx('ui'); a.w++; b.sq = -0.4; if (a.w >= 3) done(P.rec + 0.2); else a.t = 0.5;
      }
      break;
    }
    case 'gavel': {   // 競売ハンマー：ボスからプレイヤーへ向かって3回たたき、最後に巨大なハンマーで「落札！！」
      if (a.step === 0) { b.sq = 0.5 + Math.sin(a.t * 30) * 0.12; if (a.t <= 0) { a.step = 1; a.n = 0; a.t = 0; a.tx = player.x; a.ty = player.y - 4; } }
      else if (a.t <= 0) {
        if (a.n < 3) {
          const l = Math.hypot(a.tx - b.x, a.ty - b.y) || 1, d = 70 * (a.n + 1), ux = (a.tx - b.x) / l, uy = (a.ty - b.y) / l;
          b.zones.push({ k: 'rect', x: clamp(b.x + ux * d, ARENA.x0 - 20, ARENA.x1 + 20), y: clamp(b.y - 4 + uy * d, ARENA.y0 - 30, ARENA.y1 + 10), hw: 30, hh: 22, t: 0.7, T: 0.7, dmg: 22, gavel: 1 });
          a.n++; a.t = 0.22; b.sq = -0.4;
        } else if (a.n === 3) { b.zones.push({ k: 'rect', x: clamp(player.x, ARENA.x0, ARENA.x1), y: clamp(player.y - 4, ARENA.y0 - 20, ARENA.y1), hw: 56, hh: 40, t: 0.95, T: 0.95, dmg: 30, gavel: 2 }); a.n++; a.t = 1.1; sfx('warn'); }
        else done(P.rec + 0.2);
      }
      break;
    }
    case 'hole': {   // 自己破産ブラックホール：真ん中に黒い穴。プレイヤーを吸い込み、まわりから請求書が吸い込まれてくる。最後に「破産宣告」の衝撃波
      if (a.step === 0) {
        b.blinkA = Math.max(0, a.t / 0.3); bossTrail(b, dt, 0.05);
        if (a.t <= 0) {
          b.x = (ARENA.x0 + ARENA.x1) / 2; b.y = ARENA.y0 + 6; b.z = 0; b.trail = []; b.blinkA = null; a.step = 1; a.t = 0.7;
          b.hole = { x: (ARENA.x0 + ARENA.x1) / 2, y: (ARENA.y0 + ARENA.y1) / 2 + 14, t: 0, T: 4.0, r: 2, hc: 0, gap: Math.random() * Math.PI * 2 };
          bossSay(BOSS_G.lines.hole, 1.8); sfx('warn'); state.shake = 0.4;
        }
      } else if (a.step === 1) { if (a.t <= 0) { a.step = 2; a.t = 3.6; a.sp = 0; } }
      else {
        a.sp -= dt; const h = b.hole;
        while (h && a.sp <= 0) {
          a.sp += 0.16; const sd = rndi(0, 3), ex = sd === 0 ? 34 : sd === 1 ? 350 : rnd(40, 344), ey = sd === 2 ? 32 : sd === 3 ? 258 : rnd(36, 256), l = Math.hypot(h.x - ex, h.y - ey) || 1;
          b.shots.push({ x: ex, y: ey, vx: (h.x - ex) / l * 72, vy: (h.y - ey) / l * 72, life: 5, r: 4, dmg: 10, bill: 1, sink: 1 });
        }
        if (a.t <= 0) done(P.rec + 0.3);
      }
      break;
    }
    case 'crash': {   // 大暴落チャート：ろうそく足の弾の壁が横切る。すき間（株価）が上下にぎざぎざ動き、最後に大暴落する
      if (a.step === 0) {
        b.tilt = Math.sin(a.t * 50) * 0.05;
        if (a.t <= 0) { a.step = 1; a.n = 0; a.sp = 0; a.dirX = player.x < (ARENA.x0 + ARENA.x1) / 2 ? -1 : 1; a.gy = clamp(player.y - 6, 70, 220); a.vy = (Math.random() < 0.5 ? -1 : 1) * 6; bossSay(BOSS_G.lines.crash, 1.8); sfx('warn'); }
      } else {
        a.sp -= dt;
        if (a.sp <= 0 && a.n < 16) {
          a.sp += 0.17;
          if (a.n >= 11) a.vy = 7.5; else if (Math.random() < 0.3) a.vy = -a.vy;   // 12本目からは大暴落（下へまっすぐ）
          a.gy = clamp(a.gy + a.vy + rnd(-1.5, 1.5), 52, 236); if (a.gy <= 52 || a.gy >= 236) a.vy = -a.vy;
          const sx = a.dirX > 0 ? 34 : 350, up = a.vy < 0;
          for (let y = 36; y <= 256; y += 11) if (Math.abs(y - a.gy) > 21) b.shots.push({ x: sx, y, vx: a.dirX * 112, vy: 0, life: 4, r: 3, dmg: 12, cdl: up ? 1 : 2 });
          b.chart.push({ x: sx, y: a.gy, vx: a.dirX * 112, up }); a.n++; if (Math.random() < 0.5) sfx('ui');
          if (a.n === 12) floatText(b.x, b.y - 70, '株価大暴落！', '#ff5a4a');
        }
        if (a.n >= 16 && a.sp <= -2.6) done(P.rec + 0.2);
      }
      break;
    }
    case 'snow': {   // 借金雪だるま式：転がるほど大きく速くなる借金の雪玉。壁で跳ね返りながら6秒転がって、最後ははじける
      b.sq = 0.4 + Math.sin(a.t * 30) * 0.1;
      if (a.t <= 0) {
        const an = ang + rnd(-0.3, 0.3); b.balls.push({ x: b.x, y: b.y - 8, vx: Math.cos(an) * 105, vy: Math.sin(an) * 105, r: 9, t: 0, T: 6, hc: 0, rot: 0 });
        sfx('thud'); b.sq = -0.5; bossSay(BOSS_G.lines.snow, 1.8); done(P.rec + 0.1);
      }
      break;
    }
    case 'bomb': {   // 延滞利息ボム：コインの爆弾を5個置く（半分はプレイヤーの近く）。時間が来ると十字に爆発する
      if (a.step === 0) { b.sq = 0.4 + Math.sin(a.t * 30) * 0.1; if (a.t <= 0) { a.step = 1; a.t = 0; } }
      else if (a.t <= 0) {
        let x, y; if (a.n % 2 === 0) { x = player.x + rnd(-26, 26); y = player.y - 4 + rnd(-22, 22); } else { x = rnd(ARENA.x0, ARENA.x1); y = rnd(ARENA.y0 - 20, ARENA.y1); }
        b.zones.push({ k: 'cross', x: clamp(x, 44, 340), y: clamp(y, 50, 248), th: 9, t: 1.4, T: 1.4, dmg: 20, bomb: 1 }); a.n++; sfx('ui'); b.sq = -0.35; b.hop = 0.12;
        if (a.n >= 5) done(P.rec + 0.6); else a.t = 0.28;
      }
      break;
    }
    case 'boom': {   // 返済ブーメラン：投げた電卓が、弧を描いて必ず戻ってくる（2回。2回目は5本）
      if (a.step === 0) { b.sq = 0.5 + Math.sin(a.t * 30) * 0.12; if (a.t <= 0) { a.step = 1; a.t = 0; bossSay(BOSS_G.lines.boom, 1.6); } }
      else if (a.step === 1) {
        if (a.t <= 0) {
          const n = a.w === 0 ? 3 : 5, spr = a.w === 0 ? 0.5 : 0.42;
          for (let i = 0; i < n; i++) { const an = ang + (i - (n - 1) / 2) * spr; b.shots.push({ x: b.x, y: b.y - 18, vx: Math.cos(an) * 235, vy: Math.sin(an) * 235, life: 3.2, r: 5, dmg: 14, boom: 1, age: 0 }); }
          sfx('chop'); b.sq = -0.6; a.w++;
          if (a.w >= 2) { a.step = 2; a.t = 1.6; } else a.t = 0.75;
        }
      } else if (a.t <= 0) done(P.rec);
      break;
    }
    case 'heal': {   // 無限リボ払い：体力をすべて回復（その間は攻撃が効かない）
      if (a.step === 0) { a.step = 1; a.t = 2.2; a.T = 2.2; a.h0 = b.hp; a.h1 = Math.min(b.max, b.hp + Math.round(b.max * BOSS_G.healAmt)); a.lh = b.hp; a.ft = 0.25; b.healN = (b.healN || 0) + 1; bossSay(BOSS_G.lines.heal, 2.2); sfx('unlock'); sfx('warn');   // v8.1再：回復量は最大体力の healAmt。v8.2：1.8→2.2秒、カットイン
        b.cut = { k: 'heal', t: 1.4, T: 1.4 }; state.shake = Math.max(state.shake, 0.35); for (let i = 0; i < 3; i++) b.vfx.push({ k: 'ring', x: b.x, y: b.y - 4, r: 8 + i * 8, v: 150, t: 0.6, T: 0.6, col: i % 2 ? '255,216,74' : '125,255,138' }); }   // v8.1再：回復量は最大体力の healAmt
      else {
        const k = 1 - a.t / a.T; b.hp = Math.round(a.h0 + (a.h1 - a.h0) * Math.min(1, k * 1.25)); b.lag = Math.max(b.lag, b.hp);
        if (Math.random() < dt * 30) burst(b.x + rnd(-26, 26), b.y - rnd(0, 50), Math.random() < 0.5 ? '#ffd84a' : '#7dff8a', 1);
        if (Math.random() < dt * 4) b.vfx.push({ k: 'ring', x: b.x, y: b.y - 4, r: 10, v: 90, t: 0.6, T: 0.6, col: '125,255,138' });
        if (Math.random() < dt * 45) { const sd = rndi(0, 3), sx = sd === 0 ? 32 : sd === 1 ? 352 : rnd(32, 352), sy = sd === 2 ? 30 : sd === 3 ? 258 : rnd(30, 258); b.vfx.push({ k: 'coin', x: sx, y: sy, t: 0.75, T: 0.75, h: rnd(0, 6) }); }   // v8.2：ステージ中からコインが集まってくる
        a.ft -= dt; if (a.ft <= 0) { a.ft = 0.25; const add = b.hp - a.lh; if (add > 0) { floatText(b.x + rnd(-16, 16), b.y - 50, '+' + add, '#7dff8a'); a.lh = b.hp; } }   // v8.2：回復した数字
        if (a.t <= 0) { b.hp = a.h1; b.lag = Math.max(b.lag, a.h1); b.healCd = BOSS_G.healCd; floatText(b.x, b.y - 64, '体力回復！', '#7dff8a'); burst(b.x, b.y - 24, '#7dff8a', 24); burst(b.x, b.y - 24, '#ffd84a', 16); for (let i = 0; i < 4; i++) b.vfx.push({ k: 'ring', x: b.x, y: b.y - 4, r: 10 + i * 10, v: 220, t: 0.5, T: 0.5, col: i % 2 ? '255,216,74' : '125,255,138' }); state.shake = Math.max(state.shake, 0.4); done(P.rec); }   // v8.2：回復しきった時に光がはじける   // v8.1再：全回復 → 一部回復
      }
      break;
    }
  }
}
function updateBossHazards(dt, b) {
  for (let i = b.rings.length - 1; i >= 0; i--) {
    const r = b.rings[i]; r.r += r.v * dt; if (r.r > r.max) { b.rings.splice(i, 1); continue; }
    const dx = player.x - r.x, dy = player.y - 4 - r.y, d = Math.hypot(dx, dy);
    if (!r.hit && Math.abs(d - r.r) < r.w && Math.abs(angDiff(Math.atan2(dy, dx), r.gap)) > r.gh) { r.hit = 1; bossHit(r.dmg, r.x, r.y); }
  }
  for (let i = b.shots.length - 1; i >= 0; i--) {
    const s = b.shots[i];
    if (s.acc) { const f = 1 + s.acc * dt; if (Math.hypot(s.vx, s.vy) < 330) { s.vx *= f; s.vy *= f; } }   // v8.1：複利スパイラルの弾は、だんだん速くなる
    if (s.home > 0) {   // v8.2：督促状はしばらくプレイヤーを追いかける（曲がれる角度に上限あり）
      s.home -= dt; const want = Math.atan2(player.y - 6 - s.y, player.x - s.x), cur = Math.atan2(s.vy, s.vx), spd = Math.hypot(s.vx, s.vy);
      let d = want - cur; while (d > Math.PI) d -= Math.PI * 2; while (d < -Math.PI) d += Math.PI * 2;
      const na = cur + clamp(d, -2.4 * dt, 2.4 * dt); s.vx = Math.cos(na) * spd; s.vy = Math.sin(na) * spd;
    }
    if (s.boom) {   // v8.2：返済ブーメランは、ボスの方へ引き戻される
      s.age += dt; const ax = b.x - s.x, ay = b.y - 18 - s.y, l = Math.hypot(ax, ay) || 1; s.vx += ax / l * 330 * dt; s.vy += ay / l * 330 * dt;
      const sp2 = Math.hypot(s.vx, s.vy); if (sp2 > 260) { s.vx *= 260 / sp2; s.vy *= 260 / sp2; }
      if (s.age > 0.5 && l < 14) { b.shots.splice(i, 1); continue; }
    }
    if (s.sink && b.hole && Math.hypot(s.x - b.hole.x, s.y - b.hole.y) < 10) { b.shots.splice(i, 1); continue; }   // v8.2：ブラックホールに吸い込まれた請求書は消える
    s.x += s.vx * dt; s.y += s.vy * dt; s.life -= dt;
    if (s.life <= 0 || s.x < 30 || s.x > 354 || s.y < 30 || s.y > 262) { b.shots.splice(i, 1); continue; }
    if (Math.hypot(player.x - s.x, player.y - 6 - s.y) < s.r + 5) { b.shots.splice(i, 1); bossHit(s.dmg, s.x, s.y); }
  }
  if (b.fx) { b.fx.t -= dt; if (b.fx.t <= 0) b.fx = null; }
  // v6b：判子（予告の1秒後に落ちる。落ちた跡はしばらく残る）
  for (let i = b.stamps.length - 1; i >= 0; i--) {
    const st = b.stamps[i]; st.t -= dt;
    if (!st.land && st.t <= 0) {
      st.land = 1; st.t = 0.7; burst(st.x, st.y, '#c8302a', 5); state.shake = Math.max(state.shake, st.stun ? 0.5 : 0.12); if (st.stun || Math.random() < 0.45) sfx('thud');
      if (Math.hypot(player.x - st.x, player.y - 4 - st.y) < st.r + 3) { const can = state.invuln <= 0 && !state.god; bossHit(st.dmg, st.x, st.y); if (st.stun && can) stunPlayer(st.stun); }   // v8.1：差し押さえプレスは当たると動けない
    } else if (st.land && st.t <= 0) b.stamps.splice(i, 1);
  }
  // v8.1：多重債務ミラーの分身（ねらう → 突っ込む → 消える）
  for (let i = (b.clones || []).length - 1; i >= 0; i--) {
    const c = b.clones[i]; c.t -= dt;
    if (c.st === 'aim') {
      c.a = Math.min(1, c.a + dt * 4); if (c.t > 0.2) c.dir = Math.atan2(player.y - 6 - (c.y - 12), player.x - c.x); c.face = Math.cos(c.dir) < 0 ? -1 : 1;
      if (c.t <= 0) { c.st = 'dash'; c.t = 0.85; sfx('warn'); }
    } else if (c.st === 'dash') {
      c.x += Math.cos(c.dir) * 420 * dt; c.y += Math.sin(c.dir) * 420 * dt; if (Math.random() < 0.6) burst(c.x, c.y - 4, `hsl(${(c.hue + 40) % 360},100%,65%)`, 1);
      if (!c.hit && Math.hypot(player.x - c.x, player.y - 6 - (c.y - 12)) < 22) { c.hit = 1; bossHit(18, c.x, c.y - 12); }
      if (c.t <= 0 || c.x < 20 || c.x > 364 || c.y < 40 || c.y > 272) { c.st = 'out'; c.t = 0.25; }
    } else { c.a = Math.max(0, c.t / 0.25); if (c.t <= 0) b.clones.splice(i, 1); }
  }
  if (b.gaming) { b.healCd = Math.max(0, (b.healCd || 0) - dt); b.zinfCd = Math.max(0, (b.zinfCd || 0) - dt); }   // v8.1
  // v8.2：ハンマー・爆弾の範囲（予告のあとに一気に当たる）
  for (let i = (b.zones || []).length - 1; i >= 0; i--) {
    const z = b.zones[i]; z.t -= dt;
    if (!z.land && z.t <= 0) {
      z.land = 1; z.t = 0.35; const px = player.x, py = player.y - 4;
      const hit = z.k === 'rect' ? Math.abs(px - z.x) < z.hw + 3 && Math.abs(py - z.y) < z.hh + 3 : Math.abs(py - z.y) < z.th + 3 || Math.abs(px - z.x) < z.th + 3;
      if (hit) bossHit(z.dmg, z.x, z.y);
      state.shake = Math.max(state.shake, z.gavel === 2 ? 0.75 : 0.3); sfx('thud');
      if (z.gavel) { floatText(z.x, z.y - z.hh - 6, z.gavel === 2 ? '落札！！' : '落札！', '#ffd84a'); burst(z.x, z.y, '#ffd84a', z.gavel === 2 ? 22 : 9); for (let k = 0; k < (z.gavel === 2 ? 3 : 1); k++) b.vfx.push({ k: 'ring', x: z.x, y: z.y, r: 8 + k * 8, v: 170 + k * 40, t: 0.4, T: 0.4, col: '255,216,74' }); if (z.gavel === 2) state.flash = Math.max(state.flash, 0.25); }
      if (z.bomb) { burst(z.x, z.y, '#ffb040', 12); b.vfx.push({ k: 'ring', x: z.x, y: z.y, r: 6, v: 160, t: 0.35, T: 0.35, col: '255,200,80' }); }
    } else if (z.land && z.t <= 0) b.zones.splice(i, 1);
  }
  // v8.2：借金の雪玉（転がるほど大きく・速くなる。壁で跳ね返る。最後ははじけて弾になる）
  for (let i = (b.balls || []).length - 1; i >= 0; i--) {
    const o = b.balls[i]; o.t += dt; o.hc = Math.max(0, o.hc - dt);
    const g = Math.min(1, o.t / 5), sp = 105 * (1 + 0.45 * g), l = Math.hypot(o.vx, o.vy) || 1; o.r = 9 + 21 * g; o.vx = o.vx / l * sp; o.vy = o.vy / l * sp;
    o.x += o.vx * dt; o.y += o.vy * dt; o.rot += sp * dt / o.r * (o.vx < 0 ? -1 : 1);
    if (o.x < 30 + o.r) { o.x = 30 + o.r; o.vx = Math.abs(o.vx); sfx('thud'); } if (o.x > 354 - o.r) { o.x = 354 - o.r; o.vx = -Math.abs(o.vx); sfx('thud'); }
    if (o.y < 34 + o.r) { o.y = 34 + o.r; o.vy = Math.abs(o.vy); } if (o.y > 258 - o.r) { o.y = 258 - o.r; o.vy = -Math.abs(o.vy); }
    if (Math.random() < dt * 20) burst(o.x + rnd(-o.r, o.r), o.y + o.r * 0.6, '#e8f0ff', 1);
    if (o.hc <= 0 && Math.hypot(player.x - o.x, player.y - 6 - o.y) < o.r + 5) { o.hc = 0.8; bossHit(20, o.x, o.y); }
    if (o.t >= o.T) {
      for (let k = 0; k < 14; k++) { const an = k / 14 * Math.PI * 2; b.shots.push({ x: o.x, y: o.y, vx: Math.cos(an) * 100, vy: Math.sin(an) * 100, life: 3, r: 4, dmg: 12, bill: 1 }); }
      burst(o.x, o.y, '#ffffff', 24); b.vfx.push({ k: 'ring', x: o.x, y: o.y, r: o.r, v: 200, t: 0.4, T: 0.4, col: '220,235,255' }); state.shake = Math.max(state.shake, 0.4); sfx('thud'); b.balls.splice(i, 1);
    }
  }
  // v8.2：自己破産ブラックホール（大きくなる → 吸い込む → 最後の0.8秒は吸い込みが止まり、すき間のある「破産宣告」の衝撃波）
  if (b.hole) {
    const h = b.hole; h.t += dt; h.hc = Math.max(0, h.hc - dt); h.r = 2 + 18 * Math.min(1, h.t / 0.7);
    const dx = h.x - player.x, dy = h.y - (player.y - 4), d = Math.hypot(dx, dy) || 1;
    if (h.t > 0.7 && h.t < h.T - 0.8 && d > 4) { const pw = (34 + 26 * Math.min(1, (h.t - 0.7) / 2)) * dt; tryMove(dx / d * pw, 0); tryMove(0, dy / d * pw); }
    if (h.hc <= 0 && d < h.r + 4) { h.hc = 0.7; bossHit(20, h.x, h.y); }
    if (Math.random() < dt * 30) { const an = rnd(0, Math.PI * 2), r = rnd(50, 110); b.vfx.push({ k: 'suck', x: h.x + Math.cos(an) * r, y: h.y + Math.sin(an) * r * 0.6, t: 0.6, T: 0.6, hx: h.x, hy: h.y, h: rndi(0, 359) }); }
    if (h.t >= h.T) {
      b.rings.push({ x: h.x, y: h.y, r: 10, v: 150, max: 210, w: 7, dmg: 14, gap: h.gap, gh: 0.7, rb: 1 });
      floatText(h.x, h.y - 24, '破産宣告！', '#ff5a4a'); burst(h.x, h.y, '#c080ff', 20); state.shake = Math.max(state.shake, 0.55); sfx('thud'); b.hole = null;
    }
  }
  // v8.2：株価の線（弾の壁と一緒に流れる）
  for (let i = (b.chart || []).length - 1; i >= 0; i--) { const c = b.chart[i]; c.x += c.vx * dt; if (c.x < 20 || c.x > 364) b.chart.splice(i, 1); }
  if (b.cut) { b.cut.t -= dt; if (b.cut.t <= 0) b.cut = null; }   // v8.2：カットイン
  b.impact = Math.max(0, (b.impact || 0) - dt);
  if (b.beam) { b.beam.t -= dt; if (b.beam.t <= 0) b.beam = null; }
  for (let i = b.vfx.length - 1; i >= 0; i--) { const v = b.vfx[i]; v.t -= dt; v.r += (v.v || 0) * dt; if (v.t <= 0) b.vfx.splice(i, 1); }
  for (let i = b.trail.length - 1; i >= 0; i--) { b.trail[i].a -= dt * 2.2; if (b.trail[i].a <= 0) b.trail.splice(i, 1); }
  for (let i = b.sparks.length - 1; i >= 0; i--) { const p = b.sparks[i], a = b.atk; p.t -= dt; const tx = a && a.side ? b.x - a.side * 26 : b.x, ty = b.y - 26; p.x += (tx - p.x) * Math.min(1, dt * 7); p.y += (ty - p.y) * Math.min(1, dt * 7); if (p.t <= 0) b.sparks.splice(i, 1); }
  b.kx = Math.max(0, b.kx - dt * 6); b.hop = Math.max(0, b.hop - dt);
  b.zbCd = Math.max(0, b.zbCd - dt);
}
function updateBoss(dt) {
  if (!game || game.map !== 'cave2') { if (state.boss) endBossFight(); return; }
  if (!state.boss) { if (bossCanSpawn() && !state.fading && state.scene === 'play') spawnBoss(); return; }
  if (state.fading) return;
  const b = state.boss, P = BP[b.phase];
  if (b.st === 'pre') { bossIntro(b); return; }   // v6.1b：明るくなったら登場
  state.camBias = lerp(state.camBias || 0, b.st === 'intro' ? 0.6 : 0, Math.min(1, dt * (b.st === 'intro' ? 6 : 1.6)));   // v6.1b：登場が終わったら、カメラをゆっくりプレイヤーへ戻す
  b.hurt = Math.max(0, b.hurt - dt); b.sayT = Math.max(0, b.sayT - dt);
  b.lag = Math.max(b.hp, b.lag - Math.max(6, (b.lag - b.hp) * 1.6) * dt);
  b.sq += (0 - b.sq) * Math.min(1, dt * 10); b.tilt += (0 - b.tilt) * Math.min(1, dt * 8);
  updateBossHazards(dt, b);
  if (b.st === 'die') { b.t -= dt; b.sq = Math.sin(b.t * 30) * 0.2; if (Math.random() < dt * 22) burst(b.x + rnd(-20, 20), b.y - rnd(6, 44), Math.random() < 0.5 ? '#ffffff' : '#c080ff', 3); if (b.t <= 0) bossDefeated(); else updateBossBar(); return; }   // v6b：倒れる時に光がはじける。v8.1：絵は Boss_Dead.png
  if (b.st === 'fake' || b.st === 'revive') { bossRevive(b, dt); if (state.boss) updateBossBar(); return; }   // v8.1：倒れたまま → 第2形態へ
  if (b.gaming && b.st !== 'pre' && b.st !== 'intro') b.gT += dt;   // v8.1：第2形態と戦っている秒数（耐えた記録）
  // v6b：歩く動き（速さから足取りを作る）・3段階目のオーラ
  const mvx = (b.x - b.px) / Math.max(dt, 0.001), mvy = (b.y - b.py) / Math.max(dt, 0.001), msp = Math.hypot(mvx, mvy); b.px = b.x; b.py = b.y; b.vx = mvx;
  const w0 = Math.sin(b.walk); b.walk += dt * Math.min(msp, 200) * 0.11; if (msp > 30 && b.z <= 1 && Math.sign(Math.sin(b.walk)) !== Math.sign(w0)) burst(b.x + rnd(-10, 10), b.y - 1, '#6a6070', 2);
  if (b.phase >= 3 && b.st !== 'die' && Math.random() < dt * (b.gaming ? 26 : 14)) burst(b.x + rnd(-18, 18), b.y - b.z - rnd(10, 40), b.gaming ? `hsl(${rndi(0, 359)},100%,62%)` : Math.random() < 0.5 ? '#a02040' : '#6020a0', 1);   // v8.1：第2形態は虹色の光
  const dx = player.x - b.x, dy = player.y - 6 - (b.y - 12), dist = Math.hypot(dx, dy) || 0.01;
  if (Math.abs(dx) > 4 && (!b.atk || b.atk.step === 0) && !(b.atk && b.atk.k === 'zero')) b.face = dx < 0 ? -1 : 1;
  if (b.z <= 2 && b.blinkA == null && b.st !== 'pre' && b.st !== 'intro' && b.st !== 'roar' && b.st !== 'stun' && !(b.atk && b.atk.k === 'zero') && Math.hypot(player.x - b.x, player.y - 6 - (b.y - 16)) < 20) bossHit(BOSS.contact, b.x, b.y - 16);   // 体当たり
  b.t -= dt;
  switch (b.st) {
    case 'intro': if (b.t <= 0) { b.st = 'move'; b.t = 0.9; } break;   // v6.1b：セリフのあと、少し歩いてから最初の攻撃
    case 'roar': b.sq = Math.sin(b.t * 40) * 0.15; if (b.t <= 0) { b.st = 'move'; b.t = 0.25; } break;
    case 'move': {   // 距離を保ちながら、横に回り込む
      if (Math.random() < dt * 0.7) b.orb *= -1;
      const ux = dx / dist, uy = dy / dist, f = clamp((dist - 60) / 40, -1, 1);
      let mx = ux * f - uy * b.orb * 0.9, my = uy * f + ux * b.orb * 0.9; const l = Math.hypot(mx, my) || 1;
      if (bossMove(b, mx / l * P.mv * dt, my / l * P.mv * dt)) b.orb *= -1;
      if (b.t <= 0) bossPick(b, dist);
      break;
    }
    case 'atk': bossAtk(b, dt, P, dx, dy, dist); break;
    case 'stun': b.sq = Math.sin(b.t * 7) * 0.08; if (b.t <= 0) { b.st = 'rec'; b.t = 0.3; } break;   // v6b：ゼロ・バーストのあと動けない（v6.1b：3秒）
    case 'rec': if (b.t <= 0) { b.st = 'move'; b.t = P.cd + Math.random() * 0.35; } break;
  }
  updateBossBar();
}
function updateBossBar(force) {
  const el = $('boss-bar'); if (!el) return; const b = state.boss;
  if (!b) { el.classList.add('hidden'); return; }
  if (force || el.classList.contains('hidden')) { el.classList.remove('hidden'); el.querySelector('.bb-name').textContent = bossNameOf(b); }   // v8.1：第2形態の名前
  if (el.classList.contains('gaming') !== !!b.gaming) el.classList.toggle('gaming', !!b.gaming);   // v8.1：虹色の体力バー
  { const hl = !!(b.atk && b.atk.k === 'heal'); if (el.classList.contains('healing') !== hl) el.classList.toggle('healing', hl); }   // v8.2：無限リボ払いの間は緑に光る
  el.querySelector('.bb-fill').style.width = (Math.max(0, b.hp) / b.max * 100).toFixed(1) + '%';
  el.querySelector('.bb-lag').style.width = (Math.max(0, b.lag) / b.max * 100).toFixed(1) + '%';
  const pc = el.querySelector('.bb-pct'); if (pc) { const t = Math.ceil(Math.max(0, b.hp) / b.max * 100) + '%'; if (pc.textContent !== t) pc.textContent = t; }   // v6.2：残り体力の%
}
// ---- 描画 ----
function drawBossFloor(time) {
  const b = state.boss; if (!b) return;
  const al = (0.2 + 0.16 * Math.sin(time * 18)).toFixed(2);
  for (const g of b.tg || []) {
    ctx.fillStyle = `rgba(255,40,40,${al})`; ctx.strokeStyle = 'rgba(255,100,90,0.95)'; ctx.lineWidth = 1; ctx.beginPath();
    if (g.k === 'cone') { const cx = b.x, cy = b.y - 12; ctx.moveTo(cx, cy); ctx.arc(cx, cy, g.r, g.a - g.half, g.a + g.half); ctx.closePath(); }
    else if (g.k === 'line') { const cx = b.x, cy = b.y - 12, L = 380, w = g.w / 2, c = Math.cos(g.a), s = Math.sin(g.a); ctx.moveTo(cx - s * w, cy + c * w); ctx.lineTo(cx - s * w + c * L, cy + c * w + s * L); ctx.lineTo(cx + s * w + c * L, cy - c * w + s * L); ctx.lineTo(cx + s * w, cy - c * w); ctx.closePath(); }
    else if (g.k === 'circle') ctx.arc(g.x, g.y, g.r, 0, Math.PI * 2);
    else if (g.k === 'ring') { const cx = b.x, cy = b.y - 6; ctx.moveTo(cx, cy); ctx.arc(cx, cy, 90, g.gap + g.gh, g.gap - g.gh + Math.PI * 2); ctx.closePath(); }
    ctx.fill(); ctx.stroke();
  }
  // v8.2：ゼロ・バースト∞の魔法陣（足元で回る虹色の円・六芒星・お金の記号）
  { const za = b.atk && b.atk.k === 'zero' && b.atk.inf ? b.atk : null;
    if (za && za.step >= 1 && za.step <= 3) {
      const mk = za.step === 1 ? clamp((1.6 - za.t) / 0.5, 0, 1) : 1, R = 64 * mk * (za.step === 2 ? 1 + b.charge * 0.25 : 1.25);
      ctx.save(); ctx.translate(b.x, b.y - 2); ctx.scale(1, 0.5);
      for (const [rr, w, sp] of [[R, 2, 1], [R * 0.8, 1, -1.4], [R * 0.45, 1, 2]]) { ctx.strokeStyle = `hsla(${Math.round(time * 260 + rr * 3) % 360},100%,62%,0.9)`; ctx.lineWidth = w; ctx.beginPath(); ctx.arc(0, 0, rr, 0, Math.PI * 2); ctx.stroke();
        ctx.setLineDash([3, 4]); ctx.lineDashOffset = -time * 30 * sp; ctx.beginPath(); ctx.arc(0, 0, rr - 4, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]); ctx.lineDashOffset = 0; }
      for (let t2 = 0; t2 < 2; t2++) { ctx.strokeStyle = `hsla(${Math.round(time * 300 + t2 * 180) % 360},100%,70%,0.85)`; ctx.lineWidth = 1.5; ctx.beginPath(); for (let i = 0; i <= 3; i++) { const an = (t2 ? -time * 1.1 : time * 1.3) + t2 * Math.PI / 3 + i * Math.PI * 2 / 3, x = Math.cos(an) * R * 0.8, y = Math.sin(an) * R * 0.8; if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); } ctx.stroke(); }
      ctx.font = 'bold 9px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (let i = 0; i < 12; i++) { const an = -time * 0.9 + i * Math.PI / 6; ctx.fillStyle = `hsl(${(i * 30 + Math.round(time * 200)) % 360},100%,72%)`; ctx.fillText('∞¥$€'[i % 4], Math.cos(an) * R * 0.9, Math.sin(an) * R * 0.9); }
      ctx.restore(); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.lineWidth = 1;
    }
  }
  // v8.2：自己破産ブラックホール（虹色の降着円盤と、真っ黒な穴。最後は衝撃波のすき間を緑で予告）
  if (b.hole) {
    const h = b.hole, R = h.r;
    for (let i = 0; i < 4; i++) { const rr = R * 2.1 + i * 6 + Math.sin(time * 6 + i) * 1.5; ctx.strokeStyle = `hsla(${Math.round(time * 320 + i * 90) % 360},100%,60%,${(0.75 - i * 0.14).toFixed(2)})`; ctx.lineWidth = 3 - i * 0.5; ctx.beginPath(); ctx.ellipse(h.x, h.y, rr, rr * 0.55, 0, time * (2 + i * 0.6), time * (2 + i * 0.6) + Math.PI * 1.6); ctx.stroke(); }
    ctx.lineWidth = 1;
    for (let i = 0; i < 16; i++) { const p2 = (time * 0.9 + i / 16) % 1, an = i * 0.7 + p2 * 5, rr = R * 5 * (1 - p2) + R; ctx.fillStyle = `rgba(200,150,255,${(0.7 * p2).toFixed(2)})`; ctx.fillRect(Math.round(h.x + Math.cos(an) * rr), Math.round(h.y + Math.sin(an) * rr * 0.55), 2, 1); }
    const gr = ctx.createRadialGradient(h.x, h.y, 0, h.x, h.y, R * 1.7); gr.addColorStop(0, '#000000'); gr.addColorStop(0.55, 'rgba(8,0,18,0.97)'); gr.addColorStop(0.8, 'rgba(120,40,200,0.6)'); gr.addColorStop(1, 'rgba(80,0,120,0)');
    ctx.fillStyle = gr; ctx.beginPath(); ctx.ellipse(h.x, h.y, R * 1.7, R * 1.2, 0, 0, Math.PI * 2); ctx.fill();
    if (h.t > h.T - 0.8) { ctx.fillStyle = `rgba(255,40,40,${al})`; ctx.strokeStyle = 'rgba(255,100,90,0.95)'; ctx.beginPath(); ctx.moveTo(h.x, h.y); ctx.arc(h.x, h.y, 110, h.gap + 0.7, h.gap - 0.7 + Math.PI * 2); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = 'rgba(120,255,140,0.28)'; ctx.beginPath(); ctx.moveTo(h.x, h.y); ctx.arc(h.x, h.y, 110, h.gap - 0.7, h.gap + 0.7); ctx.closePath(); ctx.fill(); }
  }
  // v8.2：ハンマー・爆弾の範囲の予告（真ん中から塗られていき、満ちたら当たる）と、当たった瞬間の光
  for (const z of b.zones || []) {
    const zp = sc => { ctx.beginPath(); if (z.k === 'rect') ctx.rect(z.x - z.hw * sc, z.y - z.hh * sc, z.hw * 2 * sc, z.hh * 2 * sc); else { ctx.rect(28, z.y - z.th * sc, 328, z.th * 2 * sc); ctx.rect(z.x - z.th * sc, 26, z.th * 2 * sc, 236); } };
    if (z.land) { const a2 = Math.max(0, z.t / 0.35); zp(1); ctx.fillStyle = z.bomb ? `rgba(255,190,90,${(0.75 * a2).toFixed(2)})` : `rgba(255,236,150,${(0.7 * a2).toFixed(2)})`; ctx.fill(); continue; }
    const k = 1 - z.t / z.T, fl = k > 0.75 && Math.floor(time * 20) % 2;
    zp(1); ctx.fillStyle = 'rgba(255,40,40,0.14)'; ctx.fill(); ctx.strokeStyle = fl ? 'rgba(255,240,200,0.95)' : 'rgba(255,100,90,0.9)'; ctx.lineWidth = 1; ctx.stroke();
    zp(k); ctx.fillStyle = `rgba(255,40,40,${(0.18 + k * 0.25).toFixed(2)})`; ctx.fill();
  }
  // v6b：判子レインの予告（赤い円。真ん中から塗られていき、満ちたら落ちる）と、落ちた跡
  for (const st of b.stamps) {
    if (st.land) { const al2 = Math.min(1, st.t / 0.4); ctx.fillStyle = `rgba(190,30,30,${(0.55 * al2).toFixed(2)})`; ctx.beginPath(); ctx.arc(st.x, st.y, st.r - 2, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = `rgba(255,220,200,${(0.6 * al2).toFixed(2)})`; ctx.lineWidth = 1; const q = Math.round(4 * st.r / 14); ctx.strokeRect(Math.round(st.x) - q, Math.round(st.y) - q, q * 2, q * 2); continue; }   // v6.1b：大きさに合わせる
    const k = 1 - st.t / st.T;
    ctx.fillStyle = 'rgba(255,40,40,0.16)'; ctx.beginPath(); ctx.arc(st.x, st.y, st.r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = `rgba(255,40,40,${(0.2 + k * 0.25).toFixed(2)})`; ctx.beginPath(); ctx.arc(st.x, st.y, st.r * k, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = `rgba(255,${k > 0.8 && Math.floor(time * 20) % 2 ? 240 : 110},90,0.95)`; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(st.x, st.y, st.r, 0, Math.PI * 2); ctx.stroke();
  }
  // v6b：ゼロ・バーストの予告（すき間以外のステージ全体）
  for (const g of b.tg || []) if (g.k === 'beam') {
    const gp = g.gap, hw = gp.w / 2 / Math.cos(gp.th), fl = Math.floor(time * 10) % 2;
    ctx.save(); ctx.beginPath(); ctx.rect(28, 26, 328, 236); ctx.clip();
    ctx.beginPath(); ctx.rect(0, 0, 384, 288); ctx.moveTo(-10, zeroLineY(gp, -10) - hw); ctx.lineTo(394, zeroLineY(gp, 394) - hw); ctx.lineTo(394, zeroLineY(gp, 394) + hw); ctx.lineTo(-10, zeroLineY(gp, -10) + hw); ctx.closePath();
    ctx.fillStyle = `rgba(255,20,60,${fl ? 0.34 : 0.22})`; ctx.fill('evenodd');
    ctx.strokeStyle = fl ? 'rgba(255,255,255,0.95)' : 'rgba(140,240,255,0.95)'; ctx.lineWidth = 1.5; ctx.setLineDash([4, 3]);
    for (const sg of [-1, 1]) { ctx.beginPath(); ctx.moveTo(-10, zeroLineY(gp, -10) + sg * hw); ctx.lineTo(394, zeroLineY(gp, 394) + sg * hw); ctx.stroke(); }
    ctx.setLineDash([]); ctx.restore();
  }
  // v8.1：多重債務ミラーの分身がねらっている道（赤い帯）
  for (const c of b.clones || []) if (c.st === 'aim') {
    const L = 420, w = 13, cs = Math.cos(c.dir), sn = Math.sin(c.dir), cx = c.x, cy = c.y - 12;
    ctx.fillStyle = `rgba(255,40,40,${(0.12 + 0.14 * c.a * (0.6 + 0.4 * Math.sin(time * 24))).toFixed(2)})`; ctx.strokeStyle = `rgba(255,${c.t < 0.2 && Math.floor(time * 20) % 2 ? 240 : 110},90,${(0.8 * c.a).toFixed(2)})`; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(cx - sn * w, cy + cs * w); ctx.lineTo(cx - sn * w + cs * L, cy + cs * w + sn * L); ctx.lineTo(cx + sn * w + cs * L, cy - cs * w + sn * L); ctx.lineTo(cx + sn * w, cy - cs * w); ctx.closePath(); ctx.fill(); ctx.stroke();
  }
  for (const r of b.rings) {
    ctx.strokeStyle = r.rb ? `hsla(${Math.round(time * 300 + r.r) % 360},100%,60%,0.95)` : 'rgba(255,130,90,0.95)'; ctx.lineWidth = r.w; ctx.beginPath(); ctx.arc(r.x, r.y, r.r, r.gap + r.gh, r.gap - r.gh + Math.PI * 2); ctx.stroke();   // v8.1：遅延損害金ウェーブは虹色
    ctx.strokeStyle = 'rgba(255,240,200,0.8)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(r.x, r.y, r.r, r.gap + r.gh, r.gap - r.gh + Math.PI * 2); ctx.stroke();
  }
}
// v8.1：ゲーミング（虹色に流れる体）。絵の上に、動く虹のグラデーションを重ねる（毎回同じキャンバスを使い回す）
const RB_ART = { cv: null, x: null };
function rainbowArt(src, hue, a) {
  if (!RB_ART.cv || RB_ART.cv.width !== src.width || RB_ART.cv.height !== src.height) { RB_ART.cv = mkCanvas(src.width, src.height); RB_ART.x = RB_ART.cv.getContext('2d'); }
  const c = RB_ART.cv, x = RB_ART.x, W = c.width, H = c.height;
  x.globalCompositeOperation = 'source-over'; x.globalAlpha = 1; x.clearRect(0, 0, W, H); x.drawImage(src, 0, 0);
  x.globalCompositeOperation = 'source-atop'; const g = x.createLinearGradient(0, 0, W, H);
  for (let i = 0; i <= 6; i++) g.addColorStop(i / 6, `hsla(${Math.round(hue + i * 60) % 360},100%,55%,${a.toFixed(2)})`);
  x.fillStyle = g; x.fillRect(0, 0, W, H); x.globalCompositeOperation = 'source-over';
  return c;
}
const bossDeadPose = b => b.st === 'die' || b.st === 'fake' || (b.st === 'revive' && !b.gaming);   // v8.1：Boss_Dead.png を出す時
function drawBoss(time) {
  const b = state.boss, art = BOSS_ART.cv; if (!b || !art) return;
  const S = art.width, sh = b.z > 0 ? Math.max(0.35, 1 - b.z / 120) : 1;
  if (!BOSS_ART.gh || BOSS_ART.ghSrc !== art) { BOSS_ART.gh = tintOf(art, '#9a5cff'); BOSS_ART.ghSrc = art; }
  // v6b：残像。v8.1：第2形態は虹色の残像
  for (const t of b.trail) { ctx.save(); ctx.globalAlpha = Math.max(0, t.a) * (b.gaming ? 0.7 : 0.6); ctx.translate(Math.round(t.x), Math.round(t.y - t.z)); if ((t.face > 0) === BOSS.facesLeft) ctx.scale(-1, 1); ctx.drawImage(b.gaming ? rainbowArt(art, time * 300 + t.a * 400, 1) : BOSS_ART.gh, -Math.round(S / 2), -S, S, S); ctx.restore(); }
  ctx.fillStyle = 'rgba(0,0,0,0.38)'; ctx.beginPath(); ctx.ellipse(b.x, b.y - 1, 18 * sh, 5 * sh, 0, 0, Math.PI * 2); ctx.fill();
  let al = 1; if (b.blinkA != null) al *= b.blinkA;   // v8.1：倒れた時は消えずに Boss_Dead.png の絵を出す
  if (al <= 0.01) return;
  // v6b：オーラ（攻撃の予兆は赤・3段階目は黒紫・ためはまぶしい光）。v8.1：第2形態は虹色、変身中はだんだん強く
  const wind = b.st === 'atk' && b.atk && (b.atk.step === 0 || (b.atk.k === 'claw' && b.atk.step === 1)) && b.atk.k !== 'zero';
  const auraC = b.charge > 0 ? `255,${Math.round(120 + 120 * b.charge)},255` : wind ? '255,50,40' : b.gaming || b.st === 'revive' ? hueRGB(time * 300) : b.phase >= 3 ? '120,20,90' : null;
  if (auraC && b.st !== 'die' && b.st !== 'fake') { const pr = 0.55 + 0.45 * Math.sin(time * (wind ? 22 : 7)), rr = S * (0.62 + (b.charge || 0) * 0.5) * (0.9 + pr * 0.15), cy = b.y - b.z - S * 0.45; const gr = ctx.createRadialGradient(b.x, cy, 2, b.x, cy, rr); gr.addColorStop(0, `rgba(${auraC},${(0.45 * al).toFixed(2)})`); gr.addColorStop(1, `rgba(${auraC},0)`); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(b.x, cy, rr, 0, Math.PI * 2); ctx.fill(); }
  // v6b：歩く時は弾むように、進む方へ少し傾く。攻撃を受けると揺れる
  const moving = b.st === 'move' && Math.abs(b.vx || 0) + 1 > 20, hopY = b.hop > 0 ? -Math.sin(b.hop / 0.16 * Math.PI) * 4 : 0;
  const bob = b.z > 0 ? 0 : b.st === 'atk' || b.st === 'stun' ? Math.round(hopY) : moving ? -Math.round(Math.abs(Math.sin(b.walk)) * 3) : Math.round(Math.sin(time * 4));
  const lean = b.st === 'move' ? clamp((b.vx || 0) / 500, -0.1, 0.1) : 0, jig = b.kx > 0 ? Math.sin(time * 90) * 2 * b.kx : 0;
  const sq = (b.sq || 0) + (moving ? Math.abs(Math.cos(b.walk)) * 0.08 : 0), w = Math.round(S * (1 + sq * 0.16)), hh = Math.round(S * (1 - sq * 0.16));
  ctx.save(); ctx.globalAlpha = al; ctx.translate(Math.round(b.x + jig), Math.round(b.y - b.z + bob)); if (b.tilt || lean) ctx.rotate((b.tilt || 0) + lean);
  if ((b.face > 0) === BOSS.facesLeft) ctx.scale(-1, 1);
  // v8.1：体力0の時は Boss_Dead.png。変身中は虹色がだんだん濃く、第2形態はずっと虹色に流れる
  let img = bossDeadPose(b) ? (BOSS_ART.dead || art) : b.hurt > 0 || (b.charge > 0.85 && Math.floor(time * 24) % 2) ? BOSS_ART.fl : art;
  if (b.st === 'revive' && !b.gaming) img = rainbowArt(img, time * 420, 0.1 + 0.6 * (b.rk || 0));
  else if (b.gaming && !(b.hurt > 0) && b.st !== 'die') img = rainbowArt(img, time * 260, 0.62);
  ctx.drawImage(img, -Math.round(w / 2), -hh, w, hh);
  ctx.restore();
  // v6b：スタン中の星
  if (b.st === 'stun') for (let i = 0; i < 3; i++) { const an = time * 4 + i * 2.09, sx = Math.round(b.x + Math.cos(an) * 14), sy = Math.round(b.y - S - 4 + Math.sin(an) * 4); ctx.fillStyle = '#ffe060'; ctx.fillRect(sx - 1, sy, 3, 1); ctx.fillRect(sx, sy - 1, 1, 3); }
}
// v8.2：ボスの演出を画面の上に重ねる（洞窟の暗さの上）。∞をためている間の黒い帯・集中線、発射の瞬間の暗転、リボ払いの緑の光、カットイン
function drawBossOverlay(time, cw, ch, zoom, camX, camY) {
  const b = state.boss; if (!b) return;
  const za = b.atk && b.atk.k === 'zero' && b.atk.inf ? b.atk : null, M = Math.max(cw, ch);
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  if (za && za.step >= 1 && za.step <= 2) {
    const k = za.step === 1 ? clamp((1.6 - za.t) / 0.5, 0, 1) : 1, c2 = za.step === 2 ? b.charge || 0 : 0;
    const vg = ctx.createRadialGradient(cw / 2, ch / 2, Math.min(cw, ch) * 0.3, cw / 2, ch / 2, M * 0.75); vg.addColorStop(0, 'rgba(10,0,25,0)'); vg.addColorStop(1, `rgba(10,0,25,${(0.6 * k).toFixed(2)})`); ctx.fillStyle = vg; ctx.fillRect(0, 0, cw, ch);
    if (za.step === 2 && c2 > 0.5) {   // 集中線（光の玉へ向かう）
      const sx = (b.x - za.side * 26 - camX) * zoom, sy = (b.y - b.z - 26 - camY) * zoom, al = (c2 - 0.5) / 0.5;
      for (let i = 0; i < 56; i++) { const an = rnd(0, Math.PI * 2), r1 = M * rnd(0.32, 0.55) * (1.1 - al * 0.35); ctx.strokeStyle = `rgba(255,255,255,${(rnd(0.15, 0.45) * al).toFixed(2)})`; ctx.lineWidth = rnd(1, 3.5); ctx.beginPath(); ctx.moveTo(sx + Math.cos(an) * r1, sy + Math.sin(an) * r1); ctx.lineTo(sx + Math.cos(an) * M * 1.3, sy + Math.sin(an) * M * 1.3); ctx.stroke(); }
    }
    const bh = Math.round(ch * 0.075 * k); ctx.fillStyle = '#000000'; ctx.fillRect(0, 0, cw, bh); ctx.fillRect(0, ch - bh, cw, bh);   // 映画のような黒い帯
    if (bh > 10) {
      const msg = '∞ WARNING ∞ ZERO BURST INFINITY ', fs = Math.round(bh * 0.5); ctx.font = `bold ${fs}px sans-serif`; ctx.textBaseline = 'middle'; const w = Math.max(40, ctx.measureText(msg).width);
      for (const [yy, d] of [[bh / 2, 1], [ch - bh / 2, -1]]) { let x0 = -((time * 140 * d) % w + w) % w; for (let x = x0 - w; x < cw + w; x += w) { ctx.fillStyle = `hsl(${Math.round(time * 300 + x * 0.3) % 360},100%,62%)`; ctx.fillText(msg, x, yy); } }
      ctx.textBaseline = 'alphabetic';
    }
  }
  if (b.impact > 0) { ctx.fillStyle = b.impact > 0.06 ? 'rgba(255,255,255,0.85)' : 'rgba(20,0,40,0.75)'; ctx.fillRect(0, 0, cw, ch); }   // 発射の瞬間の白黒のコマ
  if (b.atk && b.atk.k === 'heal' && b.atk.step === 1) {   // 無限リボ払い：画面のふちが緑と金に光る
    const pu = 0.5 + 0.5 * Math.sin(time * 9), vg = ctx.createRadialGradient(cw / 2, ch / 2, Math.min(cw, ch) * 0.32, cw / 2, ch / 2, M * 0.75);
    vg.addColorStop(0, 'rgba(60,255,120,0)'); vg.addColorStop(0.7, `rgba(60,255,120,${(0.12 + 0.1 * pu).toFixed(2)})`); vg.addColorStop(1, `rgba(255,216,74,${(0.22 + 0.12 * pu).toFixed(2)})`); ctx.fillStyle = vg; ctx.fillRect(0, 0, cw, ch);
  }
  if (b.cut) drawBossCutIn(b.cut, time, cw, ch);
}
// v8.2：カットイン（ななめの帯にボスの顔と技の名前。zfire＝発射の瞬間の、画面いっぱいの技名）
function drawBossCutIn(c, time, cw, ch) {
  const p = 1 - c.t / c.T, ain = clamp(p / 0.12, 0, 1), aout = clamp((1 - p) / 0.15, 0, 1), ez = 1 - Math.pow(1 - ain, 3), heal = c.k === 'heal', m = Math.min(cw, ch);
  const name = heal ? BOSS_G.atk.heal : BOSS_G.atk.zinf, rbGrad = (x0, x1) => { const g = ctx.createLinearGradient(x0, 0, x1, 0); for (let i = 0; i <= 6; i++) g.addColorStop(i / 6, heal ? (i % 2 ? '#7dff8a' : '#ffe680') : `hsl(${Math.round(time * 600 + i * 60) % 360},100%,62%)`); return g; };
  ctx.save(); ctx.globalAlpha = Math.min(ain, aout); ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
  if (c.k === 'zfire') {
    let fs = Math.round(Math.min(cw * 0.09, ch * 0.14)); ctx.font = `900 ${fs}px "DotGothic16", sans-serif`; let tw = ctx.measureText(name).width; if (tw > cw * 0.9) { fs = Math.floor(fs * cw * 0.9 / tw); ctx.font = `900 ${fs}px "DotGothic16", sans-serif`; tw = ctx.measureText(name).width; }
    const sc = 1 + 1.6 * Math.pow(1 - ain, 2); ctx.translate(cw / 2 + rnd(-3, 3) * aout, ch * 0.3 + rnd(-3, 3) * aout); ctx.scale(sc, sc); ctx.rotate(-0.06); ctx.textAlign = 'center';
    ctx.lineJoin = 'round'; ctx.lineWidth = Math.max(5, fs * 0.18); ctx.strokeStyle = '#000000'; ctx.strokeText(name, 0, 0); ctx.lineWidth = Math.max(2, fs * 0.08); ctx.strokeStyle = '#ffffff'; ctx.strokeText(name, 0, 0); ctx.fillStyle = rbGrad(-tw / 2, tw / 2); ctx.fillText(name, 0, 0);
    ctx.restore(); return;
  }
  const bh = m * 0.26 * (0.25 + 0.75 * ez); ctx.translate(cw / 2, ch * 0.3); ctx.rotate(-0.1);
  ctx.fillStyle = heal ? 'rgba(6,30,14,0.9)' : 'rgba(10,0,22,0.9)'; ctx.fillRect(-cw, -bh / 2, cw * 2, bh);
  ctx.save(); ctx.beginPath(); ctx.rect(-cw, -bh / 2, cw * 2, bh); ctx.clip();
  for (let i = 0; i < 28; i++) { const h1 = Math.sin(i * 91.7) * 43758.5453, hh = h1 - Math.floor(h1), yy = -bh / 2 + hh * bh, len = cw * (0.08 + hh * 0.25), xx = cw - ((time * cw * 1.8 + i * cw * 0.37) % (cw * 2.4)); ctx.fillStyle = heal ? (i % 2 ? 'rgba(125,255,138,0.35)' : 'rgba(255,216,74,0.3)') : `hsla(${Math.round(i * 40 + time * 300) % 360},100%,65%,0.35)`; ctx.fillRect(xx, yy, len, 2); }
  const art = BOSS_ART.cv; if (art) { const S = bh * 1.3, ax = -cw * 0.3 + (p - 0.5) * cw * 0.05; ctx.imageSmoothingEnabled = false; ctx.save(); ctx.translate(ax, 0); if (BOSS.facesLeft) ctx.scale(-1, 1); ctx.drawImage(heal ? art : rainbowArt(art, time * 300, 0.6), -S / 2, -S * 0.56, S, S); ctx.restore(); }
  ctx.restore();
  ctx.fillStyle = rbGrad(-cw, cw); ctx.fillRect(-cw, -bh / 2 - 3, cw * 2, 3); ctx.fillRect(-cw, bh / 2, cw * 2, 3);
  const tx = -cw * 0.1 + (1 - ez) * cw * 0.3; let fs = Math.round(bh * 0.34); ctx.font = `900 ${fs}px "DotGothic16", sans-serif`; let tw = ctx.measureText(name).width; const room = cw / 2 - tx - 12; if (tw > room) { fs = Math.max(10, Math.floor(fs * room / tw)); ctx.font = `900 ${fs}px "DotGothic16", sans-serif`; tw = ctx.measureText(name).width; }
  ctx.font = `bold ${Math.max(8, Math.round(fs * 0.4))}px sans-serif`; ctx.fillStyle = heal ? '#ffd84a' : `hsl(${Math.round(time * 300) % 360},100%,72%)`; ctx.fillText(heal ? 'INFINITE  REVOLVING  ∞' : 'ULTIMATE  ∞  GAMING', tx, -fs * 0.78);
  ctx.font = `900 ${fs}px "DotGothic16", sans-serif`; ctx.lineJoin = 'round'; ctx.lineWidth = Math.max(4, fs * 0.16); ctx.strokeStyle = '#000000'; ctx.strokeText(name, tx, fs * 0.22); ctx.lineWidth = Math.max(2, fs * 0.06); ctx.strokeStyle = '#ffffff'; ctx.strokeText(name, tx, fs * 0.22); ctx.fillStyle = rbGrad(tx, tx + tw); ctx.fillText(name, tx, fs * 0.22);
  ctx.restore();
}
function drawBossFx(time) {
  const b = state.boss; if (!b) return;
  for (const s of b.shots) {
    const x = Math.round(s.x), y = Math.round(s.y);
    if (s.env) { ctx.fillStyle = '#1a1010'; ctx.fillRect(x - 5, y - 4, 10, 8); ctx.fillStyle = '#f4efe0'; ctx.fillRect(x - 4, y - 3, 8, 6); ctx.fillStyle = '#b8b0a0'; ctx.fillRect(x - 4, y - 3, 1, 1); ctx.fillRect(x - 3, y - 2, 1, 1); ctx.fillRect(x + 3, y - 3, 1, 1); ctx.fillRect(x + 2, y - 2, 1, 1); ctx.fillStyle = '#d03030'; ctx.fillRect(x - 1, y - 1, 2, 2); continue; }   // v8.2：督促状（赤い封の封筒）
    if (s.cdl) { ctx.fillStyle = '#d8d8d8'; ctx.fillRect(x, y - 6, 1, 12); ctx.fillStyle = '#101010'; ctx.fillRect(x - 2, y - 4, 5, 8); ctx.fillStyle = s.cdl === 1 ? '#36d26a' : '#ff4a4a'; ctx.fillRect(x - 1, y - 3, 3, 6); continue; }   // v8.2：ろうそく足（上がる＝緑、下がる＝赤）
    if (s.bill) { ctx.fillStyle = '#0e2a18'; ctx.fillRect(x - 5, y - 3, 10, 6); ctx.fillStyle = '#3f9a62'; ctx.fillRect(x - 4, y - 2, 8, 4); ctx.fillStyle = '#9be8b4'; ctx.fillRect(x - 1, y - 1, 2, 2); continue; }   // v8.2：請求書（お札）
    if (s.boom) { const an = time * 22 + s.x * 0.1; ctx.save(); ctx.translate(x, y); ctx.rotate(an); ctx.fillStyle = '#1a1010'; ctx.fillRect(-5, -4, 10, 8); ctx.fillStyle = `hsl(${Math.round(time * 400 + s.y) % 360},90%,60%)`; ctx.fillRect(-4, -3, 8, 6); ctx.fillStyle = '#d8f0d0'; ctx.fillRect(-3, -2, 6, 2); ctx.fillStyle = '#1a1010'; ctx.fillRect(-3, 1, 1, 1); ctx.fillRect(-1, 1, 1, 1); ctx.fillRect(1, 1, 1, 1); ctx.restore(); continue; }   // v8.2：回る電卓
    if (s.col != null) { ctx.fillStyle = '#140a14'; ctx.fillRect(x - 3, y - 3, 6, 6); ctx.fillStyle = `hsl(${Math.round(s.col * 72 + time * 240) % 360},100%,60%)`; ctx.fillRect(x - 2, y - 2, 4, 4); ctx.fillStyle = '#ffffff'; ctx.fillRect(x - 1, y - 1, 1, 1); continue; }   // v8.1：複利スパイラルの虹色の弾
    ctx.fillStyle = '#1a1010'; ctx.fillRect(x - 4, y - 3, 8, 6); ctx.fillStyle = '#f4efe0'; ctx.fillRect(x - 3, y - 2, 6, 4); ctx.fillStyle = '#d04040'; ctx.fillRect(x - 2, y - 1, 3, 1);
  }
  // v8.1：ブラックリスト・レーザー（予告は細い点線、本番は太い虹色の光）
  if (b.laser) {
    const L = b.laser, ox = b.x, oy = b.y - b.z - 22;
    for (let i = 0; i < L.n; i++) {
      const an = L.rot + i * Math.PI * 2 / L.n, ex = ox + Math.cos(an) * 420, ey = oy + Math.sin(an) * 420;
      if (L.warn) { ctx.strokeStyle = `rgba(255,70,70,${(0.55 + 0.4 * Math.sin(time * 30)).toFixed(2)})`; ctx.lineWidth = 1; ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(ex, ey); ctx.stroke(); ctx.setLineDash([]); continue; }
      ctx.strokeStyle = `hsla(${Math.round(time * 400 + i * 90) % 360},100%,60%,0.55)`; ctx.lineWidth = L.w * 2.4; ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.strokeStyle = `hsla(${Math.round(time * 400 + i * 90 + 40) % 360},100%,65%,0.95)`; ctx.lineWidth = L.w * 1.2; ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,0.95)'; ctx.lineWidth = Math.max(1, L.w * 0.4); ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(ex, ey); ctx.stroke();
    }
    if (!L.warn) { const gr = ctx.createRadialGradient(ox, oy, 0, ox, oy, 26); gr.addColorStop(0, 'rgba(255,255,255,0.95)'); gr.addColorStop(1, `rgba(${hueRGB(time * 400)},0)`); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(ox, oy, 26, 0, Math.PI * 2); ctx.fill(); }
    ctx.lineWidth = 1;
  }
  // v8.1：多重債務ミラーの分身（虹色の金木シンジ）
  if (b.clones && b.clones.length && BOSS_ART.cv) {
    const art = BOSS_ART.cv, S = art.width;
    for (const c of b.clones) {
      if (c.a <= 0.01) continue;
      ctx.fillStyle = `rgba(0,0,0,${(0.3 * c.a).toFixed(2)})`; ctx.beginPath(); ctx.ellipse(c.x, c.y - 1, 16, 4, 0, 0, Math.PI * 2); ctx.fill();
      ctx.save(); ctx.globalAlpha = 0.8 * c.a; ctx.translate(Math.round(c.x), Math.round(c.y)); if ((c.face > 0) === BOSS.facesLeft) ctx.scale(-1, 1);
      ctx.drawImage(rainbowArt(art, time * 300 + c.hue, 0.85), -Math.round(S / 2), -S, S, S); ctx.restore();
    }
  }
  // v8.2：株価の線（ぎざぎざの折れ線。大暴落の所は赤）
  if (b.chart && b.chart.length > 1) {
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.beginPath(); b.chart.forEach((c, i) => i ? ctx.lineTo(c.x, c.y) : ctx.moveTo(c.x, c.y)); ctx.stroke();
    for (let i = 1; i < b.chart.length; i++) { const c0 = b.chart[i - 1], c1 = b.chart[i]; ctx.strokeStyle = c1.up ? 'rgba(80,255,140,0.95)' : 'rgba(255,80,80,0.95)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(c0.x, c0.y); ctx.lineTo(c1.x, c1.y); ctx.stroke(); }
    const hd = b.chart[b.chart.length - 1]; ctx.fillStyle = hd.up ? '#50ff8c' : '#ff5050'; ctx.font = 'bold 9px sans-serif'; ctx.textAlign = 'center'; ctx.fillText(hd.up ? '▲' : '▼', hd.x, hd.y + 3); ctx.textAlign = 'left'; ctx.lineWidth = 1;
  }
  // v8.2：借金の雪玉
  for (const o of b.balls || []) {
    const warn = o.T - o.t < 1 && Math.floor(time * 16) % 2;
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(o.x, o.y + o.r * 0.85, o.r, o.r * 0.3, 0, 0, Math.PI * 2); ctx.fill();
    const gr = ctx.createRadialGradient(o.x - o.r * 0.35, o.y - o.r * 0.4, 1, o.x, o.y, o.r); gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.7, warn ? '#ffb0b0' : '#dfe8f6'); gr.addColorStop(1, warn ? '#d05050' : '#9fb0cc');
    ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(o.x, o.y, o.r, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = `hsla(${Math.round(time * 300) % 360},100%,60%,0.85)`; ctx.lineWidth = 1.5; ctx.stroke(); ctx.lineWidth = 1;
    ctx.save(); ctx.translate(o.x, o.y); ctx.rotate(o.rot); ctx.font = `bold ${Math.round(o.r * 1.1)}px sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#c02020'; ctx.fillText('借', 0, 1); ctx.restore(); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  }
  // v8.2：延滞利息ボム（コインの爆弾。残り時間の数字）と、競売ハンマー（最後の0.3秒で振り下ろされる）
  for (const z of b.zones || []) {
    if (z.land) continue;
    if (z.bomb) {
      const red = z.t < 0.45 && Math.floor(time * 18) % 2, xx = Math.round(z.x), yy = Math.round(z.y);
      ctx.fillStyle = '#1a1010'; ctx.beginPath(); ctx.arc(xx, yy, 7, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = red ? '#ff5050' : '#f2c440'; ctx.beginPath(); ctx.arc(xx, yy, 6, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = red ? '#ffffff' : '#a07010'; ctx.font = 'bold 8px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('¥', xx, yy + 1);
      ctx.fillStyle = '#ffe060'; ctx.fillRect(xx + 3 + rndi(-1, 1), yy - 10 + rndi(-1, 1), 2, 2);
      ctx.font = 'bold 10px sans-serif'; ctx.fillStyle = '#ffffff'; ctx.strokeStyle = '#000'; ctx.lineWidth = 2; const cd = String(Math.ceil(z.t / 0.47)); ctx.strokeText(cd, xx, yy - 15); ctx.fillText(cd, xx, yy - 15); ctx.lineWidth = 1; ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
    } else if (z.gavel && z.t < 0.3) {
      const sc = z.gavel === 2 ? 1.9 : 1, dp = z.t / 0.3, ang2 = -0.9 * dp;
      ctx.save(); ctx.translate(z.x + 22 * sc, z.y - 6 * sc); ctx.rotate(ang2); ctx.scale(sc, sc);
      ctx.fillStyle = '#3a2416'; ctx.fillRect(-2, -34, 4, 30); ctx.fillStyle = '#6b4423'; ctx.fillRect(-1, -34, 1, 30);
      ctx.translate(-22, 0); ctx.fillStyle = '#1a1010'; ctx.fillRect(-12, -9, 26, 14); ctx.fillStyle = '#7a4a26'; ctx.fillRect(-11, -8, 24, 12); ctx.fillStyle = '#f2c440'; ctx.fillRect(-7, -8, 2, 12); ctx.fillRect(7, -8, 2, 12); ctx.fillStyle = '#a06a3a'; ctx.fillRect(-11, -8, 24, 2);
      ctx.restore();
    }
  }
  // v8.1：無限リボ払いの間の、緑に光るバリア。v8.2：光の柱・回る矢印（リボ）・六角形のバリア・∞の印で豪華に
  if (b.atk && b.atk.k === 'heal' && b.atk.step === 1) {
    const ha = b.atk, k = 1 - ha.t / ha.T, cy = b.y - b.z - 24;
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    const pw = 20 + Math.sin(time * 18) * 4, pg = ctx.createLinearGradient(b.x - pw, 0, b.x + pw, 0); pg.addColorStop(0, 'rgba(125,255,138,0)'); pg.addColorStop(0.35, 'rgba(125,255,138,0.35)'); pg.addColorStop(0.5, 'rgba(255,255,220,0.55)'); pg.addColorStop(0.65, 'rgba(125,255,138,0.35)'); pg.addColorStop(1, 'rgba(125,255,138,0)');
    ctx.fillStyle = pg; ctx.fillRect(b.x - pw, 0, pw * 2, b.y);
    const fg = ctx.createRadialGradient(b.x, b.y, 2, b.x, b.y, 50); fg.addColorStop(0, 'rgba(180,255,170,0.55)'); fg.addColorStop(1, 'rgba(60,255,120,0)'); ctx.fillStyle = fg; ctx.beginPath(); ctx.ellipse(b.x, b.y, 50, 22, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    for (let i = 0; i < 2; i++) {
      const st = time * 4.5 + i * Math.PI, en = st + 2.3, rx = 50, ry = 24; ctx.strokeStyle = i ? '#ffd84a' : '#7dff8a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(b.x, cy + 6, rx, ry, 0, st, en); ctx.stroke();
      const ex = b.x + Math.cos(en) * rx, ey = cy + 6 + Math.sin(en) * ry, tx = -Math.sin(en) * rx, ty = Math.cos(en) * ry, tl = Math.hypot(tx, ty) || 1, ux = tx / tl, uy = ty / tl;
      ctx.fillStyle = ctx.strokeStyle; ctx.beginPath(); ctx.moveTo(ex + ux * 7, ey + uy * 7); ctx.lineTo(ex - uy * 5, ey + ux * 5); ctx.lineTo(ex + uy * 5, ey - ux * 5); ctx.closePath(); ctx.fill();
    }
    ctx.lineWidth = 2; ctx.strokeStyle = `rgba(125,255,138,${(0.6 + 0.35 * Math.sin(time * 20)).toFixed(2)})`; ctx.beginPath();
    for (let i = 0; i <= 6; i++) { const an = time * 1.5 + i * Math.PI / 3, rr = 36 + Math.sin(time * 12) * 2; if (i) ctx.lineTo(b.x + Math.cos(an) * rr, cy + Math.sin(an) * rr); else ctx.moveTo(b.x + Math.cos(an) * rr, cy + Math.sin(an) * rr); }
    ctx.stroke(); ctx.fillStyle = 'rgba(125,255,138,0.13)'; ctx.fill(); ctx.lineWidth = 1;
    const ip = 1 + 0.15 * Math.sin(time * 14); ctx.save(); ctx.translate(b.x, cy - 42); ctx.scale(ip, ip); ctx.font = 'bold 20px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineWidth = 3; ctx.strokeStyle = '#1a3010'; ctx.strokeText('∞', 0, 0); ctx.fillStyle = '#ffe680'; ctx.fillText('∞', 0, 0); ctx.restore(); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.lineWidth = 1;
  }
  // v6b：落ちてくる判子（最後の0.25秒で上から落ちる）
  for (const st of b.stamps) if (!st.land && st.t < 0.25) {
    const sc = st.r / 14, yy = Math.round(st.y - (st.t / 0.25) * 46 * sc), xx = Math.round(st.x);   // v6.1b：判子の大きさ（半径14が1倍）
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(xx, st.y, st.r * (1 - st.t * 2), 4 * sc, 0, 0, Math.PI * 2); ctx.fill();
    ctx.save(); ctx.translate(xx, yy); ctx.scale(sc, sc);
    ctx.fillStyle = '#3a2416'; ctx.fillRect(-3, -20, 6, 12); ctx.fillStyle = '#6b4423'; ctx.fillRect(-2, -20, 2, 12);
    ctx.fillStyle = '#1a1010'; ctx.fillRect(-11, -9, 22, 9); ctx.fillStyle = st.rb ? `hsl(${Math.round(time * 360 + st.x) % 360},100%,55%)` : '#c8302a'; ctx.fillRect(-10, -8, 20, 7); ctx.fillStyle = '#ff7060'; ctx.fillRect(-10, -8, 20, 1);   // v8.1：第2形態の判子は虹色
    ctx.restore();
  }
  // v6b：見た目だけの輪（着地・吠える・戻る）
  // v8.2：見た目だけの光の粒（ブラックホールに吸い込まれる光・∞の紙吹雪・リボ払いで集まるコイン）
  for (const v of b.vfx) {
    if (v.k === 'suck') { const p2 = 1 - v.t / v.T, e = p2 * p2; ctx.fillStyle = `hsla(${v.h},100%,70%,${(0.9 * (1 - p2 * 0.5)).toFixed(2)})`; ctx.fillRect(Math.round(v.x + (v.hx - v.x) * e), Math.round(v.y + (v.hy - v.y) * e), 2, 2); }
    else if (v.k === 'conf') { const ag = v.T - v.t, x = v.x + v.vx * ag, y = v.y + v.vy * ag + 70 * ag * ag, a3 = Math.min(1, v.t / 0.5); ctx.fillStyle = `hsla(${(v.h + Math.round(time * 400)) % 360},100%,65%,${a3.toFixed(2)})`; ctx.fillRect(Math.round(x), Math.round(y), Math.floor(time * 12 + v.h) % 2 ? 3 : 1, 2); }
    else if (v.k === 'coin') { const p2 = 1 - v.t / v.T, e = p2 * p2 * p2, px = v.x + (b.x - v.x) * e + Math.sin(p2 * 9 + v.h) * 14 * (1 - p2), py = v.y + (b.y - 24 - v.y) * e; ctx.fillStyle = '#1a1010'; ctx.fillRect(Math.round(px) - 2, Math.round(py) - 2, 4, 4); ctx.fillStyle = Math.floor(time * 16 + v.h) % 2 ? '#ffe680' : '#f2c440'; ctx.fillRect(Math.round(px) - 1, Math.round(py) - 1, 2, 2); }
  }
  for (const v of b.vfx) if (v.k === 'ring') { const a = Math.max(0, v.t / v.T); ctx.strokeStyle = `rgba(${v.col || '255,255,255'},${(a * 0.9).toFixed(2)})`; ctx.lineWidth = 1 + a * 2; ctx.beginPath(); ctx.ellipse(v.x, v.y, v.r, v.r * 0.55, 0, 0, Math.PI * 2); ctx.stroke(); }
  // v6b：ゼロ・バーストのため（光の玉と、集まってくる光）
  const za = b.atk && b.atk.k === 'zero' ? b.atk : null;
  if (za && za.inf && b.charge > 0) {   // v8.2：∞は、ステージ中から虹色の光の筋が集まり、玉のまわりにトゲの光が回る
    const ox = b.x - za.side * 26, oy = b.y - b.z - 26, c2 = b.charge;
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 26; i++) { const h1 = Math.sin(i * 12.9898) * 43758.5453, hh = h1 - Math.floor(h1), an = hh * Math.PI * 2 + i, p2 = (time * (0.9 + hh * 0.8) + hh) % 1, r1 = 220 * (1 - p2) + 12, r2 = r1 + 18 + c2 * 20;
      ctx.strokeStyle = `hsla(${Math.round(i * 37 + time * 300) % 360},100%,62%,${(0.8 * p2).toFixed(2)})`; ctx.lineWidth = 1 + c2 * 1.5; ctx.beginPath(); ctx.moveTo(ox + Math.cos(an) * r1, oy + Math.sin(an) * r1); ctx.lineTo(ox + Math.cos(an) * r2, oy + Math.sin(an) * r2); ctx.stroke(); }
    const R = 6 + c2 * 20 + Math.sin(time * 34) * 1.5;
    for (let i = 0; i < 12; i++) { const an = time * 5 + i * Math.PI / 6, r2 = R * (1.4 + 0.5 * Math.sin(time * 26 + i)); ctx.strokeStyle = `hsla(${Math.round(i * 30 + time * 500) % 360},100%,70%,0.9)`; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(ox + Math.cos(an) * R * 0.7, oy + Math.sin(an) * R * 0.7); ctx.lineTo(ox + Math.cos(an) * r2, oy + Math.sin(an) * r2); ctx.stroke(); }
    const gr = ctx.createRadialGradient(ox, oy, 0, ox, oy, R * 2.6); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.3, `rgba(${hueRGB(time * 400)},0.85)`); gr.addColorStop(0.65, `rgba(${hueRGB(time * 400 + 120)},0.4)`); gr.addColorStop(1, `rgba(${hueRGB(time * 400 + 240)},0)`);
    ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(ox, oy, R * 2.6, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(ox, oy, R * 0.5, 0, Math.PI * 2); ctx.fill(); ctx.lineWidth = 1;
    for (const p of b.sparks) { ctx.fillStyle = `hsl(${rndi(0, 359)},100%,75%)`; ctx.fillRect(Math.round(p.x), Math.round(p.y), 2, 2); }
  } else if (za && b.charge > 0) {
    const ox = b.x - za.side * 26, oy = b.y - b.z - 26, rr = 3 + b.charge * 13 + Math.sin(time * 30) * 1.2;
    const gr = ctx.createRadialGradient(ox, oy, 0, ox, oy, rr * 2.4); gr.addColorStop(0, 'rgba(255,255,255,0.95)'); gr.addColorStop(0.35, 'rgba(255,120,220,0.8)'); gr.addColorStop(1, 'rgba(120,20,160,0)');
    ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(ox, oy, rr * 2.4, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(ox, oy, rr * 0.45, 0, Math.PI * 2); ctx.fill();
    for (const p of b.sparks) { ctx.fillStyle = Math.random() < 0.5 ? '#ffd0ff' : '#ffffff'; ctx.fillRect(Math.round(p.x), Math.round(p.y), 1, 1); }
  }
  // v6b：ゼロ・バースト（すき間以外を焼きつくす光線）。v6.2：発射口から伸びる・流れる光の筋・すき間のふちの稲妻・発射口の光で豪華に
  if (b.beam) {
    const bm = b.beam, gp = bm.gap, k = bm.t / bm.T, age = bm.T - bm.t, hw = gp.w / 2 / Math.cos(gp.th), jit = () => rnd(-2, 2);
    const sd = bm.side, ox = bm.ox != null ? bm.ox : (sd < 0 ? 40 : 344), oy = bm.oy != null ? bm.oy : bm.y0, dir = -sd;
    const reach = clamp(age / 0.12, 0, 1), front = ox + dir * reach * 420;   // 最初の0.12秒で、発射口から反対側へ伸びる
    const hsh = i => { const v = Math.sin(i * 127.1 + 311.7) * 43758.5453; return v - Math.floor(v); };
    ctx.save(); ctx.beginPath();
    if (dir > 0) ctx.rect(20, 20, clamp(front - 20, 0, 344), 250); else { const fx = clamp(front, 20, 364); ctx.rect(fx, 20, 364 - fx, 250); }
    ctx.clip();
    const path = pad => { ctx.beginPath(); ctx.rect(0, 0, 384, 288); ctx.moveTo(-10, zeroLineY(gp, -10) - hw - pad); for (let x = 0; x <= 400; x += 16) ctx.lineTo(x, zeroLineY(gp, x) - hw - pad + jit()); ctx.lineTo(400, zeroLineY(gp, 400) + hw + pad); for (let x = 400; x >= -10; x -= 16) ctx.lineTo(x, zeroLineY(gp, x) + hw + pad + jit()); ctx.closePath(); };
    path(0); ctx.fillStyle = `rgba(255,40,140,${(0.55 * k + 0.15).toFixed(2)})`; ctx.fill('evenodd');
    path(5); ctx.fillStyle = `rgba(255,220,120,${(0.55 * k).toFixed(2)})`; ctx.fill('evenodd');
    path(12); ctx.fillStyle = `rgba(255,255,255,${(0.75 * k * (0.75 + Math.random() * 0.25)).toFixed(2)})`; ctx.fill('evenodd');
    if (bm.inf) { const rg = ctx.createLinearGradient(0, 0, 384, 288); for (let i = 0; i <= 6; i++) rg.addColorStop(i / 6, `hsla(${Math.round(time * 500 + i * 60) % 360},100%,60%,${(0.45 * k).toFixed(2)})`); ctx.fillStyle = rg; path(12); ctx.fill('evenodd'); }   // v8.1：ゼロ・バースト∞は虹色。v8.1再：すき間は塗らない
    if (bm.inf) {   // v8.2：∞の光線を豪華に（流れる虹色の帯・飛んでいく「∞」・すき間のふちの赤と水色のずれ）
      for (let i = 0; i < 10; i++) { const yy = 26 + ((i * 27 + time * 140) % 240); if (Math.abs(yy - zeroLineY(gp, 192)) < hw + 8) continue; ctx.fillStyle = `hsla(${Math.round(time * 700 + i * 36) % 360},100%,66%,${(0.55 * k).toFixed(2)})`; ctx.fillRect(20, Math.round(yy), 344, 3); }
      ctx.font = 'bold 13px sans-serif'; ctx.textBaseline = 'middle';
      for (let i = 0; i < 22; i++) { const yy = 30 + hsh(i + 200) * 228; if (Math.abs(yy - zeroLineY(gp, 192)) < hw + 10) continue; const xx = ox + dir * ((time * (420 + hsh(i + 300) * 360) + hsh(i + 400) * 400) % 400); ctx.fillStyle = `hsla(${Math.round(hsh(i) * 360 + time * 500) % 360},100%,80%,${k.toFixed(2)})`; ctx.fillText('∞', Math.round(xx), Math.round(yy)); }
      ctx.textBaseline = 'alphabetic';
      for (const [e, cc] of [[-3, '255,60,90'], [3, '80,220,255']]) { ctx.strokeStyle = `rgba(${cc},${(0.85 * k).toFixed(2)})`; ctx.lineWidth = 2; for (const sg of [-1, 1]) { ctx.beginPath(); ctx.moveTo(20, zeroLineY(gp, 20) + sg * (hw + 4) + e); ctx.lineTo(364, zeroLineY(gp, 364) + sg * (hw + 4) + e); ctx.stroke(); } }
    }
    // 流れる光の筋（発射口から反対側へ）
    ctx.lineWidth = 1;
    for (let i = 0; i < 46; i++) {
      const yy = 26 + hsh(i) * 240; if (Math.abs(yy - zeroLineY(gp, 192)) < hw + 6) continue;
      const len = 14 + hsh(i + 50) * 34, sp = 520 + hsh(i + 90) * 480, xx = ox + dir * ((time * sp + hsh(i + 130) * 400) % 400);
      ctx.strokeStyle = i % 3 ? `rgba(255,255,255,${(0.85 * k).toFixed(2)})` : `rgba(255,150,230,${(0.9 * k).toFixed(2)})`;
      ctx.beginPath(); ctx.moveTo(Math.round(xx), Math.round(yy) + 0.5); ctx.lineTo(Math.round(xx - dir * len), Math.round(yy) + 0.5); ctx.stroke();
    }
    for (let i = 0; i < 6; i++) { const yy = rnd(30, 260); if (Math.abs(yy - zeroLineY(gp, 192)) < hw + 10) continue; ctx.fillStyle = `rgba(255,255,255,${(0.8 * k).toFixed(2)})`; ctx.fillRect(20, Math.round(yy), 344, 1); }
    // すき間のふち：ばちばちと光る稲妻
    for (const e of [-1, 1]) {
      ctx.beginPath();
      for (let x = 20; x <= 364; x += 8) { const y = zeroLineY(gp, x) + e * (hw + 1) + rnd(-2.5, 2.5); if (x === 20) ctx.moveTo(x, y); else ctx.lineTo(x, y); }
      ctx.strokeStyle = `rgba(150,240,255,${(0.95 * k).toFixed(2)})`; ctx.lineWidth = 2; ctx.stroke();
      ctx.strokeStyle = `rgba(255,255,255,${k.toFixed(2)})`; ctx.lineWidth = 1; ctx.stroke();
    }
    ctx.restore();
    // 発射口の光（回る光の線と、大きな光の玉）
    const fr = 22 + 18 * k + Math.sin(time * 40) * 3;
    const mg = ctx.createRadialGradient(ox, oy, 0, ox, oy, fr * 2.2); mg.addColorStop(0, `rgba(255,255,255,${k.toFixed(2)})`); mg.addColorStop(0.3, `rgba(255,140,230,${(0.85 * k).toFixed(2)})`); mg.addColorStop(1, 'rgba(120,20,180,0)');
    ctx.fillStyle = mg; ctx.beginPath(); ctx.arc(ox, oy, fr * 2.2, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = `rgba(255,240,160,${(0.9 * k).toFixed(2)})`; ctx.lineWidth = 2;
    for (let i = 0; i < 10; i++) { const an = time * 6 + i * Math.PI / 5, r1 = fr * 0.6, r2 = fr * (1.6 + 0.6 * Math.sin(time * 30 + i)); ctx.beginPath(); ctx.moveTo(ox + Math.cos(an) * r1, oy + Math.sin(an) * r1); ctx.lineTo(ox + Math.cos(an) * r2, oy + Math.sin(an) * r2); ctx.stroke(); }
    ctx.lineWidth = 1; ctx.fillStyle = `rgba(255,255,255,${(0.6 + 0.4 * k).toFixed(2)})`; ctx.beginPath(); ctx.arc(ox, oy, fr * 0.45, 0, Math.PI * 2); ctx.fill();
  }
  if (b.fx && b.fx.k === 'slash') {
    const cx = b.x, cy = b.y - 12, a = (b.fx.t / 0.18).toFixed(2);
    ctx.strokeStyle = `rgba(255,90,90,${(a * 0.7).toFixed(2)})`; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(cx, cy, 40, b.fx.a - 0.8, b.fx.a + 0.8); ctx.stroke();   // v6b：爪あとを太く
    ctx.strokeStyle = `rgba(255,255,255,${a})`; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(cx, cy, 44, b.fx.a - 0.9, b.fx.a + 0.9); ctx.stroke();
    ctx.strokeStyle = `rgba(30,10,20,${a})`; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx, cy, 52, b.fx.a - 0.7, b.fx.a + 0.7); ctx.stroke();
  }
  // v6.1b：セリフは drawBossSay（画面の中に収める）で描く
}
// v6.1b：ボスのセリフ。画面の外・HUDに重ならない位置へずらす。長い時は折り返す。暗闇の上に描く
const SAY_HUD = ['hud-status', 'minimap', 'hud-gauges', 'hud-menu', 'hud-objective', 'hotbar', 'boss-bar', 'keyguide', 'tbtns', 'stick-base', 'hint'];
const sayCache = { t: -1, rects: [], safe: null };
function screenSafe() {
  if (!sayCache.safe) {
    const d = document.createElement('div');
    d.style.cssText = 'position:fixed;left:0;top:0;width:0;height:0;visibility:hidden;pointer-events:none;padding:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px)';
    document.body.appendChild(d); const cs = getComputedStyle(d);
    sayCache.safe = { t: parseFloat(cs.paddingTop) || 0, r: parseFloat(cs.paddingRight) || 0, b: parseFloat(cs.paddingBottom) || 0, l: parseFloat(cs.paddingLeft) || 0 };
    d.remove(); window.addEventListener('resize', () => { sayCache.safe = null; sayCache.t = -1; });
  }
  return sayCache.safe;
}
function sayObstacles(now) {
  if (now - sayCache.t < 0.25 && sayCache.t >= 0) return sayCache.rects;
  sayCache.t = now; sayCache.rects = [];
  for (const id of SAY_HUD) {
    const el = $(id); if (!el || !el.offsetParent || el.classList.contains('hidden')) continue;
    const r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) continue;
    sayCache.rects.push({ l: r.left, t: r.top, r: r.right, b: r.bottom });
  }
  return sayCache.rects;
}
function wrapSay(text, maxW) {
  const out = []; let cur = '';
  for (const ch of text) { const t = cur + ch; if (cur && ctx.measureText(t).width > maxW) { out.push(cur); cur = ch; } else cur = t; }
  if (cur) out.push(cur);
  return out;
}
function drawBossSay(time, camX, camY) {
  const b = state.boss; if (!b || !b.say || !(b.sayT > 0)) return;
  const cr = canvas.getBoundingClientRect(), k = canvas.width / (cr.width || 1), W = canvas.width, H = canvas.height, sf = screenSafe();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  const uiK = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--ui')) || 1;   // v6.1e：UIの大きさに合わせる
  const fs = Math.max(Math.round(12 * k * uiK), Math.round(7 * zoom)), lh = Math.round(fs * 1.3), pad = Math.round(fs * 0.55), gap = Math.round(4 * k);
  ctx.font = `${fs}px "DotGothic16", sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  const mL = (sf.l + 6) * k, mR = (sf.r + 6) * k, mT = (sf.t + 6) * k, mB = (sf.b + 6) * k;
  const lines = wrapSay(b.say, Math.min(W - mL - mR - pad * 2, fs * 20));
  const tw = Math.ceil(Math.max(...lines.map(t => ctx.measureText(t).width))) + pad * 2, th = lines.length * lh + Math.round(pad * 0.9);
  const ax = (b.x - camX) * zoom, ay = (b.y - b.z - BOSS.size - 4 - camY) * zoom;   // 頭の上
  const fitX = x => clamp(x, mL, Math.max(mL, W - mR - tw)), fitY = y => clamp(y, mT, Math.max(mT, H - mB - th));
  let x = fitX(ax - tw / 2), y = fitY(ay - th - gap * 2);
  // HUDと重なったら、いちばん近い空いている所へずらす
  const rects = sayObstacles(time).map(r => ({ l: r.l * k - gap, t: r.t * k - gap, r: r.r * k + gap, b: r.b * k + gap }));
  if (b.blinkA == null || b.blinkA > 0.3) { const S2 = BOSS.size / 2, bt = (b.y - b.z - BOSS.size - camY) * zoom; rects.push({ l: (b.x - S2 - camX) * zoom - gap, t: bt - gap, r: (b.x + S2 - camX) * zoom + gap, b: (b.y - b.z - camY) * zoom + gap }); }   // ボスの体にも重ねない
  const hits = (x, y) => rects.some(r => x < r.r && x + tw > r.l && y < r.b && y + th > r.t);
  for (let it = 0; it < 4 && hits(x, y); it++) {
    let best = null;
    for (const r of rects) {
      if (!(x < r.r && x + tw > r.l && y < r.b && y + th > r.t)) continue;
      for (const [cx, cy] of [[x, r.b], [x, r.t - th], [r.r, y], [r.l - tw, y]]) {
        const nx = fitX(cx), ny = fitY(cy); if (hits(nx, ny)) continue;
        const d = Math.abs(nx - x) + Math.abs(ny - y); if (!best || d < best.d) best = { x: nx, y: ny, d };
      }
    }
    if (!best) break; x = best.x; y = best.y;
  }
  x = Math.round(x); y = Math.round(y);
  const bw = Math.max(2, Math.round(k * 1.5));
  // しっぽ（ボスの方を指す）
  const tx = clamp(ax, x + pad, x + tw - pad), down = ay > y + th, up = ay < y, tl = Math.round(6 * k);
  ctx.fillStyle = '#140a12';
  if (down || up) { const by = down ? y + th : y, dir = down ? 1 : -1; ctx.beginPath(); ctx.moveTo(tx - tl - bw, by); ctx.lineTo(tx, by + dir * (tl + bw)); ctx.lineTo(tx + tl + bw, by); ctx.closePath(); ctx.fill(); }
  ctx.fillRect(x - bw, y - bw, tw + bw * 2, th + bw * 2); ctx.fillStyle = '#fff8ec'; ctx.fillRect(x, y, tw, th);
  if (down || up) { const by = down ? y + th - 1 : y + 1, dir = down ? 1 : -1; ctx.beginPath(); ctx.moveTo(tx - tl, by); ctx.lineTo(tx, by + dir * tl); ctx.lineTo(tx + tl, by); ctx.closePath(); ctx.fill(); }
  ctx.fillStyle = '#2a1820';
  lines.forEach((t, i) => ctx.fillText(t, x + tw / 2, y + Math.round(pad * 0.45) + lh * i + lh / 2 + 0.5));
}
/* ---------- ギャンブル ---------- */
function linerDir() {
  const o = maps.island.objs.find(x => x.t === 'liner'); if (!o) return '';
  const dx = o.x - maps.island.W / 2, dy = o.y - maps.island.H / 2, a = Math.atan2(dy, dx) * 180 / Math.PI;
  return ['東', '南東', '南', '南西', '西', '北西', '北', '北東'][Math.round(((a + 360) % 360) / 45) % 8];
}
function gambleLog(bet, win) { const c = game.casino; c.net += win - bet; c.plays++; game.stats.gamble = (game.stats.gamble || 0) + win - bet; }
const fmtNet = n => (n >= 0 ? '+' : '-') + fmt$(Math.abs(n));
function openLiner() {
  const g = game;
  if (!g.flags.linerSeen) { g.flags.linerSeen = 1; queueTalk(TALK.liner, openLiner); return; }
  if (g.casino.open) { openCasino(); return; }
  UI.open({ render: (el, L) => el.appendChild(windowEl(L, { title: '豪華客船の残骸', cls: 'small', body: b => {
    b.appendChild(h('p', { class: 'note', style: 'color:var(--text);font-size:14px' }, '船内のカジノは電源が落ちている。発電機を直せば動きそうだ。'));
    b.appendChild(sec('修理に必要な素材', costEls(LINER_REPAIR)));
    b.appendChild(h('div', { style: 'display:flex;justify-content:center;margin-top:8px' }, btn('発電機を直す', () => {
      if (!hasAll(LINER_REPAIR)) { sfx('error'); toast('素材が足りません', 'bad'); return; }
      payCost(LINER_REPAIR); g.casino.open = true; sfx('unlock'); UI.close(L); saveGame(true);
      const o = maps.island.objs.find(x => x.t === 'liner'); if (o) burst(o.x * 16 + 24, o.y * 16, '#ff5ac8', 24);
      queueTalk(TALK.linerOpen, openCasino);
    }, { key: 'repair', cls: hasAll(LINER_REPAIR) ? 'primary' : '', disabled: !hasAll(LINER_REPAIR), why: '素材が足りません' })));
  } })) });
}
// カジノ（スロット・ルーレット）
let slotRun = null, rouRun = null, slotSaveT = 0, raceRun = null;   // v8c：raceRun＝ヤドカリレース
function ensureCasino() { const c = game.casino; if (c.coins == null) c.coins = 0; if (c.pend === undefined) c.pend = null; if (!Array.isArray(c.reel)) c.reel = [1, 3, 5]; c.bb = c.bb || 0; c.rb = c.rb || 0; c.replay = !!c.replay; return c; }
const coinValue = n => Math.floor(n * SLOT.coinCost / SLOT.coinRate);
function openCasino() {
  sfx('door'); ensureCasino();
  // v6.2：カジノで遊んでいる間も時間は進む（船の中なので、獣や雷のダメージは受けない）
  UI.open({ tab: 'slot', live: true, casino: true, bet: 10, rouType: 'red', rouNum: 7, smsg: '', rmsg: '', focusKey: 'lever',
    onClose: () => { finishSlot(); finishRoulette(); finishRace(true); saveGame(true); },
    onTick: (dt, L) => { if (L.tab === 'slot') { if (slotRun) for (let k = 1; k <= 3; k++) if (Input.press('H' + k)) stopReel(k - 1); slotTick(dt); drawSlotReels(); drawSlotLamp(); } },
    render: (el, L) => {
      if (L.tab !== 'slot' && slotRun) finishSlot();
      if (L.tab !== 'race' && raceRun) finishRace(true);   // v8c
      el.appendChild(windowEl(L, {
        title: 'カジノ「ルナ・マリーナ」', cls: 'casino',
        sub: statusSub(h('span', null, 'コイン ', h('b', { id: 'slot-coins-sub' }, `${game.casino.coins}枚`), '　収支 ', h('b', { class: game.casino.net >= 0 ? 'ok' : 'ng' }, fmtNet(game.casino.net)))),
        tabs: [{ id: 'slot', label: 'スロット' }, { id: 'rou', label: 'ルーレット' }, { id: 'race', label: 'ヤドカリレース' }],   // v8c
        body: b => {
          L._side = null; (L.tab === 'slot' ? renderSlot : L.tab === 'race' ? renderRace : renderRoulette)(b, L);
          (L._side || b).appendChild(h('p', { class: 'note warn', style: 'margin-top:8px' }, 'カジノは長く続けるほど負ける仕組みです。借金の返済は計画的に。'));   // v8a：横画面は右の列に入れる
        },
      }));
    } });
}
/* --- スロット（v4：5ライン・ストップは好きな順番・ウェイト3秒・連打防止0.2秒） --- */
// 1ライン（左・中・右の図柄）の役
function slotRole(ln) {
  if (ln[0] === 'seven' && ln[1] === 'seven' && ln[2] === 'seven') return 'BB';
  if (ln[0] === 'seven' && ln[1] === 'seven' && ln[2] === 'bar') return 'RB';
  if (ln[0] === ln[1] && ln[1] === ln[2] && (ln[0] === 'replay' || ln[0] === 'grape' || ln[0] === 'bell')) return ln[0];
  return null;
}
const reelSym = (i, p) => { const st = SLOT.reels[i], N = st.length; return st[((Math.round(p) % N) + N) % N]; };
// リールに見えている3コマ（0=上段 1=中段 2=下段）。図柄は上から下へ流れるので、上段は p+1
const reelCol = (i, p) => [reelSym(i, p + 1), reelSym(i, p), reelSym(i, p - 1)];
// 止まった図柄の判定（cols：3リールぶんの列）。チェリーは左リールのどこかに見えればOK
function slotEval(cols) {
  const lines = [];
  for (let li = 0; li < SLOT_LINES.length; li++) { const rw = SLOT_LINES[li], role = slotRole([cols[0][rw[0]], cols[1][rw[1]], cols[2][rw[2]]]); if (role) lines.push({ li, role }); }
  return { lines, cherry: cols[0].includes('cherry') };
}
// その止まり方が抽選結果どおりか（F：当たった小役 / bonus：揃えてよいボーナス）
function slotAcceptable(cols, F, bonus) {
  const ev = slotEval(cols);
  if (ev.cherry !== (F === 'cherry')) return false;
  for (const l of ev.lines) if (!(l.role === F || (bonus && l.role === bonus))) return false;
  if (F && F !== 'cherry' && !ev.lines.some(l => l.role === F)) return false;
  return true;
}
// まだ止まっていないリールを、抽選結果どおりに止められる位置があるか
function slotFeasible(cols, F, bonus) {
  if (cols[0] && cols[0].includes('cherry') !== (F === 'cherry')) return false;
  const k = cols.findIndex(c => !c);
  if (k < 0) return slotAcceptable(cols, F, bonus);
  const N = SLOT.reels[k].length;
  for (let p = 0; p < N; p++) { const c2 = cols.slice(); c2[k] = reelCol(k, p); if (slotFeasible(c2, F, bonus)) return true; }
  return false;
}
// 当選中のボーナスが、止まっているリールとどれかのラインで揃う見込みがあるか
function bonusPossible(cols, pend) {
  const pat = ['seven', 'seven', pend === 'BB' ? 'seven' : 'bar'];
  return SLOT_LINES.some(rw => [0, 1, 2].every(k => !cols[k] || cols[k][rw[k]] === pat[k]));
}
// リールを止める位置を決める（c0＝押した時に次に中段へ来るコマ。そこから何コマ滑らせるかを返す）
function slotDecide(run, i, c0) {
  const N = SLOT.reels[i].length, F = run.flag, pend = game.casino.pend;
  const known = run.reels.map((r, k) => r.target != null ? reelCol(k, r.target) : null);
  const colAt = s => { const c = known.slice(); c[i] = reelCol(i, c0 + s); return c; };
  const pick = (to, pred, bonus) => { for (let s = 0; s <= to; s++) { const c = colAt(s); if (pred(c) && slotFeasible(c, F, bonus)) return s; } return -1; };
  let s = -1;
  if (F && F !== 'cherry') s = pick(N - 1, c => c[i][1] === F, null);                          // 小役は中段に自動で揃える
  else if (F === 'cherry' && i === 0) s = pick(N - 1, c => c[0].includes('cherry'), null);
  else if (run.aim) {   // ボーナス当選中：7（右リールはRBならBAR）を目押し。アシストONなら必ず揃う
    const want = i < 2 || pend === 'BB' ? 'seven' : 'bar';
    s = pick(settings.slotAssist ? N - 1 : SLOT.slide, c => c[i].includes(want) && bonusPossible(c, pend), pend);
    if (s < 0) run.aim = false;   // 取りこぼし（当選は次のゲームへ持ち越し）
  }
  if (s < 0) s = pick(N - 1, () => true, run.aim ? pend : null);
  return s < 0 ? 0 : s;
}
function slotLever(L) {
  if (L && L.el) { L.focusKey = 'lever'; UI.applyFocus(L); }   // キーボード・コントローラーの決定は常にレバーへ
  if (slotRun) { if (slotRun.wait > 0) return; const i = slotRun.reels.findIndex(x => x.target == null); if (i >= 0) stopReel(i); return; }   // 回っている時は左から順に止める
  const c = ensureCasino(), now = performance.now(); if (now < (c._next || 0)) return;
  const free = c.replay;
  if (!free && c.coins < SLOT.bet) { sfx('error'); toast(`コインが足りません（${fmt$(SLOT.coinCost)}で${SLOT.coinRate}枚）`, 'bad'); return; }
  if (free) c.replay = false; else c.coins -= SLOT.bet;
  // 抽選（ボーナス持ち越し中は、ボーナスの抽選はしない）
  let flag = null, nb = null; const r = Math.random(); let acc = 0;
  for (const k of ['BB', 'RB', 'replay', 'grape', 'cherry', 'bell']) { acc += SLOT.prob[k]; if (r < acc) { if (k === 'BB' || k === 'RB') { if (!c.pend) nb = k; } else flag = k; break; } }
  if (state.slotForce && !c.pend) { nb = state.slotForce; flag = null; }
  state.slotForce = null;
  if (nb) { c.pend = nb; sfx('unlock'); }
  c.plays++; c._win = null;
  // ウェイト：前のゲームが回り出してから SLOT.wait 秒たつまで、次のゲームは回り出さない（表示はしない）
  const wait = Math.max(0, SLOT.wait - (now - (c._lever || -1e9)) / 1000); c._lever = now + wait * 1000;
  slotRun = { L, flag, aim: !!c.pend && !flag, t: 0, wait, cd: 0, fresh: !!nb, reels: [0, 1, 2].map(i => ({ pos: c.reel[i], target: null, done: false, delay: i * 0.08 })) };
  if (!wait) sfx('ui');
  L.smsg = nb ? '★ ボーナスランプ点灯！ 7を狙え！' : c.pend ? (flag ? 'ボーナス持ち越し中' : 'ボーナス当選中！ 7を狙え！') : free ? 'リプレイ（無料）' : '';
  slotDom(L);
}
// i：0=左 1=中 2=右。好きな順番で止められる（連打防止のクールタイムあり）
function stopReel(i) {
  const r = slotRun; if (!r || r.wait > 0 || r.t < 0.3 || r.cd > 0) return; const rl = r.reels[i]; if (!rl || rl.target != null) return;
  const c0 = Math.ceil(rl.pos + 0.001); rl.target = c0 + slotDecide(r, i, c0); r.cd = SLOT.stopCd;
  slotDom(r.L);
}
function slotTick(dt) {
  const r = slotRun; if (!r) return;
  if (r.wait > 0) { r.wait -= dt; if (r.wait > 0) return; r.wait = 0; sfx('ui'); }
  r.t += dt; r.cd = Math.max(0, r.cd - dt);
  for (const rl of r.reels) {
    if (rl.done) continue;
    if (rl.delay > 0) { rl.delay -= dt; continue; }
    rl.pos += SLOT.speed * dt;
    if (rl.target != null && rl.pos >= rl.target) { rl.pos = rl.target; rl.done = true; sfx('ui'); }
  }
  if (r.reels.every(x => x.done)) slotResult();
}
function slotResult() {
  const r = slotRun, c = game.casino; if (!r) return; slotRun = null;
  r.reels.forEach((rl, i) => { c.reel[i] = ((Math.round(rl.target) % 21) + 21) % 21; });
  const ev = slotEval(r.reels.map((rl, i) => reelCol(i, rl.target)));
  const bl = ev.lines.find(l => (l.role === 'BB' || l.role === 'RB') && l.role === c.pend);
  const rp = ev.lines.filter(l => l.role === 'replay'), sm = ev.lines.find(l => l.role === 'grape' || l.role === 'bell');
  let win = 0, msg; c._win = []; c._winT = performance.now() + 2600;
  if (bl) {
    const role = bl.role; win = SLOT.pay[role]; c.pend = null; if (role === 'BB') c.bb++; else c.rb++; c._win = [bl.li];
    msg = `${SLOT.name[role]}！ ${win}枚 獲得！`; sfx('unlock'); state.shake = 0.4; toast(`★ ${SLOT.name[role]} ${win}枚！ ★`, 'money');
  } else if (rp.length) { c.replay = true; c._win = rp.map(l => l.li); msg = 'リプレイ！ 次のゲームは無料'; sfx('coin'); }
  else if (sm) { win = SLOT.pay[sm.role]; c._win = ev.lines.filter(l => l.role === sm.role).map(l => l.li); msg = `${SLOT.name[sm.role]} ${win}枚`; sfx('coin'); }
  else if (ev.cherry) { win = SLOT.pay.cherry; c._win = ['cherry']; msg = `${SLOT.name.cherry} ${win}枚`; sfx('coin'); }
  else msg = c.pend ? (r.aim === false && !r.flag ? '取りこぼし……当選は持ち越し！ もう一度7を狙え' : 'ボーナス当選中！ 7を狙え！') : 'はずれ';
  c.coins += win; c._next = performance.now() + 300; r.L.smsg = msg;
  slotDom(r.L);
  const now = performance.now(); if (now - slotSaveT > 3000) { slotSaveT = now; saveGame(true); }
}
// 画面を閉じた時など：回っているリールをその場で止めて精算
function finishSlot() {
  const r = slotRun; if (!r) return;
  r.wait = 0; r.t = 1; r.reels.forEach((rl, i) => { if (rl.target == null) { const c0 = Math.ceil(rl.pos + 0.001); rl.target = c0 + slotDecide(r, i, c0); } rl.pos = rl.target; rl.done = true; });
  slotResult();
}
// 画面の文字だけ書き換える（回っている最中に作り直さない）
function slotDom(L) {
  const c = game.casino, set = (id, t) => { const e = document.getElementById(id); if (e) e.textContent = t; };
  set('slot-msg', L.smsg || (c.pend ? 'ボーナス当選中！ 7を狙え！' : 'レバーを引いて、ストップを好きな順に3回押そう'));
  set('slot-coins', `${c.coins}枚`); set('slot-coins-sub', `${c.coins}枚`);
  // v6a：現金に戻す金額と「〜相当」を、コインの増減と同時に更新する
  set('slot-coins-val', `（$${coinValue(c.coins).toLocaleString()}相当）`);
  const cb = document.querySelector('.modal:not(.under) [data-k=cash]'); if (cb) { cb.textContent = `コインを現金に戻す（$${coinValue(c.coins).toLocaleString()}）`; cb.classList.toggle('dis', !!slotRun || !c.coins); }
  set('slot-games', `ゲーム数 ${c.plays}　BB ${c.bb}回　RB ${c.rb}回`);
  const lv = document.querySelector('.modal:not(.under) [data-k=lever]');
  if (lv) lv.textContent = slotRun ? `ストップ（${slotRun.reels.filter(x => x.target == null).length}）` : c.replay ? 'レバー（リプレイ・無料）' : `MAX BET＆レバー（${SLOT.bet}枚）`;
  document.querySelectorAll('.modal:not(.under) .stop-btns .stop').forEach((b, k) => b.classList.toggle('off', !slotRun || slotRun.reels[k].target != null));
  const lamp = document.getElementById('slot-lamp-wrap'); if (lamp) lamp.classList.toggle('on', !!c.pend);
}
// ストップボタン（左・中・右）。押した瞬間に止める（タッチの遅れを出さない）
function stopBtn(k) {
  const b = h('button', { class: 'btn f stop off', 'data-k': 'stop' + k, tabindex: '-1', type: 'button' }, ['左', '中', '右'][k], h('small', null, 'STOP'));
  b.addEventListener('pointerdown', e => { e.preventDefault(); b._pd = performance.now(); stopReel(k); });
  b.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); if (performance.now() - (b._pd || 0) < 700) return; stopReel(k); });
  return b;
}
function renderSlot(b, L) {
  const c = ensureCasino();
  const reels = h('canvas', { id: 'slot-reels', class: 'slot-reels', width: '176', height: '156' });
  reels.addEventListener('pointerdown', e => { e.preventDefault(); if (!slotRun) { slotLever(L); return; } const rc = reels.getBoundingClientRect(), i = clamp(Math.floor((e.clientX - rc.left) / rc.width * 3), 0, 2); stopReel(i); });
  const lamp = h('div', { class: 'slot-lamp-wrap' + (c.pend ? ' on' : ''), id: 'slot-lamp-wrap' }, h('canvas', { id: 'slot-lamp', width: '24', height: '24' }), h('div', { class: 'slot-lamp-lbl' }, 'BONUS'));
  // v8a：筐体（左：リールとストップ、右：名前・メッセージ・クレジット・レバー）と、横の操作（コイン・配当）に分ける。縦に並べた時は今までと同じ順番
  const side = h('div', { class: 'slot-side' }); L._side = side;
  const lay = h('div', { class: 'slot-layout' }); b.appendChild(lay);
  lay.appendChild(h('div', { class: 'jug-machine' },
    h('div', { class: 'jug-left' }, reels, h('div', { class: 'stop-btns' }, stopBtn(0), stopBtn(1), stopBtn(2))),
    h('div', { class: 'jug-right' },
    h('div', { class: 'jug-head' }, lamp, h('div', { class: 'jug-name' }, 'ルナ・サンライズ', h('small', null, '5ライン・3枚掛け'))),
    h('div', { class: 'slot-msg', id: 'slot-msg' }, ''),
    h('div', { class: 'jug-credit' }, 'クレジット ', h('b', { id: 'slot-coins' }, `${c.coins}枚`), h('span', { class: 'desc', id: 'slot-coins-val' }, `（$${coinValue(c.coins).toLocaleString()}相当）`)),
    h('div', { style: 'display:flex;justify-content:center;margin:6px 0 4px' }, btn('MAX BET＆レバー', () => slotLever(L), { key: 'lever', cls: 'primary big', silent: true })),
    h('div', { class: 'desc', id: 'slot-games', style: 'text-align:center' }, ''))));
  lay.appendChild(side);
  const busy = !!slotRun;
  side.appendChild(sec('コイン', h('div', { class: 'btns' },
    btn(`${fmt$(SLOT.coinCost)} → ${SLOT.coinRate}枚`, () => { if (slotRun) { sfx('error'); toast('回っている間はできません', 'bad'); return; } if (game.money < SLOT.coinCost) { sfx('error'); toast('所持金が足りません', 'bad'); return; } game.money -= SLOT.coinCost; c.coins += SLOT.coinRate; c.net -= SLOT.coinCost; game.stats.gamble = (game.stats.gamble || 0) - SLOT.coinCost; sfx('coin'); saveGame(true); UI.refresh(L); }, { key: 'xchg', cls: 'gold', disabled: busy, why: '回っている間はできません' }),
    btn(`コインを現金に戻す（$${coinValue(c.coins).toLocaleString()}）`, () => { if (slotRun) { sfx('error'); toast('回っている間はできません', 'bad'); return; } const v = coinValue(c.coins); if (!c.coins) { sfx('error'); toast('コインがありません', 'bad'); return; } game.money += v; c.net += v; game.stats.gamble = (game.stats.gamble || 0) + v; toast(`コイン${c.coins}枚を ${fmt$(v)} に戻した`, 'money'); c.coins = 0; sfx('coin'); saveGame(true); UI.refresh(L); }, { key: 'cash', cls: busy || !c.coins ? 'dis' : '' }),   // v6a：使えるかどうかは押した時に判定（表示は slotDom で同期）
    btn(`目押しアシスト：${settings.slotAssist ? 'ON' : 'OFF'}`, () => { if (slotRun) { sfx('error'); toast('回っている間は変えられません', 'bad'); return; } settings.slotAssist = !settings.slotAssist; saveSettings(); UI.refresh(L); }, { key: 'assist', cls: settings.slotAssist ? 'gold' : '', disabled: busy, why: '回っている間は変えられません' })),
    h('p', { class: 'note' }, settings.slotAssist ? 'アシストON：ランプが点いている時は、ストップを押すだけで7が揃います。' : 'アシストOFF：7が枠の中に来る少し前にストップを押そう（4コマまで引き込みます）。'),
    h('p', { class: 'note' }, `ストップは左・中・右を好きな順番で押せます（${Input.mode === 'key' ? '1・2・3キーでも止められます。' : 'リールを直接タップしても止まります。'}）`)));
  const sym = k => h('img', { class: 'icon sm', src: SLOT_URL[k], alt: SLOT.name[k] });
  side.appendChild(sec('配当（5ライン：上段・中段・下段・斜め2本）', h('div', { class: 'paytable' },
    h('span', null, sym('seven'), sym('seven'), sym('seven'), ` BB ${SLOT.pay.BB}枚`), h('span', null, sym('seven'), sym('seven'), sym('bar'), ` RB ${SLOT.pay.RB}枚`),
    h('span', null, sym('bell'), `×3 ${SLOT.pay.bell}枚`), h('span', null, sym('grape'), `×3 ${SLOT.pay.grape}枚`), h('span', null, sym('cherry'), `（左リール） ${SLOT.pay.cherry}枚`), h('span', null, sym('replay'), '×3 もう1回無料'))));
  setTimeout(() => { slotDom(L); drawSlotReels(); drawSlotLamp(); }, 0);
}
function drawSlotReels() {
  const cv = document.getElementById('slot-reels'); if (!cv || !game) return;
  const x = cv.getContext('2d'), c = game.casino, run = slotRun; x.imageSmoothingEnabled = false;
  x.fillStyle = '#140a1e'; x.fillRect(0, 0, cv.width, cv.height);
  for (let i = 0; i < 3; i++) {
    const st = SLOT.reels[i], N = st.length, pos = run ? run.reels[i].pos : c.reel[i], rx = 6 + i * 56, base = Math.floor(pos), fr = pos - base;
    x.fillStyle = '#fff8e8'; x.fillRect(rx, 6, 52, 144);
    x.save(); x.beginPath(); x.rect(rx, 6, 52, 144); x.clip();
    for (let k = -2; k <= 2; k++) { const j = base + k, sy = st[((j % N) + N) % N], y = 54 + (fr - k) * 48; x.drawImage(SLOT_CV[sy], rx + 2, Math.round(y), 48, 48); }
    const gr = x.createLinearGradient(0, 6, 0, 150); gr.addColorStop(0, 'rgba(20,10,30,0.35)'); gr.addColorStop(0.2, 'rgba(20,10,30,0)'); gr.addColorStop(0.8, 'rgba(20,10,30,0)'); gr.addColorStop(1, 'rgba(20,10,30,0.35)');
    x.fillStyle = gr; x.fillRect(rx, 6, 52, 144); x.restore();
    if (run && run.reels[i].done) { x.strokeStyle = '#f2c440'; x.lineWidth = 2; x.strokeRect(rx + 1, 7, 50, 142); }
  }
  // 5ラインの印（左右の三角＝上段・中段・下段、四隅の点＝斜めのライン）
  x.fillStyle = '#e8302a';
  for (const yy of [30, 78, 126]) for (const [lx, d] of [[1, 1], [175, -1]]) { x.beginPath(); x.moveTo(lx, yy - 5); x.lineTo(lx + 4 * d, yy); x.lineTo(lx, yy + 5); x.fill(); }
  x.fillStyle = '#f2c440'; for (const [px, py] of [[0, 4], [0, 149], [173, 4], [173, 149]]) x.fillRect(px, py, 3, 3);
  // 当たったライン（少しの間だけ表示）
  if (!run && c._win && c._win.length && performance.now() < (c._winT || 0)) {
    x.strokeStyle = 'rgba(242,196,64,0.95)'; x.lineWidth = 3;
    for (const li of c._win) {
      if (li === 'cherry') { x.strokeRect(7, 7, 50, 142); continue; }
      const rw = SLOT_LINES[li]; x.beginPath(); rw.forEach((row, k) => { const px = 32 + k * 56, py = 30 + row * 48; if (k) x.lineTo(px, py); else x.moveTo(px, py); }); x.stroke();
    }
  }
}
function drawSlotLamp() {
  const cv = document.getElementById('slot-lamp'); if (!cv || !game) return;
  const x = cv.getContext('2d'), on = !!game.casino.pend; x.clearRect(0, 0, 24, 24); x.imageSmoothingEnabled = false;
  x.drawImage(on ? (Math.floor(performance.now() / 180) % 2 ? LAMP_CV.on1 : LAMP_CV.on2) : LAMP_CV.off, 0, 0);
}
/* --- ルーレット（アメリカ式：0と00。37を00として扱う） --- */
const rouColor = n => n === 0 || n === 37 ? 'green' : ROU_RED.includes(n) ? 'red' : 'black';
const rouLabel = n => n === 37 ? '00' : String(n);
const ROU_NUM_MAX = 100;   // 数字1つに賭けられる上限
function renderRoulette(b, L) {
  const types = [['red', '赤（2倍）'], ['black', '黒（2倍）'], ['even', '偶数（2倍）'], ['odd', '奇数（2倍）'], ['num', '数字1つ（36倍）']], busy = !!rouRun;
  if (L.rouType === 'num' && L.bet > ROU_NUM_MAX) L.bet = ROU_NUM_MAX;
  const b0 = b, lay = h('div', { class: 'rou-layout' }), left = h('div', { class: 'rou-left' }), right = h('div', { class: 'rou-right' }); lay.appendChild(left); lay.appendChild(right); b0.appendChild(lay); L._side = right;   // v8a：横画面は左右に並べる
  b = left;
  b.appendChild(sec('かけ金', h('div', { class: 'preset-row' }, ...BETS.map(v => btn(fmt$(v), () => { L.bet = v; UI.refresh(L); }, { key: 'bet' + v, cls: L.bet === v ? 'on' : '', disabled: busy || (L.rouType === 'num' && v > ROU_NUM_MAX), why: busy ? '回っている間は変えられません' : `数字1つは${fmt$(ROU_NUM_MAX)}までです` })))));
  b.appendChild(sec('どこに賭ける？', h('div', { class: 'preset-row' }, ...types.map(([k, t]) => btn(t, () => { L.rouType = k; UI.refresh(L); }, { key: 'rt-' + k, cls: L.rouType === k ? 'on' : '', disabled: busy, why: '回っている間は変えられません' })))));
  if (L.rouType === 'num') b.appendChild(stepper('rnum', '数字（0・00・1〜36）', rouLabel(L.rouNum), () => { if (!rouRun) { L.rouNum = (L.rouNum + 37) % 38; UI.refresh(L); } }, () => { if (!rouRun) { L.rouNum = (L.rouNum + 1) % 38; UI.refresh(L); } }));
  const n = rouRun ? rouRun.show : L.rouLast;
  b = right;
  b.appendChild(h('div', { class: 'rou-ball ' + (n == null ? '' : rouColor(n)), id: 'rou-ball' }, n == null ? '?' : rouLabel(n)));
  b.appendChild(h('div', { class: 'slot-msg', id: 'rou-msg' }, rouRun ? '回っています……' : (L.rmsg || '0と00は親の総取り（どの賭けも負け）')));
  b.appendChild(h('div', { style: 'display:flex;justify-content:center;margin:6px 0' }, btn(rouRun ? '……' : `回す（${fmt$(L.bet)}）`, () => rouSpin(L), { key: 'spin', cls: 'primary big', disabled: busy, why: '回っています', silent: true })));
}
function rouSpin(L) {
  const g = game; if (rouRun) return;
  if (L.rouType === 'num' && L.bet > ROU_NUM_MAX) L.bet = ROU_NUM_MAX;
  if (g.money < L.bet) { sfx('error'); toast('所持金が足りません', 'bad'); return; }
  g.money -= L.bet; sfx('ui'); L.rmsg = '';
  rouRun = { L, bet: L.bet, type: L.rouType, num: L.rouNum, res: Math.floor(Math.random() * 38), show: 0, t: 0 };
  rouRun.iv = setInterval(() => {
    const r = rouRun; if (!r) return; r.t += 70; r.show = Math.floor(Math.random() * 38);
    const el = document.getElementById('rou-ball'); if (el) { el.textContent = rouLabel(r.show); el.className = 'rou-ball ' + rouColor(r.show); }
    if (r.t % 210 === 0) sfx('talk');
    if (r.t >= 1600) finishRoulette();
  }, 70);
  UI.refresh(L);
}
/* --- v8c：ヤドカリレース（8匹のうち、1着を当てる単勝。仮の内容） --- */
const RACE_COL = ['#e84a4a', '#4a8ae8', '#f2c440', '#5ac85a', '#c060e0', '#f08a3c', '#40d0d0', '#f0f0f0'];
const RACE_NAME = ['アカヤド', 'アオヤド', 'キイヤド', 'ミドヤド', 'ムラヤド', 'ダイヤド', 'ミズヤド', 'シロヤド'];
// 次のレースの調子とオッズ。オッズ＝0.85÷勝つ確率（長く続けると負ける）
function raceCard(L) {
  if (!L.rc || L.rc.done) {
    const w = Array.from({ length: 8 }, () => Math.pow(0.6 + Math.random() * 0.9, 3)), s = w.reduce((a, b) => a + b, 0), p = w.map(v => v / s);
    L.rc = { p, odds: p.map(v => Math.max(1.4, Math.floor(0.85 / v * 10) / 10)), done: false, no: (L.rc ? L.rc.no : 0) + 1 };
  }
  return L.rc;
}
function renderRace(b, L) {
  const rc = raceCard(L), busy = !!raceRun; if (L.rcPick == null) L.rcPick = 0;
  const lay = h('div', { class: 'rou-layout race-layout' }), left = h('div', { class: 'rou-left' }), right = h('div', { class: 'rou-right' }); lay.appendChild(left); lay.appendChild(right); b.appendChild(lay); L._side = right;
  left.appendChild(sec(`第${rc.no}レース：1着を当てよう（単勝）`, h('div', { class: 'race-list' }, ...RACE_NAME.map((n, i) => btn(h('span', { class: 'race-pick' }, h('i', { style: `background:${RACE_COL[i]}` }), `${i + 1} ${n}`, h('b', null, `${rc.odds[i].toFixed(1)}倍`)), () => { L.rcPick = i; UI.refresh(L); }, { key: 'rc-' + i, cls: L.rcPick === i ? 'on' : '', disabled: busy, why: 'レース中は変えられません' })))));
  left.appendChild(sec('かけ金', h('div', { class: 'preset-row' }, ...BETS.map(v => btn(fmt$(v), () => { L.bet = v; UI.refresh(L); }, { key: 'rbet' + v, cls: L.bet === v ? 'on' : '', disabled: busy, why: 'レース中は変えられません' })))));
  const cv = h('canvas', { class: 'race-cv', id: 'race-cv', width: 224, height: 140 }); right.appendChild(cv);
  right.appendChild(h('div', { class: 'slot-msg', id: 'race-msg' }, raceRun ? 'レース中……' : (L.rcmsg || `${L.rcPick + 1}番 ${RACE_NAME[L.rcPick]}に賭ける（当たれば${fmt$(Math.floor(L.bet * rc.odds[L.rcPick]))}）`)));
  right.appendChild(h('div', { style: 'display:flex;justify-content:center;margin:6px 0' }, btn(raceRun ? '……' : `スタート（${fmt$(L.bet)}）`, () => raceStart(L), { key: 'rstart', cls: 'primary big', disabled: busy, why: 'レース中です', silent: true })));
  setTimeout(() => drawRace(raceRun ? raceRun : { pos: L.rcLast || null, win: L.rcWin }), 0);
}
function raceStart(L) {
  const g = game, rc = raceCard(L); if (raceRun) return;
  if (g.money < L.bet) { sfx('error'); toast('所持金が足りません', 'bad'); return; }
  g.money -= L.bet; sfx('ui'); L.rcmsg = '';
  const win = (() => { let r = Math.random(); for (let i = 0; i < 8; i++) { r -= rc.p[i]; if (r < 0) return i; } return 7; })();
  const T0 = rnd(7.5, 9), T = Array.from({ length: 8 }, (_, i) => i === win ? T0 : T0 + rnd(0.2, 2.6));
  const wv = Array.from({ length: 8 }, () => [rnd(2, 5), rnd(0, 6)]);
  raceRun = { L, bet: L.bet, pick: L.rcPick, odds: rc.odds[L.rcPick], win, T, wv, t: 0, last: performance.now(), pos: new Array(8).fill(0) };
  const step = () => {
    const r = raceRun; if (!r) return; const now = performance.now(); r.t += Math.min(0.05, (now - r.last) / 1000); r.last = now;
    for (let i = 0; i < 8; i++) { const k = r.t / r.T[i], base = Math.min(1, k); r.pos[i] = clamp(base + 0.06 * Math.sin(r.t * r.wv[i][0] + r.wv[i][1]) * Math.min(1, r.t) * (1 - base), 0, 1); }
    drawRace(r); if (Math.floor(r.t * 4) !== Math.floor((r.t - 0.02) * 4)) sfx('talk');
    if (r.t >= r.T[r.win] + 1.2) { finishRace(); return; }
    r.raf = requestAnimationFrame(step);
  };
  UI.refresh(L); raceRun.raf = requestAnimationFrame(step);
}
function finishRace(instant) {
  if (!raceRun) return;
  const r = raceRun; cancelAnimationFrame(r.raf); raceRun = null;
  const hit = r.pick === r.win, win = hit ? Math.floor(r.bet * r.odds) : 0;
  game.money += win; gambleLog(r.bet, win);
  r.L.rcLast = r.T.map((t, i) => i === r.win ? 1 : clamp((r.T[r.win]) / t, 0, 0.98)); r.L.rcWin = r.win; r.L.rc.done = true;
  r.L.rcmsg = `1着は ${r.win + 1}番 ${RACE_NAME[r.win]}！… ` + (hit ? `${fmt$(win)} 獲得！` : 'はずれ');
  if (!instant) sfx(hit ? (r.odds >= 5 ? 'unlock' : 'coin') : 'error');
  saveGame(true);
  if (UI.top() === r.L) UI.refresh(r.L);
}
// コース：8レーン。左がスタート、右がゴール。ヤドカリは番号の色の貝
function drawRace(r) {
  const cv = document.getElementById('race-cv'); if (!cv) return; const x = cv.getContext('2d'); x.imageSmoothingEnabled = false;
  const W = cv.width, H = cv.height, lane = 16, top = 6, x0 = 18, x1 = W - 20;
  x.fillStyle = '#e8d8a0'; x.fillRect(0, 0, W, H);
  for (let i = 0; i < 8; i++) { x.fillStyle = i % 2 ? '#e0cf92' : '#efe2b0'; x.fillRect(0, top + i * lane, W, lane); x.fillStyle = RACE_COL[i]; x.fillRect(2, top + i * lane + 4, 10, 8); x.fillStyle = i === 7 ? '#333' : '#fff'; x.font = 'bold 8px sans-serif'; x.fillText(String(i + 1), 4, top + i * lane + 11); }
  x.fillStyle = '#ffffff'; x.fillRect(x0 - 2, top, 2, lane * 8);
  for (let y = top; y < top + lane * 8; y += 4) { x.fillStyle = (y / 4) % 2 ? '#1a1a1a' : '#ffffff'; x.fillRect(x1 + 6, y, 4, 4); x.fillStyle = (y / 4) % 2 ? '#ffffff' : '#1a1a1a'; x.fillRect(x1 + 10, y, 4, 4); }
  const pos = r && r.pos ? r.pos : new Array(8).fill(0), t = r && r.t ? r.t : 0;
  for (let i = 0; i < 8; i++) {
    const px = Math.round(x0 + pos[i] * (x1 - x0)), py = top + i * lane + 3, f = Math.floor(t * 10 + i) % 2;
    x.fillStyle = '#c0402e'; x.fillRect(px + 8, py + 8 - f, 2, 2); x.fillRect(px + 2, py + 9 + f - 1, 2, 2); x.fillRect(px + 10, py + 5, 3, 3);
    x.fillStyle = RACE_COL[i]; x.beginPath(); x.ellipse(px + 5, py + 5, 5, 4.4, 0, 0, Math.PI * 2); x.fill();
    x.fillStyle = 'rgba(255,255,255,0.45)'; x.fillRect(px + 3, py + 2, 3, 2); x.fillStyle = 'rgba(0,0,0,0.25)'; x.fillRect(px + 5, py + 5, 2, 2);
    x.fillStyle = '#1a1a1a'; x.fillRect(px + 12, py + 3, 1, 1);
  }
  if (r && r.win != null && !raceRun) { const py = top + r.win * lane; x.strokeStyle = '#d82a2a'; x.lineWidth = 2; x.strokeRect(1, py + 1, W - 2, lane - 2); }
}
function finishRoulette() {
  if (!rouRun) return;
  const r = rouRun, n = r.res; clearInterval(r.iv); rouRun = null;
  const zero = n === 0 || n === 37;
  const hit = r.type === 'num' ? n === r.num : zero ? false : r.type === 'red' ? rouColor(n) === 'red' : r.type === 'black' ? rouColor(n) === 'black' : r.type === 'even' ? n % 2 === 0 : n % 2 === 1;
  const win = hit ? r.bet * (r.type === 'num' ? 36 : 2) : 0;
  game.money += win; gambleLog(r.bet, win); r.L.rouLast = n;
  r.L.rmsg = `${rouLabel(n)}（${{ red: '赤', black: '黒', green: '緑' }[rouColor(n)]}）… ` + (win ? `${fmt$(win)} 獲得！` : 'はずれ');
  sfx(win ? (r.type === 'num' ? 'unlock' : 'coin') : 'error');
  saveGame(true);   // 結果ごとに保存（再読み込みで取り消せない）
  if (UI.top() === r.L) UI.refresh(r.L);
}
// ゼニ丸の倍々チャンス（ゼニ丸の画面の「勝負」タブ）
function renderZeniBet(b, L) {
  const g = game;
  b.appendChild(h('div', { class: 'zeni-say' }, ...TALK.zeniBet.map(l => h('p', null, l[1]))));
  b.appendChild(h('p', { class: 'note', style: 'color:var(--text)' }, `素材を1種類まるごと賭けて勝負！ 勝てば査定額の${ZENI_BET.up}倍、負ければ${Math.round(ZENI_BET.down * 10)}割で買い取られます（1日1回、査定${fmt$(ZENI_BET.max)}まで）。`));
  if (L.zmsg) b.appendChild(h('div', { class: 'slot-msg' }, L.zmsg, settings.zeniTr ? h('div', { class: 'zeni-tr' }, `（${zeniTr(L.zmsg)}）`) : null));   // v8e：ゼニ丸翻訳
  if (g.flags.zeniDay === g.day) { b.appendChild(h('p', { class: 'note warn' }, '今日の勝負はもう終わりました。また明日。')); return; }
  const ids = sortItems(Object.keys(g.inv).filter(k => ITEMS[k] && !ITEMS[k].key && !ITEMS[k].noEv && g.inv[k] > 0 && ITEMS[k].p > 0));   // v6b：黒い宝玉は勝負の対象外
  if (!ids.length) { b.appendChild(h('p', { class: 'note' }, '賭けられる物を持っていません。')); return; }
  for (const id of ids) {
    const n = g.inv[id], val = sellEstimate(id, n), ok = val <= ZENI_BET.max;
    b.appendChild(h('div', { class: 'row-item' }, icon(id), h('div', { class: 'grow' }, h('div', { class: 'name' }, `${ITEMS[id].n} ×${n}`), h('div', { class: 'desc' }, `査定 ${fmt$(val)} → 勝ち ${fmt$(Math.round(val * ZENI_BET.up))}／負け ${fmt$(Math.round(val * ZENI_BET.down))}`)),
      h('div', { class: 'btns' }, btn('勝負する', () => confirmBox(`${ITEMS[id].n}×${n}（査定${fmt$(val)}）を賭けますか？`, () => zeniGamble(id, L), { yes: '勝負！', danger: true }), { key: 'zb-' + id, cls: ok ? 'gold' : '', disabled: !ok, why: '査定額が高すぎて受けられません' }))));
  }
}
function zeniGamble(id, L) {
  const g = game, n = g.inv[id] || 0; if (!n || g.flags.zeniDay === g.day) return;
  const val = sellEstimate(id, n), it = ITEMS[id], win = Math.random() < ZENI_BET.win, pay = Math.round(val * (win ? ZENI_BET.up : ZENI_BET.down));
  let m = g.market.m[id] != null ? g.market.m[id] : 1; g.market.m[id] = Math.max(0.3, m - DROP[it.c] * n);
  takeItem(id, n); g.money += pay; g.stats.earned += pay; g.stats.sold += n; g.flags.zeniDay = g.day; gambleLog(val, pay);
  L.zmsg = win ? `ピピーッ！ アタリ！ ${fmt$(pay)} デ買イ取リマス！` : `ザンネン……ハズレ。${fmt$(pay)} デ買イ叩キマス。ゼニ！`;
  sfx(win ? 'unlock' : 'error'); toast(`${it.n}×${n}：${win ? '勝ち' : '負け'}（${fmt$(pay)}）`, win ? 'money' : 'bad');
  saveGame(true); if (UI.top() === L) UI.refresh(L);
}
// 寝床：眠る・回収
function openBed(o) {
  UI.open({ live: true, render: (el, L) => el.appendChild(windowEl(L, { title: '寝床', cls: 'small', body: b => {
    b.appendChild(h('p', { class: 'note', style: 'color:var(--text)' }, isNight() || hourOf(game.time) >= 17 ? '朝までぐっすり眠れそうだ。' : 'まだ明るい。夕方（17時）から眠れる。'));
    b.appendChild(h('div', { class: 'btns', style: 'margin-top:8px' }, btn('朝まで眠る', () => trySleep(), { key: 'sleep', cls: 'primary' }), pickupBtn(o)));
  } })) });
}
// チェスト（v6.2：8枠）：押した枠を反対側へ移す
function transferSlot(arr, i, other, N) {
  if (arr[i] && arr[i].eq) { sfx('error'); toast('装備中の防具は、外してからしまおう', 'bad'); return false; }   // v6b
  for (let guard = 0; guard < 40 && arr[i]; guard++) {
    const a = arr[i]; let j = -1;
    if (!isTool(a.id)) j = other.findIndex((x, k) => k < N && x && x.id === a.id && x.n < stackOf(x.id));
    if (j < 0) j = other.findIndex((x, k) => k < N && !x);
    if (j < 0) return false;
    moveSlot(arr, i, other, j);
  }
  return true;
}
// v8b：横にとなり合ったチェストは、2つで「ラージチェスト」（16枠）。3つ以上並んだら左から2つずつ
function chestPartner(m, o) {
  if (!m || !o || o.t !== 'chest') return null;
  const cs = m.objs.filter(q => q.t === 'chest' && q.y === o.y).sort((a, b) => a.x - b.x);
  for (let i = 0; i < cs.length;) { const a = cs[i], b = cs[i + 1]; if (b && b.x === a.x + 1) { if (a === o || b === o) return { l: a, r: b }; i += 2; } else i++; }
  return null;
}
// ラージチェストの画面は、2つの中身をつないだ16枠を使い、変わったら左右のチェストへ書き戻す
function chestSync(L) { const c = L.chest; if (c && c._pr) { c._pr.l.slots = c.slots.slice(0, 8); c._pr.r.slots = c.slots.slice(8, 16); } }
function openChest(o) {
  o.slots = Array.isArray(o.slots) ? o.slots : []; while (o.slots.length < 8) o.slots.push(null);   // v6.2：6枠→8枠（古いチェストも広げる）
  sfx('door');
  UI.open({ live: true, chest: o, onClose: () => { chestSync(UI.top() && UI.top().chest ? UI.top() : { chest: null }); saveGame(true); }, render: (el, L) => {
    chestSync(L); { const pr = chestPartner(curMap(), o); for (const c of pr ? [pr.l, pr.r] : []) { c.slots = Array.isArray(c.slots) ? c.slots : []; while (c.slots.length < 8) c.slots.push(null); } L.chest = pr ? { slots: pr.l.slots.concat(pr.r.slots), _pr: pr } : o; }   // v8b
    const box = L.chest, big = !!box._pr;
    el.appendChild(windowEl(L, { title: big ? 'ラージチェスト' : 'チェスト', sub: statusSub(), body: b => {
    const hs = CONFIG.hotSize, N = slotCount();
    const cell = (arr, i, key, other, ON) => {
      const sl = arr[i], hb = arr === game.slots && i < hs;
      const c = h('button', { class: 'islot f' + (hb ? ' hb' : ''), 'data-k': key + i, tabindex: '-1', type: 'button' }, hb ? h('span', { class: 'hn' }, String(i + 1)) : null, sl ? icon(sl.id) : null, sl && sl.n > 1 ? h('span', { class: 'hc' }, String(sl.n)) : null,
        sl && isTool(sl.id) && TOOLS[sl.id].dur ? h('span', { class: 'dbar' }, h('i', { style: `width:${Math.round(sl.dur / TOOLS[sl.id].dur * 100)}%;background:${durColor(sl.dur / TOOLS[sl.id].dur)}` })) : null);
      c.addEventListener('click', e => { e.preventDefault(); if (dragJustEnded()) return; L.focusKey = key + i; if (!arr[i]) return; const done = transferSlot(arr, i, other, ON); syncInv(); chestSync(L); if (!done) { sfx('error'); toast('入れる場所がありません', 'bad'); } else sfx('pick'); UI.refresh(L); });
      slotDnD(c, L, arr === game.slots ? 'inv' : 'chest', i);
      return c;
    };
    const b0 = b, cols = h('div', { class: 'two-cols chest-cols' }), cA = h('div', { class: 'col chest-l' }), cB = h('div', { class: 'col' }); cols.appendChild(cA); cols.appendChild(cB); b0.appendChild(cols); b = cA;   // v8a：スマホの横画面は「チェスト」と「持ち物」を左右に並べる
    b.appendChild(sec(`${big ? 'ラージチェスト' : 'チェスト'}の中（${box.slots.length}枠）`, h('div', { class: 'slot-row8' + (big ? ' big' : '') }, ...box.slots.map((_, i) => cell(box.slots, i, 'ch-', game.slots, N)))));
    b = cB;
    const rows = h('div', { class: 'slot-area' });
    for (let r = hs; r < N; r += 8) rows.appendChild(h('div', { class: 'slot-row8' }, ...Array.from({ length: Math.min(8, N - r) }, (_, k) => cell(game.slots, r + k, 'pl-', box.slots, box.slots.length))));
    b.appendChild(sec('持ち物', rows));
    b.appendChild(sec('アイテムバー', h('div', { class: 'slot-row8 hbrow' }, ...Array.from({ length: hs }, (_, k) => cell(game.slots, k, 'pl-', box.slots, box.slots.length)))));
    b = cB;   // v8b：説明は右の列に（スマホの横画面で1画面に収める）
    b.appendChild(h('p', { class: 'note' }, `枠を押すと、反対側（チェスト⇔持ち物）へ移します。${Input.mode === 'touch' ? '長押し' : 'ドラッグ'}で好きな枠へ動かすこともできます。道具も入れられます。${big ? '' : 'となりにもう1つ置くと、ラージチェスト（16枠）になります。'}`));
    if (!box.slots.some(Boolean)) b.appendChild(h('div', { style: 'margin-top:6px' }, pickupBtn(o)));
  } })); } });
}
// 眠る（寝床・小屋）
function trySleep() {
  if (!(isNight() || hourOf(game.time) >= 17)) { toast('まだ明るい。夕方（17時）から眠れる'); sfx('error'); return; }
  if (enemyNear(7 * 16)) { toast('近くに危険な生き物がいる。眠れない', 'bad'); sfx('error'); return; }
  confirmBox('朝まで眠りますか？\n（体力が回復します。空腹と渇きは少し減ります）', () => { UI.closeAll(); sleep(); }, { yes: '眠る' });
}
/* 古い小屋：倉庫と休憩 */
const storeCount = () => Object.values(game.storage).reduce((a, b) => a + b, 0);
function openHut() {
  sfx('door');
  UI.open({ tab: 'store', live: true, onClose: () => saveGame(true), render: (el, L) => el.appendChild(windowEl(L, {
    title: '古い小屋', sub: statusSub(h('span', null, '倉庫 ', h('b', null, `${storeCount()}/${STORAGE_CAP}`))),
    tabs: [{ id: 'store', label: '倉庫' }, { id: 'rest', label: '休む' }],
    body: b => (L.tab === 'store' ? renderStore : renderRest)(b, L),
  })) });
}
function storeMove(id, n, toStore) {
  if (toStore) {
    n = Math.min(n, game.inv[id] || 0, STORAGE_CAP - storeCount());
    if (n <= 0) { sfx('error'); toast(storeCount() >= STORAGE_CAP ? '倉庫がいっぱいです' : '持っていません', 'bad'); return; }
    takeItem(id, n); game.storage[id] = (game.storage[id] || 0) + n;
  } else {
    n = Math.min(n, game.storage[id] || 0); const a = addItem(id, n);
    if (a <= 0) { sfx('error'); toast('持ち物がいっぱいです', 'bad'); return; }
    game.storage[id] -= a; if (game.storage[id] <= 0) delete game.storage[id];
  }
  sfx('pick');
}
function renderStore(b, L) {
  const row = (id, n, toStore) => h('div', { class: 'row-item' }, icon(id), h('div', { class: 'grow' }, h('div', { class: 'name' }, `${ITEMS[id].n} ×${n}`)),
    h('div', { class: 'btns' }, btn(toStore ? '1個しまう' : '1個出す', () => { storeMove(id, 1, toStore); UI.refresh(L); }, { key: (toStore ? 'in1-' : 'out1-') + id, silent: true }),
      btn(toStore ? '全部しまう' : '全部出す', () => { storeMove(id, 9999, toStore); UI.refresh(L); }, { key: (toStore ? 'inA-' : 'outA-') + id, silent: true, cls: 'primary' })));
  const inv = sortItems(Object.keys(game.inv).filter(k => ITEMS[k] && !ITEMS[k].key && game.inv[k] > 0));
  const st = sortItems(Object.keys(game.storage).filter(k => ITEMS[k] && game.storage[k] > 0));
  b.appendChild(h('p', { class: 'note' }, `倉庫の中身は持ち物の数に入りません（最大${STORAGE_CAP}個）。倒れても失いません。`));
  b.appendChild(sec('倉庫の中', st.length ? h('div', null, ...st.map(k => row(k, game.storage[k], false))) : h('p', { class: 'note' }, '空っぽです。')));
  b.appendChild(sec('持ち物', inv.length ? h('div', null, ...inv.map(k => row(k, game.inv[k], true))) : h('p', { class: 'note' }, '持ち物はありません。')));
}
function renderRest(b) {
  b.appendChild(h('p', { class: 'note', style: 'color:var(--text);font-size:14px' }, '小屋のそばでは雨に濡れず、夜も冷えません。焚き火と同じように、獣も近寄ってきません。'));
  b.appendChild(h('p', { class: 'note' }, '夕方（17時）から、朝までぐっすり眠れます。'));
  b.appendChild(h('div', { style: 'margin-top:10px' }, btn('朝まで眠る', () => trySleep(), { key: 'sleep', cls: 'primary' })));
}
function buildRaft() {
  if (!hasAll(RAFT_COST)) return;
  payCost(RAFT_COST); game.raftBuilt = true; game.stats.crafted++; sfx('craft');
  const r = maps.island.lm.raft; burst(r.x * 16 + 8, r.y * 16 + 20, P.woodL, 16);
  queueTalk(TALK.raftBuilt); saveGame(true);
}
function depart() {
  if (voyageFood() < 3) { sfx('error'); toast('航海用の食料が3個必要です', 'bad'); return; }
  const go = () => {
    let need = 3; for (const k of VOYAGE_FOOD) { const n = Math.min(need, game.inv[k] || 0); if (n) { takeItem(k, n); need -= n; } }
    const led = has('ledger'), id = game.debt > 0 ? (led ? 'C' : 'E') : (led ? 'B' : 'A');   // v8f：A＝完済、B＝完済＋裏帳簿（TRUE）、C＝借金あり＋裏帳簿、E＝借金あり（黒い宝玉のエンディングは削除）
    UI.closeAll(); fade(() => endGame(id));
  };
  // v8e：嵐の日は出航できない（BAD END「嵐の海」は削除）
  if (game.weather === 'storm') { sfx('error'); toast('外は大嵐だ。嵐がおさまってから出航しよう', 'bad'); return; }
  if (game.debt > 0) confirmBox(`借金が ${fmt$(game.debt)} 残っています。\nこのまま夜逃げしますか？`, go, { yes: '夜逃げする', danger: true });
  else confirmBox('食料を3個積んで出航します。\nもう島には戻れません。よろしいですか？', go, { yes: '出航する' });
}
function sleep() {
  sfx('sleep'); stopFishing();
  fade(() => {
    const g = game; g.hp = Math.min(100, g.hp + 45); g.hunger = Math.max(5, g.hunger - 15); g.thirst = Math.max(5, g.thirst - 20); g.stamina = 100; g.exhaust = false; g.poison = 0;   // v6.1c：眠ると毒も治る
    newDay('sleep');
  }, () => { if (state.scene === 'play') toast('ぐっすり眠った。体力が回復した', 'good'); });
}
function faint() {
  if (state.faintLock) return; state.faintLock = true; if (UI.isOpen()) UI.closeAll(); sfx('hurt'); stopFishing(); cancelPlace(true);
  if (game.map === 'cave2') { bossRetry(); return; }   // v5：地下2階で倒れた時は、階段の前でやり直し（日付・持ち物はそのまま）
  if (game.mode === 'hard') { gameOver(); return; }
  fade(() => {
    const g = game, m = curMap(), [tx, ty] = playerTile();
    // 持ち物は倒れた場所に落とす（大切なもの・黄金の亀像は手元に残る）
    for (let i = 0; i < g.slots.length; i++) { const sl = g.slots[i]; if (!sl || isTool(sl.id)) continue; if (spawnDrop(m, tx, ty, sl.id, sl.n, 0, undefined, true)) g.slots[i] = null; }   // v6.2：倒れた時に落とした物は消えない
    if (g.off && !isTool(g.off.id) && spawnDrop(m, tx, ty, g.off.id, g.off.n, 0, undefined, true)) g.off = null;   // v6b：左手の回復アイテムも落とす
    syncInv();   // 道具・武器は手元に残る
    g.money = Math.floor(g.money * 0.9);
    g.map = 'island'; const s = maps.island.lm.spawn; player.x = s.x * 16 + 8; player.y = s.y * 16 + 12; player.dir = 0;
    g.hp = 40; g.hunger = Math.max(g.hunger, 35); g.thirst = Math.max(g.thirst, 35); g.stamina = 100; g.exhaust = false; g.sick = 0; g.poison = 0;   // v6.1c
    newDay('faint');
  }, () => { state.faintLock = false; if (state.scene === 'play') queueTalk(TALK.faint); });
}
// ハードモード：体力0でゲームオーバー（セーブは消さない）
function gameOver() {
  const g = game;
  fade(() => {
    state.scene = 'gameover'; state.faintLock = false; Dialog.active = false; $('dialog').classList.add('hidden'); UI.closeAll();
    $('hud').classList.add('hidden'); $('hint').classList.add('hidden'); updateTouchVisibility();
    UI.open({ cls: 'dark', onBack: () => {}, render: el => {
      el.appendChild(h('div', { class: 'ending' },
        h('div', { class: 'etype', style: 'color:var(--red)' }, 'GAME OVER'), h('div', { class: 'etitle' }, '力尽きた……'),
        h('p', { style: 'animation-delay:.3s' }, `${g.day}日目。${g.name}は、島で倒れたまま動けなくなった。`),
        h('p', { style: 'animation-delay:.9s' }, 'ハードモードでは、倒れるとその冒険は終わりです。\n「つづきから」で、最後にセーブした所からやり直せます。'),
        h('div', { style: 'opacity:0;animation:fadeIn .8s ease-out 1.4s forwards' }, btn('タイトルへ', () => showTitle(), { key: 'title', cls: 'primary' }))));
    } });
  });
}
function newDay(kind) {
  const g = game; g.day++; g.time = 0; state.warn = {}; state.mobs = []; state.mobT = 4;
  let interest = 0;
  if (g.debt > 0) { interest = Math.ceil(g.debt * g.contract.rate / 100); g.debt += interest; g.interestPaid += interest; if (interest > 0) logDebt('i'); }   // v7b：グラフ用に記録
  // 締め日のチェック（前日が締め日なら判定）
  const st = stagesOf(g.contract), stTalk = [];
  while (g.stageI < st.length && st[g.stageI].day <= g.day - 1) {
    const sg = st[g.stageI]; g.stageI++;
    if (g.debt <= 0) continue;
    if (g.repaid >= sg.need) stTalk.push(['same', `${sg.day}日目の締め日、累計 ${fmt$(sg.need)} の返済は確かに受け取ったぜ。……チッ、やるじゃねえか。`]);
    else {
      const pen = Math.ceil(g.debt * STAGE_PENALTY); g.debt += pen; g.penalty = (g.penalty || 0) + pen; logDebt('x');
      stTalk.push(['same', `${sg.day}日目の締め日だぜ、{name}。約束の累計 ${fmt$(sg.need)} に届いてねえな。`], ['same', `遅延損害金として ${fmt$(pen)} 上乗せだ。次の締め日は守れよ？`], ['sys', `借金に ${fmt$(pen)} が加算された。`]);
    }
  }
  if (g.debt > 0 && !g.contract.free && g.day > g.contract.days) { endGame('D'); return false; }   // v8f：回収の朝はD
  const prevW = g.weather; g.weather = rollWeather(prevW); g.wHalf = 0;
  g.surfD = g.day >= CONFIG.surface.from && !g.demo && chance(CONFIG.surface.p) ? g.day : 0;   // v8c：今夜、洞窟の魔物が地上に出るか
  regrowAll(); respawn(maps.island, false, prevW === 'storm');
  if (prevW === 'storm') setTimeout(() => { if (state.scene === 'play') toast('嵐のあと、浜辺にたくさんの物が流れ着いた'); }, 1800);
  for (const k in g.market.m) g.market.m[k] = lerp(g.market.m[k], 1, 0.5);
  rollMarketEvent();
  const left = g.contract.days - g.day + 1;
  toast(`${g.day}日目の朝（${WEATHER[g.weather].n}）` + (interest ? `　利息 ${fmt$(interest)} が加算された` : ''), interest ? 'bad' : '');
  if (stTalk.length) queueTalk(stTalk);
  const ev = g.market.ev; if (ev) setTimeout(() => toast(`本日の特需：${ITEMS[ev.up].n}　値崩れ：${ITEMS[ev.dn].n}`, 'money'), 900);
  if (g.debt > 0 && !g.contract.free) {
    const half = Math.ceil(g.contract.days / 2) + 1;
    if (left === 1) queueTalk(TALK.lastDay);
    else if (g.day === half && !g.flags.half) { g.flags.half = 1; queueTalk(repaidRatio() < 0.5 ? TALK.halfBad : TALK.halfGood); }
  }
  state.autosave = 0; saveGame(true);
  return true;
}
function rollWeather(prev) {
  const r = Math.random(); let w = r < 0.42 ? 'sun' : r < 0.65 ? 'cloud' : r < 0.83 ? 'rain' : r < 0.92 ? 'storm' : 'snow';   // v8c：雪（8%）
  if (w === 'storm' && prev === 'storm') w = 'rain';
  return w;
}
function regrowAll() {
  for (const k in maps) {
    const m = maps[k];
    for (const o of m.objs) {
      if (o.t === 'palm') o.n = Math.min(3, (o.n || 0) + 1);
      else if (o.t === 'bush') o.n = 1;
      else if (REVERT[o.t] && o.r && game.day >= o.r) {
        const to = REVERT[o.t];
        if (OBJ[to].block && k === game.map && Math.floor(player.x / 16) === o.x && Math.floor((player.y - 3) / 16) === o.y) continue;
        o.t = to; o.r = 0;
      }
    }
  }
}
function respawn(m, initial, bonus) {
  const k = m.W * m.H > 5000 ? 1.9 : 1, L = m.spawn, want = { pebble: Math.round(22 * k), twig: Math.round(14 * k), driftwood: Math.round((7 + (bonus ? 6 : 0)) * k), shell: Math.round(9 * k), scrap: Math.round(3 * k), crate: Math.round((2 + (bonus ? 1 : 0)) * k) };   // v6c：広い島は約1.9倍
  const cnt = {}; for (const o of m.objs) cnt[o.t] = (cnt[o.t] || 0) + 1;
  const ptx = Math.floor(player.x / 16), pty = Math.floor(player.y / 16);
  const place = (type, list, n, blocking) => {
    for (let i = 0; i < n; i++) for (let a = 0; a < 40; a++) {
      const [x, y] = list[Math.floor(Math.random() * list.length)];
      if (objAt(m, x, y)) continue; if (blocking && Math.abs(x - ptx) <= 2 && Math.abs(y - pty) <= 2) continue;
      addObj(m, { t: type, x, y }); break;
    }
  };
  place('pebble', L.land, Math.max(0, want.pebble - (cnt.pebble || 0)), false);
  place('twig', L.land, Math.max(0, want.twig - (cnt.twig || 0)), false);
  place('driftwood', L.shore, Math.max(0, want.driftwood - (cnt.driftwood || 0)), false);
  place('shell', L.sand, Math.max(0, want.shell - (cnt.shell || 0)), false);
  place('scrap', L.wreck.length ? L.wreck : L.sand, Math.max(0, want.scrap - (cnt.scrap || 0)), true);
  place('crate', L.shore, Math.min(initial || bonus ? 2 : 1, Math.max(0, want.crate - (cnt.crate || 0))), true);
}

/* 釣り */
function startFishing(tg) {
  if (game.weather === 'storm') { sfx('error'); toast('嵐で海が荒れていて、釣りができない', 'bad'); return; }
  if (invFull()) { sfx('error'); toast('持ち物がいっぱいで釣りができない！', 'bad'); return; }
  const wm = game.weather === 'rain' ? 0.8 : game.weather === 'cloud' ? 0.9 : 1;
  state.fishing = { phase: 'wait', t: rnd(2.5, 5.5) * wm, bx: tg.tx * 16 + 8, by: tg.ty * 16 + 8, age: 0, landed: false };   // v7a：age＝投げてからの時間（見た目用）
  state.gather.o = null; sfx('ui');   // v7a：振りかぶって投げる → 着水で水しぶき（updateFishing）
}
const FISH_CAST = 0.45;   // v7a：竿を振って、うきが着水するまでの秒数（見た目だけ）
// v7a：竿の角度（投げる・構える・当たりで震える・引き上げる）
function rodAngle(rest) {
  const f = state.fishing;
  if (state.reel > 0) return rest - 0.9 * (state.reel / 0.3);
  if (!f) return rest;
  if (f.age < FISH_CAST) { const k = f.age / FISH_CAST; return k < 0.4 ? rest - (k / 0.4) * 1.2 : rest - 1.2 + ((k - 0.4) / 0.6) * 2.1; }
  return rest + 0.9 + (f.phase === 'bite' ? Math.sin(state.time * 40) * 0.12 : Math.sin(state.time * 2) * 0.03);
}
function stopFishing(why) { if (!state.fishing) return; state.fishing = null; if (why === 'moved') toast('釣りをやめた'); }
function updateFishing(dt) {
  const f = state.fishing; f.t -= dt; f.age = (f.age || 0) + dt;
  if (!f.landed && f.age >= FISH_CAST) { f.landed = true; sfx('splash'); burst(f.bx, f.by, '#dff3fa', 6); }   // v7a：着水
  if (Input.press('B')) { stopFishing(); return; }
  if (f.phase === 'wait') {
    if (Input.press('A')) { state.fishing = null; sfx('error'); burst(f.bx, f.by, '#dff3fa', 4); toast('早すぎた！ 魚に逃げられた', 'bad'); return; }
    if (f.t <= 0) { f.phase = 'bite'; f.t = 0.9; sfx('bite'); }
  } else if (f.phase === 'bite') {
    if (Input.press('A')) {
      state.fishing = null;
      // v4：先に魚を決めてから持ち物に入れる（v3は順番が逆でエラーになり、釣れていなかった）。入りきらない時は足元に置く（消えない）
      const id = rollFish();
      addItem(id, 1, true); useTool('rod'); game.stats.fish = (game.stats.fish || 0) + 1; game.stats.gathered++;
      sfx('catch'); floatText(player.x, player.y - 22, `+1 ${ITEMS[id].n}`, '#ffffff'); burst(f.bx, f.by, '#dff3fa', 10);
      state.fishFx = { t: 0, T: 0.55, x0: f.bx, y0: f.by, id }; state.reel = 0.3;   // v7a：竿を引き上げ、魚が弧を描いて手元へ
      return;
    }
    if (f.t <= 0) { state.fishing = null; burst(f.bx, f.by, '#dff3fa', 4); toast('逃げられた……'); }
  }
}

// 釣れる物：時間帯と天気で変わる
function rollFish() {
  const hr = hourOf(game.time) % 24, w = game.weather, wet = w === 'rain' || w === 'storm';
  const tbl = [['sardine', 28], ['fish', 30], ['bigfish', 10 * (wet ? 1.4 : w === 'cloud' ? 1.2 : 1)], ['katsuo', (hr >= 5 && hr < 9 ? 9 : 3) * (wet ? 1.4 : 1)],
    ['octopus', hr >= 19 || hr < 5 ? 12 : 3], ['fugu', 6], ['boot', 7 * (wet ? 1.3 : 1)], ['rareshell', 5]];
  let r = Math.random() * tbl.reduce((a, b) => a + b[1], 0);
  for (const [id, wt] of tbl) { r -= wt; if (r <= 0) return id; }
  return 'fish';
}
/* ---------- 生き物・敵 ---------- */
const MOBSPR = {};
// v6.1a：暗闇で光る目（絵の中の目の位置と色。p＝[x, y]）
const MOB_EYES = {
  dog:   { p: [[15, 3]], c: 'rgba(255,215,80,0.9)' },
  gcrab: { p: [[7, 3], [11, 3]], c: 'rgba(255,215,80,0.9)' },
  bat:   { p: [[6, 3], [8, 3]], c: 'rgba(255,96,96,0.95)' },
  scorpion: { p: [[15, 9]], c: 'rgba(255,90,60,0.95)' },   // v6.1c
};
function buildMobSprites() {
  const D = {
    crab: (g, f) => { g.e(7, 6, 5, 3, '#e0503a'); g.e(7, 5, 3.6, 1.6, '#f07a5a'); g.e(2, 3.4, 1.8, 1.6, '#e0503a'); g.e(12, 3.4, 1.8, 1.6, '#e0503a'); g.p(5, 3, '#ffffff'); g.p(9, 3, '#ffffff'); for (let i = 0; i < 3; i++) { g.p(2 + i * 2 + f, 9, '#a03020'); g.p(8 + i * 2 - f, 9, '#a03020'); } },
    gcrab: (g, f) => { g.e(9, 8, 7, 4, '#9a2a2a'); g.e(9, 7, 5, 2, '#c04a3a'); g.e(2.4, 4, 2.4, 2.2, '#b03a2a'); g.e(15.6, 4, 2.4, 2.2, '#b03a2a'); g.p(7, 3, '#ffd040'); g.p(11, 3, '#ffd040'); g.p(5, 5, '#6a1a1a'); g.p(13, 5, '#6a1a1a'); for (let i = 0; i < 3; i++) { g.p(3 + i * 2 + f, 12, '#6a1a1a'); g.p(10 + i * 2 - f, 12, '#6a1a1a'); } },
    rabbit: (g, f) => { g.e(5, 7, 4.6, 3.4, '#e8e0d0'); g.e(10, 5, 2.8, 2.4, '#e8e0d0'); g.r(9, 0, 1, 3, '#e8e0d0'); g.r(11, 0, 1, 3, '#e8e0d0'); g.p(11, 1, '#f0a0a0'); g.p(11, 5, P.ol); g.p(12, 6, '#f08090'); g.p(0, 6, '#ffffff'); g.r(f ? 3 : 6, 10, 2, 1, '#c8c0b0'); },
    grabbit: (g, f) => { const B = '#f2c440', H = '#fff3a0', S = '#c8961e'; g.e(5, 7, 4.6, 3.4, B); g.e(4, 6, 2.4, 1.4, H); g.e(10, 5, 2.8, 2.4, B); g.r(9, 0, 1, 3, B); g.r(11, 0, 1, 3, B); g.p(11, 1, '#ffd0a0'); g.p(11, 5, P.ol); g.p(12, 6, '#f08090'); g.p(0, 6, H); g.r(f ? 3 : 6, 10, 2, 1, S); },   // v7a：金のウサギ
    hermit: (g, f) => { g.e(8.5, 5, 5, 4.2, '#c8945a'); g.e(8.4, 4.2, 3.8, 2.8, '#e8b878'); g.e(8.8, 4.6, 1.8, 1.4, '#9a6a38'); g.p(9, 4, '#f4d0a0'); g.p(6, 3, '#f6dcb4'); g.e(3.2, 7, 2.2, 1.6, '#e0503a'); g.p(2, 6, '#f07a5a'); g.r(3, 3, 1, 3, '#e0503a'); g.p(3, 2, P.ol); for (let i = 0; i < 3; i++) g.p(4 + i * 3, 9 - ((i + f) % 2), '#c0402e'); },   // v8c：ヤドカリ
    pbear: (g, f) => { const W = '#f4f6fa', S = '#cfd6e0', D2 = '#9aa4b0'; const lg = f ? [[4, 12], [9, 13], [13, 12], [17, 13]] : [[5, 13], [9, 12], [14, 13], [17, 12]]; for (const [x, y] of lg) { g.r(x, y, 3, 3, S); g.r(x, y + 2, 3, 1, D2); } g.e(11, 9, 9, 5, S); g.e(11, 8, 8.4, 4.4, W); g.e(19.5, 7, 4, 3.4, W); g.e(17.5, 3.8, 1.4, 1.3, W); g.p(17, 4, S); g.e(22.8, 8, 1.6, 1.3, S); g.p(23, 7, '#1a1a1a'); g.p(21, 6, '#1a1a1a'); g.r(4, 7, 3, 1, '#ffffff'); },   // v8c：シロクマ
    bee: (g, f) => { const Y = '#f2c440', K = '#2a2018', W = 'rgba(220,240,255,0.85)'; g.e(5.5, 5.5, 3.4, 2.3, Y); g.r(4, 3, 1, 5, K); g.r(6, 3, 1, 5, K); g.e(9.6, 5, 1.8, 1.8, K); g.p(10, 4, '#ffffff'); g.p(1, 6, K); if (f) { g.e(5, 1.6, 1.8, 1.2, W); g.e(7.4, 1.6, 1.8, 1.2, W); } else { g.e(4.6, 2.6, 2.2, 0.9, W); g.e(7.6, 2.6, 2.2, 0.9, W); } },   // v7a：蜂（羽ばたく）
    dog: (g, f) => { g.r(3, 4, 10, 4, '#6e665e'); g.r(3, 4, 10, 1, '#8a827a'); g.e(14, 4, 2.8, 2.4, '#6e665e'); g.r(15, 5, 2, 2, '#5a524a'); g.r(13, 1, 2, 2, '#5a524a'); g.p(15, 3, '#ffd040'); g.l(3, 4, 0, 1, '#6e665e'); const c = '#5a524a'; if (f) { g.r(5, 8, 1, 3, c); g.r(10, 8, 1, 3, c); } else { g.r(4, 8, 1, 3, c); g.r(11, 8, 1, 3, c); } },
    // v6.1c：サソリ（右向き。尾を持ち上げて、毒針は黄色）
    scorpion: (g, f) => {
      const B = '#a85c2c', L = '#dc9450', D = '#5e2c12', Y = '#f6e070', R = '#ff4a30';
      for (let i = 0; i < 3; i++) { const lx = 6 + i * 3, o = (i + f) % 2; g.p(lx - o, 12, D); g.p(lx + 1 - o, 11, D); }   // 脚（交互に動く）
      g.e(9, 9.5, 4.4, 2, B); g.r(6, 8, 6, 1, L); g.p(7, 9, D); g.p(10, 9, D);   // 胴
      g.e(13.6, 9.5, 2.1, 1.8, B); g.p(14, 8, L); g.p(15, 9, R);   // 頭と目
      g.l(15, 8, 16, 6, B); g.e(17.3, 5.3, 1.6, 1.3, B); g.p(18, 4, L); g.p(19, 4, B); g.p(19, 6, B); g.p(17, 5, L);   // 上のはさみ
      g.l(15, 11, 16, 12, B); g.e(17.3, 11.6, 1.5, 1.1, B); g.p(19, 11, B); g.p(18, 11, L);   // 下のはさみ
      const s = f ? 1 : 0;   // 尾（少し揺れる）
      g.e(4.6, 9, 1.4, 1.4, B); g.e(3.6, 6.8, 1.3, 1.3, B); g.e(4, 4.6, 1.3, 1.3, B); g.e(5.6, 3 - s * 0.2, 1.3, 1.2, B); g.e(7.8, 2.4 - s * 0.2, 1.3, 1.1, B);
      g.p(4, 6, L); g.p(5, 3, L); g.p(8, 2, L);
      g.p(9 + s, 3, D); g.p(10 + s, 4, Y); g.p(10 + s, 5, Y);   // 毒針
    },
    bat: (g, f) => { g.e(7, 4, 2, 2.6, '#4a3058'); g.p(6, 1, '#4a3058'); g.p(8, 1, '#4a3058'); g.p(6, 3, '#ff4a4a'); g.p(8, 3, '#ff4a4a'); const c = '#5a3a6a'; if (f) { g.r(0, 4, 5, 3, c); g.r(10, 4, 5, 3, c); } else { g.r(0, 1, 5, 3, c); g.r(10, 1, 5, 3, c); } },
  };
  const SZ = { hermit: [14, 10], pbear: [24, 16], crab: [14, 10], gcrab: [18, 13], rabbit: [13, 11], dog: [17, 12], bat: [15, 9], scorpion: [21, 14], grabbit: [13, 11], bee: [12, 8] };   // v7a：金のウサギ・蜂   // v6.1c：サソリ
  for (const k in D) { const [w, hh] = SZ[k], fr = [0, 1].map(f => mk(w, hh, g => D[k](g, f))); MOBSPR[k] = [fr, fr.map(flipH)]; }
  buildCasinoSprites();
}
// 沈没船カジノとスロットの絵柄
const SLOT_URL = {}, SLOT_CV = {}, LAMP_CV = {};
function buildCasinoSprites() {
  const liner = lit => g => {
    g.r(2, 22, 44, 10, '#e8e4dc'); g.r(2, 22, 44, 1, '#ffffff'); g.r(2, 29, 44, 1, '#c03a3a'); g.r(2, 30, 44, 4, '#2a3a5a');
    g.r(0, 24, 2, 8, '#d8d4cc'); g.r(46, 24, 2, 6, '#d8d4cc');
    for (let x = 5; x < 44; x += 5) g.e(x + 0.5, 25.5, 1, 1, lit ? '#ffe08a' : '#4a5a6a');
    g.r(8, 12, 30, 10, '#f3efe6'); g.r(8, 12, 30, 1, '#ffffff'); g.r(8, 21, 30, 1, '#c8c0b0');
    for (let x = 10; x < 36; x += 4) g.r(x, 15, 2, 3, lit ? '#ffd860' : '#3a4a5a');
    g.r(31, 3, 6, 9, '#c03a3a'); g.r(31, 3, 6, 2, '#2a2a2a'); g.r(32, 6, 4, 1, '#e8e4dc');
    g.r(11, 6, 16, 5, '#2a1a3a'); for (let x = 12; x < 26; x += 2) g.p(x, 8, lit ? (x % 4 ? '#ff5ac8' : '#5ae0ff') : '#5a3a5a');
    g.l(20, 22, 23, 33, '#8a7a6a'); g.l(23, 33, 26, 30, '#8a7a6a'); g.p(14, 27, '#b0703a'); g.p(38, 26, '#b0703a'); g.p(40, 27, '#b0703a');
    g.r(3, 32, 3, 2, '#3a6a3a'); g.r(40, 32, 4, 2, '#3a6a3a');
  };
  SPR.liner = mk(48, 36, liner(false)); SPR.linerLit = mk(48, 36, liner(true));
  const px = (g, x0, y0, rows, col) => rows.forEach((row, y) => { for (let x = 0; x < row.length; x++) if (row[x] === '#') g.p(x0 + x, y0 + y, col); });
  const D = {
    seven: g => { g.r(3, 2, 10, 3, '#e8302a'); g.r(3, 2, 10, 1, '#ff8a80'); g.l(12, 5, 8, 14, '#e8302a'); g.l(11, 5, 7, 14, '#e8302a'); g.l(10, 5, 6, 14, '#b01c18'); g.p(4, 3, '#ffd0c8'); g.r(3, 5, 2, 1, '#b01c18'); },
    bar: g => { g.r(0, 4, 16, 8, '#1a1a26'); g.r(1, 5, 14, 6, '#34344a'); g.r(1, 5, 14, 1, '#4a4a66');
      px(g, 2, 6, ['##.', '#.#', '##.', '#.#', '##.'], '#f2c440'); px(g, 6, 6, ['.#.', '#.#', '###', '#.#', '#.#'], '#f2c440'); px(g, 10, 6, ['##.', '#.#', '##.', '#.#', '#.#'], '#f2c440'); },
    bell: g => { g.e(8, 8, 4.6, 5, '#f2c440'); g.r(3, 11, 10, 2, '#f2c440'); g.r(10, 6, 1, 5, '#c8961e'); g.p(8, 14, '#c8961e'); g.p(6, 6, '#fff3a0'); g.p(7, 5, '#fff3a0'); g.r(7, 2, 2, 2, '#c8961e'); },
    cherry: g => { g.e(5, 11, 2.8, 2.8, '#e0303a'); g.e(11, 11, 2.8, 2.8, '#e0303a'); g.l(5, 9, 9, 3, '#3a8a3a'); g.l(11, 9, 9, 3, '#3a8a3a'); g.r(9, 2, 3, 2, '#5ab05a'); g.p(4, 10, '#ff9aa0'); g.p(10, 10, '#ff9aa0'); },
    grape: g => { g.r(8, 1, 1, 3, '#5a3a1a'); g.e(11, 3, 2.4, 1.3, '#4aa040'); for (const [x, y] of [[6, 6], [10, 6], [4, 9], [8, 9], [12, 9], [6, 12], [10, 12], [8, 14.5]]) { g.e(x, y, 2, 2, '#7a3ab0'); g.p(x - 1, y - 1, '#c08ae8'); } },
    replay: g => { for (let a = 40; a <= 320; a += 8) { const t = a * Math.PI / 180; g.p(Math.round(8 + 5 * Math.cos(t)), Math.round(8 + 5 * Math.sin(t)), '#2a7ad8'); g.p(Math.round(8 + 4 * Math.cos(t)), Math.round(8 + 4 * Math.sin(t)), '#5aa8ff'); }
      g.r(11, 2, 4, 1, '#2a7ad8'); g.r(13, 2, 2, 4, '#2a7ad8'); g.p(12, 3, '#5aa8ff'); g.p(8, 8, '#e8f4ff'); },
  };
  for (const k in D) { SLOT_CV[k] = mk(16, 16, D[k]); SLOT_URL[k] = SLOT_CV[k].toDataURL(); }
  // ボーナスランプ（オリジナル：南国の太陽）
  const sun = (core, rim, ray, len) => g => { for (let a = 0; a < 360; a += 45) { const t = a * Math.PI / 180; g.l(12 + 7.5 * Math.cos(t), 12 + 7.5 * Math.sin(t), 12 + len * Math.cos(t), 12 + len * Math.sin(t), ray); } g.e(12, 12, 6.2, 6.2, rim); g.e(12, 12, 5, 5, core); g.e(10.5, 10.5, 1.6, 1.4, '#fff8d0'); };
  LAMP_CV.off = mk(24, 24, sun('#5a4a30', '#3e3222', '#2e2618', 10)); LAMP_CV.on1 = mk(24, 24, sun('#ffd84a', '#ff9a20', '#ffe080', 11)); LAMP_CV.on2 = mk(24, 24, sun('#fff07a', '#ffb43a', '#fff3b0', 10));
}
function mobBlocked(mp, d, x, y) {
  if (d.fly) { const v = tileAt(mp, Math.floor(x / 16), Math.floor(y / 16)); return v === T.CWALL || !WALK[v]; }
  for (const [ox, oy] of [[-4, -3], [4, -3], [-4, 0], [4, 0]]) if (isBlocked(mp, Math.floor((x + ox) / 16), Math.floor((y + oy - 0.01) / 16))) return true;
  return false;
}
function moveMob(mp, d, m, ax, ay) {
  if (ax) { if (!mobBlocked(mp, d, m.x + ax, m.y)) m.x += ax; else m.vx = -m.vx; }
  if (ay) { if (!mobBlocked(mp, d, m.x, m.y + ay)) m.y += ay; else m.vy = -m.vy; }
}
// v8c：重みつきで1つ選ぶ [[値, 重み], ...]
function pickW(list) { let s = 0; for (const [, w] of list) s += w; let r = Math.random() * s; for (const [v, w] of list) { if ((r -= w) < 0) return v; } return list[list.length - 1][0]; }
// v8c：時間帯が合わない生き物（ヤドカリ6〜20時、シロクマ6〜18時と雪、地上に出た洞窟の魔物は夜だけ）
function mobWrongTime(d, night, onIsland) { if (d.hours) { const hr = hourOf(game.time); if (hr < d.hours[0] || hr >= d.hours[1]) return true; } if (d.snow && game.weather !== 'snow') return true; if (d.where === 'cave' && onIsland && !night) return true; return (d.at === 'day' && night) || (d.at === 'night' && !night); }
// v8c：今夜、洞窟の魔物が地上に出るか（evening＝18時のお知らせ用）
function surfTonight(evening) { const g = game; return !!g && g.surfD === g.day && !g.demo && g.tut < 0 && (evening || isNight()); }
function spawnMob(type, x, y) {
  const m = { mob: 1, type, x, y, hp: MOBS[type].hp, dir: 1, vx: 0, vy: 0, t: 0, an: 0, atkCd: 1, hurt: 0, flee: 0, lunge: 0, map: game.map, seed: Math.random() * 6 };
  state.mobs.push(m); return m;
}
// v7a：1日の出現数（金のウサギ・蜂）。日付が変わると数え直す
function daily() { const g = game; if (!g.daily || g.daily.d !== g.day) g.daily = { d: g.day, gr: 0, bee: 0 }; return g.daily; }
function goldRabbitRoll() { const c = CONFIG.goldRabbit; return daily().gr < c.perDay && chance(c.p); }
function spawnGoldRabbit(x, y) { daily().gr++; spawnMob('grabbit', x, y); }   // v8c：お知らせは出さない（偶然見つける）
// v7a：木を切り始めた時に、まれに蜂が飛び出す（チュートリアル中・デモプレイは出ない）
function tryBee(o) {
  const g = game, c = CONFIG.bee;
  if (g.map !== 'island' || g.demo || g.tut >= 0 || daily().bee >= c.perDay || !chance(c.p)) return;
  daily().bee++; spawnMob('bee', o.x * 16 + 8, o.y * 16 + 6); sfx('warn'); toast('木を揺らしたら、蜂が飛び出してきた！', 'bad');
}
function caveFloor(mp) { const a = []; for (let y = 1; y < mp.H - 1; y++) for (let x = 1; x < mp.W - 1; x++) if (mp.tiles[y * mp.W + x] === T.CFLOOR) a.push([x, y]); return a; }
// 焚き火・小屋のまわりは安全地帯（敵が近寄らない）
function safePoints() { return curMap().objs.filter(o => o.t === 'campfire' || o.t === 'hut').map(o => o.t === 'hut' ? [o.x * 16 + 16, o.y * 16 + 8, 64] : [o.x * 16 + 8, o.y * 16 + 10, 60]); }
const inSafe = (pts, x, y) => pts.some(([sx, sy, r]) => Math.hypot(sx - x, sy - y) < r);
function nearHut() { if (game.map !== 'island') return false; const hu = maps.island.objs.find(o => o.t === 'hut'); return !!hu && Math.hypot(hu.x * 16 + 16 - player.x, hu.y * 16 + 8 - player.y) < 44; }
const enemyNear = r => state.mobs.some(m => m.map === game.map && MOBS[m.type].kind === 'enemy' && Math.hypot(m.x - player.x, m.y - player.y) < r);
function trySpawnMobs() {
  if (game.map === 'cave2' || game.map === 'house') return;   // 地下2階は、ボス以外は出ない。v7c：家の中は生き物が出ない
  const mp = curMap(), cave = game.map === 'cave', night = isNight(), [ptx, pty] = playerTile(), pts = safePoints();
  for (const type in MOBS) {
    const d = MOBS[type];
    if (d.noSpawn) continue;   // v7a：金のウサギ・蜂は、ふつうの抽選では出ない
    const surf = !cave && d.where === 'cave' && game.map === 'island' && surfTonight();   // v8c：洞窟の魔物が地上に出る夜
    if (!surf && cave !== (d.where === 'cave')) continue;
    if (mobWrongTime(d, night, !cave)) continue;
    const big = !cave && mp.W * mp.H > 5000, wideCave = cave && mp.W * mp.H > 2000;   // v6.1d：広い洞窟は敵を多めに
    const cap = surf ? (big ? 2 : 1) : d.snow ? (big ? 2 : 1) : (big ? (d.kind === 'enemy' ? d.cap + 1 : Math.round(d.cap * 1.6)) : wideCave ? (d.capWide || d.cap) : d.cap) + (d.kind === 'enemy' && game.mode === 'hard' ? 1 : 0);   // v6c：広い島は生き物を多めに（敵は+1まで）
    if (state.mobs.filter(m => m.type === type && m.map === game.map).length >= cap) continue;
    const list = cave ? (mp.floor || (mp.floor = caveFloor(mp))) : d.where === 'sand' ? mp.spawn.sand : mp.spawn.land;
    if (!list || !list.length) continue;
    for (let a = 0; a < 12; a++) {
      const [tx, ty] = list[Math.floor(Math.random() * list.length)], dd = Math.hypot(tx - ptx, ty - pty);
      if (dd < (cave ? 7 : 10) || dd > 24) continue;
      const x = tx * 16 + 8, y = ty * 16 + 12;
      if (mobBlocked(mp, d, x, y) || (d.kind === 'enemy' && inSafe(pts, x, y))) continue;
      if (type === 'rabbit' && goldRabbitRoll()) spawnGoldRabbit(x, y); else spawnMob(type, x, y);   // v7a：まれに金のウサギ
      if (d.kind === 'enemy' && !cave && !game.flags.firstEnemy) { game.flags.firstEnemy = 1; toast('どこかで獣の遠吠えが聞こえる……焚き火や小屋のそばは安全だ', 'bad'); sfx('warn'); }
      break;
    }
  }
}
const MOB_LEAVE = 2.5;   // v8f：消えるまでの秒数
function updateMobs(dt) {
  const mp = curMap(), night = isNight(), pts = safePoints(), playerSafe = inSafe(pts, player.x, player.y), px = player.x, py = player.y - 4;
  state.mobT -= dt; if (state.mobT <= 0) { state.mobT = game.map === 'cave' ? 5 : 3; if (!state.noMobs) trySpawnMobs(); }   // v8c：洞窟は出る間隔を少し長く
  for (let i = state.mobs.length - 1; i >= 0; i--) {
    const m = state.mobs[i];
    if (m.map !== game.map) { state.mobs.splice(i, 1); continue; }
    const d = MOBS[m.type], dx = px - m.x, dy = py - (m.y - 4), dist = Math.hypot(dx, dy) || 0.01;
    const wrongTime = mobWrongTime(d, night, m.map === 'island');   // v8c
    if (dist > 30 * 16 || (wrongTime && dist > 12 * 16)) { state.mobs.splice(i, 1); continue; }
    m.hurt = Math.max(0, m.hurt - dt); m.atkCd = Math.max(0, m.atkCd - dt); m.flee = Math.max(0, m.flee - dt); m.lunge = Math.max(0, m.lunge - dt); m.t -= dt;
    if (d.gold && chance(dt * 5)) state.particles.push({ x: m.x + rnd(-6, 6), y: m.y - rnd(4, 12), vx: rnd(-8, 8), vy: rnd(-30, -10), life: rnd(0.3, 0.6), col: chance(0.5) ? '#fff3a0' : '#f2c440' });   // v7a：金のウサギはキラキラ光る
    if (wrongTime && !m.boss) {   // v8f：時間帯・天気が合わなくなった生き物（18時を過ぎたシロクマなど）は、プレイヤーから離れながら消えていく
      m.leave = (m.leave || 0) + dt; m.cs = null;
      if (m.leave >= MOB_LEAVE) { burst(m.x, m.y - 6, '#e8e0d0', 4); state.mobs.splice(i, 1); continue; }
      moveMob(mp, d, m, -dx / dist * d.sp * 0.8 * dt, -dy / dist * d.sp * 0.8 * dt); if (Math.abs(dx) > 0.1) m.dir = dx > 0 ? -1 : 1; m.an += dt * 6; continue;
    } else m.leave = 0;
    let vx = 0, vy = 0, sp = d.sp;
    const wander = () => { if (m.t <= 0) { m.t = rnd(1.2, 3); if (chance(0.4)) m.vx = m.vy = 0; else { const a = rnd(0, Math.PI * 2); m.vx = Math.cos(a); m.vy = Math.sin(a); } } vx = m.vx; vy = m.vy; sp *= 0.5; };
    if (d.kind === 'passive') {
      if (d.calm) wander();   // v8c：ヤドカリは逃げない
      else if (m.flee > 0 || dist < (d.fleeR || 34)) { vx = -dx / dist; vy = -dy / dist; sp = d.fleeSp || sp * 1.3; if (d.smart) [vx, vy] = smartFlee(mp, d, m, vx, vy, dt); } else wander();   // v8c：金のウサギはかしこく逃げる
    } else if (d.kind === 'neutral') {   // v8c：シロクマ（ふだんはおとなしい。攻撃されると怒って突進）
      const r = bearAI(mp, d, m, dist, dx, dy, dt, playerSafe, wrongTime); vx = r[0]; vy = r[1]; sp = r[2] != null ? r[2] : sp; if (r[3]) { m.an += dt * 8; continue; }
      if (!m.cs) wander();   // v8e：突進していない時はうろうろ
    } else if (dist < d.sight && !playerSafe && !wrongTime && game.hp > 0) {
      vx = dx / dist; vy = dy / dist;
      if (dist < 13) { vx = vy = 0; if (m.atkCd <= 0) { m.atkCd = 1.3; m.lunge = 0.2; m.dir = dx < 0 ? -1 : 1; const can = state.invuln <= 0 && !state.god; hurtPlayer(d.dmg, m); if (d.poison && can && chance(d.poisonP == null ? 1 : d.poisonP)) poisonPlayer(); } }   // v6.1c：サソリは毒（v7a：蜂は30%）
    } else if (inSafe(pts, m.x, m.y - 4) || (playerSafe && dist < 90)) { vx = -dx / dist; vy = -dy / dist; }
    else wander();
    if (d.fly && (vx || vy)) { vx += Math.sin(state.time * 7 + m.seed) * 0.6; vy += Math.cos(state.time * 5 + m.seed) * 0.6; }
    if (m.hurt > 0.12) vx = vy = 0;
    if (vx || vy) { const l = Math.hypot(vx, vy); moveMob(mp, d, m, vx / l * sp * dt, vy / l * sp * dt); if (Math.abs(vx) > 0.1) m.dir = vx < 0 ? -1 : 1; m.an += dt * 8; }
  }
}
// v8c：金のウサギの逃げ方。逃げる向きのまわり（±120度）を調べ、ふさがっていない・遠くまで行ける方向を選ぶ（0.2秒ごとに決め直す）
function smartFlee(mp, d, m, vx, vy, dt) {
  m.sfT = (m.sfT || 0) - dt;
  if (m.sfT <= 0 || !m.sfd) {
    m.sfT = 0.2; const base = Math.atan2(vy, vx); let best = null, bs = -1e9;
    for (const da of [0, 0.5, -0.5, 1.0, -1.0, 1.5, -1.5, 2.1, -2.1]) {
      const a = base + da, cx = Math.cos(a), cy = Math.sin(a); let free = 0;
      for (let s = 8; s <= 64; s += 8) { if (mobBlocked(mp, d, m.x + cx * s, m.y + cy * s)) break; free = s; }
      const sc = free * (1 + 0.7 * Math.cos(da)) - (m.sfd && (m.sfd[0] * cx + m.sfd[1] * cy) < -0.3 ? 30 : 0);
      if (sc > bs) { bs = sc; best = [cx, cy]; }
    }
    m.sfd = best;
  }
  return m.sfd;
}
// v8c：シロクマ。v8e：プレイヤーが10マス以内に入ると一度止まり、0.5秒後、その瞬間のプレイヤーの位置へ一直線に突進（速さ131）
// 突進の行き先は突進を始めた時に決まる（途中で曲がらない）ので、左右に避ければかわせる。木や岩にぶつかると止まる
// v8f：攻撃されるまでは、近づいてもおとなしくうろうろするだけ（敵対しない）。突進がすぐ木や岩に止められた時や、間に木などがある時は、回りこんで歩いて近づく（止まったまま動かなくなるのを防ぐ）
// 戻り値 [vx, vy, 速さ, 自分で動かした]
function bearAI(mp, d, m, dist, dx, dy, dt, playerSafe, wrongTime) {
  if (wrongTime || game.hp <= 0) { m.cs = null; return [0, 0, null, false]; }
  m.ct = (m.ct || 0) - dt;
  if (m.cs === 'prep') { if (m.ct <= 0) { m.cs = 'dash'; m.ct = 2.2; m.hitDone = false; m.tx = player.x; m.ty = player.y; m.dmv = 0; m.dt0 = 0; m.dir = player.x < m.x ? -1 : 1; sfx('warn'); } return [0, 0, 0, true]; }
  if (m.cs === 'dash') {
    const tx = m.tx - m.x, ty = m.ty - m.y, td = Math.hypot(tx, ty), step = Math.min(td, (d.dashSp || 96) * dt), ox = m.x, oy = m.y;
    if (td > 2) { moveMob(mp, d, m, tx / td * step, ty / td * step); m.dir = tx < 0 ? -1 : 1; }
    const mv = Math.hypot(m.x - ox, m.y - oy), stuck = mv < step * 0.3; m.dmv += mv; m.dt0 += dt;
    if (!m.hitDone && Math.hypot(player.x - m.x, (player.y - 4) - (m.y - 4)) < 15) { m.hitDone = true; m.lunge = 0.25; hurtPlayer(d.dmg, m); }
    if (td <= 3 || stuck || m.ct <= 0) { if (stuck && m.dmv < 10 && !m.hitDone) { m.cs = 'walk'; m.ct = 1.8; } else { m.cs = 'rest'; m.ct = 1.3; } }   // v8f：出だしで止められたら、回りこむ
    return [0, 0, 0, true];
  }
  if (m.cs === 'rest') { if (m.ct <= 0) m.cs = null; return [0, 0, 0, false]; }
  if (!m.angry) { m.cs = null; return [0, 0, null, false]; }   // v8f：攻撃されるまでは敵対しない
  if (playerSafe) { if (dist < d.sight) return [-dx / dist, -dy / dist, d.sp, false]; m.cs = null; return [0, 0, null, false]; }   // 焚き火・小屋のそばには近寄らない
  const see = !losBlocked(m.x, m.y - 4, player.x, player.y - 4);
  if (m.cs === 'walk') {   // v8f：歩いて近づく（ふさがっていない方へ回りこむ）
    if (m.ct <= 0 || dist > d.sight * 1.8) m.cs = null;
    else {
      if (dist < 15 && m.atkCd <= 0) { m.atkCd = 1.3; m.lunge = 0.2; m.dir = dx < 0 ? -1 : 1; hurtPlayer(d.dmg, m); }
      if (see && m.ct < 1.0 && dist > 30 && dist <= d.sight) { m.cs = 'prep'; m.ct = d.prep || 1.0; m.dir = dx < 0 ? -1 : 1; return [0, 0, 0, true]; }
      const [vx, vy] = smartFlee(mp, d, m, dx / dist, dy / dist, dt); return [vx, vy, d.sp * 1.6, false];
    }
  }
  if (dist <= d.sight && see) { m.cs = 'prep'; m.ct = d.prep || 1.0; m.dir = dx < 0 ? -1 : 1; return [0, 0, 0, true]; }
  if (dist <= d.sight * 1.6) { m.cs = 'walk'; m.ct = 1.6; const [vx, vy] = smartFlee(mp, d, m, dx / dist, dy / dist, dt); return [vx, vy, d.sp * 1.6, false]; }   // v8f：間に木や岩がある時は、歩いて回りこむ
  m.cs = null; return [0, 0, null, false];   // v8e：遠い時は、ふつうにうろうろする
}
function hurtPlayer(dmg, m) {
  if (casinoOpen() && !(m && m.pierce)) return;   // v6.2：カジノ船の中にいる間は、獣に襲われない
  if ((state.invuln > 0 && !m.pierce) || state.god) return;   // v6b：pierce＝必殺技（無敵時間・防具を無視）
  if (UI.isOpen()) UI.closeAll();   // 攻撃されたらメニューを閉じる
  const g = game; dmg = Math.round(dmg * (g.mode === 'hard' ? 1.25 : 1));
  // v6b：防具でダメージを減らす。攻撃を受けるたびに耐久が1減る
  const ar = !m.pierce && armorSlot();
  if (ar) {
    dmg = Math.max(1, Math.round(dmg * (1 - (TOOLS[ar.id].def || 0)))); ar.dur--; burst(player.x, player.y - 8, P.ironL, 3);
    if (ar.dur <= 0) { const i = g.slots.indexOf(ar); if (i >= 0) g.slots[i] = null; syncInv(); toast(`${TOOLS[ar.id].n}が壊れた！`, 'bad'); }
    else if (ar.dur === 10) toast(`${TOOLS[ar.id].n}の耐久が残りわずか（あと10回）`, 'bad');
  }
  g.hp = Math.max(0, g.hp - dmg); state.invuln = 0.8; state.shake = 0.3; sfx('hurt'); stopFishing(); state.gather.o = null;
  floatText(player.x, player.y - 20, `-${dmg}`, '#ff6a5a');
  const dx = player.x - m.x, dy = player.y - m.y, l = Math.hypot(dx, dy) || 1;
  tryMove(dx / l * 10, 0); tryMove(0, dy / l * 10);
  if (!g.flags.firstHurt) { g.flags.firstHurt = 1; toast(`${m.name || MOBS[m.type].n}に襲われた！ ${Input.mode === 'key' ? '向き合って左クリックかSpace' : '向き合って' + keyLabel('A')}で反撃（剣があると強い）`, 'bad'); }
}
// v6.2：2点の間に、通れない物（木・岩・設置物・壁など）があるか（自分と相手のマスは数えない）
function losBlocked(x0, y0, x1, y1) {
  const m = curMap(), n = Math.max(2, Math.ceil(Math.hypot(x1 - x0, y1 - y0) / 4));
  const sx = Math.floor(x0 / 16), sy = Math.floor(y0 / 16), ex = Math.floor(x1 / 16), ey = Math.floor(y1 / 16);
  for (let i = 1; i < n; i++) {
    const t = i / n, tx = Math.floor((x0 + (x1 - x0) * t) / 16), ty = Math.floor((y0 + (y1 - y0) * t) / 16);
    if ((tx === sx && ty === sy) || (tx === ex && ty === ey)) continue;
    if (isBlocked(m, tx, ty)) return true;
  }
  return false;
}
function mobInFront() {
  const [vx, vy] = D8[dir8()], px = player.x, py = player.y - 4; let best = null, bd = 28;   // v8d：8方向   // v6.1a：リーチ 24→28px
  for (const m of state.mobs) {
    if (m.map !== game.map) continue;
    const dx = m.x - px, dy = (m.y - 4) - py, d = Math.hypot(dx, dy);
    if (d > 28 || (d > 8 && (dx * vx + dy * vy) / d < 0.3)) continue;
    if (d > 10 && losBlocked(px, py, m.x, m.y - 4)) continue;   // v6.2：間に木・岩・設置物などがあると、攻撃は届かない
    if (d < bd) { bd = d; best = m; }
  }
  return best;
}
function attackMob(m) {
  const g = game, wk = heldAtk(), hit = rollAtk(wk), d = MOBS[m.type], dmg = d.fixedDmg ? (hit.crit ? 2 : 1) : hit.dmg;   // v7a：金のウサギは、どの武器でも1（会心で2）   // v6.1a：新しいダメージ計算
  state.atkCd = (wk === 'ironSword' ? 0.32 : 0.42) * (g.stamina <= 0 ? 1.6 : 1); state.swing = 0.15; player.lunge = 0.12;
  g.stamina = Math.max(0, g.stamina - stCost(5)); state.stIdle = 0;
  if (wk) useTool(TOOLS[wk].cat);   // v6.1a：斧・つるはしで殴っても耐久が減る
  m.hp -= dmg; m.hurt = 0.25; m.flee = 3; sfx('chop');
  if (d.kind === 'neutral' && !m.angry) { m.angry = 1; sfx('warn'); toast(`${d.n}が怒った！ 突進に気をつけよう`, 'bad'); }   // v8c。v8f：攻撃されて初めて怒る（お知らせを戻した）
  const dx = m.x - player.x, dy = m.y - player.y, l = Math.hypot(dx, dy) || 1;
  if (!(m.cs === 'dash')) moveMob(curMap(), d, m, dx / l * 12, dy / l * 12);
  hitText(m.x, m.y - 18, dmg, hit.crit); burst(m.x, m.y - 6, '#ffffff', 5);
  if (m.hp <= 0) killMob(m);
}
function killMob(m) {
  const i = state.mobs.indexOf(m); if (i >= 0) state.mobs.splice(i, 1);
  const d = MOBS[m.type], mp = curMap(), tx = Math.floor(m.x / 16), ty = Math.floor((m.y - 3) / 16);
  for (const [id, n, p, kp] of d.drops) if (p == null || chance(p)) spawnDrop(mp, tx, ty, id, n, 0, undefined, kp);   // v7a：kp＝消えない落とし物
  if (d.dropFn) for (const [id, n] of d.dropFn()) spawnDrop(mp, tx, ty, id, n, 0);   // v8c：ヤドカリ・シロクマ
  burst(m.x, m.y - 6, '#e8e0d0', 12); sfx('thud'); game.stats.kills = (game.stats.kills || 0) + 1;
  toast(`${d.n}をたおした！`, 'good');
  if (d.gold) { sfx('unlock'); toast('黄金の生肉と黄金の毛皮を落とした！', 'good'); }   // v7a
}
// v6.1a：敵の絵を描く位置（目の光と同じ計算を使う）
function mobDrawPos(m, time) {
  const fr = MOBSPR[m.type], d = MOBS[m.type], spr = fr[m.dir < 0 ? 1 : 0][Math.floor(m.an) % 2];
  let x = Math.round(m.x - spr.width / 2), y = Math.round(m.y - spr.height);
  if (d.fly) y -= 6 + Math.round(Math.sin(time * 6 + m.seed) * 2);
  if (m.lunge > 0) x += m.dir * 2;
  return { spr, x, y };
}
function drawMob(m, time) {
  const fr = MOBSPR[m.type]; if (!fr) return;
  const d = MOBS[m.type], { spr, x, y } = mobDrawPos(m, time);
  const fa = m.leave > 0 ? clamp(1 - m.leave / MOB_LEAVE, 0, 1) : 1;   // v8f：消えていく途中は薄く
  ctx.globalAlpha = fa; ctx.fillStyle = 'rgba(0,0,0,0.22)'; ctx.fillRect(Math.round(m.x) - 4, Math.round(m.y) - 1, 8, 2);
  if (m.hurt > 0 && Math.floor(time * 30) % 2) ctx.globalAlpha = 0.4 * fa;
  if (m.cs === 'prep') { ctx.drawImage(spr, x + (Math.floor(time * 30) % 2 ? 1 : -1), y); } else ctx.drawImage(spr, x, y); ctx.globalAlpha = 1;
  if (fa < 1) return;
  if (m.cs === 'prep') {   // v8c：シロクマが止まった合図（v8e：狙う場所の×印はなくした）
    ctx.fillStyle = '#ff5a4a'; ctx.fillRect(Math.round(m.x) - 1, y - 12, 3, 6); ctx.fillRect(Math.round(m.x) - 1, y - 4, 3, 2);
  }
  if (m.hp < d.hp) { ctx.fillStyle = P.ol; ctx.fillRect(Math.round(m.x) - 6, y - 4, 12, 3); ctx.fillStyle = d.kind === 'enemy' || m.angry ? '#ff5a4a' : '#9fe09a'; ctx.fillRect(Math.round(m.x) - 5, y - 3, Math.max(1, Math.round(10 * m.hp / d.hp)), 1); }
}

/* 演出 */
// v8c：稲妻（空から落ちる折れ線と光）・地面の焦げ・打たれたあと数秒、体のまわりをピリピリ走る電気
function drawBolt(time) {
  const b = state.bolt;
  if (b && b.t > 0) {
    const a = Math.min(1, b.t / 0.25), top = state.cam.y - 30, pts = [[b.x, top]]; let x = b.x;
    for (let y = top + 14; y < b.y; y += 14) { x += (hash2(Math.floor(y), Math.floor(b.seed), 3) - 0.5) * 22; pts.push([x, y]); } pts.push([b.x, b.y]);
    ctx.globalAlpha = a;
    for (const [w, c] of [[6, 'rgba(160,190,255,0.35)'], [3, 'rgba(220,235,255,0.9)'], [1.2, '#ffffff']]) { ctx.strokeStyle = c; ctx.lineWidth = w; ctx.beginPath(); pts.forEach(([px, py], i) => i ? ctx.lineTo(px, py) : ctx.moveTo(px, py)); ctx.stroke(); }
    ctx.fillStyle = 'rgba(255,240,180,0.55)'; ctx.beginPath(); ctx.ellipse(b.x, b.y, 14, 6, 0, 0, Math.PI * 2); ctx.fill();
    ctx.globalAlpha = 1;
  }
  if (state.zap > 0 && game.map !== 'house') {   // 打たれたあとのピリピリ
    const px = player.x, py = player.y - 10, f = Math.floor(time * 20);
    ctx.lineWidth = 1;
    for (let i = 0; i < 4; i++) {
      if ((f + i) % 3 === 0) continue;
      const a0 = hash2(f, i, 7) * Math.PI * 2, r0 = 7 + hash2(i, f, 9) * 4; let x = px + Math.cos(a0) * r0, y = py + Math.sin(a0) * r0 * 1.3;
      ctx.strokeStyle = i % 2 ? '#ffe14a' : '#9fe8ff'; ctx.beginPath(); ctx.moveTo(x, y);
      for (let k = 0; k < 3; k++) { x += (hash2(f, i * 3 + k, 11) - 0.5) * 8; y += (hash2(i * 3 + k, f, 13) - 0.5) * 8; ctx.lineTo(x, y); }
      ctx.stroke();
    }
    if (f % 4 === 0) { ctx.fillStyle = 'rgba(255,240,120,0.25)'; ctx.fillRect(px - 8, py - 10, 16, 20); }
  }
}
// v8c：弓 ------------------------------------------------------------------
// 円の中で狙える相手（間に木や岩がない）。敵・怒ったシロクマを先に、同じなら近い方
function bowTarget() {
  const R = CONFIG.bow.r, px = player.x, py = player.y - 6; let best = null, bs = 1e9;
  for (const m of state.mobs) {
    if (m.map !== game.map || m.hp <= 0) continue;
    const d = Math.hypot(m.x - px, (m.y - 6) - py); if (d > R) continue;
    if (losBlocked(px, py, m.x, m.y - 4)) continue;
    const md = MOBS[m.type], sc = d - (md.kind === 'enemy' || m.angry ? 1000 : 0);
    if (sc < bs) { bs = sc; best = m; }
  }
  return best;
}
function shootArrow() {
  const t = bowTarget();
  if (!t) { if (state.boss && game.map === 'cave2') { if (!state.bowMsg) { state.bowMsg = 1; toast('弓はボスには効かない（硬い毛皮にはじかれる）', 'bad'); } return false; } return false; }
  if (!has('arrow')) { sfx('error'); toast('矢がない（作業台で、木の枝・石・繊維から作れる）', 'bad'); state.atkCd = 0.5; return true; }
  takeItem('arrow', 1); useTool('bow');
  state.atkCd = CONFIG.bow.cd * (game.stamina <= 0 ? 1.6 : 1); state.swing = 0.12; state.stIdle = 0;
  const [lo, hi] = CONFIG.bow.dmg, crit = chance(CONFIG.atk.crit);
  (state.arrows || (state.arrows = [])).push({ x: player.x, y: player.y - 10, m: t, map: game.map, dmg: Math.round(rndi(lo, hi) * (crit ? CONFIG.atk.critMul : 1)), crit, life: 1.6, a: Math.atan2(t.y - 6 - player.y + 10, t.x - player.x) });
  player.dir = Math.abs(t.x - player.x) > Math.abs(t.y - player.y) ? (t.x < player.x ? 2 : 3) : (t.y < player.y ? 1 : 0);
  setFace8(t.x - player.x, t.y - 6 - player.y);   // v8d：弓は撃つ向き（8方向）を向く
  sfx('ui'); return true;
}
function updateArrows(dt) {
  const A = state.arrows; if (!A || !A.length) return; const sp = CONFIG.bow.speed;
  for (let i = A.length - 1; i >= 0; i--) {
    const a = A[i]; a.life -= dt;
    if (a.map !== game.map || a.life <= 0) { A.splice(i, 1); continue; }
    const alive = a.m && state.mobs.includes(a.m) && a.m.map === game.map;
    if (alive) { const tx = a.m.x - a.x, ty = (a.m.y - 6) - a.y, d = Math.hypot(tx, ty); if (d < 6) { arrowHit(a.m, a.dmg, a.crit); A.splice(i, 1); continue; } a.a = Math.atan2(ty, tx); }
    a.x += Math.cos(a.a) * sp * dt; a.y += Math.sin(a.a) * sp * dt;
    if (!alive && isBlocked(curMap(), Math.floor(a.x / 16), Math.floor((a.y + 6) / 16))) A.splice(i, 1);
  }
}
function arrowHit(m, dmg, crit) {
  const d = MOBS[m.type]; if (d.fixedDmg) dmg = crit ? 2 : 1;
  m.hp -= dmg; m.hurt = 0.25; m.flee = 3; sfx('chop');
  if (d.kind === 'neutral' && !m.angry && m.hp > 0) { m.angry = 1; sfx('warn'); toast(`${d.n}が怒った！ 突進に気をつけよう`, 'bad'); }   // v8c。v8f：矢が当たっても怒る
  hitText(m.x, m.y - 18, dmg, crit); burst(m.x, m.y - 6, '#ffffff', 4);
  if (m.hp <= 0) killMob(m);
}
function drawArrows(time) {
  if (heldTool('bow') && game && game.hp > 0 && !UI.isOpen()) {   // 弓を持っている間は、射程の円と、狙っている相手の印
    const R = CONFIG.bow.r; ctx.strokeStyle = 'rgba(255,240,180,0.5)'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.arc(player.x, player.y - 6, R, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
    const t = bowTarget(); if (t) { const r = 7 + Math.sin(time * 8); ctx.strokeStyle = 'rgba(255,90,70,0.9)'; ctx.beginPath(); ctx.arc(t.x, t.y - 6, r, 0, Math.PI * 2); ctx.moveTo(t.x - r - 2, t.y - 6); ctx.lineTo(t.x - r + 3, t.y - 6); ctx.moveTo(t.x + r + 2, t.y - 6); ctx.lineTo(t.x + r - 3, t.y - 6); ctx.stroke(); }
  }
  for (const a of state.arrows || []) {
    if (a.map !== game.map) continue; const cx = Math.cos(a.a), cy = Math.sin(a.a);
    ctx.strokeStyle = P.woodL; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(a.x - cx * 7, a.y - cy * 7); ctx.lineTo(a.x, a.y); ctx.stroke();
    ctx.fillStyle = '#e8eef4'; ctx.fillRect(Math.round(a.x - cx * 7) - 1, Math.round(a.y - cy * 7) - 1, 2, 2); ctx.fillStyle = P.stoneL; ctx.fillRect(Math.round(a.x) - 1, Math.round(a.y) - 1, 2, 2);
  }
}
function burst(x, y, col, n) { for (let i = 0; i < n; i++) state.particles.push({ x, y, vx: rnd(-40, 40), vy: rnd(-70, -10), life: rnd(0.3, 0.6), col }); }
function floatText(x, y, text, col) { state.floats.push({ x, y, text, col, life: 1.1 }); }
function updateFx(dt) {
  for (let i = state.particles.length - 1; i >= 0; i--) { const p = state.particles[i]; p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 220 * dt; if (p.life <= 0) state.particles.splice(i, 1); }
  for (let i = state.floats.length - 1; i >= 0; i--) { const f = state.floats[i]; f.life -= dt; f.y -= 14 * dt; if (f.life <= 0) state.floats.splice(i, 1); }
  for (const k in maps) for (const o of maps[k].objs) if (o._shake > 0) o._shake -= dt;
  state.shake = Math.max(0, state.shake - dt); player.lunge = Math.max(0, player.lunge - dt); state.flash = Math.max(0, state.flash - dt);
  if (state.bolt) { state.bolt.t -= dt; if (state.bolt.t <= 0) state.bolt = null; } state.zap = Math.max(0, (state.zap || 0) - dt);   // v8c
  if (state.fishFx) { state.fishFx.t += dt; if (state.fishFx.t >= state.fishFx.T) state.fishFx = null; } state.reel = Math.max(0, (state.reel || 0) - dt);   // v7a：釣りの演出
}

/* 目標とHUD */
function objectiveText() {
  const g = game, f = g.flags;
  if (g.debt <= 0) { if (!g.bp.raft) return '島の西にある古い小屋を調べよう'; if (!g.raftBuilt) return '南の桟橋の先で、いかだを組み立てよう'; return '食料を3個持って、いかだで出航しよう'; }
  if (!f.firstSale) return f.g5 ? 'ゼニ丸を呼んで、素材を売ろう' : '浜辺の小石・流木・ヤシの実などを集めよう';   // v8f：回収ボックスはなくした
  if (!g.tools.stoneAxe && !g.tools.ironAxe) return `クラフト（${Input.mode === 'key' ? 'Cキー' : Input.mode === 'pad' ? '持ち物からRB' : 'バッグの右のハンマー'}）で石斧を作ろう`;   // v6.2：メニューを廃止。v7a：ハンマーはアイテムバーの右
  if (!maps.island.objs.some(o => o.t === 'workbench')) return '作業台を設置しよう（クラフト）';
  if (!f.firstRepay) return 'ゼニ丸に借金を返済しよう（利息は毎朝つく）';
  if (!f.diary1) return '島の西にある古い小屋を調べてみよう';
  if (!g.tools.stonePick && !g.tools.ironPick) return 'つるはしを作って岩や鉱脈を掘ろう';
  if (!f.diary2) return '北東の岩山にある洞窟を探索しよう';
  if (!f.turtle) { if (!g.bp.furnace) return 'ゼニ丸から炉の設計図を買おう'; if (!g.bp.iron) return 'ゼニ丸から鉄の道具の設計図を買おう'; if (!g.tools.ironPick) return '炉で鉄インゴットを作り、鉄のつるはしを作ろう'; return '洞窟の奥の硬い岩を砕いて、祠を探そう'; }
  return `借金を完済しよう（残り ${fmt$(g.debt)}）`;
}
const hudCache = {};
function setHud(id, v, prop) { if (hudCache[id + (prop || '')] === v) return; hudCache[id + (prop || '')] = v; const el = $(id); if (!el) return; if (prop) el.style[prop] = v; else el.textContent = v; }
function updateHud() {
  const g = game, left = g.contract.days - g.day + 1;
  setHud('hud-day', `${g.day}日目` + (g.map === 'cave' ? '（洞窟）' : g.map === 'cave2' ? '（地下2階）' : g.map === 'house' ? `・${WEATHER[g.weather].n}（家の中）` : `・${WEATHER[g.weather].n}`));
  setHud('hud-clock', clockText(g.time));
  setHud('hud-money', fmt$(g.money)); setHud('hud-debt', fmt$(Math.max(0, g.debt))); setHud('hud-rate', `返済率${Math.floor(repaidRatio() * 100)}%`);   // v6.2：借金の横に返済率
  setHud('hud-debtbar-fill', Math.round(repaidRatio() * 100) + '%', 'width');
  const dl = $('hud-deadline');
  const free = g.contract.free;
  setHud('hud-deadline', g.debt <= 0 ? '完済！ いかだで脱出しよう' : free ? '返済期限なし（デモ）' : left <= 1 ? '今日が返済期限！' : `期限まであと${left}日（今日を含む）`);
  dl.classList.toggle('warn', !free && g.debt > 0 && left <= 2);
  const nowT = performance.now(); if (nowT > (state.ltT || 0)) { state.ltT = nowT + 500; if (Input.mode === 'touch') layoutTouch(); layoutTut(); }
  const ns = nextStage(), sEl = $('hud-stage');
  setHud('hud-stage', ns ? `締め日 ${ns.day}日目：累計${fmt$(ns.need)}` + (g.repaid >= ns.need ? '（達成）' : `（あと${fmt$(ns.need - g.repaid)}）`) : '');
  if (sEl) sEl.classList.toggle('warn', !!ns && g.repaid < ns.need && ns.day - g.day <= 0);
  const ch = state.conds.map(([t, c]) => `<span class="${c}">${t}</span>`).join(' ');
  if (ch !== state.condHtml) { state.condHtml = ch; const ce = $('hud-cond'); if (ce) ce.innerHTML = ch; }
  for (const [id, v] of [['g-hp', g.hp], ['g-hunger', g.hunger], ['g-thirst', g.thirst], ['g-st', g.stamina]]) {
    const el = $(id), fill = el.querySelector('.g-fill'), w = Math.round(v) + '%';
    if (fill.style.width !== w) fill.style.width = w; el.classList.toggle('low', v < 25);
    if (id === 'g-hp') el.classList.toggle('poison', g.poison > 0);   // v6.1c：毒の間は体力バーが緑
    if (id !== 'g-st') { const nm = el.querySelector('.g-num'), t = String(Math.max(0, Math.ceil(v))); if (nm && nm.textContent !== t) nm.textContent = t; }   // v6a：数値の表示
  }
  const cap = $('hud-cap'), c = invCount(), cp = capacity(); setHud('hud-cap', `持ち物 ${c}/${cp}枠`); cap.classList.toggle('full', invFull());
  setHud('hud-objective', '目標：' + objectiveText());
  { const ob = $('hud-objective'); if (ob) ob.classList.toggle('tut-off', !(g.tut >= 0 && g.tut < TUT.length)); }   // v8f：目標はチュートリアルの間だけ表示（閉じたら消す。ステータス画面の「いまの目標」でいつでも見られる）
  updateHotbar(); updateMinimap();
  // ヒント
  const hint = $('hint');
  if (UI.isOpen() || Dialog.active || state.fading) { hint.classList.add('hidden'); return; }
  let html = null;
  if (state.place) html = `${kb('A')}ここに設置　${kb('B')}やめる<br><span class="sub">${Input.mode === 'touch' ? '置きたいマスをタップ' : Input.mode === 'pad' ? '十字キーで場所を選ぶ' : 'マウスで場所を選んでクリック（右クリックでやめる）'}／自分から${CONFIG.placeRange}マス以内</span>`;
  else if (state.fishing) html = state.fishing.phase === 'bite' ? `<span class="ng">！ 今だ！</span> ${kb('A')}` : (Input.mode === 'key' ? `釣り中…「！」が出たら ${kb('A')}　<span class="sub">（「！」の前に押すと、やめる）</span>` : `釣り中…「！」が出たら ${kb('A')}　<span class="sub">${kb('B')}やめる</span>`);
  else {
    const th = targetHint(state.target);
    if (th) {
      if (th.info) html = `<span class="sub">${th.info}</span>`;
      else if (th.ng) html = `${kb('A')}${th.act}　<span class="ng">${th.ng}</span>`;
      else if (th.act) {
        html = `${(th.atk || th.lmb) && Input.mode === 'key' ? kb('A') + '<span class="kb">左クリック</span>' : (th.atk || th.lmb) && Input.mode === 'pad' ? '<span class="kb">ZR</span>' : kb('A')}${th.act}`   /* v8c：コントローラーの攻撃・採掘はZR */ + (th.sub ? ` <span class="sub">(${th.sub})</span>` : '') + (th.gather ? ' <span class="sub">長押し</span>' : '');
        const gs = state.gather; if (th.gather && gs.o && state.target && gs.o === state.target.o) { const gd = OBJ[gs.o.t].g, need = gd.hits[gd.cat ? toolLv(gd.cat) : 0] || 1; html += `<div class="hold"><i style="width:${Math.round(gs.hits / need * 100)}%"></i></div>`; }
      }
    }
  }
  if (html !== state.hintHtml) { state.hintHtml = html; if (html) { hint.innerHTML = html; hint.classList.remove('hidden'); } else hint.classList.add('hidden'); }
}

/* ---------- 20. 描画 ---------- */
let canvas = null, ctx = null, zoom = 4, lightC = null, lightX = null, viewW = 0, viewH = 0;
// ミニマップ（ステータスの下。押すと地図画面）
const mmBase = {}; let mmNext = 0;
function updateMinimap() {
  const c = $('minimap'); if (!c || !game || state.scene !== 'play') return;
  { const hide = game.map === 'house'; if (c._hide !== hide) { c._hide = hide; c.style.display = hide ? 'none' : ''; } if (hide) return; }   // v8b：家の中では地図を出さない
  const now = performance.now(); if (now < mmNext) return; mmNext = now + 250;
  const m = curMap(), k = 2;
  if (c.width !== m.W * k || c.height !== m.H * k) { c.width = m.W * k; c.height = m.H * k; c.style.aspectRatio = `${m.W} / ${m.H}`; }
  let base = m._mmBase;   // v6c：島の大きさが変わっても作り直す。v8b：マップごとに持つ（ランダムマップで別のセーブを開いた時に、前の島が残らないように）
  if (!base) { base = mkCanvas(m.W * k, m.H * k); const bx = base.getContext('2d'); for (let y = 0; y < m.H; y++) for (let xx = 0; xx < m.W; xx++) { const v = m.tiles[y * m.W + xx]; bx.fillStyle = v === T.CWALL ? '#15121a' : TC[v][0]; bx.fillRect(xx * k, y * k, k, k); } m._mmBase = base; }
  const x = c.getContext('2d'); x.drawImage(base, 0, 0);
  const COL = { box: P.gold, campfire: '#f08a3c', workbench: '#f08a3c', furnace: '#f08a3c', bed: '#f08a3c', chest: '#f08a3c', cave: '#c040c0', exit: '#c040c0', hut: '#c8a36a', raft: '#ffffff', liner: '#ff5ac8', shrine: P.gold, ladder: '#d8b878', miner: '#7fe08a', house: '#e8b060', hexit: '#c040c0' };   // v7b・v7c
  for (const o of m.objs) { const col = COL[o.t]; if (!col || !caveSeenAt(m, o.x, o.y)) continue; x.fillStyle = P.ol; x.fillRect(o.x * k - 2, o.y * k - 2, k + 4, k + 4); x.fillStyle = col; x.fillRect(o.x * k - 1, o.y * k - 1, k + 2, k + 2); }
  if (m.name === 'cave') { x.fillStyle = '#07060c'; for (let y = 0; y < m.H; y++) for (let xx = 0; xx < m.W; xx++) if (!caveSeenAt(m, xx, y)) x.fillRect(xx * k, y * k, k, k); }   // v6a：まだ見ていない所は黒く
  const px = Math.floor(player.x / 16), py = Math.floor((player.y - 4) / 16), blink = Math.floor(now / 400) % 2;
  x.fillStyle = '#ffffff'; x.fillRect(px * k - 2, py * k - 2, k + 4, k + 4); x.fillStyle = blink ? '#e2574c' : '#ffd0c8'; x.fillRect(px * k - 1, py * k - 1, k + 2, k + 2);
}
// アイテムバー（HUD）
let hotEls = null;
let hotBag = null, hotCraft = null, hotZeni = null;   // v8b：hotZeni＝スマホのゼニ丸ボタン   // v7a：hotCraft＝スマホのクラフト（ハンマー）
let hotOff = null;   // v6b：左手（アイテムバー1の左。何も持っていない時は出さない）
function buildHotbar() {
  const bar = $('hotbar'); if (!bar) return; bar.innerHTML = ''; hotEls = [];
  { const ic = h('img', { class: 'icon', alt: '', draggable: 'false' }), cnt = h('span', { class: 'hc' }), db = h('i'), dbar = h('span', { class: 'dbar' }, db);
    const sl = h('div', { class: 'hslot hoff hidden', role: 'button', 'aria-label': '左手' }, h('span', { class: 'hn' }, '左'), ic, cnt, dbar);
    sl.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); offTap(); });
    bar.appendChild(sl); hotOff = { sl, ic, cnt, db, dbar, sig: '' }; }
  for (let i = 0; i < CONFIG.hotSize; i++) {
    const ic = h('img', { class: 'icon', alt: '', draggable: 'false' }), cnt = h('span', { class: 'hc' }), db = h('i'), dbar = h('span', { class: 'dbar' }, db);
    const sl = h('div', { class: 'hslot' }, h('span', { class: 'hn' }, String(i + 1)), ic, cnt, dbar);
    // タップ／クリック：選ぶ。選んでいる枠をもう一度タップすると「使う」（スマホ向け）
    sl.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); hotbarTap(i, e.pointerType); });
    bar.appendChild(sl); hotEls.push({ sl, ic, cnt, dbar, db, sig: '' });
  }
  // v4：8番目の右にバッグのボタン（v6.2：メニューを廃止したので、持ち物を開く）
  hotBag = h('div', { class: 'hslot hbag', role: 'button', 'aria-label': '持ち物を開く', title: '持ち物（E）' }, h('img', { class: 'icon', src: ICON_URL.uiBag, alt: '', draggable: 'false' }));
  hotBag.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); bagTap(); });
  bar.appendChild(hotBag);
  // v7a：スマホはバッグの右にクラフトのボタン（ハンマー）。キーボード・コントローラーでは出さない
  hotCraft = h('div', { class: 'hslot hcraft', role: 'button', 'aria-label': 'クラフトを開く', title: 'クラフト' }, h('img', { class: 'icon', src: ICON_URL.uiCraft, alt: '', draggable: 'false' }));
  hotCraft.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); if (state.scene === 'play' && game && !UI.isOpen() && !Dialog.active && !state.fading && !state.place && !state.clockIntro) openMainMenu('craft'); });
  bar.appendChild(hotCraft);
  // v8b：スマホはハンマーの右にゼニ丸（売買）のボタン
  hotZeni = h('div', { class: 'hslot hcraft hzeni', role: 'button', 'aria-label': 'ゼニ丸を呼ぶ（売買）', title: 'ゼニ丸' }, h('img', { class: 'icon', src: ICON_URL.uiZeni, alt: '', draggable: 'false' }));
  hotZeni.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); callZeni(); });
  bar.appendChild(hotZeni);
  bar.appendChild(h('div', { class: 'hot-name', id: 'hot-name' }));
}
// v6b：左手の枠を押す＝左手の回復アイテムを使う
function offTap() {
  if (state.scene !== 'play' || !game || UI.isOpen() || state.place || Dialog.active || state.fading) return;
  if (offUsable()) consume(game.off.id, 'off'); else if (game.off) toast(`左手に${itemName(game.off.id)}を持っている（持ち物画面で戻せます）`);
}
function bagTap() {
  if (state.scene !== 'play' || !game || UI.isOpen() || state.place || Dialog.active || state.fading) return;
  openMainMenu('inv');
}
// タップ／クリック：選ぶ。選んでいる枠をもう一度タップすると「使う」（スマホ向け）
function hotbarTap(i, ptype) {
  if (i === CONFIG.hotSize + 1) { offTap(); return; }   // v6b：左手
  if (i >= CONFIG.hotSize) { bagTap(); return; }   // バッグのボタン
  if (state.scene !== 'play' || !game || UI.isOpen() || state.place || Dialog.active) return;
  if (game.hotSel === i && ptype !== 'mouse') useSelected(false); else hotSelect(i);
}
// 画面の位置がアイテムバーのどの枠か（-1：どれでもない、hotSize：バッグのボタン）
function hotbarSlotAt(x, y) {
  if (!hotEls || state.scene !== 'play' || $('hud').classList.contains('hidden')) return -1;
  for (let i = 0; i < hotEls.length; i++) { const r = hotEls[i].sl.getBoundingClientRect(); if (x >= r.left - 2 && x <= r.right + 2 && y >= r.top - 4 && y <= r.bottom + 4) return i; }
  if (hotBag) { const r = hotBag.getBoundingClientRect(); if (x >= r.left - 2 && x <= r.right + 4 && y >= r.top - 4 && y <= r.bottom + 4) return CONFIG.hotSize; }
  if (hotOff && !hotOff.sl.classList.contains('hidden')) { const r = hotOff.sl.getBoundingClientRect(); if (x >= r.left - 4 && x <= r.right + 2 && y >= r.top - 4 && y <= r.bottom + 4) return CONFIG.hotSize + 1; }   // v6b：左手
  return -1;
}
// v4：スティックの反応範囲をアイテムバーに重ならない左下だけにする（横画面：バーの左まで／縦画面：バーの下まで）
window.addEventListener('resize', () => { if (typeof Input !== 'undefined' && Input.mode === 'touch' && state.scene === 'play') setTimeout(() => { try { layoutTouch(); } catch (e) { /* noop */ } }, 60); });   // v8f
function layoutTouch() {
  const zone = $('stick-zone'), bar = $('hotbar'); if (!zone || !bar) return;
  const W = window.innerWidth, H = window.innerHeight, r = bar.getBoundingClientRect();
  const ro = hotOff && !hotOff.sl.classList.contains('hidden') ? hotOff.sl.getBoundingClientRect() : null, left = ro && ro.width ? Math.min(r.left, ro.left) : r.left;   // v6b：左手の枠も避ける
  let w = W * 0.5, hh = H * 0.62;
  if (r.width > 0) { if (left - 8 >= 170) w = Math.min(w, left - 8); else hh = Math.min(hh, Math.max(170, H - r.bottom - 6)); }
  // v8f：スマホの横画面は、ミニマップを左上の表示（時間など）のすぐ下に置き、スティックとの間に入る大きさにする（文字の大きさで表示の高さが変わるため、実際の高さで決める）
  const mm = $('minimap'), st = $('hud-status'), land = window.matchMedia && window.matchMedia('(max-height:460px) and (orientation:landscape)').matches;
  if (mm) {
    if (land && st && st.offsetParent && mm.offsetParent) {
      const uk = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--ui')) || 1, sr = st.getBoundingClientRect(), hr = $('hud').getBoundingClientRect();
      const top = (sr.bottom - hr.top) / uk + 6, stickTop = H - (34 + 128 * (settings.touchSize || 1)) - 8, mw = clamp(((stickTop - hr.top) / uk - top) * 72 / 56, 60, 104);
      mm.style.top = Math.round(top) + 'px'; mm.style.width = Math.round(mw) + 'px';
    } else { mm.style.top = ''; mm.style.width = ''; }
    // v8f：スティックを動かせる範囲は、ミニマップより下だけ（ミニマップの下の方を押しても地図が開くように）
    if (mm.offsetParent) { const mr = mm.getBoundingClientRect(); if (mr.height > 0 && mr.left < w) hh = Math.min(hh, Math.max(120, H - mr.bottom - 10)); }
  }
  zone.style.width = Math.round(w) + 'px'; zone.style.height = Math.round(hh) + 'px';
}
// v4：スマホは、食べ物・飲み物を持って画面の何もない所を1秒長押しすると使う（マイクラ風。進み具合を指の位置に輪で表示）
function startHoldUse(e) {
  const sl = heldSlot(), it = sl && ITEMS[sl.id], main = !!(it && (it.food || it.heal || it.buff)); if (!main && !offUsable()) return;   // v6b：左手の回復アイテムも長押しで使える
  cancelHold();
  const ring = h('div', { class: 'hold-ring' }); ring.style.left = Math.round(e.clientX - 30) + 'px'; ring.style.top = Math.round(e.clientY - 30) + 'px';
  document.body.appendChild(ring);
  state.holdUse = { id: e.pointerId, x: e.clientX, y: e.clientY, t0: performance.now(), sel: game.hotSel, item: sl ? sl.id : null, off: !main, ring };
}
function updateHoldUse() {
  const hu = state.holdUse; if (!hu) return;
  const sl = heldSlot();
  if (UI.isOpen() || Dialog.active || state.place || state.fading || game.hotSel !== hu.sel || (hu.off ? !offUsable() : (!sl || sl.id !== hu.item))) { cancelHold(); return; }
  const p = (performance.now() - hu.t0) / 1000;
  hu.ring.style.opacity = p < 0.15 ? '0' : '1'; hu.ring.style.setProperty('--p', String(Math.min(1, p)));
  if (p >= 1) { const off = hu.off; cancelHold(); if (off) consume(game.off.id, 'off'); else useSelected(false); try { if (navigator.vibrate) navigator.vibrate(15); } catch (er) { /* noop */ } }
}
function cancelHold() { const hu = state.holdUse; if (!hu) return; if (hu.ring) hu.ring.remove(); state.holdUse = null; }
// v4：チュートリアルは、左上（日付・お金）と右上（体力など）の表示の間に収める（縦画面などはCSSで画面下へ）
function layoutTut() {
  const el = $('tut'), a = $('hud-status'), g = $('hud-gauges'); if (!el || !a || !g) return;
  const reset = () => { el.style.left = el.style.width = el.style.minWidth = el.style.transform = ''; };
  if (window.matchMedia('(max-width:560px)').matches) { reset(); return; }
  const L = a.offsetLeft + a.offsetWidth + 8, room = g.offsetLeft - 8 - L;
  if (room < 200) { reset(); return; }
  const w = Math.min(360, room); el.style.width = w + 'px'; el.style.minWidth = '0'; el.style.left = Math.round(L + (room - w) / 2) + 'px'; el.style.transform = 'none';
}
/* v4：持ち物の枠 — ドラッグ（スマホは長押し）で好きな枠へ移動。PCはマウスを乗せると名前と耐久を表示 */
const Drag = { st: null, ghost: null, over: null, endT: 0 };
const dragJustEnded = () => performance.now() < Drag.endT;
const slotArr = (L, name) => name === 'chest' ? (L.chest && L.chest.slots) : name === 'off' ? [game.off] : game.slots;   // v6.2：'off'＝左手の枠
function slotDnD(c, L, arrName, i) {
  c.dataset.arr = arrName; c.dataset.i = String(i);
  c.addEventListener('pointerdown', e => {
    const arr = slotArr(L, arrName); if (!arr || !arr[i] || (e.pointerType === 'mouse' && e.button !== 0)) return;
    dragCancel(); hideTip();
    Drag.st = { L, arrName, i, id: e.pointerId, type: e.pointerType, x0: e.clientX, y0: e.clientY, x: e.clientX, y: e.clientY, src: c, active: false, timer: 0 };
    if (e.pointerType !== 'mouse') Drag.st.timer = setTimeout(() => { if (Drag.st && !Drag.st.active) dragStart(); }, 330);
  });
  c.addEventListener('pointerenter', e => { if (e.pointerType === 'mouse' && !Drag.st) showTip(L, arrName, i, e.clientX, e.clientY); });
  c.addEventListener('pointermove', e => { if (e.pointerType !== 'mouse' || Drag.st) return; if (tipEl && tipEl._k === arrName + i && tipEl.style.display === 'block') moveTip(e.clientX, e.clientY); else showTip(L, arrName, i, e.clientX, e.clientY); });
  c.addEventListener('pointerleave', () => hideTip());
}
function dragStart() {
  const s = Drag.st; if (!s) return; const arr = slotArr(s.L, s.arrName), sl = arr && arr[s.i]; if (!sl || UI.top() !== s.L) { dragCancel(); return; }
  s.active = true; hideTip(); s.src.classList.add('dragging');
  Drag.ghost = h('div', { class: 'drag-ghost' }, icon(sl.id), sl.n > 1 ? h('span', { class: 'hc' }, String(sl.n)) : null);
  document.body.appendChild(Drag.ghost); dragMove(s.x, s.y); sfx('ui');
}
function dragMove(x, y) {
  const s = Drag.st; if (!s) return; s.x = x; s.y = y;
  if (!s.active) {
    const d = Math.hypot(x - s.x0, y - s.y0);
    if (s.type === 'mouse') { if (d > 6) dragStart(); } else if (d > 10) dragCancel();   // 長押しの前に指が動いた＝スクロール
    if (!Drag.st || !Drag.st.active) return;
  }
  if (Drag.ghost) Drag.ghost.style.transform = `translate(${Math.round(x - 22)}px,${Math.round(y - 22)}px)`;
  const t = dropTargetAt(x, y);
  if (Drag.over !== t) { if (Drag.over) Drag.over.classList.remove('drop-on'); Drag.over = t; if (t) t.classList.add('drop-on'); }
}
function dropTargetAt(x, y) {
  const el = document.elementFromPoint(x, y), c = el && el.closest ? el.closest('.islot') : null;
  return c && c.dataset.arr && !c.closest('.modal.under') ? c : null;
}
function dragEnd(x, y) {
  const s = Drag.st; if (!s) return; const was = s.active;
  if (was) {
    const t = dropTargetAt(x, y);
    if (t) {
      const ta = t.dataset.arr, j = +t.dataset.i;
      if (ta === 'off' || s.arrName === 'off') {   // v6.2：左手の枠へ／左手の枠から
        if (ta === 'off' && s.arrName === 'inv') { if (toOffhand(s.i)) { s.L.sel = null; s.L.focusKey = 'sl-off'; } }
        else if (s.arrName === 'off' && ta === 'inv') { if (offToSlot(j)) { s.L.sel = null; s.L.focusKey = t.dataset.k; } }
        else if (ta === 'off' && s.arrName === 'chest') { sfx('error'); toast('左手には、持ち物から移してね', 'bad'); }
      } else {
        const A = slotArr(s.L, s.arrName), B = slotArr(s.L, ta);
        if (A && B && A[s.i] && !(A === B && j === s.i)) { moveSlot(A, s.i, B, j); syncInv(); sfx('pick'); s.L.sel = null; s.L.focusKey = t.dataset.k; }
      }
    }
    Drag.endT = performance.now() + 350;   // 指を離した直後の「クリック」は無視する
  }
  dragCancel(); if (was && UI.top() === s.L) UI.refresh(s.L);
}
function dragCancel() {
  const s = Drag.st; if (s && s.timer) clearTimeout(s.timer);
  if (s && s.src) s.src.classList.remove('dragging');
  if (Drag.ghost) { Drag.ghost.remove(); Drag.ghost = null; }
  if (Drag.over) { Drag.over.classList.remove('drop-on'); Drag.over = null; }
  Drag.st = null;
}
let tipEl = null;
function showTip(L, arrName, i, x, y) {
  if (Input.mode === 'touch') return;
  const arr = slotArr(L, arrName), sl = arr && arr[i]; if (!sl) { hideTip(); return; }
  if (!tipEl) { tipEl = h('div', { class: 'slot-tip' }); document.body.appendChild(tipEl); }
  const t = TOOLS[sl.id]; tipEl.innerHTML = ''; tipEl._k = arrName + i;
  tipEl.appendChild(h('div', { class: 'tn' }, itemName(sl.id) + (sl.n > 1 ? ` ×${sl.n}` : '')));
  if (t && t.dur) tipEl.appendChild(h('div', { class: 'td' }, `耐久 ${durText(sl)}`));
  tipEl.style.display = 'block'; moveTip(x, y);
}
function moveTip(x, y) { if (!tipEl || tipEl.style.display !== 'block') return; const w = tipEl.offsetWidth, hh = tipEl.offsetHeight; tipEl.style.left = Math.max(4, Math.min(x + 14, window.innerWidth - w - 4)) + 'px'; tipEl.style.top = Math.max(4, Math.min(y + 18, window.innerHeight - hh - 4)) + 'px'; }
function hideTip() { if (tipEl) tipEl.style.display = 'none'; }
function updateHotbar() {
  if (!hotEls) buildHotbar(); if (!hotEls) return;
  for (let i = 0; i < CONFIG.hotSize; i++) {
    const sl = game.slots[i], id = sl ? sl.id : null, t = id && TOOLS[id], r = t && t.dur ? sl.dur / t.dur : -1;
    const sig = `${id}|${sl ? sl.n : 0}|${r.toFixed ? r.toFixed(2) : r}|${i === game.hotSel}|${sl && sl.eq ? 1 : 0}`, e = hotEls[i];
    if (e.sig === sig) continue; e.sig = sig;
    e.sl.classList.toggle('on', i === game.hotSel); e.sl.classList.toggle('eq', !!(sl && sl.eq)); e.sl.classList.toggle('empty', !id);
    if (id) { e.ic.src = ICON_URL[id] || ICON_URL.bp; e.ic.style.visibility = 'visible'; e.cnt.textContent = sl.n > 1 ? String(sl.n) : ''; }
    else { e.ic.removeAttribute('src'); e.ic.style.visibility = 'hidden'; e.cnt.textContent = ''; }
    e.dbar.style.display = r >= 0 ? '' : 'none';
    if (r >= 0) { e.db.style.width = Math.round(r * 100) + '%'; e.db.style.background = durColor(r); }
  }
  if (hotOff) {   // v6b：左手
    const o = game.off, t = o && TOOLS[o.id], r = t && t.dur ? o.dur / t.dur : -1, sig = o ? `${o.id}|${o.n}|${r.toFixed(2)}` : '';
    if (hotOff.sig !== sig) {
      hotOff.sig = sig; hotOff.sl.classList.toggle('hidden', !o);
      if (o) { hotOff.ic.src = ICON_URL[o.id] || ICON_URL.bp; hotOff.cnt.textContent = o.n > 1 ? String(o.n) : ''; }
      hotOff.dbar.style.display = r >= 0 ? '' : 'none'; if (r >= 0) { hotOff.db.style.width = Math.round(r * 100) + '%'; hotOff.db.style.background = durColor(r); }
      if (Input.mode === 'touch') setTimeout(layoutTouch, 0);
    }
  }
  const id = hotItem();
  setHud('hot-name', state.hotName > 0 ? (id ? itemName(id) : `${game.hotSel + 1}番：空き`) : '');
}
function resize() {
  const dpr = Math.min(window.devicePixelRatio || 1, 3), w = window.innerWidth, hh = window.innerHeight;
  // メニュー・HUDの大きさ：PCでは125%、小さい画面では自動で小さく（最小100%）
  // v6.1e：「大きめ」は最大187.5%（通常の1.5倍）。画面に入りきらない時は入る大きさまで（タッチボタンは変えない）
  document.documentElement.style.setProperty('--ui', clamp(Math.min(w / 880, hh / 560), 1, settings.uiBig ? 1.875 : 1.25).toFixed(3));
  canvas.width = Math.max(1, Math.round(w * dpr)); canvas.height = Math.max(1, Math.round(hh * dpr));
  zoom = Math.max(2, Math.floor(Math.min(canvas.width, canvas.height) / (TILE * 11.5)));
  setTimeout(layoutTouch, 0);
}
// v6c：縄梯子（ロープの手すりと木の段。上に杭）
function drawLadder(tx, ty, h, al) {
  const x0 = tx * 16, y0 = ty * 16, y1 = (ty + h) * 16; ctx.globalAlpha = al;
  ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(x0 + 4, y0 - 2, 9, y1 - y0 + 3);
  for (let y = y0 + 1; y < y1; y += 4) { ctx.fillStyle = '#5a3a1c'; ctx.fillRect(x0 + 3, y + 1, 10, 2); ctx.fillStyle = '#a06a35'; ctx.fillRect(x0 + 3, y, 10, 2); }
  ctx.fillStyle = '#7a5a30'; ctx.fillRect(x0 + 2, y0 - 3, 2, y1 - y0 + 3); ctx.fillRect(x0 + 12, y0 - 3, 2, y1 - y0 + 3);
  ctx.fillStyle = '#d8b878'; ctx.fillRect(x0 + 2, y0 - 3, 1, y1 - y0 + 3); ctx.fillRect(x0 + 12, y0 - 3, 1, y1 - y0 + 3);
  ctx.fillStyle = '#4a3020'; ctx.fillRect(x0 + 1, y0 - 5, 4, 3); ctx.fillRect(x0 + 11, y0 - 5, 4, 3);
  ctx.globalAlpha = 1;
}
// v8b：自動伐採機の範囲（3×3）を囲む低い金属の枠。四すみに柱。床の段に描く（上を歩ける）
function drawLumberFrame(cx, cy, a) {
  const x0 = (cx - 1) * 16 + 1, y0 = (cy - 1) * 16 + 1, w = 46, hh = 46; ctx.globalAlpha = a;
  ctx.fillStyle = 'rgba(30,34,44,0.55)'; ctx.fillRect(x0, y0, w, 2); ctx.fillRect(x0, y0 + hh - 2, w, 2); ctx.fillRect(x0, y0, 2, hh); ctx.fillRect(x0 + w - 2, y0, 2, hh);
  ctx.fillStyle = 'rgba(242,196,64,0.75)'; for (let i = 4; i < w - 4; i += 6) { ctx.fillRect(x0 + i, y0, 3, 1); ctx.fillRect(x0 + i, y0 + hh - 2, 3, 1); } for (let i = 4; i < hh - 4; i += 6) { ctx.fillRect(x0, y0 + i, 1, 3); ctx.fillRect(x0 + w - 2, y0 + i, 1, 3); }
  ctx.fillStyle = '#2a303c'; for (const [px, py] of [[x0 - 1, y0 - 2], [x0 + w - 3, y0 - 2], [x0 - 1, y0 + hh - 4], [x0 + w - 3, y0 + hh - 4]]) { ctx.fillRect(px, py, 4, 5); ctx.fillStyle = '#8a96a8'; ctx.fillRect(px + 1, py, 2, 1); ctx.fillStyle = '#2a303c'; }
  ctx.globalAlpha = 1;
}
// v8b：画面の下のアイテムバー（とヒント）の高さ（ゲーム内のドット単位）。0.5秒ごとに測り直す
let _hudRes = 0, _hudResT = 0;
function hudReserve() {
  const now = performance.now(); if (now - _hudResT < 500) return _hudRes; _hudResT = now;
  const hb = $('hotbar'), rc = canvas && canvas.getBoundingClientRect(); if (!hb || !rc || !rc.height) return _hudRes;
  const top = hb.getBoundingClientRect().top; _hudRes = Math.max(0, (rc.bottom - top + 6) * (canvas.height / rc.height) / zoom); return _hudRes;
}
// v8c：雪の日の地面。草地・森は白く、道・砂浜・岩場・崖は少しだけ。マップごとに1回作って使い回す
function snowLayer(m) {
  if (m._snow) return m._snow;
  const cv = document.createElement('canvas'); cv.width = m.W * 16; cv.height = m.H * 16; const g = cv.getContext('2d');
  for (let y = 0; y < m.H; y++) for (let x = 0; x < m.W; x++) {
    const t = m.tiles[y * m.W + x], a = t === T.GRASS || t === T.FOREST ? 0.62 : t === T.LEDGE || t === T.CLIFF ? 0.32 : t === T.SAND || t === T.PATH || t === T.ROCK ? 0.16 : 0;
    if (!a) continue;
    g.fillStyle = `rgba(244,248,255,${a})`; g.fillRect(x * 16, y * 16, 16, 16);
    g.fillStyle = `rgba(255,255,255,${Math.min(1, a + 0.25)})`; for (let k = 0; k < 4; k++) { const h = hash2(x, y, 31 + k); g.fillRect(x * 16 + Math.floor(h * 15), y * 16 + Math.floor(hash2(y, x, 57 + k) * 15), 1 + (h > 0.7 ? 1 : 0), 1); }
    if (a < 0.3) { g.fillStyle = 'rgba(120,130,150,0.10)'; g.fillRect(x * 16 + Math.floor(hash2(x, y, 91) * 12), y * 16 + Math.floor(hash2(y, x, 93) * 12), 3, 2); }
  }
  return (m._snow = cv);
}
// v8c：雪の日は、木・ヤシ・しげみの上に雪が積もる
function snowCap(o, x, y) {
  ctx.fillStyle = '#f6f9ff';
  if (o.t === 'tree') { ctx.fillRect(x + 4, y + 4, 8, 2); ctx.fillRect(x + 3, y + 6, 3, 1); ctx.fillRect(x + 9, y + 6, 4, 1); ctx.fillRect(x + 2, y + 10, 3, 1); ctx.fillRect(x + 11, y + 11, 3, 1); ctx.fillStyle = '#d8e2f0'; ctx.fillRect(x + 5, y + 6, 6, 1); }
  else if (o.t === 'palm') { ctx.fillRect(x + 3, y + 3, 4, 1); ctx.fillRect(x + 9, y + 3, 4, 1); ctx.fillRect(x + 6, y + 2, 4, 1); }
  else if (o.t === 'bush') { ctx.fillRect(x + 4, y + 6, 8, 2); ctx.fillRect(x + 3, y + 8, 2, 1); ctx.fillRect(x + 11, y + 8, 2, 1); }
  else if (o.t === 'boulder' || o.t === 'stone') { ctx.fillRect(x + 4, y + 6, 8, 2); }
}
function drawObj(o, time) {
  let spr = SPR[o.t], x, y, oy = 0;
  switch (o.t) {
    case 'tree': spr = ((o.x * 7 + o.y * 13) % 3 === 0) ? SPR.treeB : SPR.treeA; break;
    case 'bush': spr = o.n > 0 ? SPR.bushB : SPR.bush; break;
    case 'campfire': spr = Math.floor(time * 6) % 2 ? SPR.fire1 : SPR.fire0; break;
    case 'workbench': spr = game && game.up.benchUp ? SPR.bench2 : SPR.bench; break;
    case 'furnace': spr = o.q && o.q.length ? SPR.furnaceOn : SPR.furnace; break;
    case 'miner': { const sm = o.small ? 'minerS' : 'miner'; spr = minerOn(o) ? (Math.floor(time * 8) % 2 ? SPR[sm + 'On2'] : SPR[sm + 'On']) : SPR[sm]; break; }   // v7b。v8b：2×2の新しい絵
    case 'lumber': spr = lumberOn(o) ? (Math.floor(time * 8) % 2 ? SPR.lumberOn2 : SPR.lumberOn) : SPR.lumber; break;   // v8b
    case 'house': spr = o.done ? SPR.house : SPR['houseB' + Math.min(3, Math.floor(houseProg(o) * 4))]; break;   // v7c：建設中は4段階
    case 'raft': spr = game && game.raftBuilt ? SPR.raft : SPR.raftSpot; break;
    case 'diary': oy = Math.round(Math.sin(time * 3)) - 2; break;
    case 'chest': { const pr = game && state.scene === 'play' ? chestPartner(curMap(), o) : null; if (pr) { if (pr.r === o) return; spr = SPR.chestL; } break; }   // v8b：ラージチェスト
    case 'zeniH': spr = Math.floor(time * 12) % 2 ? SPR.drone1 : SPR.drone0; oy = -6 + Math.round(Math.sin(time * 2.4) * 2); ctx.fillStyle = 'rgba(0,0,0,0.2)'; ctx.fillRect(o.x * 16 + 4, o.y * 16 + 13, 8, 2); break;   // v8b：家の中のゼニ丸
    case 'brazier': spr = Math.floor(time * 6 + o.x) % 2 ? SPR.fire1 : SPR.fire0; break;
    case 'drop': {
      const ic = ICON[o.id]; if (!ic) return; const bob = Math.round(Math.sin(time * 3 + o.x * 0.7));
      ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(o.x * 16 + 4, o.y * 16 + 13, 8, 2);
      if (o.lock > 0) ctx.globalAlpha = 0.55;
      else if (!o.keep && o.exp > 0 && game && o.exp - dayNow() < 0.1 && Math.floor(time * 6) % 2) ctx.globalAlpha = 0.3;   // v6.2：消える少し前は点滅
      ctx.drawImage(ic, o.x * 16 + 2, o.y * 16 + 1 + bob, 12, 12); ctx.globalAlpha = 1;
      if (o.n > 1) { ctx.fillStyle = P.ol; ctx.fillRect(o.x * 16 + 10, o.y * 16 + 9 + bob, 6, 5); ctx.fillStyle = '#fff'; ctx.font = '5px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(o.n > 9 ? '+' : String(o.n), o.x * 16 + 13, o.y * 16 + 11.5 + bob); }
      return;
    }
  }
  if (!spr) return;
  if (o.t === 'liner' && game && game.casino && game.casino.open) spr = SPR.linerLit;
  if (o.t === 'hut' || o.t === 'wreck' || o.t === 'liner' || o.t === 'house' || (o.t === 'miner' && !o.small) || spr === SPR.chestL) x = o.x * 16; else x = o.x * 16 + Math.floor((16 - spr.width) / 2);
  y = o.y * 16 + 16 - spr.height + oy;
  if (o.t === 'raft' && game && game.raftBuilt) y = o.y * 16 + 2;
  if (o._shake > 0) x += Math.round(Math.sin(o._shake * 80));
  ctx.drawImage(spr, x, y);
  if (game && state.scene === 'play' && game.weather === 'snow' && game.map === 'island' && (o.t === 'tree' || o.t === 'palm' || o.t === 'bush' || o.t === 'boulder')) snowCap(o, x, y);   // v8c：雪が積もる
  if (o.t === 'house' && !o.done && state.scene === 'play') { const fr = houseProg(o); ctx.fillStyle = P.ol; ctx.fillRect(x + 8, y - 6, 32, 4); ctx.fillStyle = P.gold; ctx.fillRect(x + 9, y - 5, Math.round(30 * fr), 2); }   // v7c：建設の進み具合
  if (o.t === 'palm' && o.n > 0) { const cs = [[5, 10], [9, 11], [7, 12]]; for (let i = 0; i < Math.min(3, o.n); i++) ctx.drawImage(SPR.coco, x + cs[i][0], y + cs[i][1]); }
  if (state.scene === 'play' && (OBJ[o.t].it === 'station' || o.t === 'miner' || o.t === 'lumber')) {   // v7b：採掘機も、次の採掘までのバーと✓を出す。v8b：伐採機も
    if (o.t === 'miner' && !o.small) x += 8;   // v8b：2マス幅の真ん中に
    if (o.t === 'miner' && minerOn(o)) { const fr = clamp(1 - (o.tm == null ? CONFIG.miner.every : o.tm) / CONFIG.miner.every, 0, 1); ctx.fillStyle = P.ol; ctx.fillRect(x + 1, y - 4, 14, 3); ctx.fillStyle = '#7fe08a'; ctx.fillRect(x + 2, y - 3, Math.round(12 * fr), 1); }
    if (o.t === 'lumber' && lumberOn(o)) { const fr = clamp(1 - (o.tm == null ? CONFIG.lumber.every : o.tm) / CONFIG.lumber.every, 0, 1); ctx.fillStyle = P.ol; ctx.fillRect(x + 1, y - 4, 14, 3); ctx.fillStyle = '#7fe08a'; ctx.fillRect(x + 2, y - 3, Math.round(12 * fr), 1); }
    if (o.q && o.q.length) { const rec = findProc(OBJ[o.t].st, o.q[0].id), fr = clamp(1 - o.q[0].left / procTime(OBJ[o.t].st, rec), 0, 1); ctx.fillStyle = P.ol; ctx.fillRect(x + 1, y - 4, 14, 3); ctx.fillStyle = P.gold; ctx.fillRect(x + 2, y - 3, Math.round(12 * fr), 1); }
    if (o.t === 'miner' ? minerStored(o) > 0 : o.t === 'lumber' ? lumberStored(o) > 0 : (o.out && Object.keys(o.out).length)) {   // v6.2：できあがりは緑の✓（以前は黄色の「！」）。v7b：採掘機は保管がある時
      const b = Math.round(Math.sin(time * 5) * 1.5), cx = x + 3, cy = y - 14 + b;
      ctx.fillStyle = P.ol; ctx.fillRect(cx + 1, cy, 8, 10); ctx.fillRect(cx, cy + 1, 10, 8);
      ctx.fillStyle = '#3fbf4f'; ctx.fillRect(cx + 1, cy + 1, 8, 8); ctx.fillStyle = '#7fe08a'; ctx.fillRect(cx + 1, cy + 1, 8, 1);
      ctx.fillStyle = '#ffffff'; for (const [px, py] of [[2, 4], [2, 5], [3, 5], [3, 6], [4, 6], [4, 5], [5, 5], [5, 4], [6, 4], [6, 3], [7, 3], [7, 2]]) ctx.fillRect(cx + px, cy + py, 1, 1);
    }
  }
}
function objTop(o) { const spr = o.t === 'tree' ? SPR.treeA : o.t === 'raft' ? SPR.raftSpot : SPR[o.t] || SPR.pebble; return o.y * 16 + 16 - spr.height; }
function render(time) {
  const cw = canvas.width, ch = canvas.height;
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.imageSmoothingEnabled = false;
  viewW = cw / zoom; viewH = ch / zoom;
  let m, camX, camY;
  if (state.scene === 'title' && titleMap) {
    m = titleMap; const t = state.titleT;
    camX = m.W * 8 + Math.sin(t * 0.05) * m.W * 4 - viewW / 2; camY = m.H * 8 + Math.cos(t * 0.037) * m.H * 3 - viewH / 2;
  } else if (state.scene === 'play' && game) {
    m = curMap(); const mw = m.W * 16, mh = m.H * 16;
    // v6.1b：ボスの登場中は、カメラをプレイヤーとボスの中間へ寄せる（小さい画面でもボスが見えるように）
    const bb = state.boss && m.name === 'cave2' ? state.boss : null, cb = bb ? (state.camBias || 0) : 0;
    const fx = bb ? lerp(player.x, bb.x, cb) : player.x, fy = bb ? lerp(player.y - 8, bb.y - 24, cb) : player.y - 8;
    camX = mw <= viewW ? (mw - viewW) / 2 : clamp(fx - viewW / 2, 0, mw - viewW);
    camY = mh <= viewH ? (mh - viewH) / 2 : clamp(fy - viewH / 2, 0, mh - viewH);
    if (m.name === 'house') { const rs = hudReserve(), vh = viewH - rs; camY = mh <= vh ? (mh - vh) / 2 : clamp(fy - vh / 2, 0, mh - vh); }   // v8b：家の中は、下のアイテムバーにかからないよう上へ寄せる
    if (state.shake > 0 && settings.shake) { camX += rnd(-2, 2); camY += rnd(-2, 2); }
  } else { ctx.fillStyle = '#000'; ctx.fillRect(0, 0, cw, ch); return; }
  camX = Math.round(camX * zoom) / zoom; camY = Math.round(camY * zoom) / zoom;
  state.cam.x = camX; state.cam.y = camY;
  const cave = m.name === 'cave' || m.name === 'cave2';
  ctx.fillStyle = cave ? '#0d0b12' : m.name === 'house' ? '#1a120a' : '#2b5f9e'; ctx.fillRect(0, 0, cw, ch);   // v7c：家の中のまわりは暗い茶色
  ctx.setTransform(zoom, 0, 0, zoom, -camX * zoom, -camY * zoom);
  ctx.drawImage(m.terrain, 0, 0);
  if (state.scene === 'play' && game && game.weather === 'snow' && m.name === 'island') ctx.drawImage(snowLayer(m), 0, 0);   // v8c：雪の日は地面が白くなる（道・砂浜・岩場は控えめ）
  if (m.name === 'cave2' && state.boss) drawBossFloor(time);   // ボスの攻撃の予兆（床）
  // 波のきらめき
  const tx0 = Math.max(0, Math.floor(camX / 16)), ty0 = Math.max(0, Math.floor(camY / 16)), tx1 = Math.min(m.W - 1, Math.ceil((camX + viewW) / 16)), ty1 = Math.min(m.H - 1, Math.ceil((camY + viewH) / 16));
  if (!cave || m.name === 'cave') for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {   // v6.1d：洞窟の泉もきらめく
    const v = m.tiles[ty * m.W + tx]; if (!isWater(v) && v !== T.SPRING) continue;
    const h1 = hash2(tx, ty, 3), s = Math.sin(time * 1.3 + h1 * 6.28);
    if (s > 0.55) { ctx.fillStyle = `rgba(255,255,255,${((s - 0.55) * (v === T.SPRING ? 1.6 : 0.9)).toFixed(2)})`; const ox = 2 + Math.floor(h1 * 9), oy = 3 + Math.floor(hash2(ty, tx, 5) * 10); ctx.fillRect(tx * 16 + ox, ty * 16 + oy, 4, 1); ctx.fillRect(tx * 16 + ox + 1, ty * 16 + oy - 1, 2, 1); }
  }
  // 物と人を奥から順に
  const list = [], x0 = camX - 40, x1 = camX + viewW + 40, y0 = camY - 16, y1 = camY + viewH + 48;
  for (const o of m.objs) if (o.t === 'lumber' && o.x * 16 > x0 - 16 && o.x * 16 < x1 + 16 && o.y * 16 > y0 - 16 && o.y * 16 < y1 + 16) drawLumberFrame(o.x, o.y, 1);   // v8b：自動伐採機の範囲の枠（中は歩ける）
  for (const o of m.objs) if (o.t === 'ladder' && o.x * 16 > x0 && o.x * 16 < x1 && (o.y + (o.h || 1)) * 16 > y0 && o.y * 16 < y1) drawLadder(o.x, o.y, o.h || 1, 1);   // v6c：縄梯子は床の段で
  for (const o of m.objs) { if (o.t === 'ladder') continue; const px = o.x * 16, py = o.y * 16; if (px < x0 || px > x1 || py < y0 || py > y1) continue; list.push([OBJ[o.t].block || o.t === 'raft' ? py + 15 : py + 3, o]); }
  if (state.scene === 'play') { list.push([player.y, 'player']); if (state.boss && m.name === 'cave2') list.push([state.boss.y, 'boss']); for (const mb of state.mobs) if (mb.map === game.map && mb.x > x0 && mb.x < x1 && mb.y > y0 && mb.y < y1) list.push([mb.y, mb]); }
  if (state.scene === 'play' && game && m.name !== 'house' && state.zeni) list.push([state.zeni.y + 2, 'zeniF']);   // v8b：ついてくるゼニ丸（家の中では出口のそばに立っている）
  list.sort((a, b) => a[0] - b[0]);
  for (const [, it] of list) {
    if (it === 'player') drawPlayerNow(time);
    else if (it === 'boss') drawBoss(time);
    else if (it.mob) drawMob(it, time);
    else if (it === 'zeniF') drawZeniFollow(time);   // v8b
    else drawObj(it, time);
  }
  if (state.scene === 'play') drawWorldFx(time);
  if (state.scene === 'play') drawArrows(time);   // v8c：矢と、弓の射程
  if (state.boss && m.name === 'cave2') drawBossFx(time);
  // 明かり
  const inHouseV = m.name === 'house';   // v7c：家の中は夜でも暗くしない
  const hr = state.scene === 'play' ? hourOf(game.time) : 12, dark = cave ? (m.name === 'cave2' ? 0.66 : 0.93) : inHouseV ? 0 : darkness(hr);
  if (!cave && !inHouseV && state.scene === 'play') { const du = duskAmt(hr); if (du > 0) { ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = `rgba(255,110,40,${(0.12 * du).toFixed(3)})`; ctx.fillRect(0, 0, cw, ch); } }
  if (dark > 0.01) {
    const lw = Math.ceil(viewW / 2) + 2, lh = Math.ceil(viewH / 2) + 2;
    if (lightC.width !== lw || lightC.height !== lh) { lightC.width = lw; lightC.height = lh; }
    lightX.globalCompositeOperation = 'source-over'; lightX.clearRect(0, 0, lw, lh);
    lightX.fillStyle = `rgba(6,8,24,${dark})`; lightX.fillRect(0, 0, lw, lh);
    lightX.globalCompositeOperation = 'destination-out';
    const light = (wx, wy, r) => { const sx = (wx - camX) / 2, sy = (wy - camY) / 2, rr = r / 2; if (sx < -rr || sy < -rr || sx > lw + rr || sy > lh + rr) return; const gr = lightX.createRadialGradient(sx, sy, 0, sx, sy, rr); gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(0.55, 'rgba(0,0,0,0.85)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); lightX.fillStyle = gr; lightX.beginPath(); lightX.arc(sx, sy, rr, 0, Math.PI * 2); lightX.fill(); };
    const torch = game && state.scene === 'play' && torchLit();   // v6b：左手のたいまつも同じ明るさ
    light(player.x, player.y - 8, cave ? (torch ? 84 : 36) : (torch ? 78 : 34));
    const fl = Math.sin(time * 9) * 3 + Math.sin(time * 13) * 2;
    for (const o of m.objs) {
      if (o.t === 'campfire') light(o.x * 16 + 8, o.y * 16 + 8, 72 + fl);
      else if (o.t === 'furnace' && o.q && o.q.length) light(o.x * 16 + 8, o.y * 16 + 10, 40 + fl);
      else if (o.t === 'miner' && minerOn(o)) light(o.x * 16 + (o.small ? 8 : 16), o.y * 16 + 2, 26);   // v7b
      else if (o.t === 'house' && o.done) light(o.x * 16 + 24, o.y * 16 - 8, 46);   // v7c：家の窓あかり
      else if (o.t === 'box') light(o.x * 16 + 8, o.y * 16, 30);
      else if (cave && o.t === 'crystal') light(o.x * 16 + 8, o.y * 16 + 6, 26 + fl * 0.4);   // v6.1d：水晶がほのかに光る
      else if (o.t === 'liner' && game && game.casino && game.casino.open) light(o.x * 16 + 24, o.y * 16, 64);
      else if (o.t === 'diary') light(o.x * 16 + 8, o.y * 16 + 8, 20);
      else if (o.t === 'exit') light(o.x * 16 + 8, o.y * 16 + 8, 56);
      else if (o.t === 'shrine') light(o.x * 16 + 8, o.y * 16, 34);
      else if (o.t === 'brazier') light(o.x * 16 + 8, o.y * 16 + 6, 120 + fl * 2);
      else if (o.t === 'stairsDown') light(o.x * 16 + 8, o.y * 16 + 8, 26);
      else if (o.t === 'crystal') light(o.x * 16 + 8, o.y * 16 + 8, 22);
      else if (o.t === 'goldVein') light(o.x * 16 + 8, o.y * 16 + 8, 14);
    }
    if (state.boss && m.name === 'cave2') light(state.boss.x, state.boss.y - 22 - state.boss.z, 130);
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.imageSmoothingEnabled = true;
    ctx.drawImage(lightC, 0, 0, lw, lh, 0, 0, lw * 2 * zoom, lh * 2 * zoom);
    ctx.imageSmoothingEnabled = false;
    if (dark > 0.3) {
      ctx.globalCompositeOperation = 'lighter';
      for (const o of m.objs) if (o.t === 'campfire') { const sx = (o.x * 16 + 8 - camX) * zoom, sy = (o.y * 16 + 8 - camY) * zoom, r = (40 + fl) * zoom; if (sx < -r || sy < -r || sx > cw + r || sy > ch + r) continue; const gr = ctx.createRadialGradient(sx, sy, 0, sx, sy, r); gr.addColorStop(0, 'rgba(255,140,40,0.22)'); gr.addColorStop(1, 'rgba(255,140,40,0)'); ctx.fillStyle = gr; ctx.fillRect(sx - r, sy - r, r * 2, r * 2); }
      // v6.1d：洞窟の水晶の青い光
      if (cave) for (const o of m.objs) if (o.t === 'crystal') { const sx = (o.x * 16 + 8 - camX) * zoom, sy = (o.y * 16 + 6 - camY) * zoom, r = (24 + Math.sin(time * 2 + o.x) * 2) * zoom; if (sx < -r || sy < -r || sx > cw + r || sy > ch + r) continue; const gr = ctx.createRadialGradient(sx, sy, 0, sx, sy, r); gr.addColorStop(0, 'rgba(110,200,255,0.2)'); gr.addColorStop(1, 'rgba(110,200,255,0)'); ctx.fillStyle = gr; ctx.fillRect(sx - r, sy - r, r * 2, r * 2); }
      ctx.globalCompositeOperation = 'source-over';
    }
  }
  if (state.scene === 'play' && !cave && m.name !== 'house') drawWeather(time, cw, ch);   // v7c：家の中は雨や雲の表示もなし
  if (state.scene === 'play' && game.hp < 25) {
    ctx.setTransform(1, 0, 0, 1, 0, 0); const a = 0.44 + Math.sin(time * 4) * 0.11, gr = ctx.createRadialGradient(cw / 2, ch / 2, Math.min(cw, ch) * 0.2, cw / 2, ch / 2, Math.max(cw, ch) * 0.7);   // v6a：少し濃く
    gr.addColorStop(0, 'rgba(180,0,0,0)'); gr.addColorStop(0.5, `rgba(175,0,0,${(a * 0.4).toFixed(2)})`); gr.addColorStop(1, `rgba(185,0,0,${a.toFixed(2)})`); ctx.fillStyle = gr; ctx.fillRect(0, 0, cw, ch);
  }
  if (state.scene === 'play' && state.boss && m.name === 'cave2') drawBossOverlay(time, cw, ch, zoom, camX, camY);   // v8.2：ボスの演出（暗さの上）
  // 夜の敵の目（暗闇でも光る）
  if (state.scene === 'play' && dark > 0.4 && state.mobs.length) {
    ctx.setTransform(zoom, 0, 0, zoom, -camX * zoom, -camY * zoom);
    // v6.1a：光る目を、絵の目とぴったり同じ位置に描く（コウモリのふわふわ・向き・踏み込みにも付いていく）
    for (const mb of state.mobs) {
      if (mb.map !== game.map || MOBS[mb.type].kind !== 'enemy' || !MOBSPR[mb.type]) continue;
      const E = MOB_EYES[mb.type]; if (!E) continue;
      const { spr, x, y } = mobDrawPos(mb, time); ctx.fillStyle = E.c;
      for (const [ex, ey] of E.p) ctx.fillRect(x + (mb.dir < 0 ? spr.width - 1 - ex : ex), y + ey, 1, 1);
    }
  }
  // 設置モードの表示（暗闇の上）
  if (state.scene === 'play' && state.place) {
    const pl = state.place, [ptx, pty] = playerTile(), R = pl.id === 'houseKit' ? houseRange() : pl.id === 'lumber' ? CONFIG.placeRange + 2 : CONFIG.placeRange;   // v8b
    ctx.setTransform(zoom, 0, 0, zoom, -camX * zoom, -camY * zoom);
    for (let y = pty - R; y <= pty + R; y++) for (let x = ptx - R; x <= ptx + R; x++) {
      if (Math.hypot(x - ptx, y - pty) > R) continue;
      ctx.fillStyle = placeOk(x, y) ? 'rgba(160,255,160,0.13)' : 'rgba(0,0,0,0.12)'; ctx.fillRect(x * 16 + 1, y * 16 + 1, 14, 14);
    }
    const okp = placeOk(pl.tx, pl.ty), spr = SPR[PLACE_SPR[pl.id]];
    if (pl.id === 'houseKit') {   // v7c：家（3×3）と、まわり1マスの通り道（5×5）
      ctx.globalAlpha = 0.55 + Math.sin(time * 6) * 0.15; ctx.drawImage(SPR.house, (pl.tx - 1) * 16, (pl.ty + 1) * 16 + 16 - SPR.house.height); ctx.globalAlpha = 1;
      ctx.strokeStyle = okp ? '#7dff8a' : '#ff6a5a'; ctx.lineWidth = 1; ctx.strokeRect((pl.tx - 2) * 16 + 0.5, (pl.ty - 2) * 16 + 0.5, 79, 79); ctx.setLineDash([2, 2]); ctx.strokeRect((pl.tx - 1) * 16 + 0.5, (pl.ty - 1) * 16 + 0.5, 47, 47); ctx.setLineDash([]);
    } else {
    if (pl.id === 'lumber') drawLumberFrame(pl.tx, pl.ty, 0.5 + Math.sin(time * 6) * 0.2);   // v8b：伐採機の範囲
    if (spr) { ctx.globalAlpha = 0.6 + Math.sin(time * 6) * 0.15; ctx.drawImage(spr, pl.tx * 16 + (pl.id === 'miner' ? 0 : Math.floor((16 - spr.width) / 2)), pl.ty * 16 + 16 - spr.height); ctx.globalAlpha = 1; }
    if (pl.id === 'ladder') { const sp = ladderSpan(curMap(), pl.tx, pl.ty); if (sp) drawLadder(sp.x, sp.y, sp.h, 0.55 + Math.sin(time * 6) * 0.15); }   // v6c：掛かる列を予告
    ctx.strokeStyle = okp ? '#7dff8a' : '#ff6a5a'; ctx.lineWidth = 1; if (pl.id === 'miner') ctx.strokeRect(pl.tx * 16 + 0.5, (pl.ty - 1) * 16 + 0.5, 31, 31); else ctx.strokeRect(pl.tx * 16 + 0.5, pl.ty * 16 + 0.5, 15, 15);
    if (pl.id === 'lumber') { ctx.setLineDash([2, 2]); ctx.strokeRect((pl.tx - 1) * 16 + 0.5, (pl.ty - 1) * 16 + 0.5, 47, 47); ctx.setLineDash([]); }
    }
  }
  // 文字（暗闇の上に表示）
  if (state.scene === 'play' && state.floats.length) {
    ctx.setTransform(zoom, 0, 0, zoom, -camX * zoom, -camY * zoom);
    ctx.font = '8px "DotGothic16", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineWidth = 2; ctx.lineJoin = 'round';
    for (const f of state.floats) { ctx.globalAlpha = clamp(f.life * 2, 0, 1); ctx.strokeStyle = P.ol; ctx.strokeText(f.text, f.x, f.y); ctx.fillStyle = f.col; ctx.fillText(f.text, f.x, f.y); }
    ctx.globalAlpha = 1;
  }
  if (state.scene === 'play' && state.boss && m.name === 'cave2') drawBossSay(time, camX, camY);   // v6.1b：ボスのセリフ（いちばん上）
}
// 天気の表示（画面座標）
function drawWeather(time, cw, ch) {
  const w = game.weather;
  drawBolt(time);   // v8c：雷の稲妻と、打たれたあとのピリピリ（ゲーム内の座標で描く）
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  if (w === 'snow') {   // v8c：雪がちらちら降る
    ctx.fillStyle = 'rgba(200,215,240,0.10)'; ctx.fillRect(0, 0, cw, ch);
    const n = 120, s = Math.max(1, Math.round(zoom * 0.45));
    for (let i = 0; i < n; i++) {
      const sp = (0.10 + hash2(i, 3, 9) * 0.12) * ch, y = ((hash2(i, 2, 7) * (ch + 40) + time * sp) % (ch + 40)) - 20;
      const x = ((hash2(i, 1, 7) * cw + Math.sin(time * 1.3 + i) * 14 * zoom * 0.3) % cw + cw) % cw;
      ctx.fillStyle = i % 3 ? 'rgba(255,255,255,0.85)' : 'rgba(230,240,255,0.6)'; ctx.fillRect(x, y, s * (i % 4 === 0 ? 2 : 1), s * (i % 4 === 0 ? 2 : 1));
    }
  }
  if (w === 'cloud' || w === 'rain' || w === 'storm') { ctx.fillStyle = `rgba(30,40,60,${w === 'storm' ? 0.28 : w === 'rain' ? 0.16 : 0.1})`; ctx.fillRect(0, 0, cw, ch); }
  if (w === 'rain' || w === 'storm') {
    const n = w === 'storm' ? 150 : 85, len = ch * 0.025, slant = w === 'storm' ? 0.35 : 0.12;
    ctx.strokeStyle = 'rgba(190,210,240,0.45)'; ctx.lineWidth = Math.max(1, zoom * 0.35); ctx.beginPath();
    for (let i = 0; i < n; i++) {
      const sp = (0.7 + hash2(i, 3, 9) * 0.5) * ch * 1.5, y = ((hash2(i, 2, 7) * (ch + 60) + time * sp) % (ch + 60)) - 30;
      const x = ((hash2(i, 1, 7) * cw - y * slant) % cw + cw) % cw;
      ctx.moveTo(x, y); ctx.lineTo(x - len * slant, y + len);
    }
    ctx.stroke();
  }
  if (state.flash > 0) { ctx.fillStyle = `rgba(235,240,255,${Math.min(0.55, state.flash * 1.6).toFixed(2)})`; ctx.fillRect(0, 0, cw, ch); }
}
// v6b：手に持った道具・武器と、左手のたいまつを描く。攻撃・採集の時は振る
function drawHeld(time, back, lx, ly) {
  const d = [0, 1, 2, 3, 2, 3, 1, 1][dir8()], bob = player.moving ? Math.sin(player.anim * Math.PI / 2) * 0.08 : 0;   // v8d：斜めのときは近い向きの手の位置
  const one = (id, hx, hy, mirror, ang, sc) => {
    const ic = ICON[id]; if (!ic) return;
    ctx.save(); ctx.translate(Math.round(hx + lx), Math.round(hy + ly)); if (mirror) ctx.scale(-1, 1); ctx.rotate(ang);
    const z = sc || 0.62, gx = id === 'stoneAxe' || id === 'ironAxe' ? 3 : 4; ctx.drawImage(ic, -gx * z, -13 * z, 16 * z, 16 * z); ctx.restore();   // v8a：斧は持つ位置が（3,13）
  };
  // 右手（アイテムバーで選んでいる物）：上向きは体の後ろ、それ以外は前
  const sl = heldSlot(), id = sl && sl.id, t = id && TOOLS[id];
  if (t && t.cat !== 'armor' && (d === 1) === back) {
    const hp = [[5, -6, false], [-5, -7, true], [-3, -6, true], [3, -6, false]][d], rest = [0.55, -0.1, 0.15, 0.15][d];
    let a = rest + bob;
    const casting = t.cat === 'rod' && (state.fishing || state.reel > 0);   // v8f
    if (t.cat === 'torch') a = [0.1, -0.05, 0.05, 0.05][d] + bob * 0.5;
    else if (casting) a = rodAngle(rest);   // v7a：釣り竿の動き
    else if (state.swing > 0) { const k = 1 - state.swing / 0.15; a = rest - 1.0 + k * 2.4; }   // 攻撃：後ろから前へ振る
    else if (player.lunge > 0) { const k = 1 - player.lunge / 0.12; a = rest - 0.7 + k * 1.6; }   // 採集：振り下ろす
    one(casting ? 'rodCast' : id, player.x + hp[0], player.y + hp[1], hp[2], a);   // v8f：釣りの間は、うきのない竿
    if (casting) {   // v8f：竿の先の位置（ここから海のうきへ糸を張る）
      const z = 0.62, ux = (13 - 4) * z, uy = (1.5 - 13) * z, c = Math.cos(a), s = Math.sin(a); let rx = ux * c - uy * s; const ry = ux * s + uy * c; if (hp[2]) rx = -rx;
      state.rodTip = [Math.round(player.x + hp[0] + lx) + rx, Math.round(player.y + hp[1] + ly) + ry];
    }
    if (t.cat === 'torch' && !back) { const fl = Math.sin(time * 23) > 0 ? '#ffd45a' : '#ff8a3a'; ctx.fillStyle = fl; ctx.fillRect(Math.round(player.x + hp[0] + lx + (hp[2] ? -1 : 1)), Math.round(player.y + hp[1] + ly - 9), 1, 1); }
  }
  // 左手のたいまつ：右・左向きは体の後ろ、下向きは前、上向きは後ろ
  const o = game.off;
  if (o && o.id === 'torch' && (d !== 0) === back) {
    const hp = [[-5, -6, true], [5, -7, false], [3, -7, false], [-3, -7, true]][d];
    one('torch', player.x + hp[0], player.y + hp[1], hp[2], 0.05 + bob * 0.5, 0.56);
  }
}
function drawPlayerNow(time) {
  state.rodTip = null;   // v8f：竿の先（drawHeld で決まる）
  const climb = onLadder(), fr = player.moving ? [1, 0, 2, 0][Math.floor(player.anim) % 4] : 0, spr = (armorSlot() ? PLA : PL)[climb ? 1 : dir8()][fr];   // v6b：防具を着ている時の絵。v6c：縄梯子では背中を向ける
  let lx = 0, ly = 0; if (player.lunge > 0) { lx = Math.round(D8[dir8()][0]); ly = Math.round(D8[dir8()][1]); }   // v8d：8方向
  ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(Math.round(player.x) - 5, Math.round(player.y) - 1, 10, 2);
  const blinkOff = state.invuln > 0 && Math.floor(time * 20) % 2;
  if (!blinkOff && !climb) drawHeld(time, true, lx, ly);   // v6b：体の後ろに来る持ち物
  if (!blinkOff) ctx.drawImage(spr, Math.round(player.x) - 8 + lx, Math.round(player.y) - 16 + ly);
  if (!blinkOff && !climb) drawHeld(time, false, lx, ly);   // v6b：体の前に来る持ち物
  if (state.swing > 0) {
    const [vx, vy] = D8[dir8()], a0 = Math.atan2(vy, vx), k = 1 - state.swing / 0.15;   // v8d：8方向
    ctx.strokeStyle = `rgba(255,255,255,${(0.9 - k * 0.6).toFixed(2)})`; ctx.lineWidth = 1.2; ctx.beginPath();
    ctx.arc(player.x + vx * 4, player.y - 7 + vy * 4, 10, a0 - 1.1 + k * 0.6, a0 + 0.4 + k * 0.6); ctx.stroke();
  }
  // v6.1b：スタン中の星
  if (state.pstun > 0) for (let i = 0; i < 3; i++) { const an = time * 6 + i * 2.09, sx = Math.round(player.x + Math.cos(an) * 7), sy = Math.round(player.y - 22 + Math.sin(an) * 2); ctx.fillStyle = '#ffe060'; ctx.fillRect(sx - 1, sy, 3, 1); ctx.fillRect(sx, sy - 1, 1, 3); }
  const f = state.fishing;
  if (f) {
    const tip = state.rodTip, hx = tip ? tip[0] : player.x + DIRV[player.dir][0] * 6, hy = tip ? tip[1] : player.y - 9, k = Math.min(1, (f.age == null ? 9 : f.age) / FISH_CAST);   // v8f：糸は竿の先から
    let bx = f.bx, by = f.by + Math.round(Math.sin(time * 4) * 0.6);
    if (k < 1) { bx = hx + (f.bx - hx) * k; by = hy + (f.by - hy) * k - Math.sin(k * Math.PI) * 18; }   // v7a：うきが弧を描いて飛ぶ
    else if (f.phase === 'bite') by = f.by + 2 + Math.round(Math.sin(time * 30) * 1.5);   // v7a：当たりでうきが沈む
    ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 0.5; ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(bx, by); ctx.stroke();
    if (k >= 1) { const rp = (time * (f.phase === 'bite' ? 1.6 : 0.7)) % 1; ctx.strokeStyle = `rgba(223,243,250,${(0.55 * (1 - rp)).toFixed(2)})`; ctx.lineWidth = 0.6; ctx.beginPath(); ctx.ellipse(f.bx, f.by + 1, 2 + rp * 6, 1 + rp * 2.5, 0, 0, Math.PI * 2); ctx.stroke(); }   // v7a：波紋
    ctx.drawImage(SPR.bob, Math.round(bx) - 2, Math.round(by) - 2);
    if (f.phase === 'bite') { ctx.fillStyle = P.ol; ctx.fillRect(Math.round(player.x) - 2, Math.round(player.y) - 30, 5, 10); ctx.fillStyle = '#ff5a4a'; ctx.fillRect(Math.round(player.x) - 1, Math.round(player.y) - 29, 3, 5); ctx.fillRect(Math.round(player.x) - 1, Math.round(player.y) - 23, 3, 2); }
  }
  const ff = state.fishFx;   // v7a：釣れた魚が弧を描いて手元へ飛んでくる
  if (ff && ICON[ff.id]) { const k = Math.min(1, ff.t / ff.T), x = ff.x0 + (player.x - ff.x0) * k, y = ff.y0 + (player.y - 14 - ff.y0) * k - Math.sin(k * Math.PI) * 22; ctx.drawImage(ICON[ff.id], Math.round(x) - 6, Math.round(y) - 6, 12, 12); }
}
function drawWorldFx(time) {
  // 対象マーカー
  const tg = state.target;
  if (tg && !state.fishing && !UI.isOpen() && !Dialog.active) {
    let cx, top;
    if (tg.kind === 'mob') { cx = Math.round(tg.m.x); top = Math.round(tg.m.y) - (MOBS[tg.m.type].fly ? 22 : 14); }
    else if (tg.kind === 'boss') { if (!state.boss) return; cx = Math.round(state.boss.x); top = Math.round(state.boss.y - state.boss.z) - BOSS.size - 2; }
    else if (tg.kind === 'obj') { const o = tg.o, fp = OBJ[o.t].fp; cx = o.x * 16 + 8 + (o.t === 'hut' || (o.t === 'miner' && !o.small) ? 8 : o.t === 'wreck' || o.t === 'liner' ? 16 : 0); top = objTop(o) + (o.t === 'diary' ? -2 : 0); if (fp && o.t === 'cave') top = o.y * 16 - 8; }
    else if (tg.kind === 'spring' || tg.kind === 'water') { const [vx, vy] = DIRV[player.dir]; const tx = Math.floor((player.x + vx * 11) / 16), ty = Math.floor((player.y - 4 + vy * 11) / 16); cx = tx * 16 + 8; top = ty * 16 + 4; if (tg.kind === 'water' && !game.tools.rod) cx = null; }
    if (cx != null) { const b = Math.round(Math.sin(time * 6) * 1.5), y = top - 7 + b; ctx.fillStyle = P.ol; ctx.fillRect(cx - 4, y - 1, 9, 2); ctx.fillRect(cx - 3, y + 1, 7, 1); ctx.fillRect(cx - 2, y + 2, 5, 1); ctx.fillRect(cx - 1, y + 3, 3, 1); ctx.fillStyle = '#ffffff'; ctx.fillRect(cx - 3, y, 7, 1); ctx.fillRect(cx - 2, y + 1, 5, 1); ctx.fillRect(cx - 1, y + 2, 3, 1); }
  }
  for (const r of state.rocks) {
    const k = clamp(1 - r.t / 1.2, 0, 1); ctx.fillStyle = `rgba(0,0,0,${(0.2 + k * 0.35).toFixed(2)})`;
    const w = Math.round(4 + k * 6); ctx.fillRect(Math.round(r.x - w / 2), Math.round(r.y) - 1, w, 3);
    ctx.drawImage(SPR.rock, Math.round(r.x) - 4, Math.round(r.y - r.t * 80) - 6);
  }
  for (const p of state.particles) { ctx.fillStyle = p.col; ctx.fillRect(Math.round(p.x), Math.round(p.y), 1, 1); }
}

/* ---------- 21. メインループ ---------- */
let lastT = 0;
function frame(ts) {
  const now = ts / 1000, dt = Math.min(0.05, Math.max(0, now - (lastT || now))); lastT = now;
  try {
    state.time += dt;
    Input.poll();
    if (state.scene === 'title') state.titleT += dt;
    if (state.cine) { if (['A', 'B', 'START'].some(k => Input.press(k))) state.cine.skip(); }   // v8e：オープニング中
    else if (state.endSkip && state.scene === 'ending' && ['A', 'START'].some(k => Input.press(k))) state.endSkip();   // v8e：エンディングの字幕を飛ばす
    else if (state.endSkip && UI.top() && UI.top().endReplay && Input.press('A')) state.endSkip();   // v8f：タイトルから見ているエンディングも、Aで飛ばせる
    else if (Dialog.active) Dialog.update(dt);
    else if (state.clockIntro) { placeClockIntro(); if (['A', 'B', 'X', 'Y', 'START', 'ATK', 'INV', 'CRAFT', 'MAP'].some(k => Input.press(k))) closeClockIntro(); }   // v6.2：時計の説明（押すまで時間は止まる）
    else if (UI.isOpen()) { UI.update(dt); if (state.scene === 'play' && game && !state.fading && !state.place && UI.isOpen() && UI.isLive()) gameUpdate(dt, true); }
    else if (state.scene === 'play' && !state.fading) { if (state.place) updatePlace(); else gameUpdate(dt); }
    if (state.scene === 'play' && game) { processTalks(); updateFx(dt); updateHud(); updateTut(dt); }
    else if (!state.tutHidden) { const te = $('tut'); if (te) te.classList.add('hidden'); }
    render(now);
    if (state.scene === 'play' && game) drawTutGuide();   // v5：チュートリアルの案内
  } catch (e) { console.error(e); }
  Input.endFrame();
  requestAnimationFrame(frame);
}
function init() {
  canvas = $('game'); ctx = canvas.getContext('2d'); lightC = mkCanvas(8, 8); lightX = lightC.getContext('2d');
  UI.root = $('modal-root');
  loadSettings();
  buildSprites(); buildIcons(); buildPortraits(); buildMobSprites();
  loadBossArt();   // v6.1b：ボスの画像は起動時に読み込んでおく（地下2階に入った時に間に合うように）
  setupInput(); applySettings(); migrateLegacySave(); buildHotbar(); BGM.init();
  if (window.matchMedia && matchMedia('(pointer: coarse)').matches) setInputMode('touch');
  resize(); window.addEventListener('resize', resize); window.addEventListener('orientationchange', () => setTimeout(resize, 250));
  showTitle();
  try { playOpening(); } catch (e) { console.error(e); state.cine = null; }   // v8e：サイトを開くたびに1回、オープニングムービー
  requestAnimationFrame(frame);
  window.__mujintou = { get game() { return game; }, craft, RECIPES, repaidRatio, openStatus, openLog, openChest, expireDrops, addHours, hourOf, mobInFront, updateWeather, interact, richParse, BGM, Dialog, condDetails, openTitleDebug, startZero, dayNow, syncInv, addItem, /* v6.2：テスト用 */ get boss() { return state.boss; }, examineEmptyShrine, goCave2, leaveCave2, attackBoss, bossRetry, depart, ensureLiner, BOSS, BOSS_ART, get slot() { return curSlot; }, maps, state, player, newDay, endGame, saveGame, loadGame, isBlocked, objAt, dropFromSlot, spawnDrop, startPlace, confirmPlace, placeOk, rollFish, get slotRunDbg() { return slotRun; }, reelCol, stagesOf_: stagesOf, consume_: consume, stagesOf, consume, openPause, slotEval, slotFeasible, gatherRoomOk, moveSlot, addStackTool, layoutTouch, BGM, Dialog, DEMO, backToTitle, updateMinimap, startDemo, openHowTo, exportBackup, TUT, spawnMob, attackMob, openHut, storeMove, openLiner, openCasino, slotRole, slotDecide, slotLever, stopReel, finishSlot, zeniGamble, __setAssist: v => { settings.slotAssist = v; }, __flag: () => slotRun ? slotRun.flag : null, __line: () => game.casino.reel.map((p, i) => SLOT.reels[i][p]), addItem, takeItem, syncInv, roomFor, autoTool, useSelected, sellToolSlot, toolPrice, openChest, pickupPlaced, migrateToSlots, openMainMenu, openDebugLayer, enterCave, revealCave, mapSecretTap, conditions, hurtPlayer, settings: () => settings, unstickPlayer, openStation, enqueue, collectOutput, toOffhand, fromOffhand, swapOffhand, toggleEquip, armorSlot, startZero, zeroSafe, sellCheck, offTap, aimDir, genIsland, ladderSpan, onLadder, setupMaps, placeOk, confirmPlace, rollAtk, atkRange, autoWeapon, atkWillUse, heldAtk, mobInFront, bossInFront, hotSelect, MOB_EYES, mobDrawPos, itemDetail, stunPlayer, drawBossSay, bossCanSpawn, renderDebug, fade, BOSS_ART_: () => BOSS_ART, poisonPlayer, updatePoison, MOBSPR, MOBS, killMob, genCave, showTutOk, applySettings, renderTerrain, /* v7a：テスト用 */ tryBee, daily, goldRabbitRoll, trySpawnMobs, gatherDone, tutProgText, rodAngle, dropCliffBush, objectiveText, startFishing, ITEMS, CONFIG, PROCESS, SHOP, TALK, OBJ, /* v7b：テスト用 */ updateMiners, openMiner, minerFuel, minerCollect, minerOn, minerStored, minerTotal, enqueue, findProc, logDebt, debtChartEl, addV7Veins, get stations() { return stations; }, /* v7c：テスト用 */ houseObj, houseSpotOk, buildHouse, absHours, houseProg, enterHouse, leaveHouse, genHouse, startPlace, cancelPlace, /* v8a：テスト用 */ pickMapSeed, islandOk, setMapSeed: s => { MAP_SEED = s; }, get mapSeed() { return MAP_SEED; }, respawn, openShop, openRaft, openBed, openSettingsLayer, openSlots, openEndings, openNewGame, askTutorial, /* v8b：テスト用 */ updateLumbers, openLumber, lumberStored, chestPartner, houseSpotWhy, fixHouseObjs, callZeni, furnaceFuelIn, widenMiners, rebuildOcc, get UIs() { return UI; }, /* v8c：テスト用 */ shootArrow, bowTarget, raceStart, finishRace, mobWrongTime, surfTonight, trySpawnMobs, spawnMob, killMob, arrowHit, MOBS, isNight, /* v8d：テスト用 */ PL, PLA, dir8, setFace8, /* v8e：テスト用 */ drawOpening, drawEndPhase, END_SCENES, OPENING_T, endGame, zeniTr, playOpening, ENDINGS, ENDING_ORDER, genCaveRandom, pickMapSeed, seedMix, seedText, bearAI, /* v8.1：テスト用 */ BOSS_G, debugGaming, drawBossOverlay, bossDefeated, bossRevive, bossPick, startZero, clearExitZone, rainbowArt, gamingDefeated, bossNameOf, updateBossBar, enterCave };
}
if (typeof document !== 'undefined') { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init(); }
else if (typeof module !== 'undefined') module.exports = { genIsland, genCave, T, WALK, OBJ, isLandT, isWater };
})();
